import {defineConfig} from 'vite';
import fs from 'node:fs';
const base=process.env.VITE_BASE_PATH||'/';
export default defineConfig({base,server:{host:'0.0.0.0',allowedHosts:true},preview:{host:'0.0.0.0',allowedHosts:true},plugins:[{name:'precache-all-local-assets',closeBundle(){const extras=fs.readdirSync('dist/assets').map(n=>'assets/'+n);const path='dist/sw.js';fs.writeFileSync(path,fs.readFileSync(path,'utf8').replace('const EXTRA_URLS = [];','const EXTRA_URLS = '+JSON.stringify(extras)+';'));}}]});
