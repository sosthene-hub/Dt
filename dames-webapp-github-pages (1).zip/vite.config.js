import {defineConfig} from 'vite';
import fs from 'node:fs';
import crypto from 'node:crypto';

const base = process.env.VITE_BASE_PATH || '';

// Le service worker doit changer de nom de cache à chaque nouveau build,
// sinon un ancien index.html reste servi et pointe vers des fichiers disparus.
function buildId() {
  const files = fs.readdirSync('dist/assets').sort();
  const hash = crypto.createHash('sha1');
  for (const file of files) hash.update(file).update(fs.readFileSync(`dist/assets/${file}`));
  hash.update(fs.readFileSync('dist/index.html'));
  return hash.digest('hex').slice(0, 12);
}

export default defineConfig({
  base,
  server: { host: '0.0.0.0', allowedHosts: true },
  preview: { host: '0.0.0.0', allowedHosts: true },
  plugins: [{
    name: 'precache-all-local-assets',
    closeBundle() {
      const extras = fs.readdirSync('dist/assets').map(name => `assets/${name}`);
      const path = 'dist/sw.js';
      let source = fs.readFileSync(path, 'utf8');
      source = source.replace('const EXTRA_URLS = [];', `const EXTRA_URLS = ${JSON.stringify(extras)};`);
      source = source.replace(
        /const CACHE_NAME = '([^']+)';/,
        (_match, name) => `const CACHE_NAME = '${name.replace(/-[a-z0-9]{8,}$/, '')}-${buildId()}';`,
      );
      fs.writeFileSync(path, source);
    },
  }],
});
