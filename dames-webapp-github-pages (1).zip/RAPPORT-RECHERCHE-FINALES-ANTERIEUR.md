# Rapport de tests — recherche avancée, tables et nulles

Livraison du **18 octobre 2026**, en complément du générateur sur racine.

## Tests exécutés et réussis

### Régressions

`VITE_BASE_PATH=/Dt/ npm test` : build de production, règles, positions, PDN, moteur Scan, cache, générateur et nouveaux tests finales. Journal complet : `tests-execution.log`.

Générateur conservé : 300 essais, 137 preuves rejouées conformes, dont 37 avec des coups et 100 cas témoins à la position initiale. Test navigateur : 429 parties essayées, 102 preuves conformes (doublons compris), 100 candidats uniques analysés à profondeur 3 et 10 témoins. La tolérance volontairement large de 10 sert à tester le circuit, pas à certifier l’équilibre stratégique.

### Tables de finales réelles

- **41 fichiers Scan**, 2 682 273 octets avant encodage, couvrant tous les matériels de **2 à 4 pièces au total**. CRC ZIP vérifié à l’extraction ; manifeste SHA-256 fourni.
- **18 890 contrôles de cohérence WDL** : toutes les 17 690 positions légales à une pièce de chaque camp, pour les quatre associations pion/dame et les deux traits ; 1 200 contrôles supplémentaires sur 600 damiers de trois/quatre pièces, aux deux traits.
- Chaque contrôle vérifie l’équation minimax : au moins un successeur perdant pour un gain, tous gagnants pour une perte, sinon nulle, avec captures et promotions calculées par les règles locales. Cela vérifie la cohérence du port d’indexation ; ce n’est pas une preuve indépendante exhaustive de toute la base quatre pièces.
- Comparaison avec **Scan réel, bb-size=4** : 60 positions (30 de trois pièces, 30 de quatre pièces) en analyse, profondeur 2. Les 60 coups moteurs préservent le résultat de la table directe.
- Mode jeu : 55 positions avec plusieurs coups optimaux testées également, sans blocage. Les cinq positions à un seul coup optimal utilisent le contournement local documenté du moteur pour les coups forcés. Le score numérique de recherche n’est pas comparé au WDL, car Scan peut afficher une évaluation non nulle sur une finale nulle tout en filtrant correctement les coups.

### Nulles FMJD 2024

Tests : répétition triple avec même trait ; distinction des traits ; limite 25 coups de chaque camp ; remise à zéro lors d’un mouvement de pion ; finales à 16/5 ; cas de la dame seule occupant seule la grande diagonale ; maintien d’une échéance après prise ; priorité de victoire terminale sur une limite de nulle.

Deux suites de coups réellement légaux, sans répétition ni prise prématurée, atteignent les échéances de **50 demi-coups (25 par camp)** et **32 demi-coups (16 par camp)**. Test navigateur : 10 demi-coups légaux jusqu’à la nulle cinq coups, puis annulation et restauration du compteur.

### Recherche et stockage

Tests unitaires : validation d’import, absence d’écriture partielle après erreur, dédoublonnage, suppression, filtres texte, trait, matériel/dames, cases obligatoirement vides.

**Chromium réel, réseau désactivé, HTML autonome en file://, fenêtre 412 × 915** :
- sauvegarde depuis l’éditeur et apparition dans la recherche ;
- filtres texte, trait et vide imposé ;
- import de tirage JSON, export bibliothèque, conservation après rechargement ;
- ouverture d’un résultat dans l’analyse ;
- consultation d’une table nulle et d’une position gagnante avec prise ;
- nulle cinq coups et annulation ;
- aucune erreur JavaScript ni débordement horizontal.

### Site publié / hors ligne réel

Build servi sous `/Dt/` dans Chromium. Installation et activation réelles du service worker, contrôle de la présence du worker du générateur dans le cache, passage du contexte navigateur hors ligne, rechargement : **interface, Scan et nouveau tirage fonctionnent**.

Le démarrage de Scan attend la préparation du cache, avec repli après délai, pour éviter deux téléchargements simultanés des données à la première visite. Les ressources locales Vite sont toutes précachées. Le test est réel dans Chromium, en plus du test de cache simulé existant.

## Fichiers de résultats

`finales-test-results.json`, `bitbases-native-results.json`, `bitbases-think-results.json`, `browser-finales-results.json`, `browser-offline-results.json`, `browser-test-results.json`, `generator-test-results.json`.

## Limites à connaître

- **Tables 5 et 6 pièces non incluses.** Au-delà de quatre pièces, l’interface annonce explicitement l’absence de table ; Scan continue avec son analyse classique.
- Les bitbases fournissent un résultat théorique, pas une distance au gain ni un résultat certifié en tenant compte d’un historique inconnu. Les compteurs réglementaires sont gérés séparément.
- Une position chargée dans l’analyse commence à zéro pour les compteurs et répétitions : son passé ne peut pas être reconstitué du seul damier.
- Référence des règles : FMJD Annexes 2024, annexe 1, articles 6.1–6.4. Les dispositions spécifiques de compétitions avec cadence fixe et réclamation arbitrale ne sont pas simulées dans ce jeu sans horloge.
- Android physique non testé. Taille mobile dans Chromium et réseau réellement coupé testés ; cela ne remplace pas un appareil Android réel.
- Le moteur reste Scan JavaScript/asm.js, pas WASM. Profondeur 20 du générateur non certifiée en temps/mémoire.
- Pas de publication dans votre compte GitHub : remplacer l’archive du même nom déclenchera votre workflow existant.
