# Rapport — analyse des menaces, renommage PIONICIDE et PDN moteur contre moteur

**Série 2 · 21 octobre 2026.** Les deux demandes du brief `ANALYSE DES MENACES + RENOMMAGE PIONICIDE` et la remarque ajoutée sur le bouton PDN du match moteur contre moteur sont traitées. Toutes les affirmations ci-dessous viennent de tests exécutés, pas d'une liste de tests proposés.

---

## 1. Bouton PDN entre les parties moteur contre moteur

C'était le point qui manquait : le bouton `⤓ PDN` restait désactivé tant que la série n'était pas finie, et il écrasait la mémoire des parties au démarrage de la série suivante.

**Ce qui change**

- **`⤓ PDN de la partie en cours`** : exporte immédiatement la partie en cours, sans attendre la fin ni arrêter le match. Résultat provisoire `*`, en-tête `[Termination "partie en cours"]`.
- **`⤓ PDN`** : exporte **toutes** les parties de la session dans un seul fichier, séparées par leurs en-têtes (parties terminées, parties arrêtées, partie en cours).
- **Panneau « Parties et PDN »** : une ligne par partie avec résultat, raison de la fin, nombre de demi-coups et profondeurs de chaque camp, puis deux boutons — `⤓ PDN` (cette partie seule) et **`Étudier`** (ouvre la partie dans le damier d'analyse, coup par coup, sans quitter la session).
- **`Afficher / copier le PDN`** : affiche le texte complet dans une zone sélectionnable et propose « Copier ». Secours pour les navigateurs Android ou les aperçus intégrés qui bloquent les téléchargements.
- Une partie **arrêtée** avec `Arrêter` rejoint l'archive : elle n'est plus perdue, elle reste exportable et étudiable.
- Une série suivante **n'efface plus** les parties précédentes ; la numérotation des parties continue dans la session.
- En-têtes complets et relisibles : `Event` = « PIONICIDE contre PIONICIDE », `White` / `Black` = « PIONICIDE A · profondeur N · x s/coup », `Round`, `Result`, `Termination`, et `FEN` si la position de départ n'est pas la position initiale.

**Vérifié** (`scripts/browser-svs-pdn.mjs`, production `/Dt/`) : PDN de la partie en cours téléchargé au 30e demi-coup, **relu par le parseur de l'application, 100 % de coups légaux** ; archive avec la partie en cours puis avec la partie arrêtée ; passage direct à l'étude (46 demi-coups affichés) ; partie terminée (nulle FMJD, 136 demi-coups) ; fichier de 2 parties relu intégralement ; affichage du texte ; mobile 412 × 915 sans débordement ; 0 erreur JavaScript.

---

## 2. Analyse des menaces de la partie

Nouveau panneau **« Menaces de la partie »** dans le damier d'analyse. Calculs sur des copies de positions : la partie enregistrée n'est jamais modifiée.

### Définition appliquée (celle du brief)

- **Menace créée** : position **après** le coup, le camp qui vient de jouer **rejoue** (l'adversaire passe). Sa ligne principale est la menace ; le gain est l'écart entre « je rejoue » et « l'adversaire rejoue » (évaluations signées du point de vue du camp au trait).
- **Menace évitée** : position **avant** le coup, on **rend le trait à l'adversaire**. Sa ligne principale est la menace adverse. Une seconde analyse, **après le coup avec l'adversaire au trait**, vérifie la parade : si la valeur pour le camp qui a joué n'a pas remonté à moins du seuil, l'application écrit « Le coup joué ne pare pas cette menace ».
- **Garde-fou du brief** : si la position inversée impose une prise obligatoire, la mesure serait artificielle → « Menace non calculable : prise obligatoire en jeu. » (compté à part dans le récapitulatif).
- Seuil réglable, **0,5 pion par défaut** ; en dessous : « Aucune menace réelle ».
- Toutes les évaluations sont faites avec le moteur dans son Web Worker ; l'interface reste utilisable (aucun calcul sur le fil de l'affichage).

### Réglages

| Réglage | Valeurs |
|---|---|
| Profondeur | 6, 8, 9, 10 (défaut), 12, 14, 16, 20 |
| Portée | toute la partie · coups des Blancs · coups des Noirs · plage de coups (n° de début / de fin) |
| Seuil | 0,1 à 9 pions (0,5 par défaut) |
| Export | « Inclure les menaces dans le PDN et le PDF » (décoché par défaut) |
| Passage | « Un seul passage avec l'analyse annotée » (coché par défaut) |

### Performance et mémoire des résultats

- **Un seul passage** : quand l'analyse annotée et l'analyse des menaces sont lancées ensemble, les évaluations normales (la position au trait) sont faites **une seule fois** et partagées par un cache commun (clé = position + profondeur) ; il n'y a qu'une barre de progression et un seul texte de progression. Mesure sur la partie Verpoest–Berte 1980 (131 positions, profondeur 9) : **3,4 s** pour l'annotation **et** les menaces, 44 menaces créées et 34 évitées retenues, 60 commentaires d'export.
- **Pas de recalcul à la réouverture** : les résultats sont mémorisés pour la session (signature de la partie = position de départ + liste des coups). Revenir sur la partie affiche « Résultats mémorisés · … · aucun recalcul » et réactive les exports instantanément (mesuré : 1,1 s pour réafficher une partie de 131 coups, annotation et menaces comprises, sans relancer le moteur). Un second passage complet sur les mêmes positions ne déclenche **aucune** nouvelle évaluation.
- Un recalcul de portée (par exemple « coups des Blancs » après un passage complet) **fusionne** ses résultats avec les précédents au lieu de les écraser.
- Arrêt possible : bouton `Arrêter` ; une interruption ne laisse aucun export partiel.

### Affichage

- **Repères** dans la liste des coups : `▲` (menace créée, vert) et `▼` (menace évitée, orange), avec une infobulle qui reprend le texte de la menace.
- **Flèches numérotées 1, 2, 3** sur le damier : **vert** = menace créée, **orange** = menace évitée, **rouge** = rafle ou combinaison, avec le nombre de pions concerné dans le texte. La flèche du coup joué garde sa couleur propre (jaune) : les deux lectures ne se confondent pas. Les flèches suivent le retournement du damier.
- **Texte court** sous le damier, par exemple : « Menace évitée : les Noirs menaçaient 18-23 puis 35x24, rafle de 1 pion. Le coup joué l'empêche. » ; « Menace créée : les Blancs menacent 31-26 … gain de 0,8 pion si l'adversaire ne réagit pas ». Les écarts supérieurs à 90 (position gagnée au sens du moteur) sont rendus par « gain décisif » plutôt que par « 95 pions ».
- **Récapitulatif** en haut du panneau : menaces créées et évitées **par camp**, nombre de coups non calculables (prise obligatoire), nombre de coups qui ne parent pas la menace, et **les trois coups les plus importants** (cliquables : ils placent le damier sur le coup et affichent ses flèches).
- **« Revenir à la partie »** efface les flèches.
- **Deux boutons sur un coup isolé** : « Menace créée du coup affiché » et « Menace évitée du coup affiché » relancent ce seul calcul à la profondeur choisie (utile pour vérifier une menace à profondeur plus forte sans refaire la partie).

### Export

- **PDN** : quand l'option est cochée, chaque coup concerné reçoit un commentaire `{ Menace créée : … }` ou `{ Menace évitée : … }`, et les en-têtes `[ThreatAnalysis "PIONICIDE"]`, `[ThreatDepth "…"]`, `[ThreatThreshold "…"]` sont ajoutés. Le fichier reste relisible : vérifié **131/131 demi-coups légaux** au réimport.
- **Feuille imprimable / PDF** : section « Menaces de la partie » ajoutée après la liste des coups, un bloc par coup concerné (coup, camp, texte), plus la mention « Menaces analysées à la profondeur N ». Aucun graphique, aucune courbe.

---

## 3. Renommage en PIONICIDE

- Nom visible partout : en-tête et tiroir de navigation (`P`, « PIONICIDE », sous-titre « DAMES · ENTRAÎNEMENT 10×10 »), `<title>` et description de la page, titres d'écran, messages, indicateur de calcul, niveaux de difficulté, tableau de bord du moteur, pied de page, combinaisons, éditeur, import.
- Écran moteur contre moteur : titre « PIONICIDE contre PIONICIDE », joueurs « PIONICIDE A » / « PIONICIDE B ».
- Analyse : « Partie annotée par PIONICIDE », étiquette PDN `[Annotator "PIONICIDE · profondeur N"]`, pied de la feuille « Partie analysée par PIONICIDE », en-tête `Event` des parties moteur contre moteur.
- Fichiers téléchargés : `pionicide-contre-pionicide-N-parties.pdn`, `pionicide-partie-en-cours.pdn`, `pionicide-partie.pdn`.
- **Aucune mention de « Scan » ne subsiste dans l'interface** : vérifié par test (`document.body.innerText` sur les écrans visités, et contenu du PDN exporté).
- Le moteur lui-même n'est **pas** modifié : `src/engine.js`, `public/scan-wasm*.js`, `public/scan-wasm.worker.js`, `public/scan_normal.data`, `public/scan-book.bin`, les tables de finales et les sources `engine-src/` sont inchangés à l'octet. Le moteur garde son nom technique interne (Scan 3.1b, GPL-3.0) dans les fichiers et les notices de licence ; seule l'interface porte PIONICIDE, comme demandé (« Ne rien changer au fonctionnement du moteur »).

---

## 4. Fichiers touchés

| Fichier | Nature |
|---|---|
| `src/analysis/threats.js` | **nouveau** — analyse des menaces, cache d'évaluations, récapitulatif, textes, annotations d'export |
| `src/pages/threat-panel.js` | **nouveau** — panneau, réglages, repères, flèches, recalcul isolé |
| `src/pages/analysis.js` | intégration : passage unique, mémoire des résultats, repères, export, nettoyage |
| `src/analysis/export.js` | menaces dans le PDN annoté et la feuille imprimable ; signature PIONICIDE |
| `src/analysis/annotate.js` | `pvToMoves` exporté (réutilisé par les menaces) |
| `src/board-view.js` | flèches d'analyse numérotées et colorées |
| `src/pages/scan-vs-scan.js` | boutons PDN, archive des parties, en-têtes complets, « Étudier », texte copiable |
| `src/main.js`, `index.html`, `src/store.js`, `src/engine.js`, `src/bitbases.js`, `src/pages/*`, `src/combinations/*` | renommage PIONICIDE |
| `src/style.css` | styles du panneau, des repères, des flèches, de l'archive, de la feuille |
| `public/sw.js` | cache `…-pionicide-v14` (nouvelle version servie aux visiteurs déjà venus) |
| `scripts/test-threats.mjs` | **nouveau** — tests moteur réels des menaces |
| `scripts/browser-threats.mjs` | **nouveau** — parcours navigateur complet |
| `scripts/browser-svs-pdn.mjs` | **nouveau** — PDN du match moteur contre moteur |
| `scripts/test-offline.mjs`, `browser-annotate*.mjs`, `browser-scan-disponible.mjs`, chemins `file://` des scripts autonomes | mis à jour (nom PIONICIDE, chemins portables) |
| `package.json` | scripts `test:threats`, `test:browser-threats`, `test:browser-svs-pdn` ; `test:threats` ajouté à `npm test` |

---

## 5. Résultats des tests (exécutés)

### Moteur et règles — `npm test`, code de sortie **0**

`npm test` = build de production + règles + position + PDN + export + **menaces** + moteur + WASM (portable et SIMD) + hors ligne + finales + validateur. Tout passe.

- `node scripts/test-threats.mjs` : **unités** (textes, portée, seuils) ; annotation réelle de 19 positions ; **analyse des menaces réelle** sur 18 demi-coups de la partie Verpoest–Berte 1980 à la profondeur 9 : **6 menaces créées, 3 menaces évitées, 3 coups à prise obligatoire** ; **toutes les lignes de menaces rejouées coup par coup sur les règles FMJD** ; **cache réutilisé** (47 évaluations réutilisées pour 19 nouvelles) ; **second passage : 0 nouvelle évaluation, résultats identiques** ; portée à un seul camp ; seuil 5 pions → 0 menace ; **recalcul isolé identique au passage complet** ; 9 commentaires d'export ; **interruption sans export partiel**. Trace : `perf/threats-tests.json`.
- `Scan WASM : 120 cas WDL` × 2 (portable et SIMD) : le moteur est intact.

### Navigateur — production `/Dt/`

| Script | Résultat |
|---|---|
| `browser-threats.mjs` | **16 étapes, 0 erreur** — marque renommée ; aucune mention de « Scan » ; passage unique 131 coups annotés + 131 examinés en **3,4 s** ; récapitulatif (Blancs 17 / Noirs 27 créées, Blancs 21 / Noirs 13 évitées) ; **78 repères** ; flèches 1-2-3 vertes avec texte ; **recalcul isolé** ; flèches effacées ; **PDN exporté** (60 commentaires de menace) et **réimporté 131/131 légaux** ; **résultats mémorisés** (1,1 s, aucun recalcul) ; **feuille imprimable** (61 blocs de menace, mention PIONICIDE) ; portée « Blancs » (66 coups) ; portée par plage (6 demi-coups) ; mobile 412 × 915 sans débordement |
| `browser-svs-pdn.mjs` | **10 étapes, 0 erreur** — PDN en cours de partie légal, archive, arrêt, étude, partie terminée, PDN de toutes les parties relu, affichage/copie, mobile |
| `browser-annotate.mjs` | **réussi** — annotation réelle, PDN, feuille, PDF 3 pages, réimport |
| `browser-scan-disponible.mjs` | **réussi** — un seul moteur partagé : analyse → match → analyse → combinaisons vérifiées (« PIONICIDE d12 ») → partie |
| `browser-scan-vs-scan.mjs` | **réussi** — parties complètes et série avec alternance, en-têtes PIONICIDE |
| `browser-study.mjs` | **réussi** — HTML autonome hors ligne, PDN 131/131, deux lignes, rafles, retournement |
| `browser-editor-game.mjs`, `browser-finales.mjs`, `browser-check.mjs`, `browser-combinaisons.mjs`, `browser-combinaisons-offline.mjs`, `browser-annotate-offline.mjs` | **réussis** |

Traces et captures : `perf/threats/` (`rapport.json`, `partie-menaces.pdn`), `perf/svs-pdn/` (`rapport.json`, `partie-en-cours.pdn`, `toutes-les-parties.pdn`), `perf/threats-tests.json`.

### Mesures

| Mesure | Valeur |
|---|---|
| Annotation + menaces, 131 positions, profondeur 9, un seul passage | 3,4 s (Chromium/Linux, bureau) |
| Menaces seules, profondeur 9, cap 1,5 s/position | ~0,03 s par évaluation sur cette partie ; 82 évaluations pour 40 demi-coups |
| Réaffichage d'une partie déjà analysée | 1,1 s, 0 évaluation |
| PDF de la feuille avec menaces | 3 pages pour la partie d'exemple |

---

## 6. Limites explicites

- La « menace » est une **mesure du moteur**, pas une bibliothèque de menaces tactiques : l'écart de score entre « je rejoue » et « l'adversaire rejoue » à profondeur fixée. Un changement de profondeur peut changer la liste ; c'est pour cela que la profondeur de chaque analyse est écrite dans le récapitulatif, le PDN et le PDF.
- Les positions où une **prise obligatoire** rend l'inversion du trait artificielle ne sont pas mesurées : elles sont comptées et affichées comme telles.
- La vérification de parade compare deux évaluations de même profondeur : une nulle exacte avec historique peut apparaître comme « parée » alors que la partie est nulle par répétition ; les compteurs FMJD de l'analyse restent la référence pour la nulle.
- La mémoire des résultats est **celle de la session** (pas d'IndexedDB) : recharger la page efface les analyses, comme avant pour l'annotation.
- Les mesures de temps sont faites sous Chromium/Linux ; un téléphone Android peut être plus lent, la profondeur 10 sur 131 coups reste à confirmer sur appareil physique.
- Le renommage est **visuel** : les fichiers du moteur (`scan-wasm*.js`, `scan_normal.data`) et les mentions de licence GPL-3.0 gardent le nom Scan 3.1b, obligation de licence comprise.
