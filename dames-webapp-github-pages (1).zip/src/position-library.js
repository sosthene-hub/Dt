import {positionKey} from './game-rules.js';
const KEY='dames-position-library-v1';
export function validRecord(p){return p&&Array.isArray(p.board)&&p.board.length===51&&p.board.slice(1).every(v=>['e','w','b','W','B'].includes(v))&&['w','b'].includes(p.side)&&p.board.slice(1).some(v=>v!=='e');}
export function readLibrary(){try{const data=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(data)?data.filter(validRecord):[];}catch{return [];}}
export function savePositions(input){const records=readLibrary();let added=0;for(const p of input){if(!validRecord(p))throw Error('Position importée invalide.');const id=positionKey(p.board,p.side);if(records.some(x=>positionKey(x.board,x.side)===id))continue;if(records.length>=3000)throw Error('Limite locale : 3 000 positions. Exportez votre bibliothèque.');records.push({id,board:p.board.slice(),side:p.side,name:String(p.name||'Position').slice(0,160),tags:String(p.tags||p.source||'').slice(0,200),date:p.date||new Date().toISOString()});added++;}localStorage.setItem(KEY,JSON.stringify(records));return added;}
export function deletePosition(id){localStorage.setItem(KEY,JSON.stringify(readLibrary().filter(p=>p.id!==id)));}
export function exportLibrary(){return JSON.stringify({format:'dames-positions-v1',positions:readLibrary()},null,2);}
export function importPositions(data){const list=Array.isArray(data)?data:data.positions||data.results;if(!Array.isArray(list)||list.length>3000)throw Error('Fichier attendu : bibliothèque de positions ou export de tirage (3 000 maximum).');return savePositions(list);}
export function matchesPosition(p,f){if(f.text&&!`${p.name} ${p.tags}`.toLowerCase().includes(f.text.toLowerCase()))return false;if(f.side&&p.side!==f.side)return false;
 const count=s=>p.board.filter(x=>x.toLowerCase()===s).length;
 for(const s of ['w','b']){if(count(s)<f.min||count(s)>f.max)return false;if(f[s+'Kings']!==''&&f[s+'Kings']!==undefined&&p.board.filter(x=>x===s.toUpperCase()).length!==Number(f[s+'Kings']))return false;}
 for(let n=1;n<=50;n++){if(f.exact){if(p.board[n]!==f.root[n])return false;}else if(f.root[n]!=='e'&&p.board[n]!==f.root[n])return false;}if(f.empty.some(n=>p.board[n]!=='e'))return false;return true;}
