// Tiny shared state between pages.
export const store = {
  difficulty: 'normal',
  pendingNewGame: false,
  analysisDraft:null,
  retroDraft:null,
  positionDraft: null, // {board, side} passed editor -> analysis
};

export function requestNewGame() {
  store.pendingNewGame = true;
}
