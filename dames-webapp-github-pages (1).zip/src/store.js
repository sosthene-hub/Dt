// Tiny shared state between pages.
export const store = {
  difficulty: 'normal',
  pendingNewGame: false,
  positionDraft: null, // {board, side} passed editor -> analysis
};

export function requestNewGame() {
  store.pendingNewGame = true;
}
