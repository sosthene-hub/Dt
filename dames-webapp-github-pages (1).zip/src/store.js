// Tiny shared state between pages.
export const store = {
  difficulty: 'normal',
  pendingNewGame: false,
  analysisDraft:null,
  positionDraft: null, // {board, side} passed editor -> analysis
  playDraft: null, // {board, side, human, level, label} : jouer une position contre PIONICIDE
  studyDraft: null, // {start, moves, headers, result, source} : partie à commenter // {board, side, human, level, label} : jouer une position contre PIONICIDE
};

export function requestNewGame() {
  store.pendingNewGame = true;
}
