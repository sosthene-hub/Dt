// Deterministic tactical puzzle and position generation.
// Puzzles are guaranteed solvable by construction: the local rules engine
// proves the solution is legal and unique before the puzzle is served.

import { applyMove, generateLegalMoves, opponent } from './game-rules.js';

// Small deterministic PRNG so the “puzzle du jour” is stable for everyone.
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffled(rng, items) {
  const copy = items.slice();
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

// Random sparse position with both camps represented.
export function randomPosition(rng, { pieces = 8, kings = true } = {}) {
  const board = Array(51).fill('e');
  const squares = shuffled(rng, Array.from({ length: 50 }, (_, i) => i + 1));
  const total = Math.max(2, Math.min(40, pieces));
  for (let i = 0; i < total; i++) {
    const side = i % 2 === 0 ? 'w' : 'b';
    const isKing = kings && rng() < 0.15;
    board[squares[i]] = side === 'w' ? (isKing ? 'W' : 'w') : (isKing ? 'B' : 'b');
  }
  const side = rng() < 0.5 ? 'w' : 'b';
  return { board, side };
}

function material(board, side) {
  let count = 0;
  for (let square = 1; square <= 50; square++) {
    const piece = board[square];
    if (piece === side || piece === side.toUpperCase()) count++;
  }
  return count;
}

// One puzzle: {board, side, type, solution, difficulty, description}.
export function generatePuzzle(seed) {
  const rng = mulberry32(seed);
  for (let attempt = 0; attempt < 400; attempt++) {
    const { board, side } = randomPosition(rng, { pieces: 4 + Math.floor(rng() * 9), kings: true });
    const legal = generateLegalMoves(board, side);
    if (!legal.length) continue;

    // Attack puzzle: a unique capture sequence that takes the most pieces.
    const captures = legal.filter(move => move.captured.length > 0);
    if (captures.length) {
      const maxLength = Math.max(...captures.map(move => move.captured.length));
      if (maxLength >= 2) {
        const best = captures.filter(move => move.captured.length === maxLength);
        if (best.length === 1 && material(board, side) > 1) {
          return {
            board, side, type: 'capture', solution: best[0],
            difficulty: maxLength,
            description: `Trouvez la prise maximale : une seule séquence capture ${maxLength} pièces.`,
          };
        }
      }
    }

    // Defence puzzle: exactly one move avoids losing two pieces or more.
    const assessments = legal.map(move => {
      const after = applyMove(board, move);
      const replies = generateLegalMoves(after, opponent(side));
      const worst = replies.reduce((max, reply) => Math.max(max, reply.captured.length), 0);
      return { move, worst };
    });
    const minLoss = Math.min(...assessments.map(entry => entry.worst));
    const safe = assessments.filter(entry => entry.worst === minLoss);
    const heavyLosses = assessments.filter(entry => entry.worst >= minLoss + 2);
    if (minLoss === 0 && safe.length === 1 && heavyLosses.length >= 2 && material(board, side) > 1) {
      return {
        board, side, type: 'parade', solution: safe[0].move,
        difficulty: heavyLosses.length,
        description: `Une seule parade évite de perdre du matériel (${heavyLosses.length} coups perdent 2 pièces ou plus).`,
      };
    }
  }
  return null;
}

export function puzzleSeed(date = new Date()) {
  return Number(date.toISOString().slice(0, 10).replaceAll('-', ''));
}

export function puzzleTitle(puzzle) {
  const side = puzzle.side === 'w' ? 'Blancs' : 'Noirs';
  if (puzzle.type === 'capture') return `Prise maximale · ${side}`;
  return `La parade · ${side}`;
}

export function puzzleDifficultyLabel(puzzle) {
  if (puzzle.type === 'capture') {
    if (puzzle.difficulty <= 2) return 'Facile';
    if (puzzle.difficulty === 3) return 'Normal';
    return 'Fort';
  }
  if (puzzle.difficulty <= 2) return 'Normal';
  return 'Fort';
}

export function movePathsEqual(a, b) {
  return a.path.length === b.path.length && a.path.every((square, index) => square === b.path[index]);
}
