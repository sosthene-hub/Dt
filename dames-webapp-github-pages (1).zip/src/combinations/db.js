/**
 * Chargeur de la base privée PC Blues.
 * - version autonome privée : window.__COMBINATIONS__ (embarquée) ;
 * - version publique : aucun contenu du livre ; import manuel du fichier JSON,
 *   conservé localement dans IndexedDB ;
 * - développement : fetch de combinations-app.json servi par l'application.
 */
const DB_NAME = 'dames-combinaisons';
const STORE = 'base';

function openDb() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) { reject(new Error('IndexedDB indisponible')); return; }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function idbGet(key) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).get(key);
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error);
  });
}

async function idbSet(key, value) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(value, key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

export function validateDb(data) {
  if (!data || data.format !== 'pcblues-app-v1' || !Array.isArray(data.entries)) {
    throw new Error('Format de base inconnu : fichier combinations-app.json attendu.');
  }
  if (!data.entries.length) throw new Error('Base vide.');
  return data;
}

export async function loadCombinationDb({ allowFetch = true, baseUrl = '' } = {}) {
  if (typeof window !== 'undefined' && window.__COMBINATIONS__) {
    return { data: validateDb(window.__COMBINATIONS__), origin: 'embarquée' };
  }
  try {
    const stored = await idbGet('private');
    if (stored) return { data: validateDb(stored), origin: 'importée' };
  } catch { /* IndexedDB refusé : on continue */ }
  if (allowFetch) {
    try {
      const response = await fetch(`${baseUrl}combinations-app.json`, { cache: 'no-store' });
      if (response.ok) {
        const data = validateDb(await response.json());
        idbSet('private', data).catch(() => {});
        return { data, origin: 'fichier local' };
      }
    } catch { /* absent : version publique */ }
  }
  return { data: null, origin: null };
}

export async function importCombinationDb(file) {
  const text = await file.text();
  const data = validateDb(JSON.parse(text));
  await idbSet('private', data);
  return data;
}

export async function clearCombinationDb() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete('private');
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}
