import { coordinate, squareAtPosition, sideOf, generateLegalMoves, applyMove, moveToHub } from '../game-rules.js';

/** "38x", "38x27", "38x27x16" → cases demandées. */
export function parseRouteInput(text) {
  const raw = String(text || '').trim().replace(/[\s-]+/g, 'x').replace(/x+/gi, 'x').replace(/x$/i, '');
  if (!raw) return null;
  if (!/^\d{1,2}(x\d{1,2})*$/i.test(raw)) return null;
  const squares = raw.split(/x/i).map(Number);
  if (squares.some(n => !Number.isInteger(n) || n < 1 || n > 50)) return null;
  return { raw, squares };
}

export function routeText(squares) {
  if (!squares?.length) return '—';
  return squares.join('x');
}

export function entryRoute(entry) {
  const route = entry.rafle_complete?.length ? entry.rafle_complete : [entry.rafle_depart];
  return route;
}

export function routeMatches(route, request) {
  if (!request) return true;
  if (!route?.length) return false;
  if (route[0] !== request.squares[0]) return false;
  for (let i = 1; i < request.squares.length; i += 1) {
    if (route[i] !== request.squares[i]) return false;
  }
  return true;
}

/** Rejoue une solution en notation Hub ("35x24x13" = départ, arrivée, prises). */
export function replayHubs(board, side, hubs) {
  let current = board.slice();
  let turn = side;
  const moves = [];
  const states = [current.slice()];
  for (const hub of hubs) {
    const numbers = String(hub).split(/[x-]/).map(Number);
    const legal = generateLegalMoves(current, turn);
    const candidates = legal.filter(m => m.from === numbers[0] && m.to === numbers[1]);
    let move = candidates[0];
    if (numbers.length > 2 && candidates.length > 1) {
      const wanted = numbers.slice(2).sort((a, b) => a - b).join(',');
      move = candidates.find(m => m.captured.slice().sort((a, b) => a - b).join(',') === wanted) || move;
    }
    if (!move) return { ok: false, error: `coup illégal ${hub}`, moves, states };
    if (moveToHub(move) !== hub && candidates.length === 1) {
      // Notation du livre abrégée : la prise réelle est plus longue mais le coup est le bon.
    }
    current = applyMove(current, move);
    moves.push({ ...move, side: turn });
    states.push(current.slice());
    turn = turn === 'w' ? 'b' : 'w';
  }
  return { ok: true, moves, states, board: current, turn };
}

export function material(board) {
  let white = 0;
  let black = 0;
  for (let n = 1; n <= 50; n += 1) {
    if (sideOf(board[n]) === 'w') white += 1;
    if (sideOf(board[n]) === 'b') black += 1;
  }
  return { white, black };
}

/* ---------- isométries du damier ----------
 * Les cases jouables vérifient (ligne + colonne) impaire. Une symétrie
 * horizontale simple change cette parité : seule la rotation à 180° est
 * licite, combinée à une translation de parité paire.
 */
export function transformSquare(square, { rotate = false, dr = 0, dc = 0 } = {}) {
  const c = coordinate(square);
  if (!c) return null;
  const row = rotate ? 9 - c.row : c.row;
  const col = rotate ? 9 - c.col : c.col;
  const nr = row + dr;
  const nc = col + dc;
  if (nr < 0 || nr > 9 || nc < 0 || nc > 9) return null;
  if ((nr + nc) % 2 !== 1) return null;
  return squareAtPosition(nr, nc) || null;
}

export function transformBoard(board, transform) {
  const out = Array(51).fill('e');
  for (let n = 1; n <= 50; n += 1) {
    if (board[n] === 'e') continue;
    const target = transformSquare(n, transform);
    if (!target) return null;
    out[target] = board[n];
  }
  return out;
}

export function transformPath(path, transform) {
  const out = path.map(s => transformSquare(s, transform));
  return out.some(s => !s) ? null : out;
}

export function pathSquares(path) {
  return path.slice();
}

/** Cases traversées (départs, atterrissages et prises) par la solution. */
export function skeletonSquares(board, side, hubs) {
  const replay = replayHubs(board, side, hubs);
  if (!replay.ok) return null;
  const set = new Set();
  for (const move of replay.moves) {
    set.add(move.from);
    set.add(move.to);
    for (const s of move.path) set.add(s);
    for (const s of move.captured) set.add(s);
  }
  return set;
}
