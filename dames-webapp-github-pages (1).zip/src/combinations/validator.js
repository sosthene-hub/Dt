import { coordinate, sideOf, generateLegalMoves, moveToHub } from '../game-rules.js';
import { replayHubs } from './model.js';

/**
 * Validateur de cohérence des positions de combinaison (numérotation FMJD 1-50).
 *
 * Il ne touche jamais à la logique de la rafle du livre : il contrôle seulement
 * que la position affichée est plausible et légale avant de la montrer.
 *
 * Rangées 1 à 10 de haut en bas. Les cases jouables d'une rangée r vont de
 * 5(r-1)+1 à 5r ; la promotion blanche est la rangée 1 (cases 1-5), la
 * promotion noire la rangée 10 (cases 46-50).
 */
export const DEFAULT_VALIDATION = Object.freeze({
  maxPiecesPerSide: 20,
  maxMaterialGap: 3,
  // Pions : limites d'avancée. Un pion blanc sur les rangées 1-2 et un pion
  // noir sur les rangées 9-10 sont des leurres invraisemblables.
  whiteManMinRow: 3,
  blackManMaxRow: 8,
  // Aucun pion ajouté isolé : il lui faut un voisin de son camp à cette
  // distance de Chebyshev (en cases).
  isolationDistance: 2,
  rejectIsolated: true,
  checkParasiticCapture: true,
});

export function squareRow(square) {
  const c = coordinate(square);
  return c ? c.row + 1 : null;
}

export function rowOfSquare(square) {
  return squareRow(square);
}

function manOnPromotionRow(board) {
  const bad = [];
  for (let n = 1; n <= 50; n += 1) {
    if (board[n] === 'w' && squareRow(n) === 1) bad.push(n);
    if (board[n] === 'b' && squareRow(n) === 10) bad.push(n);
  }
  return bad;
}

function countPieces(board) {
  let white = 0;
  let black = 0;
  for (let n = 1; n <= 50; n += 1) {
    if (sideOf(board[n]) === 'w') white += 1;
    if (sideOf(board[n]) === 'b') black += 1;
  }
  return { white, black };
}

function chebyshev(a, b) {
  const A = coordinate(a);
  const B = coordinate(b);
  return Math.max(Math.abs(A.row - B.row), Math.abs(A.col - B.col));
}

/** Cases traversées par la solution rejouée (départs, atterrissages, prises). */
export function solutionSkeleton(board, trait, solution) {
  if (!board || !solution?.length) return new Set();
  const replay = replayHubs(board, trait, solution);
  if (!replay.ok) return new Set();
  const set = new Set();
  for (const move of replay.moves) {
    set.add(move.from);
    set.add(move.to);
    for (const s of move.path) set.add(s);
    for (const s of move.captured) set.add(s);
  }
  return set;
}

function sameFirstMove(legal, hub) {
  const numbers = String(hub).split(/[x-]/).map(Number);
  if (legal.from !== numbers[0] || legal.to !== numbers[1]) return false;
  const wanted = numbers.slice(2).sort((a, b) => a - b);
  if (!wanted.length) return true;
  const captured = legal.captured.slice().sort((a, b) => a - b);
  return wanted.length === captured.length && wanted.every((n, i) => n === captured[i]);
}

/**
 * @param {object} position {board, side/trait, solution?, added?}
 * @param {object} limits  voir DEFAULT_VALIDATION
 * @param {object} options {protectAdded:boolean, useSkeleton:boolean, scope:'all'|'added'}
 * @returns {{ok:boolean, violations:Array<{code:string,message:string,squares?:number[],severity:'error'|'warning'}>, counts:object}}
 */
export function validateCombinationPosition(position, limits = {}, options = {}) {
  const config = { ...DEFAULT_VALIDATION, ...limits };
  const board = position.board;
  const side = position.side ?? position.trait ?? 'w';
  const solution = position.solution || [];
  const added = position.added || null;
  const scope = options.scope || (added ? 'added' : 'all');
  const useSkeleton = options.useSkeleton !== false;
  const skeleton = useSkeleton && solution.length ? solutionSkeleton(board, side, solution) : new Set();
  const violations = [];
  const push = (code, message, squares = [], severity = 'error') => violations.push({ code, message, squares, severity });

  if (!board || board.length < 51) {
    push('position-invalide', 'Damier incomplet.');
    return { ok: false, violations, counts: { white: 0, black: 0 } };
  }

  /* 1. Pions sur la ligne de promotion : interdit par les règles. */
  const promoted = manOnPromotionRow(board);
  if (promoted.length) {
    push('pion-sur-promotion', `Pion sur une ligne de promotion (cases ${promoted.join(', ')}).`, promoted);
  }

  /* 2. Maximum 20 pièces par camp. */
  const counts = countPieces(board);
  if (counts.white > config.maxPiecesPerSide) {
    push('trop-de-pieces', `${counts.white} pièces blanches (maximum ${config.maxPiecesPerSide}).`);
  }
  if (counts.black > config.maxPiecesPerSide) {
    push('trop-de-pieces', `${counts.black} pièces noires (maximum ${config.maxPiecesPerSide}).`);
  }

  /* 3. Écart de matériel plausible. */
  const gap = Math.abs(counts.white - counts.black);
  if (gap > config.maxMaterialGap) {
    push('ecart-materiel', `Écart de ${gap} pièces entre les camps (maximum ${config.maxMaterialGap}).`);
  }

  /* 4 et 5. Leurres ajoutés : avancée et isolement. */
  const inspected = scope === 'added' && added ? added.map(x => x.square) : null;
  const targets = inspected || Array.from({ length: 50 }, (_, i) => i + 1).filter(n => sideOf(board[n]) && !skeleton.has(n));

  const tooAdvanced = [];
  for (const n of targets) {
    const piece = board[n];
    if (!piece || piece === 'e' || piece === 'W' || piece === 'B') continue;
    const row = squareRow(n);
    if (piece === 'w' && row < config.whiteManMinRow) tooAdvanced.push(n);
    if (piece === 'b' && row > config.blackManMaxRow) tooAdvanced.push(n);
  }
  if (tooAdvanced.length) {
    push('pion-trop-avance', `Pion trop avancé (cases ${tooAdvanced.join(', ')}).`, tooAdvanced);
  }

  if (config.rejectIsolated) {
    const isolated = [];
    for (const n of targets) {
      const piece = board[n];
      if (!piece || piece === 'e' || skeleton.has(n)) continue;
      const camp = sideOf(piece);
      if (!camp) continue;
      let friend = false;
      for (let m = 1; m <= 50 && !friend; m += 1) {
        if (m === n || sideOf(board[m]) !== camp) continue;
        if (chebyshev(n, m) <= config.isolationDistance) friend = true;
      }
      if (!friend) isolated.push(n);
    }
    if (isolated.length) {
      push('pion-isole', `Pion isolé de son camp (cases ${isolated.join(', ')}).`, isolated);
    }
  }

  /* 6. Prise parasite : la seule prise possible doit être celle de la solution. */
  if (config.checkParasiticCapture && solution.length) {
    const legal = generateLegalMoves(board, side);
    const captures = legal.filter(m => m.captured.length);
    if (captures.length) {
      const wanted = solution[0];
      const foreign = captures.filter(m => !sameFirstMove(m, wanted));
      if (foreign.length) {
        const squares = [...new Set(foreign.flatMap(m => [m.from, m.to]))];
        push('prise-parasite', `Prise concurrente à ${foreign.map(m => moveToHub(m)).join(', ')}.`, squares);
      }
      if (!captures.some(m => sameFirstMove(m, wanted))) {
        push('rafle-absente', 'La rafle de la solution n’est pas un coup légal au départ.');
      }
    } else if (solution[0] && String(solution[0]).includes('x')) {
      push('rafle-absente', 'La rafle de la solution n’est plus une prise obligatoire.');
    }
  }

  return { ok: violations.every(v => v.severity !== 'error'), violations, counts, materialGap: gap };
}

/** Validation d'une position destinée à être jouée contre PIONICIDE (éditeur, combinaisons). */
export function validatePlayablePosition(board, side) {
  const errors = [];
  if (!board) return ['Damier vide.'];
  const promoted = manOnPromotionRow(board);
  if (promoted.length) errors.push(`Pion sur la ligne de promotion (cases ${promoted.join(', ')}).`);
  const counts = countPieces(board);
  if (counts.white > 20) errors.push(`${counts.white} pièces blanches : maximum 20.`);
  if (counts.black > 20) errors.push(`${counts.black} pièces noires : maximum 20.`);
  if (!counts.white || !counts.black) errors.push('Il faut au moins une pièce de chaque camp.');
  if (!errors.length && !generateLegalMoves(board, side).length) {
    errors.push(`Aucun coup légal pour les ${side === 'w' ? 'Blancs' : 'Noirs'} : la position est bloquée.`);
  }
  return errors;
}

export function describeViolations(violations) {
  return violations.map(v => v.message).join(' ');
}
