import { coordinate, squareAtPosition, sideOf, generateLegalMoves, applyMove } from '../game-rules.js';
import {
  entryRoute, replayHubs, material, transformSquare, transformBoard, transformPath,
} from './model.js';

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function random() {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const LEVELS = {
  1: { min: 0, max: 0, minDistance: 0, decoys: 0, minSolution: 0, label: 'Livre' },
  2: { min: 2, max: 4, minDistance: 2, decoys: 0, minSolution: 0, label: '+2 à 4 pièces neutres' },
  3: { min: 4, max: 8, minDistance: 1, decoys: 1, minSolution: 0, label: '+4 à 8 pièces, leurres' },
  4: { min: 8, max: 12, minDistance: 1, decoys: 2, minSolution: 4, label: '+8 pièces ou plus, plusieurs leurres' },
};

export const GENERATION_LEVELS = LEVELS;

function chebyshev(a, b) {
  const A = coordinate(a);
  const B = coordinate(b);
  return Math.max(Math.abs(A.row - B.row), Math.abs(A.col - B.col));
}

export function solveTransform(route, request) {
  if (!request) return null;
  if (!route?.length || route.length < request.squares.length) return null;
  // La rotation à 180° inverserait les camps et le sens de déplacement ; le
  // miroir horizontal change la couleur des cases. Seule la translation subsiste.
  for (const rotate of [false]) {
    const mapped = transformSquare(route[0], { rotate });
    if (!mapped) continue;
    const m = coordinate(mapped);
    const target = coordinate(request.squares[0]);
    const dr = target.row - m.row;
    const dc = target.col - m.col;
    if ((dr + dc) % 2 !== 0) continue;
    let ok = true;
    for (let i = 1; i < request.squares.length; i += 1) {
      if (transformSquare(route[i], { rotate, dr, dc }) !== request.squares[i]) { ok = false; break; }
    }
    if (ok) return { rotate, dr, dc };
  }
  return null;
}

/**
 * Deux façons de répondre à une rafle demandée :
 * - « directe » : la position du livre possède déjà cette route (aucune transformation) ;
 * - « décalée » : un modèle est translaté pour que sa route tombe sur la demande.
 * La rotation et le miroir sont exclus : ils inversent les camps ou la couleur des cases.
 */
export function findModels(entries, request) {
  if (!request) return { direct: entries, translated: [] };
  const direct = entries.filter(entry => routePrefix(entryRoute(entry), request.squares));
  if (direct.length) return { direct, translated: [] };
  const translated = entries.filter(entry => {
    const transform = solveTransform(entryRoute(entry), request);
    if (!transform) return false;
    if (!transformBoard(entry.board, transform)) return false;
    return !!transformPath(entryRoute(entry), transform);
  });
  return { direct, translated };
}

export function routePrefix(route, squares) {
  if (!route?.length) return false;
  if (route[0] !== squares[0]) return false;
  for (let i = 1; i < squares.length; i += 1) if (route[i] !== squares[i]) return false;
  return true;
}

function occupied(board, squares) {
  return squares.some(s => board[s] !== 'e');
}

function validateCandidate(candidate, levelConfig) {
  const { board, trait, solution, rafle_complete: route, nb_pieces_blanc: white, nb_pieces_noir: black } = candidate;
  const replay = replayHubs(board, trait, solution);
  if (!replay.ok) return { ok: false, reason: `solution cassée (${replay.error})` };
  const lastCapture = [...replay.moves].reverse().find(m => m.side === 'w' && m.captured.length);
  if (!lastCapture) return { ok: false, reason: 'aucune prise blanche' };
  const replayedRoute = [lastCapture.from, ...lastCapture.path.slice(1)];
  for (let i = 0; i < route.length && i < replayedRoute.length; i += 1) {
    if (route[i] !== replayedRoute[i]) return { ok: false, reason: 'rafle finale modifiée' };
  }
  // Prise obligatoire : au trait initial, soit aucune prise, soit la rafle attendue seulement.
  const rootMoves = generateLegalMoves(board, trait);
  const first = replay.moves[0];
  if (rootMoves.some(m => m.captured.length)) {
    if (!first.captured.length) return { ok: false, reason: 'prise obligatoire ignorée' };
    const alternative = rootMoves.some(m => m.from !== first.from || m.to !== first.to);
    if (alternative) return { ok: false, reason: 'prise concurrente au départ' };
  } else if (first.captured.length) {
    return { ok: false, reason: 'prise disparue' };
  }
  if (Math.abs(white - black) > 1) return { ok: false, reason: 'matériel déséquilibré' };
  if (white > 20 || black > 20) return { ok: false, reason: 'trop de pièces' };
  if (candidate.solution.length < levelConfig.minSolution) return { ok: false, reason: 'solution trop courte pour le niveau' };
  return { ok: true, replayedRoute };
}

/**
 * Construit un candidat à partir d’un modèle du livre.
 * Le squelette est transformé rigidement (rotation 180° et translation) puis
 * des pièces neutres sont ajoutées sans jamais toucher les cases de passage.
 */
export function buildCandidate(entry, { level = 2, request = null, transform: fixedTransform = null, rng = Math.random } = {}) {
  if (request && !routePrefix(entryRoute(entry), request.squares)) return { ok: false, reason: 'modèle hors route' };
  const config = LEVELS[level];
  if (!config || level === 1) {
    const candidate = {
      origin: entry.id, level: 1, board: entry.board.slice(), trait: entry.trait,
      solution: entry.solution.slice(), rafle_complete: entryRoute(entry),
      nb_pieces_blanc: entry.nb_pieces_blanc, nb_pieces_noir: entry.nb_pieces_noir,
      added: [], transform: null, page: entry.page,
    };
    const check = validateCandidate(candidate, LEVELS[1]);
    return check.ok ? { ok: true, candidate: { ...candidate, ...check } } : { ok: false, reason: check.reason };
  }
  const modelRoute = entryRoute(entry);
  const replayModel = replayHubs(entry.board, entry.trait, entry.solution);
  if (!replayModel.ok) return { ok: false, reason: 'modèle illégal' };
  const skeleton = new Set();
  for (const move of replayModel.moves) {
    skeleton.add(move.from); skeleton.add(move.to);
    for (const s of move.path) skeleton.add(s);
    for (const s of move.captured) skeleton.add(s);
  }
  let transform = null;
  if (fixedTransform) {
    transform = fixedTransform;
    if (!transformBoard(entry.board, transform)) return { ok: false, reason: 'transformation hors damier' };
    for (const square of skeleton) if (!transformSquare(square, transform)) return { ok: false, reason: 'trajectoire hors damier' };
  } else if (request) {
    transform = { rotate: false, dr: 0, dc: 0 };
  } else {
    const options = [];
    for (let dr = -4; dr <= 4; dr += 1) {
      for (let dc = -4; dc <= 4; dc += 1) {
        if ((dr + dc) % 2 !== 0 || (!dr && !dc)) continue;
        const trial = { rotate: false, dr, dc };
        if (transformBoard(entry.board, trial) && [...skeleton].every(sq => transformSquare(sq, trial))) options.push(trial);
      }
    }
    options.push({ rotate: false, dr: 0, dc: 0 });
    transform = options[Math.floor(rng() * options.length)];
  }
  const board = transformBoard(entry.board, transform);
  if (!board) return { ok: false, reason: 'transformation hors damier' };
  const solution = [];
  for (const move of replayModel.moves) {
    const path = transformPath(move.path, transform);
    if (!path) return { ok: false, reason: 'trajectoire hors damier' };
    const captured = move.captured.map(s => transformSquare(s, transform));
    solution.push(captured.length ? `${path[0]}x${path.at(-1)}x${captured.join('x')}` : `${path[0]}-${path.at(-1)}`);
  }
  const route = transformPath(modelRoute, transform);
  if (!route) return { ok: false, reason: 'rafle hors damier' };
  const transformedSkeleton = [...skeleton].map(s => transformSquare(s, transform));
  const baseBoard = board.slice();
  const count = config.min + Math.floor(rng() * (config.max - config.min + 1));
  let lastReason = 'emplacement impossible';
  for (let placement = 0; placement < 8; placement += 1) {
    const trial = baseBoard.slice();
    const added = [];
    let white = entry.nb_pieces_blanc;
    let black = entry.nb_pieces_noir;
    let placed = 0;
    for (const distance of [config.minDistance, Math.max(1, config.minDistance - 1)]) {
      const free = [];
      for (let n = 1; n <= 50; n += 1) {
        if (trial[n] !== 'e') continue;
        if (transformedSkeleton.includes(n)) continue;
        if (transformedSkeleton.some(sq => chebyshev(sq, n) < distance)) continue;
        free.push(n);
      }
      if (free.length < count - placed) continue;
      while (placed < count && free.length) {
        const square = free.splice(Math.floor(rng() * free.length), 1)[0];
        const color = white < black ? 'w' : black < white ? 'b' : (rng() < 0.5 ? 'w' : 'b');
        trial[square] = color;
        added.push({ square, color });
        if (color === 'w') white += 1; else black += 1;
        placed += 1;
      }
      if (placed >= count) break;
    }
    if (placed < config.min) { lastReason = 'pas assez de cases libres'; continue; }
    const candidate = {
      origin: entry.id, level, board: trial, trait: entry.trait, solution, rafle_complete: route,
      nb_pieces_blanc: white, nb_pieces_noir: black, added, transform, page: entry.page,
      solution_pretty: entry.solution_pretty,
    };
    const check = validateCandidate(candidate, config);
    if (check.ok) return { ok: true, candidate: { ...candidate, ...check } };
    lastReason = check.reason;
  }
  return { ok: false, reason: lastReason };
}

/** Compte les interactions de prise visibles (indice de difficulté, pas une preuve). */
export function countInteractions(board, side) {
  const legal = generateLegalMoves(board, side);
  return {
    legalMoves: legal.length,
    captures: legal.filter(m => m.captured.length).length,
    maxCapture: legal.reduce((m, x) => Math.max(m, x.captured.length), 0),
    pieces: material(board),
  };
}

/**
 * Vérification Scan sans multi-PV : deux recherches à profondeur égale.
 * 1. score de la position racine (meilleur coup de Scan) ;
 * 2. score après le premier coup de la solution, du point de vue adverse.
 * Le coup est retenu si la position est gagnante après ce coup et si sa valeur
 * ne s'écarte pas de plus d'une marge du meilleur coup (sinon un autre coup
 * serait clairement supérieur).
 */
export async function verifyWithScan(candidate, { search, depth = 12, minScore = 1.5, margin = 0.5 } = {}) {
  const first = candidate.solution[0];
  const numbers = first.split(/[x-]/).map(Number);
  const legal = generateLegalMoves(candidate.board, candidate.trait);
  const wantedMove = legal.find(m => m.from === numbers[0] && m.to === numbers[1]);
  if (!wantedMove) return { accepted: false, reason: 'coup absent des coups légaux' };
  const position = 'pos=' + (candidate.trait === 'w' ? 'W' : 'B') + candidate.board.slice(1).join('');
  const after = applyMove(candidate.board, wantedMove);
  // Première recherche : la position est-elle gagnante après le coup de la solution ?
  const reply = await search({ position: 'pos=' + (candidate.trait === 'w' ? 'B' : 'W') + after.slice(1).join(''), depth, mode: 'analyze', maxTimeMs: depth <= 12 ? 3000 : 10000 });
  const replyInfo = reply.infos?.at(-1);
  const replyScore = Number(replyInfo?.score);
  if (!Number.isFinite(replyScore)) return { accepted: false, reason: 'Scan sans score' };
  const value = -replyScore;
  if (value < minScore) return { accepted: false, reason: `coup non gagnant (${value.toFixed(2)} < ${minScore})`, replyScore, value, depth: replyInfo?.depth ?? null };
  // Seconde recherche seulement si le gain est là : écart avec le meilleur coup.
  const root = await search({ position, depth, mode: 'analyze', maxTimeMs: depth <= 12 ? 3000 : 10000 });
  const rootInfo = root.infos?.at(-1);
  const rootScore = Number(rootInfo?.score);
  if (!Number.isFinite(rootScore)) return { accepted: false, reason: 'Scan sans score racine' };
  const gap = rootScore - value;
  if (gap > margin) return { accepted: false, reason: `autre coup supérieur de ${gap.toFixed(2)}`, rootScore, replyScore, value, depth: replyInfo?.depth ?? null, scanMove: root.move };
  return { accepted: true, rootScore, replyScore, value, gap, depth: replyInfo?.depth ?? null, scanMove: root.move };
}

/** Recherche de candidats vérifiés ; journalise toutes les causes de rejet. */
export async function generateVerified(entries, options = {}) {
  const { level = 2, request = null, attempts = 24, search = null, depth = 12, minScore = 2, seed = Date.now(), onProgress = null } = options;
  const rng = mulberry32(seed);
  const stats = { level, attempted: 0, rejected: {}, accepted: 0, scanChecked: 0 };
  const models = findModels(entries, request);
  // findModels a déjà vérifié le préfixe ; sinon on translate un modèle.
  const pool = models.direct.length
    ? models.direct.map(entry => ({ entry, transform: null }))
    : models.translated.map(entry => ({ entry, transform: solveTransform(entryRoute(entry), request) })).filter(item => item.transform);
  if (!pool.length) return { candidate: null, stats, reason: 'aucun modèle pour cette rafle' };
  const startedAt = Date.now();
  for (let i = 0; i < attempts; i += 1) {
    stats.attempted += 1;
    if (Date.now() - startedAt > (options.timeBudgetMs || 60000)) {
      stats.rejected['budget de temps atteint'] = (stats.rejected['budget de temps atteint'] || 0) + 1;
      break;
    }
    const { entry: model, transform } = pool[Math.floor(rng() * pool.length)];
    const built = buildCandidate(model, { level, request, transform, rng });
    if (!built.ok) {
      stats.rejected[built.reason] = (stats.rejected[built.reason] || 0) + 1;
      continue;
    }
    const candidate = built.candidate;
    if (search) {
      stats.scanChecked += 1;
      const verdict = await verifyWithScan(candidate, { search, depth, minScore });
      if (onProgress) onProgress({ attempt: i + 1, verdict });
      if (!verdict.accepted) {
        const key = `Scan: ${verdict.reason}`;
        stats.rejected[key] = (stats.rejected[key] || 0) + 1;
        continue;
      }
      candidate.scan = verdict;
    }
    stats.accepted += 1;
    return { candidate, stats };
  }
  return { candidate: null, stats, reason: 'aucun candidat retenu' };
}
