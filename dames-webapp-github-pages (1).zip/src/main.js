import './style.css';
import { applyMove, createInitialBoard, generateLegalMoves, moveMatchesEngine, moveToHub, opponent, positionKey, sideOf, squareAtPosition } from './game-rules.js';

const app = document.querySelector('#app');
const BASE_URL = import.meta.env.BASE_URL;
const pages = [
  { id: 'jouer', title: 'Accueil / Jouer', icon: '◉', desc: 'Lancez une partie locale contre Scan 3.1.' },
  { id: 'creer', title: 'Créer une partie', icon: '＋', desc: 'Configurez une nouvelle partie et choisissez les paramètres de jeu.' },
  { id: 'apprendre', title: 'Apprendre', icon: '✦', desc: 'Puzzles et exercices personnalisés pour progresser aux dames internationales.' },
  { id: 'problemes', title: 'Problèmes', icon: '♟', desc: 'Entraînez-vous sur des positions tactiques.' },
  { id: 'analyse', title: 'Damier d’analyse', icon: '⌕', desc: 'Étudiez une position et ses variantes avec le moteur Scan.' },
  { id: 'editeur', title: 'Éditeur de partie', icon: '▧', desc: 'Placez les pièces et composez une position sur le damier.' },
  { id: 'importer', title: 'Importer une partie', icon: '⇧', desc: 'Chargez une partie au format PDN pour la revoir.' },
  { id: 'generateur', title: 'Générateur de positions', icon: '⠿', desc: 'Créez des positions selon vos contraintes d’entraînement.' },
  { id: 'recherche', title: 'Recherche avancée', icon: '⌕', desc: 'Recherchez une position, une partie ou une séquence.' },
];
const depthLevels = { facile: 3, normal: 5, fort: 7 };
let board = createInitialBoard();
let sideToMove = 'w';
let legalMoves = generateLegalMoves(board, sideToMove);
let selected = null;
let isThinking = false;
let isReady = false;
let gameOver = false;
let moveCount = 0;
let lastMove = null;
let worker;
let currentPage = 'jouer';
let moveHistory = [];
let repetitions = new Map([[positionKey(board, sideToMove), 1]]);
let undoStack = [];
let pendingRoundSnapshot = null;

app.innerHTML = `
  <header class="topbar">
    <button class="menu-button" id="menu-toggle" aria-label="Ouvrir le menu" aria-controls="app-drawer" aria-expanded="false" title="Menu"><span></span><span></span><span></span></button>
    <div class="brand"><span class="brand-mark">D</span><div><strong>DAMES</strong><small>ENTRAÎNEMENT 10×10</small></div></div>
    <button class="icon-button" id="new-game" aria-label="Nouvelle partie" title="Nouvelle partie">↻</button>
  </header>
  <div class="drawer-backdrop" id="drawer-backdrop"></div>
  <aside class="drawer" id="app-drawer" aria-label="Navigation principale" aria-hidden="true">
    <div class="drawer-header"><div class="drawer-brand"><span class="brand-mark">D</span><div><strong>DAMES</strong><small>ESPACE D’ENTRAÎNEMENT</small></div></div><button class="drawer-close" id="drawer-close" aria-label="Fermer le menu">×</button></div>
    <div class="drawer-label">MENU PRINCIPAL</div>
    <nav class="drawer-nav" id="drawer-nav" aria-label="Sections">
      ${pages.map(page => `<button class="nav-item ${page.id === 'jouer' ? 'active' : ''}" data-page="${page.id}" ${page.id === 'jouer' ? 'aria-current="page"' : ''}><span class="nav-icon" aria-hidden="true">${page.icon}</span><span>${page.title}</span>${page.id === 'jouer' ? '<span class="nav-dot"></span>' : ''}</button>`).join('')}
    </nav>
    <div class="drawer-bottom"><span class="engine-mini-dot"></span><div><b>Scan 3.1</b><small>Moteur local · hors ligne</small></div></div>
  </aside>
  <main id="main-content">
    <div id="home-view">
      <section class="welcome"><div class="eyebrow">DAMES INTERNATIONALES · 10×10</div><h1>À vous de jouer.</h1><p>Une partie locale contre Scan 3.1.</p></section>
      <div class="game-options"><div class="game-mode"><span class="mode-dot"></span><div><b>Partie locale</b><small>Blancs contre Scan</small></div></div><label class="level-control" for="difficulty">Niveau<select id="difficulty" aria-label="Niveau de Scan"><option value="facile">Facile</option><option value="normal" selected>Normal</option><option value="fort">Fort</option></select></label></div>
      <section class="game-card">
        <div class="player-row"><div class="avatar dark-avatar">S</div><div class="player-name"><b>Scan 3.1</b><span>Adversaire · noirs</span></div><span class="engine-pill"><i></i> <span id="engine-label">Démarrage…</span></span></div>
        <div class="board-wrap"><div class="board" id="board" role="grid" aria-label="Damier de dames internationales"></div></div>
        <div class="player-row bottom-player"><div class="avatar light-avatar">V</div><div class="player-name"><b>Vous</b><span>Blancs</span></div><span class="turn-indicator" id="turn-label">À vous</span></div>
      </section>
      <section class="control-row">
        <button class="secondary-button" id="undo" disabled>↶ <span>Annuler le tour</span></button>
        <div class="message" id="message">Chargement du moteur Scan…</div>
        <button class="secondary-button" id="help">ⓘ <span>Règles</span></button>
      </section>
      <section class="phase-note"><div class="note-icon">✓</div><div><b>Jeu local · hors ligne</b><p>Scan 3.1 fonctionne sur cet appareil. L’application sera mise en cache après le premier chargement.</p></div><span class="phase-tag">SCAN 3.1</span></section>
    </div>
    <section class="section-view hidden" id="section-view" aria-live="polite"></section>
  </main>
  <footer>Jeu local · Dames internationales · Aucun compte requis</footer>
  <div class="toast" id="toast" role="status"></div>
`;

const boardEl = document.querySelector('#board');
const messageEl = document.querySelector('#message');
const engineLabel = document.querySelector('#engine-label');
const toast = document.querySelector('#toast');
const undoButton = document.querySelector('#undo');
const drawer = document.querySelector('#app-drawer');
const menuToggle = document.querySelector('#menu-toggle');
const drawerBackdrop = document.querySelector('#drawer-backdrop');
const homeView = document.querySelector('#home-view');
const sectionView = document.querySelector('#section-view');
const turnLabel = document.querySelector('#turn-label');
const difficultySelect = document.querySelector('#difficulty');

function setDrawer(open) {
  drawer.classList.toggle('open', open);
  drawerBackdrop.classList.toggle('visible', open);
  drawer.setAttribute('aria-hidden', String(!open));
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
  if (open) drawer.querySelector('.nav-item.active')?.focus();
  else menuToggle.focus({ preventScroll: true });
}
function plannedDescription(pageId) {
  const notes = {
    apprendre: 'Puzzles tactiques, exercices issus de vos parties et répétition espacée.',
    problemes: 'Positions à résoudre, validation du coup et commentaires du moteur.',
    analyse: 'Édition de position, évaluation Scan et consultation de variantes.',
    editeur: 'Placement des pièces, choix du trait et sauvegarde de positions.',
    importer: 'Sélection et lecture des fichiers de parties PDN.',
    generateur: 'Contraintes de placement, nombre de positions et classement par Scan.',
    recherche: 'Filtres de position et recherche de séquences de coups.',
  };
  return notes[pageId] ?? 'Outils d’entraînement aux dames internationales.';
}
function renderCreatePage() {
  sectionView.innerHTML = `
    <div class="section-heading"><div class="eyebrow">PARTIE LOCALE · SCAN 3.1</div><h1>Créer une partie</h1><p>Choisissez la force de Scan, puis lancez une partie d’entraînement.</p></div>
    <article class="coming-card create-game-card"><div class="coming-icon" aria-hidden="true">＋</div><div class="coming-copy"><span class="coming-badge">PRÊT À JOUER</span><h2>Partie locale</h2><p>Vous jouez les blancs ; Scan joue les noirs. Les coups sont calculés sur cet appareil.</p></div></article>
    <div class="create-levels"><label for="create-difficulty">Niveau de Scan</label><select id="create-difficulty"><option value="facile">Facile · profondeur 3</option><option value="normal">Normal · profondeur 5</option><option value="fort">Fort · profondeur 7</option></select></div>
    <button class="start-game-button" id="start-created-game">Commencer une partie <span>→</span></button>
  `;
  const createSelect = sectionView.querySelector('#create-difficulty');
  createSelect.value = difficultySelect.value;
  createSelect.addEventListener('change', () => { difficultySelect.value = createSelect.value; });
  sectionView.querySelector('#start-created-game').addEventListener('click', () => {
    difficultySelect.value = createSelect.value;
    startNewGame();
    navigateTo('jouer');
    showToast(`Nouvelle partie · niveau ${difficultySelect.options[difficultySelect.selectedIndex].text.split(' · ')[0].toLowerCase()}`);
  });
}
function navigateTo(pageId) {
  const page = pages.find(item => item.id === pageId) ?? pages[0];
  currentPage = page.id;
  document.querySelectorAll('.nav-item').forEach(button => {
    const active = button.dataset.page === currentPage;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
    button.querySelector('.nav-dot')?.remove();
    if (active) button.insertAdjacentHTML('beforeend', '<span class="nav-dot"></span>');
  });
  const isHome = page.id === 'jouer';
  homeView.classList.toggle('hidden', !isHome);
  sectionView.classList.toggle('hidden', isHome);
  if (!isHome) {
    if (page.id === 'creer') renderCreatePage();
    else sectionView.innerHTML = `
      <div class="section-heading"><div class="eyebrow">ESPACE D’ENTRAÎNEMENT · PRÉPARATION</div><h1>${page.title}</h1><p>${page.desc}</p></div>
      <article class="coming-card"><div class="coming-icon" aria-hidden="true">${page.icon}</div><div class="coming-copy"><span class="coming-badge">SECTION ACCESSIBLE</span><h2>Bienvenue dans ${page.title.toLowerCase()}</h2><p>La navigation est en place. Le contenu et les outils de cette section seront développés dans les prochaines phases.</p></div></article>
      <div class="planned-card"><span class="planned-mark">✦</span><div><b>Prévu pour cette section</b><p>${plannedDescription(page.id)}</p></div></div>
      <button class="back-to-game" data-go-home><span>←</span> Retour à la partie</button>
    `;
    sectionView.querySelector('[data-go-home]')?.addEventListener('click', () => navigateTo('jouer'));
  }
  document.title = isHome ? 'Dames — entraînement' : `${page.title} — Dames`;
  setDrawer(false);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function availableMoves(from) { return legalMoves.filter(move => move.from === from); }
function drawBoard() {
  boardEl.innerHTML = '';
  for (let row = 0; row < 10; row++) {
    for (let col = 0; col < 10; col++) {
      const n = squareFor(row, col);
      const cell = document.createElement('button');
      cell.type = 'button';
      cell.className = `cell ${(row + col) % 2 ? 'playable' : 'light-square'}`;
      cell.setAttribute('role', 'gridcell');
      if (!n) {
        cell.disabled = true;
      } else {
        const piece = board[n];
        const color = sideOf(piece);
        cell.dataset.square = n;
        cell.setAttribute('aria-label', `Case ${n}${color ? `, ${color === 'w' ? 'pièce blanche' : 'pièce noire'}${piece === 'W' || piece === 'B' ? ', dame' : ''}` : ''}`);
        if (selected === n) cell.classList.add('selected');
        if (lastMove?.includes(n)) cell.classList.add('last-move');
        if (piece !== 'e') {
          const token = document.createElement('span');
          token.className = `piece ${color === 'w' ? 'white-piece' : 'black-piece'}${piece === 'W' || piece === 'B' ? ' king' : ''}`;
          if (piece === 'W' || piece === 'B') token.innerHTML = '<span>♛</span>';
          cell.append(token);
        } else if (selected !== null && availableMoves(selected).some(move => move.to === n)) {
          cell.classList.add('hint-target');
          cell.innerHTML = '<span class="target-dot"></span>';
        }
        cell.addEventListener('click', () => handleSquare(n));
      }
      boardEl.append(cell);
    }
  }
}
function squareFor(row, col) {
  return squareAtPosition(row, col) ?? null;
}
function handleSquare(square) {
  if (!isReady || isThinking || gameOver || sideToMove !== 'w') return;
  if (selected !== null) {
    const choices = availableMoves(selected).filter(move => move.to === square);
    if (choices.length) { playHumanMove(choices[0]); return; }
  }
  if (sideOf(board[square]) === sideToMove) {
    selected = selected === square ? null : square;
    updateBoardAndStatus(selected === null ? 'À vous de jouer.' : `Choisissez une destination pour la pièce ${square}.`);
  } else {
    selected = null;
    drawBoard();
  }
}
function takeSnapshot() {
  return { board: board.slice(), sideToMove, moveCount, lastMove: lastMove ? [...lastMove] : null, moveHistory: [...moveHistory], repetitions: new Map(repetitions) };
}
function restoreSnapshot(snapshot) {
  board = snapshot.board.slice(); sideToMove = snapshot.sideToMove; moveCount = snapshot.moveCount;
  lastMove = snapshot.lastMove ? [...snapshot.lastMove] : null; moveHistory = [...snapshot.moveHistory];
  repetitions = new Map(snapshot.repetitions); selected = null; gameOver = false;
  legalMoves = generateLegalMoves(board, sideToMove);
  engineLabel.textContent = 'Prêt'; turnLabel.textContent = sideToMove === 'w' ? 'À vous' : 'Scan joue';
  messageEl.textContent = 'Tour annulé. À vous de jouer.';
  undoButton.disabled = undoStack.length === 0;
  drawBoard();
}
function updateBoardAndStatus(message) {
  drawBoard();
  messageEl.textContent = message;
  undoButton.disabled = undoStack.length === 0 || isThinking;
}
function addPositionOccurrence() {
  const key = positionKey(board, sideToMove);
  const count = (repetitions.get(key) ?? 0) + 1;
  repetitions.set(key, count);
  return count;
}
function endIfNeeded() {
  legalMoves = generateLegalMoves(board, sideToMove);
  if (!legalMoves.length) {
    gameOver = true;
    const winner = opponent(sideToMove);
    const winnerLabel = winner === 'w' ? 'Vous gagnez' : 'Scan gagne';
    engineLabel.textContent = 'Partie terminée';
    turnLabel.textContent = 'Terminé';
    updateBoardAndStatus(`${winnerLabel} : aucune prise ni aucun déplacement légal.`);
    if (pendingRoundSnapshot) { undoStack.push(pendingRoundSnapshot); pendingRoundSnapshot = null; }
    undoButton.disabled = undoStack.length === 0;
    return true;
  }
  if ((repetitions.get(positionKey(board, sideToMove)) ?? 0) >= 3) {
    gameOver = true; engineLabel.textContent = 'Partie nulle'; turnLabel.textContent = 'Nulle';
    updateBoardAndStatus('Partie nulle : la même position s’est répétée trois fois.');
    if (pendingRoundSnapshot) { undoStack.push(pendingRoundSnapshot); pendingRoundSnapshot = null; }
    undoButton.disabled = undoStack.length === 0;
    return true;
  }
  return false;
}
function playHumanMove(move) {
  pendingRoundSnapshot = takeSnapshot();
  board = applyMove(board, move);
  lastMove = [...move.path];
  moveHistory.push(moveToHub(move));
  moveCount++; sideToMove = 'b'; selected = null;
  addPositionOccurrence();
  if (endIfNeeded()) return;
  isThinking = true; engineLabel.textContent = 'En calcul'; turnLabel.textContent = 'Scan réfléchit…';
  updateBoardAndStatus('Scan réfléchit…');
  // Scan.js has a fast-path for forced moves that omits the Hub `done` message.
  // Since the legal move generator already proved there is only one choice, play it directly.
  if (legalMoves.length === 1) {
    const forced = legalMoves[0];
    window.setTimeout(() => {
      if (isThinking && sideToMove === 'b' && !gameOver) playEngineMove(moveToHub(forced));
    }, 120);
  } else {
    sendPositionAndThink();
  }
}
function sendPositionAndThink() {
  if (!worker) return;
  worker.postMessage(`pos start moves="${moveHistory.join(' ')}"`);
  worker.postMessage(`level depth=${depthLevels[difficultySelect.value] ?? depthLevels.normal}`);
  worker.postMessage('go think');
}
function playEngineMove(notation) {
  const candidates = legalMoves.filter(move => moveMatchesEngine(move, notation));
  if (!candidates.length) {
    isThinking = false; gameOver = true; engineLabel.textContent = 'Erreur moteur'; turnLabel.textContent = 'À vérifier';
    updateBoardAndStatus(`Le coup annoncé par Scan (${notation}) n’a pas été reconnu comme légal.`);
    return;
  }
  const move = candidates[0];
  board = applyMove(board, move); lastMove = [...move.path];
  moveHistory.push(notation); moveCount++; sideToMove = 'w'; isThinking = false;
  addPositionOccurrence();
  engineLabel.textContent = 'Prêt'; turnLabel.textContent = 'À vous';
  if (pendingRoundSnapshot) { undoStack.push(pendingRoundSnapshot); pendingRoundSnapshot = null; }
  if (!endIfNeeded()) updateBoardAndStatus(`Scan a joué ${notation}. À vous !`);
  undoButton.disabled = undoStack.length === 0;
}
function processEngineLine(line) {
  if (line === 'ready') {
    isReady = true; engineLabel.textContent = 'Prêt';
    messageEl.textContent = 'À vous : sélectionnez une pièce blanche pour voir ses coups légaux.';
    drawBoard(); return;
  }
  if (line.startsWith('done')) {
    if (!isThinking || sideToMove !== 'b') return; // ignore a late reply from a reset game
    const match = line.match(/\bmove=([^\s]+)/);
    if (!match || match[1] === 'none') {
      isThinking = false; legalMoves = generateLegalMoves(board, sideToMove);
      if (!legalMoves.length) endIfNeeded();
      else { engineLabel.textContent = 'Erreur moteur'; updateBoardAndStatus('Scan n’a pas renvoyé de coup. Réessayez ou démarrez une nouvelle partie.'); }
      return;
    }
    playEngineMove(match[1]);
    return;
  }
  if (line.startsWith('error')) {
    isThinking = false; engineLabel.textContent = 'Erreur moteur';
    updateBoardAndStatus(line);
  }
}
function startNewGame() {
  board = createInitialBoard(); sideToMove = 'w'; legalMoves = generateLegalMoves(board, sideToMove);
  selected = null; isThinking = false; gameOver = false; moveCount = 0; lastMove = null;
  moveHistory = []; repetitions = new Map([[positionKey(board, sideToMove), 1]]); undoStack = []; pendingRoundSnapshot = null;
  engineLabel.textContent = isReady ? 'Prêt' : 'Démarrage…'; turnLabel.textContent = 'À vous';
  updateBoardAndStatus(isReady ? 'Nouvelle partie. À vous de jouer.' : 'Chargement du moteur Scan…');
  worker?.postMessage('new-game');
  undoButton.disabled = true;
}
function undoLastTurn() {
  if (isThinking || !undoStack.length) return;
  restoreSnapshot(undoStack.pop());
  worker?.postMessage('new-game');
  // The next engine search receives the full move list from the restored game state.
}
function showToast(text) {
  toast.textContent = text; toast.classList.add('visible');
  setTimeout(() => toast.classList.remove('visible'), 3500);
}

document.querySelector('#new-game').addEventListener('click', () => { startNewGame(); navigateTo('jouer'); });
document.querySelector('#help').addEventListener('click', () => showToast('Les prises sont obligatoires, et il faut choisir une séquence qui capture le maximum de pièces. Les dames se déplacent sur toute diagonale libre.'));
undoButton.addEventListener('click', undoLastTurn);
difficultySelect.addEventListener('change', () => showToast(`Niveau Scan : ${difficultySelect.options[difficultySelect.selectedIndex].text}`));
menuToggle.addEventListener('click', () => setDrawer(!drawer.classList.contains('open')));
document.querySelector('#drawer-close').addEventListener('click', () => setDrawer(false));
drawerBackdrop.addEventListener('click', () => setDrawer(false));
document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => navigateTo(button.dataset.page)));
document.addEventListener('keydown', event => { if (event.key === 'Escape') setDrawer(false); });

drawBoard();
try {
  worker = new Worker(`${BASE_URL}scan-normal.worker.js`);
  worker.onmessage = event => processEngineLine(String(event.data));
  worker.onerror = () => {
    isThinking = false; engineLabel.textContent = 'Indisponible';
    messageEl.textContent = 'Le moteur n’a pas démarré. Consultez le diagnostic dans la console.';
    showToast('Échec du démarrage de Scan 3.1.');
  };
  let initSent = false;
  worker.addEventListener('message', event => {
    if (String(event.data) === 'wait' && !initSent) {
      initSent = true;
      worker.postMessage('set-param name=tt-size value=16');
      worker.postMessage('set-param name=bb-size value=0');
      worker.postMessage('init');
    }
  });
  worker.postMessage('hub');
} catch (error) {
  engineLabel.textContent = 'Indisponible';
  messageEl.textContent = `Impossible de créer le Web Worker : ${error.message}`;
}

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register(`${BASE_URL}sw.js`, { scope: BASE_URL }).catch(error => console.warn('Service worker non disponible :', error)));
}
