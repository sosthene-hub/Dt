import './style.css';
import { engine } from './engine.js';
import { store } from './store.js';
import { createGamePage } from './pages/game.js';
import { createEditorPage } from './pages/editor.js';
import { createAnalysisPage } from './pages/analysis.js';
import { createImportPage } from './pages/import.js';
import { createGeneratorPage } from './pages/generateur.js';

const app = document.querySelector('#app');
const pages = [
  { id: 'jouer', title: 'Accueil / Jouer', icon: '◉', desc: 'Lancez une partie locale contre Scan 3.1.', component: 'game' },
  { id: 'creer', title: 'Créer une partie', icon: '＋', desc: 'Configurez une nouvelle partie et choisissez les paramètres de jeu.', component: 'create' },
  { id: 'analyse', title: 'Damier d’analyse', icon: '⌕', desc: 'Étudiez une position et ses variantes avec le moteur Scan.', component: 'analysis' },
  { id: 'editeur', title: 'Éditeur de partie', icon: '▧', desc: 'Placez les pièces et composez une position sur le damier.', component: 'editor' },
  { id: 'importer', title: 'Importer une partie', icon: '⇧', desc: 'Chargez une partie au format PDN pour la revoir.', component: 'import' },
  { id: 'generateur', title: 'Générateur de positions', icon: '⠿', desc: 'Créez des positions selon vos contraintes d’entraînement.', component: 'generator' },
  { id: 'recherche', title: 'Recherche avancée', icon: '⌕', desc: 'Recherchez une position, une partie ou une séquence.', component: 'placeholder' },
];

let currentPage = 'jouer';
const instances = new Map();

app.innerHTML = `
  <header class="topbar">
    <button class="menu-button" id="menu-toggle" aria-label="Ouvrir le menu" aria-controls="app-drawer" aria-expanded="false" title="Menu"><span></span><span></span><span></span></button>
    <div class="brand"><span class="brand-mark">D</span><div><strong>DAMES</strong><small>ENTRAÎNEMENT 10×10</small></div></div>
    <button class="icon-button" id="new-game" aria-label="Nouvelle partie" title="Nouvelle partie">↻</button>
  </header>
  <div class="drawer-backdrop" id="drawer-backdrop"></div>
  <aside class="drawer" id="app-drawer" aria-label="Navigation principale" aria-hidden="true">
    <div class="drawer-header"><div class="drawer-brand"><span class="brand-mark">D</span><div><strong>DAMES</strong><small>ESPACE D’ENTRAÎNEMENT</small></div></div><button class="drawer-close" id="drawer-close" aria-label="Fermer le menu">×</button></div>
    <div class="drawer-label">MENU PRINCIPAL</div>
    <nav class="drawer-nav" id="drawer-nav" aria-label="Sections">
      ${pages.map(page => `<button class="nav-item ${page.id === 'jouer' ? 'active' : ''}" data-page="${page.id}" ${page.id === 'jouer' ? 'aria-current="page"' : ''}><span class="nav-icon" aria-hidden="true">${page.icon}</span><span>${page.title}</span>${page.id === 'jouer' ? '<span class="nav-dot"></span>' : ''}</button>`).join('')}
    </nav>
    <div class="drawer-bottom"><span class="engine-mini-dot" id="engine-dot"></span><div><b>Scan 3.1</b><small id="engine-status">Démarrage…</small></div></div>
  </aside>
  <main id="main-content"><div id="page-root"></div></main>
  <footer>Jeu local · Dames internationales · Aucun compte requis</footer>
  <div class="toast" id="toast" role="status"></div>
`;

const pageRoot = document.querySelector('#page-root');
const toastEl = document.querySelector('#toast');
const drawer = document.querySelector('#app-drawer');
const menuToggle = document.querySelector('#menu-toggle');
const drawerBackdrop = document.querySelector('#drawer-backdrop');
const engineStatus = document.querySelector('#engine-status');
const engineDot = document.querySelector('#engine-dot');

function showToast(text) {
  toastEl.textContent = text;
  toastEl.classList.add('visible');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toastEl.classList.remove('visible'), 3500);
}

function setDrawer(open) {
  drawer.classList.toggle('open', open);
  drawerBackdrop.classList.toggle('visible', open);
  drawer.setAttribute('aria-hidden', String(!open));
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
  if (open) drawer.querySelector('.nav-item.active')?.focus();
  else menuToggle.focus({ preventScroll: true });
}

function plannedDescription(pageId) {
  const notes = {
    recherche: 'Filtres de position et recherche de séquences de coups.',
  };
  return notes[pageId] ?? 'Outils d’entraînement aux dames internationales.';
}

function renderCreatePage(root) {
  root.innerHTML = `
    <div class="section-heading"><div class="eyebrow">PARTIE LOCALE · SCAN 3.1</div><h1>Créer une partie</h1><p>Choisissez la force de Scan, puis lancez une partie d’entraînement.</p></div>
    <article class="coming-card create-game-card"><div class="coming-icon" aria-hidden="true">＋</div><div class="coming-copy"><span class="coming-badge">PRÊT À JOUER</span><h2>Partie locale</h2><p>Vous jouez les blancs ; Scan joue les noirs. Les coups sont calculés sur cet appareil.</p></div></article>
    <div class="create-levels"><label for="create-difficulty">Niveau de Scan</label><select id="create-difficulty"><option value="facile">Facile · profondeur 3</option><option value="normal">Normal · profondeur 5</option><option value="fort">Fort · profondeur 7</option></select></div>
    <button class="start-game-button" id="start-created-game">Commencer une partie <span>→</span></button>
  `;
  const createSelect = root.querySelector('#create-difficulty');
  createSelect.value = store.difficulty;
  createSelect.addEventListener('change', () => { store.difficulty = createSelect.value; });
  root.querySelector('#start-created-game').addEventListener('click', () => {
    store.difficulty = createSelect.value;
    store.pendingNewGame = true;
    navigateTo('jouer');
    showToast(`Nouvelle partie · niveau ${createSelect.options[createSelect.selectedIndex].text.split(' · ')[0].toLowerCase()}`);
  });
}

function renderPlaceholder(root, page) {
  root.innerHTML = `
    <div class="section-heading"><div class="eyebrow">ESPACE D’ENTRAÎNEMENT · PRÉPARATION</div><h1>${page.title}</h1><p>${page.desc}</p></div>
    <article class="coming-card"><div class="coming-icon" aria-hidden="true">${page.icon}</div><div class="coming-copy"><span class="coming-badge">SECTION ACCESSIBLE</span><h2>Bienvenue dans ${page.title.toLowerCase()}</h2><p>La navigation est en place. Le contenu et les outils de cette section seront développés dans les prochaines phases.</p></div></article>
    <div class="planned-card"><span class="planned-mark">✦</span><div><b>Prévu pour cette section</b><p>${plannedDescription(page.id)}</p></div></div>
    <button class="back-to-game" data-go-home><span>←</span> Retour à la partie</button>
  `;
  root.querySelector('[data-go-home]')?.addEventListener('click', () => navigateTo('jouer'));
}

function createPage(page) {
  switch (page.component) {
    case 'game': return createGamePage({ toast: showToast });
    case 'editor': return createEditorPage({ navigate: navigateTo, toast: showToast });
    case 'analysis': return createAnalysisPage({ navigate: navigateTo, toast: showToast });
    case 'import': return createImportPage({ navigate: navigateTo, toast: showToast });
    case 'generator': return createGeneratorPage({ navigate: navigateTo, toast: showToast });
    case 'create': return { el: createCreateElement(), mount() {} };
    default: return { el: createPlaceholderElement(page), mount() {} };
  }
}

function createCreateElement() {
  const el = document.createElement('div');
  renderCreatePage(el);
  return el;
}

function createPlaceholderElement(page) {
  const el = document.createElement('div');
  renderPlaceholder(el, page);
  return el;
}

function navigateTo(pageId) {
  const page = pages.find(item => item.id === pageId) ?? pages[0];
  currentPage = page.id;
  document.querySelectorAll('.nav-item').forEach(button => {
    const active = button.dataset.page === currentPage;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
    button.querySelector('.nav-dot')?.remove();
    if (active) button.insertAdjacentHTML('beforeend', '<span class="nav-dot"></span>');
  });
  if (!instances.has(page.id)) instances.set(page.id, createPage(page));
  const instance = instances.get(page.id);
  pageRoot.innerHTML = '';
  pageRoot.append(instance.el);
  instance.mount?.();
  document.title = page.id === 'jouer' ? 'Dames — entraînement' : `${page.title} — Dames`;
  setDrawer(false);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelector('#new-game').addEventListener('click', () => { store.pendingNewGame = true; navigateTo('jouer'); });
menuToggle.addEventListener('click', () => setDrawer(!drawer.classList.contains('open')));
document.querySelector('#drawer-close').addEventListener('click', () => setDrawer(false));
drawerBackdrop.addEventListener('click', () => setDrawer(false));
document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => navigateTo(button.dataset.page)));
document.addEventListener('keydown', event => { if (event.key === 'Escape') setDrawer(false); });

engine.onReady(() => {
  engineStatus.textContent = 'Prêt · hors ligne';
  engineDot.style.background = '#7fb78d';
});
engine.onError(message => {
  engineStatus.textContent = 'Indisponible';
  engineDot.style.background = '#c75f5f';
  console.warn(message);
});
engine.start();

navigateTo('jouer');
