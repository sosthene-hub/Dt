import './style.css';
import { engine } from './engine.js';
import { store } from './store.js';
import { createGamePage } from './pages/game.js';
import { createEditorPage } from './pages/editor.js';
import { createAnalysisPage } from './pages/analysis.js';
import { createImportPage } from './pages/import.js';
import { createCombinaisonsPage } from './pages/combinaisons.js';
import { createScanVsScanPage } from './pages/scan-vs-scan.js';
import { createBasePage } from './base/page.js';
import { createStudyPage } from './pages/etude.js';

const app = document.querySelector('#app');
const pages = [
  { id: 'jouer', title: 'Accueil / Jouer', icon: '◉', desc: 'Lancez une partie locale contre PIONICIDE.', component: 'game' },
  { id: 'scan-vs-scan', title: 'PIONICIDE contre PIONICIDE', icon: '⚔', desc: 'Deux moteurs PIONICIDE jouent l’un contre l’autre, coup par coup.', component: 'svs' },
  { id: 'analyse', title: 'Damier d’analyse', icon: '⌕', desc: 'Étudiez une position et ses variantes avec le moteur PIONICIDE.', component: 'analysis' },
  { id: 'editeur', title: 'Éditeur de partie', icon: '▧', desc: 'Placez les pièces et composez une position sur le damier.', component: 'editor' },
  { id: 'importer', title: 'Importer une partie', icon: '⇧', desc: 'Chargez une partie au format PDN pour la revoir.', component: 'import' },
  { id: 'etude', title: 'Partie commentée', icon: '✎', desc: 'Étudiez une partie : base de parties et moteur, dans un document imprimable.', component: 'etude' },
  { id: 'combinaisons', title: 'Combinaisons', icon: '♛', desc: 'Tirez une combinaison du livre par rafle et par niveau.', component: 'combinaisons' },
  { id: 'base', title: 'Base de parties', icon: '▤', desc: 'Explorez les ouvertures et cherchez une structure dans une base de parties de maîtres.', component: 'base' },
];

let currentPage = 'jouer';
const instances = new Map();

app.innerHTML = `
  <header class="topbar">
    <button class="menu-button" id="menu-toggle" aria-label="Ouvrir le menu" aria-controls="app-drawer" aria-expanded="false" title="Menu"><span></span><span></span><span></span></button>
    <div class="brand"><span class="brand-mark">P</span><div><strong>PIONICIDE</strong><small>DAMES · ENTRAÎNEMENT 10×10</small></div></div>
    <button class="icon-button" id="new-game" aria-label="Nouvelle partie" title="Nouvelle partie">↻</button>
  </header>
  <div class="drawer-backdrop" id="drawer-backdrop"></div>
  <aside class="drawer" id="app-drawer" aria-label="Navigation principale" aria-hidden="true">
    <div class="drawer-header"><div class="drawer-brand"><span class="brand-mark">P</span><div><strong>PIONICIDE</strong><small>ESPACE D’ENTRAÎNEMENT</small></div></div><button class="drawer-close" id="drawer-close" aria-label="Fermer le menu">×</button></div>
    <div class="drawer-label">MENU PRINCIPAL</div>
    <nav class="drawer-nav" id="drawer-nav" aria-label="Sections">
      ${pages.map(page => `<button class="nav-item ${page.id === 'jouer' ? 'active' : ''}" data-page="${page.id}" ${page.id === 'jouer' ? 'aria-current="page"' : ''}><span class="nav-icon" aria-hidden="true">${page.icon}</span><span>${page.title}</span>${page.id === 'jouer' ? '<span class="nav-dot"></span>' : ''}</button>`).join('')}
    </nav>
    <div class="drawer-bottom"><span class="engine-mini-dot" id="engine-dot"></span><div><b>PIONICIDE</b><small id="engine-status">Démarrage…</small></div></div>
  </aside>
  <main id="main-content"><div id="page-root"></div></main>
  <footer>PIONICIDE · Jeu local · Dames internationales 10×10 · Aucun compte requis</footer>
  <div class="toast" id="toast" role="status"></div>
`;

const pageRoot = document.querySelector('#page-root');
const toastEl = document.querySelector('#toast');
const drawer = document.querySelector('#app-drawer');
const menuToggle = document.querySelector('#menu-toggle');
const drawerBackdrop = document.querySelector('#drawer-backdrop');
const engineStatus = document.querySelector('#engine-status');
const engineDot = document.querySelector('#engine-dot');

function showToast(text) {
  toastEl.textContent = text;
  toastEl.classList.add('visible');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toastEl.classList.remove('visible'), 3500);
}

function setDrawer(open) {
  drawer.classList.toggle('open', open);
  drawerBackdrop.classList.toggle('visible', open);
  drawer.setAttribute('aria-hidden', String(!open));
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
  if (open) drawer.querySelector('.nav-item.active')?.focus();
  else menuToggle.focus({ preventScroll: true });
}

function plannedDescription(pageId) {
  const notes = {};
  return notes[pageId] ?? 'Outils d’entraînement aux dames internationales.';
}

function renderPlaceholder(root, page) {
  root.innerHTML = `
    <div class="section-heading"><div class="eyebrow">ESPACE D’ENTRAÎNEMENT · PRÉPARATION</div><h1>${page.title}</h1><p>${page.desc}</p></div>
    <article class="coming-card"><div class="coming-icon" aria-hidden="true">${page.icon}</div><div class="coming-copy"><span class="coming-badge">SECTION ACCESSIBLE</span><h2>Bienvenue dans ${page.title.toLowerCase()}</h2><p>La navigation est en place. Le contenu et les outils de cette section seront développés dans les prochaines phases.</p></div></article>
    <div class="planned-card"><span class="planned-mark">✦</span><div><b>Prévu pour cette section</b><p>${plannedDescription(page.id)}</p></div></div>
    <button class="back-to-game" data-go-home><span>←</span> Retour à la partie</button>
  `;
  root.querySelector('[data-go-home]')?.addEventListener('click', () => navigateTo('jouer'));
}

function createPage(page) {
  switch (page.component) {
    case 'game': return createGamePage({ navigate:navigateTo, toast: showToast });
    case 'editor': return createEditorPage({ navigate: navigateTo, toast: showToast });
    case 'analysis': return createAnalysisPage({ navigate: navigateTo, toast: showToast });
    case 'import': return createImportPage({ navigate: navigateTo, toast: showToast });
    case 'combinaisons': return createCombinaisonsPage({ navigate: navigateTo, toast: showToast });
    case 'svs': return createScanVsScanPage({ toast: showToast, navigate: navigateTo });
    case 'base': return createBasePage({ navigate: navigateTo, toast: showToast });
    case 'etude': return createStudyPage({ navigate: navigateTo, toast: showToast });
    default: return { el: createPlaceholderElement(page), mount() {} };
  }
}

function createPlaceholderElement(page) {
  const el = document.createElement('div');
  renderPlaceholder(el, page);
  return el;
}

/* ---- Phase 6 : le projet est bouclé — version publiée, installation, mise à jour ---- */
const APP_VERSION = '1.0.0';
const INSTALL_KEY = 'pionicide.invite-installation';

function isStandalone() {
  return window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
}

/** Bandeau discret « Installer PIONICIDE » (Chrome Android / ordinateur). */
function setupInstallInvite() {
  const banner = document.createElement('div');
  banner.className = 'install-banner';
  banner.hidden = true;
  banner.innerHTML = '<span>Installer PIONICIDE sur cet appareil : plein écran, hors ligne, sans compte.</span>'
    + '<button class="primary-button" type="button" data-install>Installer</button>'
    + '<button class="icon-button" type="button" data-dismiss aria-label="Plus tard">×</button>';
  document.body.append(banner);
  const dismiss = banner.querySelector('[data-dismiss]');
  const install = banner.querySelector('[data-install]');
  let prompt = null;
  const hide = () => { banner.hidden = true; };
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    prompt = event;
    if (localStorage.getItem(INSTALL_KEY) === 'non' || isStandalone()) return;
    banner.hidden = false;
  });
  install.addEventListener('click', async () => {
    hide();
    try { await prompt?.prompt?.(); } catch (error) { console.warn('Installation refusée :', error.message); }
    prompt = null;
  });
  dismiss.addEventListener('click', () => { localStorage.setItem(INSTALL_KEY, 'non'); hide(); });
  window.addEventListener('appinstalled', () => { localStorage.setItem(INSTALL_KEY, 'faite'); hide(); showToast('PIONICIDE installé : il s’ouvre désormais en plein écran, même hors ligne.'); });
}

/** Applique un lien direct (#base, #analyse…) puis le nettoie, sans recharger la page. */
function pageFromHash() {
  const id = decodeURIComponent(location.hash.replace(/^#/, '')).trim();
  return pages.some(page => page.id === id) ? id : null;
}

function setupHashNavigation() {
  window.addEventListener('hashchange', () => {
    const id = pageFromHash();
    if (id && id !== currentPage) navigateTo(id);
  });
}

function navigateTo(pageId) {
  const page = pages.find(item => item.id === pageId) ?? pages[0];
  instances.get(currentPage)?.unmount?.();
  currentPage = page.id;
  document.querySelectorAll('.nav-item').forEach(button => {
    const active = button.dataset.page === currentPage;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
    button.querySelector('.nav-dot')?.remove();
    if (active) button.insertAdjacentHTML('beforeend', '<span class="nav-dot"></span>');
  });
  if (!instances.has(page.id)) instances.set(page.id, createPage(page));
  const instance = instances.get(page.id);
  pageRoot.innerHTML = '';
  pageRoot.append(instance.el);
  instance.mount?.();
  document.title = page.id === 'jouer' ? 'PIONICIDE — dames 10×10' : `${page.title} — PIONICIDE`;
  if (pageFromHash() !== page.id) history.replaceState(null, '', page.id === 'jouer' ? location.pathname + location.search : `#${page.id}`);
  setDrawer(false);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelector('#new-game').addEventListener('click', () => { store.pendingNewGame = true; navigateTo('jouer'); });
menuToggle.addEventListener('click', () => setDrawer(!drawer.classList.contains('open')));
document.querySelector('#drawer-close').addEventListener('click', () => setDrawer(false));
drawerBackdrop.addEventListener('click', () => setDrawer(false));
document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => navigateTo(button.dataset.page)));
document.addEventListener('keydown', event => { if (event.key === 'Escape') setDrawer(false); });

engine.onReady(() => {
  engineStatus.textContent = `Prêt · ${engine.runtimeInfo?.runtime||'WASM'} · ${engine.settings.hashMiB} Mio · 1 fil`; 
  engineDot.style.background = '#7fb78d';
});
engine.onError(message => {
  engineStatus.textContent = 'Indisponible';
  engineDot.style.background = '#c75f5f';
  console.warn(message);
});
startLocalEngine();

navigateTo(pageFromHash() || 'jouer');
setupHashNavigation();
setupInstallInvite();
console.info(`PIONICIDE ${APP_VERSION} — ${isStandalone() ? 'installé' : 'navigateur'}`);

// Cache before starting PIONICIDE: avoids downloading its large data file twice at first launch.
async function startLocalEngine(){
 if(import.meta.env.PROD && 'serviceWorker' in navigator && /^https?:$/.test(location.protocol)){
  try{await Promise.race([(async()=>{await navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`);await navigator.serviceWorker.ready;if(!navigator.serviceWorker.controller)await new Promise(resolve=>navigator.serviceWorker.addEventListener('controllerchange',resolve,{once:true}));})(),new Promise((_,reject)=>setTimeout(()=>reject(Error('délai de cache dépassé')),20000))]);}catch(error){console.warn('Cache hors ligne non installé :',error.message);}
 }
 engine.start();
}
