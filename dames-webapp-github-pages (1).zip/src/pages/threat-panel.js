import {
  THREAT_DEFAULTS,
  analyseThreats,
  createMemoSearch,
  describeCreated,
  describeAvoided,
  moveNumberOf,
  threatSummaryText,
  analyseThreatSlice,
  summarise,
} from '../analysis/threats.js';
import { moveToPdn } from '../pdn.js';

const CREATED_COLOR = '#2f9e5b';
const AVOIDED_COLOR = '#e08a1e';
const CAPTURE_COLOR = '#c0392b';

/* La profondeur n'est plus réglée ici : elle suit le sélecteur « Profondeur »
   du damier d'analyse (host.analysisDepth), un seul réglage pour tout. */

/**
 * Panneau « Menaces de la partie » de l'écran d'analyse.
 *
 * L'interface ne calcule rien elle-même : elle règle la portée et la profondeur,
 * affiche le récapitulatif, les repères de la liste des coups et les flèches
 * numérotées du damier. Toutes les évaluations passent par le cache partagé,
 * donc l'analyse annotée et l'analyse des menaces ne calculent jamais deux fois
 * la même position.
 */
export function createThreatPanel({ host, toast = () => {} } = {}) {
  const el = document.createElement('section');
  el.className = 'panel threat-panel';
  el.innerHTML = `
    <div class="section-heading">
      <div class="eyebrow">MENACES · CE QUE LE COUP CRÉE ET CE QU’IL ÉVITE</div>
      <h2>Menaces de la partie</h2>
      <p>Pour chaque coup joué : la menace qu’il crée (le camp qui vient de jouer rejoue, l’adversaire passe) et la menace adverse qu’il écarte (on rend le trait à l’adversaire avant le coup, puis on vérifie que le coup la pare). Calculs sur des copies : la partie enregistrée n’est jamais modifiée.</p>
    </div>
    <div class="export-grid">
      <div class="export-main">
        <div class="replay-toolbar">
          <button class="primary-button" id="th-run">Analyser les menaces de la partie</button>
          <button class="secondary-button" id="th-stop" hidden>Arrêter</button>
          <button class="secondary-button" id="th-created" disabled>Menace créée du coup affiché</button>
          <button class="secondary-button" id="th-avoided" disabled>Menace évitée du coup affiché</button>
          <button class="secondary-button" id="th-clear">Revenir à la partie</button>
        </div>
        <p id="th-status" class="study-context" role="status">Aucune analyse des menaces.</p>
        <div id="th-summary" class="threat-summary"></div>
        <p id="th-detail" class="threat-detail" role="status"></p>
        <p class="threat-legend">
          <span class="threat-badge threat-created" aria-hidden="true">▲</span> menace créée
          · <span class="threat-badge threat-avoided" aria-hidden="true">▼</span> menace évitée
          · flèches numérotées 1, 2, 3 : vert = créée, orange = évitée, rouge = rafle ou combinaison (nombre de pions indiqué).
        </p>
      </div>
      <div class="export-settings">
        <label>Portée
          <select id="th-scope">
            <option value="all">Toute la partie</option>
            <option value="w">Coups des Blancs</option>
            <option value="b">Coups des Noirs</option>
            <option value="range">Plage de coups</option>
          </select>
        </label>
        <div class="export-thresholds" id="th-range" hidden>
          <label>Du coup n°<input id="th-from" type="number" min="1" step="1" value="1" inputmode="numeric"></label>
          <label>Au coup n°<input id="th-to" type="number" min="1" step="1" value="20" inputmode="numeric"></label>
        </div>
        <label>Seuil de menace (pions)<input id="th-threshold" type="number" min="0.1" max="9" step="0.1" value="0.5" inputmode="decimal"></label>
        <label class="check-row"><input type="checkbox" id="th-export">Inclure les menaces dans le PDN et le PDF</label>
        <label class="check-row"><input type="checkbox" id="th-combine" checked>Un seul passage avec l’analyse annotée</label>
        <p class="study-context">Profondeur : celle du damier d’analyse (réglage unique, 16 par défaut). Seuil de menace 0,5 pion. Une prise immédiate n’est pas comptée comme une menace. Les évaluations déjà faites par l’analyse annotée sont réutilisées ; lancer les deux ensemble ne fait qu’un seul passage.</p>
      </div>
    </div>`;

  const q = id => el.querySelector(`#${id}`);
  let results = [];
  let summary = null;
  let meta = null;
  let busy = false;
  let stopFlag = false;
  let override = new Map(); // calculs relancés isolément sur un coup
  let applying = false;

  // Cache partagé avec l'analyse annotée (jamais deux fois la même position).
  const pending = () => (host.memo ? host.memo() : createMemoSearch(options => host.search(options)));

  function options() {
    const scopeKind = q('th-scope').value;
    const thresholdValue = Math.max(0.1, Math.min(9, Number(q('th-threshold').value) || THREAT_DEFAULTS.threshold));
    const shared = Number(host.analysisDepth?.());
    const depth = Math.max(2, Math.min(30, Number.isFinite(shared) && shared > 0 ? shared : THREAT_DEFAULTS.depth));
    return {
      depth,
      threshold: thresholdValue,
      scope: scopeKind === 'range'
        ? { kind: 'range', from: Math.max(1, Number(q('th-from').value) || 1), to: Math.max(1, Number(q('th-to').value) || 20) }
        : { kind: scopeKind },
      inExport: q('th-export').checked,
      combine: q('th-combine').checked,
    };
  }

  function setBusy(value) {
    busy = value;
    q('th-run').disabled = value;
    q('th-stop').hidden = !value;
    refreshButtons();
  }

  function refreshButtons() {
    const ply = currentPly();
    const enabled = !busy && ply !== null && host.moves().length > 0;
    q('th-created').disabled = !enabled;
    q('th-avoided').disabled = !enabled;
  }

  function currentPly() {
    const cursor = host.cursor?.() ?? 0;
    if (cursor <= 0 || cursor > host.moves().length) return null;
    return cursor - 1;
  }

  function entryFor(index) {
    return override.get(index) || results.find(entry => entry.index === index) || null;
  }

  function colourFor(kind, threat) {
    if (!threat) return kind === 'created' ? CREATED_COLOR : AVOIDED_COLOR;
    return threat.captures > 0 ? CAPTURE_COLOR : kind === 'created' ? CREATED_COLOR : AVOIDED_COLOR;
  }

  function arrowsFor(threat) {
    return (threat.line || []).slice(0, 3).map((move, position) => ({
      path: move.path,
      label: String(position + 1),
      color: colourFor(threat.kind, threat),
      dashed: position > 0,
    }));
  }

  /** Flèches et texte pour le coup `index` (index de demi-coup, 0 = premier coup). */
  function overlayFor(index, kind) {
    const entry = entryFor(index);
    if (!entry) return null;
    const wanted = kind || (entry.created ? 'created' : entry.avoided ? 'avoided' : null);
    if (!wanted) return null;
    const threat = entry[wanted];
    if (!threat) return null;
    const positioned = { ...threat, kind: wanted };
    return {
      kind: wanted,
      index,
      arrows: arrowsFor(positioned),
      color: colourFor(wanted, positioned),
      pieces: positioned.captures,
      text: wanted === 'created' ? describeCreated(positioned) : describeAvoided(positioned),
      positionAfterMove: wanted === 'created',
    };
  }

  function renderSummary() {
    const box = q('th-summary');
    box.replaceChildren();
    if (!summary) return;
    const line = (label, counts) => {
      const node = document.createElement('p');
      node.className = 'threat-counts';
      node.innerHTML = `<b>${label}</b><span>Blancs ${counts.w} · Noirs ${counts.b}</span>`;
      return node;
    };
    box.append(line('Menaces créées', summary.created), line('Menaces évitées', summary.avoided));
    if (summary.notParried) {
      const warn = document.createElement('p');
      warn.className = 'threat-warning';
      warn.textContent = `${summary.notParried} coup${summary.notParried > 1 ? 's' : ''} ne pare${summary.notParried > 1 ? 'nt' : ''} pas la menace adverse.`;
      box.append(warn);
    }
    if (summary.forced) {
      const note = document.createElement('p');
      note.className = 'study-context';
      note.textContent = `${summary.forced} coup${summary.forced > 1 ? 's' : ''} non calculable${summary.forced > 1 ? 's' : ''} : prise obligatoire en jeu.`;
      box.append(note);
    }
    if (!summary.top.length) {
      const none = document.createElement('p');
      none.className = 'study-context';
      none.textContent = 'Aucune menace réelle au-dessus du seuil choisi.';
      box.append(none);
      return;
    }
    const top = document.createElement('div');
    top.className = 'threat-top';
    const title = document.createElement('b');
    title.textContent = 'Coups les plus importants';
    top.append(title);
    for (const item of summary.top) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'secondary-button';
      const weightText = item.weight >= 90 ? 'gain décisif' : `${item.weight.toFixed(1).replace('.', ',')} pion${item.weight >= 2 ? 's' : ''}`;
      button.textContent = `${item.moveNumber}${item.side === 'w' ? '.' : '…'} ${item.played} · ${weightText}`;
      button.title = [item.created ? 'menace créée' : '', item.avoided ? 'menace évitée' : ''].filter(Boolean).join(' + ');
      button.onclick = () => {
        host.selectPly(item.index + 1);
        showPly(item.index);
      };
      top.append(button);
    }
    box.append(top);
  }

  /** Affichage pour un coup : flèches sur le damier et texte explicatif. */
  function showPly(index, kind = null) {
    if (applying) return;
    refreshButtons();
    const entry = entryFor(index);
    const detail = q('th-detail');
    if (!entry) {
      detail.textContent = '';
      host.setOverlay?.(null);
      return;
    }
    const cursor = host.cursor?.() ?? 0;
    let wanted = kind;
    if (!wanted) {
      if (entry.created && cursor === index + 1) wanted = 'created';
      else if (entry.avoided && cursor === index) wanted = 'avoided';
      else if (entry.created) wanted = 'created';
      else if (entry.avoided) wanted = 'avoided';
    }
    detail.textContent = threatSummaryText(entry);
    detail.classList.toggle('threat-detail-empty', !detail.textContent);
    const threat = wanted ? entry[wanted] : null;
    if (!threat) {
      host.setOverlay?.(null);
      if (!detail.textContent) detail.textContent = 'Aucune menace réelle sur ce coup.';
      return;
    }
    const boardCursor = wanted === 'created' ? index + 1 : index;
    if (kind && cursor !== boardCursor) {
      applying = true;
      host.selectPly?.(boardCursor);
      applying = false;
    }
    const positioned = { ...threat, kind: wanted };
    host.setOverlay?.({
      kind: wanted,
      index,
      arrows: arrowsFor(positioned),
      color: colourFor(wanted, positioned),
      pieces: positioned.captures,
      text: wanted === 'created' ? describeCreated(positioned) : describeAvoided(positioned),
      boardCursor,
    });
  }

  function clearOverlay() {
    host.setOverlay?.(null);
    q('th-detail').textContent = '';
  }

  async function run({ combined = false, depth: forcedDepth = null } = {}) {
    const moves = host.moves();
    if (!moves.length) {
      toast('Importez une partie ou jouez quelques coups avant d’analyser les menaces.');
      return null;
    }
    if (busy) return null;
    const settings = options();
    if (Number.isFinite(forcedDepth) && forcedDepth > 0) {
      // passage combiné avec l'annotation : même profondeur, celle du damier
      settings.depth = Math.max(2, Math.min(30, forcedDepth));
    }
    busy = true;
    stopFlag = false;
    refreshButtons();
    q('th-run').disabled = true;
    q('th-stop').hidden = false;
    q('th-status').textContent = `Analyse des menaces à la profondeur ${settings.depth}…`;
    try {
      const report = await analyseThreats({
        states: host.states(),
        moves,
        search: pending(),
        depth: settings.depth,
        threshold: settings.threshold,
        scope: settings.scope,
        onProgress: (done, total) => host.progress?.update?.(done, total, 'menaces'),
        shouldStop: () => stopFlag || host.isActive?.() === false,
      });
      if (report.cancelled) {
        q('th-status').textContent = 'Analyse des menaces interrompue.';
        return null;
      }
      const merged = new Map(results.map(entry => [entry.index, entry]));
      for (const entry of report.results) {
        if (entry.status === 'skipped') continue;
        merged.set(entry.index, entry);
      }
      results = [...merged.values()].sort((a, b) => a.index - b.index);
      summary = summarise(results);
      meta = { depth: report.depth, threshold: report.threshold, scope: settings.scope, combined };
      renderSummary();
      const examined = report.summary?.analysed ?? summary.analysed;
      const createdTotal = summary.created.w + summary.created.b;
      const avoidedTotal = summary.avoided.w + summary.avoided.b;
      const discarded = summary.discarded || 0;
      q('th-status').textContent = `${examined} coup${examined > 1 ? 's' : ''} examiné${examined > 1 ? 's' : ''} à la profondeur ${settings.depth} · seuil ${settings.threshold.toFixed(1).replace('.', ',')} pion · ${createdTotal} menace${createdTotal > 1 ? 's' : ''} créée${createdTotal > 1 ? 's' : ''}, ${avoidedTotal} évitée${avoidedTotal > 1 ? 's' : ''} au total`
        + `${discarded ? ` · ${discarded} ligne${discarded > 1 ? 's' : ''} écartée${discarded > 1 ? 's' : ''} (prise immédiate)` : ''}.`;
      host.afterUpdate?.();
      return report;
    } catch (error) {
      q('th-status').textContent = `Analyse des menaces impossible : ${error.message}`;
      toast(`Menaces : ${error.message}`);
      return null;
    } finally {
      busy = false;
      q('th-stop').hidden = true;
      q('th-run').disabled = false;
      refreshButtons();
    }
  }

  /** Relance un seul coup à la profondeur choisie (bouton « Menace créée / évitée »). */
  async function recompute(kind) {
    const index = currentPly();
    if (index === null) {
      toast('Placez-vous sur un coup joué, puis relancez.');
      return;
    }
    if (busy) return;
    const settings = options();
    const states = host.states();
    if (!states[index] || !states[index + 1]) return;
    busy = true;
    stopFlag = false;
    refreshButtons();
    q('th-created').disabled = true;
    q('th-avoided').disabled = true;
    q('th-status').textContent = `Recalcul ${kind === 'created' ? 'de la menace créée' : 'de la menace évitée'} du coup ${moveNumberOf(index)} à la profondeur ${settings.depth}…`;
    try {
      const slice = await analyseThreatSlice({
        before: states[index],
        after: states[index + 1],
        move: host.moves()[index],
        index,
        search: pending(),
        depth: settings.depth,
        threshold: settings.threshold,
        mode: kind,
      });
      if (!slice) return;
      override.set(index, slice);
      const at = results.findIndex(entry => entry.index === index);
      if (at >= 0) results[at] = slice;
      summary = summarise(results);
      renderSummary();
      host.afterUpdate?.();
      showPly(index, kind);
      q('th-status').textContent = `Coup ${slice.moveNumber} recalculé à la profondeur ${settings.depth}${slice[kind] ? '' : ' : aucune menace au-dessus du seuil'}.`;
    } catch (error) {
      q('th-status').textContent = `Recalcul impossible : ${error.message}`;
    } finally {
      busy = false;
      refreshButtons();
    }
  }

  q('th-run').addEventListener('click', () => run());
  q('th-stop').addEventListener('click', () => {
    stopFlag = true;
    q('th-status').textContent = 'Arrêt demandé…';
  });
  q('th-created').addEventListener('click', () => recompute('created'));
  q('th-avoided').addEventListener('click', () => recompute('avoided'));
  q('th-clear').addEventListener('click', () => {
    clearOverlay();
    toast('Flèches effacées : retour à la partie.');
  });
  q('th-scope').addEventListener('change', () => {
    q('th-range').hidden = q('th-scope').value !== 'range';
  });

  return {
    el,
    options,
    setBusy,
    run,
    overlayFor,
    render(report, extra = {}) {
      results = report?.results || [];
      summary = report?.summary || null;
      meta = { depth: report?.depth, threshold: report?.threshold, ...extra };
      override.clear();
      renderSummary();
      refreshButtons();
    },
    reset() {
      results = [];
      summary = null;
      meta = null;
      override.clear();
      q('th-summary').replaceChildren();
      q('th-detail').textContent = '';
      q('th-status').textContent = 'Aucune analyse des menaces.';
      host.setOverlay?.(null);
      refreshButtons();
    },
    results: () => results,
    entryFor,
    showPly,
    clearOverlay,
    isBusy: () => busy,
    summary: () => summary,
    meta: () => meta,
    /** Restaure des résultats mémorisés (aucun recalcul à la réouverture). */
    restore(report, extra = {}) {
      this.render(report, extra);
      if (report?.results?.length) {
        q('th-status').textContent = `Résultats mémorisés · profondeur ${report.depth} · ${report.summary?.analysed ?? report.results.length} coups examinés (aucun recalcul).`;
      }
    },
    refreshButtons,
  };
}
