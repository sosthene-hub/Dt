import { renderBoard } from '../board-view.js';
import { createInitialBoard, sideOf } from '../game-rules.js';
import { positionToPdn, validatePosition, countPieces, parsePdnPosition } from '../position.js';
import { store } from '../store.js';
import { validatePlayablePosition } from '../combinations/validator.js';

const TOOLS = [
  { id: 'w', label: 'Pion blanc', cls: 'white-piece' },
  { id: 'W', label: 'Dame blanche', cls: 'white-piece king' },
  { id: 'b', label: 'Pion noir', cls: 'black-piece' },
  { id: 'B', label: 'Dame noire', cls: 'black-piece king' },
  { id: 'erase', label: 'Gomme', cls: 'erase-tool' },
];

export function createEditorPage({ navigate, toast }) {
  const el = document.createElement('div');
  let board = store.positionDraft?.board ?? createInitialBoard();
  let side = store.positionDraft?.side ?? 'w';
  let tool = 'w';
  store.positionDraft = null;

  el.innerHTML = `
    <div class="section-heading"><div class="eyebrow">OUTILS · POSITIONS</div><h1>Éditeur de partie</h1><p>Placez les pièces, choisissez le trait, puis analysez la position ou copiez son code.</p></div>
    <section class="panel editor-panel">
      <div class="palette" role="toolbar" aria-label="Outils de placement">
        ${TOOLS.map(t => `
          <button type="button" class="palette-tool ${t.id === tool ? 'active' : ''}" data-tool="${t.id}" aria-pressed="${t.id === tool}" title="${t.label}">
            ${t.id === 'erase' ? '<span class="erase-mark">✕</span>' : `<span class="piece ${t.cls}">${t.id === 'W' || t.id === 'B' ? '<span>♛</span>' : ''}</span>`}
            <small>${t.label}</small>
          </button>`).join('')}
      </div>
      <div class="editor-grid">
        <div class="board-wrap"><div id="editor-board"></div></div>
        <aside class="editor-side">
          <div class="field-block">
            <span class="field-label">Trait</span>
            <div class="segmented" role="group" aria-label="Trait">
              <button type="button" class="segment ${side === 'w' ? 'active' : ''}" data-side="w">Blancs</button>
              <button type="button" class="segment ${side === 'b' ? 'active' : ''}" data-side="b">Noirs</button>
            </div>
          </div>
          <div class="field-block">
            <span class="field-label">Position</span>
            <div class="editor-actions">
              <button class="secondary-button" id="ed-initial" type="button">Position initiale</button>
              <button class="secondary-button" id="ed-clear" type="button">Vider</button>
              <button class="secondary-button" id="ed-flip" type="button">Inverser les camps</button>
            </div>
          </div>
          <div class="field-block">
            <span class="field-label">Contrôle</span>
            <div class="position-status" id="ed-status"></div>
          </div>
          <div class="field-block">
            <span class="field-label">Code de position</span>
            <div class="code-row"><input id="ed-code" type="text" readonly aria-label="Code de position au format PDN"><button class="secondary-button" id="ed-copy" type="button">Copier</button></div>
          </div>
          <button class="start-game-button" id="ed-analyze" type="button">Analyser cette position <span>→</span></button>
          <button class="secondary-button wide" id="ed-import" type="button">Importer un code…</button>
          <input id="ed-import-input" type="text" placeholder="W:W31,32:B18 ou code Hub sur 51 caractères" hidden />
          <details class="play-launcher" id="ed-play">
            <summary>Jouer contre PIONICIDE à partir de cette position</summary>
            <div class="play-launcher-body">
              <label class="field-block"><span class="field-label">Ma couleur</span>
                <select id="ed-play-color"><option value="w">Blancs</option><option value="b">Noirs</option></select></label>
              <label class="field-block"><span class="field-label">Camp au trait</span>
                <select id="ed-play-side"><option value="w">Blancs</option><option value="b">Noirs</option></select></label>
              <label class="field-block"><span class="field-label">Niveau de PIONICIDE</span>
                <select id="ed-play-level"><option value="facile">Facile · 12</option><option value="normal" selected>Normal · 16</option><option value="fort">Fort · 20</option><option value="expert">Expert · 22</option></select></label>
              <p id="ed-play-status" class="import-status" role="status"></p>
              <button class="start-game-button" id="ed-play-start" type="button">Lancer la partie <span>→</span></button>
            </div>
          </details>
        </aside>
      </div>
    </section>
  `;

  const boardEl = el.querySelector('#editor-board');
  const statusEl = el.querySelector('#ed-status');
  const codeEl = el.querySelector('#ed-code');
  const importInput = el.querySelector('#ed-import-input');

  function refresh() {
    const error = validatePosition(board, side);
    const counts = countPieces(board);
    statusEl.innerHTML = error
      ? `<span class="status-error">⚠ ${error}</span>`
      : `<span class="status-ok">✓ Position valide</span><div class="counts">Blancs : ${counts.white} dont ${counts.whiteKings} dame${counts.whiteKings > 1 ? 's' : ''} · Noirs : ${counts.black} dont ${counts.blackKings} dame${counts.blackKings > 1 ? 's' : ''}</div>`;
    const invalid = !!error;
    el.querySelector('#ed-analyze').disabled = invalid;
    const code = positionToPdn(board, side);
    codeEl.value = code;
    draw();
  }

  function draw() {
    renderBoard(boardEl, {
      board,
      orientation: 'w',
      onSquareClick: square => {
        if (tool === 'erase') board[square] = 'e';
        else board[square] = tool;
        refresh();
      },
    });
  }

  el.querySelectorAll('.palette-tool').forEach(button => button.addEventListener('click', () => {
    tool = button.dataset.tool;
    el.querySelectorAll('.palette-tool').forEach(other => {
      const active = other === button;
      other.classList.toggle('active', active);
      other.setAttribute('aria-pressed', String(active));
    });
  }));

  el.querySelectorAll('.segment').forEach(button => button.addEventListener('click', () => {
    side = button.dataset.side;
    el.querySelectorAll('.segment').forEach(other => other.classList.toggle('active', other === button));
    refresh();
  }));

  el.querySelector('#ed-initial').addEventListener('click', () => { board = createInitialBoard(); side = 'w'; syncSegments(); refresh(); });
  el.querySelector('#ed-clear').addEventListener('click', () => { board = Array(51).fill('e'); refresh(); });
  el.querySelector('#ed-flip').addEventListener('click', () => {
    const next = Array(51).fill('e');
    for (let square = 1; square <= 50; square++) {
      const piece = board[square];
      next[square] = piece === 'e' ? 'e' : (piece === piece.toLowerCase() ? piece.toUpperCase() : piece.toLowerCase());
    }
    board = next;
    side = side === 'w' ? 'b' : 'w';
    syncSegments();
    refresh();
  });

  function syncSegments() {
    el.querySelectorAll('.segment').forEach(other => other.classList.toggle('active', other.dataset.side === side));
  }

  el.querySelector('#ed-copy').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(codeEl.value);
      toast('Code de position copié.');
    } catch {
      codeEl.select();
      toast('Sélectionnez le code puis copiez-le (Ctrl+C).');
    }
  });

  el.querySelector('#ed-import').addEventListener('click', () => {
    const visible = importInput.hidden;
    importInput.hidden = !visible;
    if (visible) importInput.focus();
  });
  importInput.addEventListener('change', () => {
    const parsed = parsePdnPosition(importInput.value);
    if (!parsed) {
      toast('Code de position non reconnu.');
      importInput.value = '';
      return;
    }
    board = parsed.board; side = parsed.side;
    syncSegments();
    importInput.hidden = true;
    importInput.value = '';
    refresh();
    toast('Position importée.');
  });

  const playPanel=el.querySelector('#ed-play');const playStatus=el.querySelector('#ed-play-status');const playSide=el.querySelector('#ed-play-side');const playColor=el.querySelector('#ed-play-color');const playLevel=el.querySelector('#ed-play-level');
  function syncPlayDefaults(){playSide.value=side;playColor.value=side;}
  playPanel.addEventListener('toggle',()=>{if(playPanel.open)syncPlayDefaults();});
  el.querySelector('#ed-play-start').addEventListener('click',()=>{
    const errors=validatePlayablePosition(board,playSide.value);
    if(errors.length){playStatus.innerHTML=`<span class="status-error">⚠ ${errors.join(' ')}</span>`;return;}
    playStatus.innerHTML='<span class="status-ok">✓ Position acceptée.</span>';
    store.playDraft={board:board.slice(),side:playSide.value,human:playColor.value,level:playLevel.value,label:'Position éditée'};
    store.difficulty=playLevel.value;
    store.pendingNewGame=false;
    navigate('jouer');
    toast('Partie lancée depuis la position éditée.');
  });
  el.querySelector('#ed-analyze').addEventListener('click', () => {
    if (validatePosition(board, side)) return;
    store.positionDraft = { board: board.slice(), side };
    navigate('analyse');
    toast('Position envoyée au damier d’analyse.');
  });

  function mount() {
    if (store.positionDraft) {
      board = store.positionDraft.board.slice();
      side = store.positionDraft.side;
      store.positionDraft = null;
      syncSegments();
      refresh();
    }
  }

  mount();
  refresh();
  return { el, mount };
}
