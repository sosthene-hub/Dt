import { renderBoard } from '../board-view.js';
import { applyMove, createInitialBoard, generateLegalMoves, opponent } from '../game-rules.js';
import { parsePdnPosition, positionToPdn, validatePosition } from '../position.js';
import { gameToPdn, moveMatchesPdn, parsePdnGames } from '../pdn.js';
import { store } from '../store.js';

const AUTO_PLAY_DELAY = 900;

export function createImportPage({ navigate, toast }) {
  const el = document.createElement('div');
  let games = [];
  let selected = -1;
  let index = 0; // number of moves applied
  let error = null;
  let autoTimer = null;
  let disposed = false;

  el.innerHTML = `
    <div class="section-heading"><div class="eyebrow">PARTIES · PDN</div><h1>Importer une partie</h1><p>Chargez un fichier ou collez du texte PDN, puis revivez la partie coup par coup avec Scan.</p></div>
    <section class="panel import-panel">
      <div class="import-grid">
        <div class="import-left">
          <div class="import-actions">
            <label class="secondary-button file-button" for="pdn-file">📄 Choisir un fichier .pdn<input id="pdn-file" type="file" accept=".pdn,.txt,text/plain" hidden /></label>
            <button class="secondary-button" id="pdn-sample" type="button">Partie d’exemple</button>
            <button class="secondary-button" id="pdn-export" type="button" disabled>⤓ Exporter en PDN</button>
          </div>
          <textarea id="pdn-input" rows="9" spellcheck="false" placeholder="Collez ici une partie PDN, par exemple :
[Event &quot;Match&quot;]
[White &quot;Blanc&quot;]
[Black &quot;Noir&quot;]
1. 32-28 17-22 2. 37-32 *"></textarea>
          <button class="start-game-button" id="pdn-load" type="button">Lire la partie <span>→</span></button>
          <div class="import-status" id="pdn-status">Aucune partie chargée.</div>
        </div>
        <div class="import-right">
          <div class="player-row"><div class="avatar dark-avatar">▦</div><div class="player-name"><b id="pdn-game-title">—</b><span id="pdn-game-meta">Sélectionnez une partie</span></div><span class="turn-indicator" id="pdn-result"></span></div>
          <div class="board-wrap"><div id="pdn-board"></div></div>
          <div class="replay-controls">
            <button class="secondary-button" id="pdn-first" title="Début">⏮</button>
            <button class="secondary-button" id="pdn-prev" title="Coup précédent">◀</button>
            <button class="secondary-button" id="pdn-play" title="Lecture automatique">▶</button>
            <button class="secondary-button" id="pdn-next" title="Coup suivant">▶</button>
            <button class="secondary-button" id="pdn-last" title="Fin">⏭</button>
          </div>
          <div class="message center" id="pdn-message">Le coup courant s’affiche ici.</div>
          <ol class="movelist" id="pdn-movelist"></ol>
          <div class="editor-actions">
            <button class="secondary-button" id="pdn-analyze" type="button" disabled>⌕ Analyser cette position</button>
          </div>
        </div>
      </div>
    </section>
  `;

  const input = el.querySelector('#pdn-input');
  const statusEl = el.querySelector('#pdn-status');
  const boardEl = el.querySelector('#pdn-board');
  const messageEl = el.querySelector('#pdn-message');
  const movelistEl = el.querySelector('#pdn-movelist');
  const titleEl = el.querySelector('#pdn-game-title');
  const metaEl = el.querySelector('#pdn-game-meta');
  const resultEl = el.querySelector('#pdn-result');
  const analyzeButton = el.querySelector('#pdn-analyze');
  const exportButton = el.querySelector('#pdn-export');
  const playButton = el.querySelector('#pdn-play');

  const SAMPLE = `[Event "Match d'entraînement"]
[Site "Damier"]
[Date "2026.10.17"]
[Round "-"]
[White "Vous"]
[Black "Scan 3.1"]
[Result "*"]

1. 32-28 17-22 2. 37-32 18-23 3. 33-28 23x32x28 4. 37x28 12-18 5. 28-24 18-22 6. 24x15 22-18 7. 15-11 18-14 *
`;

  function loadGames() {
    stopAuto();
    games = parsePdnGames(input.value);
    selected = games.length ? 0 : -1;
    index = 0;
    error = null;
    if (!games.length) {
      statusEl.innerHTML = '<span class="status-error">⚠ Aucune partie trouvée. Vérifiez le format PDN (en-têtes [Event …] puis coups « 1. 32-28 … »).</span>';
      titleEl.textContent = '—';
      metaEl.textContent = 'Sélectionnez une partie';
      resultEl.textContent = '';
      movelistEl.innerHTML = '';
      analyzeButton.disabled = true;
      exportButton.disabled = true;
      renderBoard(boardEl, { board: createInitialBoard(), onSquareClick: null });
      messageEl.textContent = 'Le coup courant s’affiche ici.';
      return;
    }
    statusEl.innerHTML = `<span class="status-ok">✓ ${games.length} partie${games.length > 1 ? 's' : ''} détectée${games.length > 1 ? 's' : ''}</span>`;
    exportButton.disabled = games.length !== 1;
    selectGame(0);
  }

  function startPosition(game) {
    if (game.headers.FEN) {
      const parsed = parsePdnPosition(game.headers.FEN);
      if (parsed && !validatePosition(parsed.board, parsed.side)) return parsed;
    }
    return { board: createInitialBoard(), side: 'w' };
  }

  function positionAt(game, upTo) {
    const start = startPosition(game);
    let board = start.board.slice();
    let side = start.side;
    let applied = 0;
    let problem = null;
    for (let i = 0; i < Math.min(upTo, game.tokens.length); i++) {
      const legal = generateLegalMoves(board, side);
      const move = legal.find(candidate => moveMatchesPdn(candidate, game.tokens[i]));
      if (!move) {
        problem = { index: i, token: game.tokens[i] };
        break;
      }
      board = applyMove(board, move);
      side = opponent(side);
      applied++;
    }
    return { board, side, applied, problem };
  }

  function selectGame(i) {
    selected = i;
    index = 0;
    error = null;
    const game = games[i];
    const { board, side } = positionAt(game, 0);
    const white = game.headers.White ?? '?';
    const black = game.headers.Black ?? '?';
    titleEl.textContent = game.headers.Event ?? 'Partie sans titre';
    metaEl.textContent = `${white} contre ${black}${game.headers.Date ? ` · ${game.headers.Date}` : ''} · ${game.tokens.length} coups`;
    resultEl.textContent = game.result ?? '';
    exportButton.disabled = games.length !== 1;
    analyzeButton.disabled = false;
    draw(board, side);
    renderMoveList();
    updateMessage();
  }

  function currentPosition() {
    const game = games[selected];
    const state = positionAt(game, index);
    if (state.problem && !error) error = state.problem;
    return { game, ...state };
  }

  function draw(board, side) {
    renderBoard(boardEl, {
      board,
      orientation: 'w',
      lastMove: index > 0 ? lastPath() : null,
      onSquareClick: null,
    });
  }
  function lastPath() {
    const game = games[selected];
    const state = positionAt(game, index);
    if (!state.applied) return null;
    const before = positionAt(game, index - 1);
    const legal = generateLegalMoves(before.board, before.side);
    const move = legal.find(candidate => moveMatchesPdn(candidate, game.tokens[index - 1]));
    return move ? move.path : null;
  }

  function updateMessage() {
    const game = games[selected];
    if (!game) return;
    if (error) {
      messageEl.innerHTML = `⚠ Coup <b>${error.token}</b> (n° ${error.index + 1}) non légal dans cette position : la relecture s’arrête là.`;
      return;
    }
    if (index === 0) { messageEl.textContent = 'Position initiale.'; return; }
    if (index >= game.tokens.length) { messageEl.textContent = `Partie terminée — résultat : ${game.result ?? '*'}`; return; }
    messageEl.textContent = `Coup ${index + 1}/${game.tokens.length} : ${game.tokens[index]} au trait.`;
  }

  function renderMoveList() {
    const game = games[selected];
    if (!game) { movelistEl.innerHTML = ''; return; }
    const blackStarts = startPosition(game).side === 'b';
    const rows = [];
    const pair = blackStarts ? 1 : 0; // décalage de numérotation si les Noirs commencent
    for (let i = 0; i < game.tokens.length; i += 2) {
      const number = Math.floor((i + pair) / 2) + 1;
      const whiteToken = blackStarts ? (i === 0 ? '…' : game.tokens[i - 1]) : game.tokens[i];
      const blackToken = blackStarts ? game.tokens[i] : game.tokens[i + 1];
      const whiteIndex = blackStarts ? i - 1 : i;
      const blackIndex = blackStarts ? i : i + 1;
      rows.push(`<li class="movelist-row ${whiteIndex + 1 === index ? 'current' : ''} ${blackIndex + 1 === index ? 'current' : ''}" data-index="${i}"><span class="movelist-num">${number}.</span><button type="button" data-jump="${whiteIndex}" ${whiteIndex < 0 ? 'disabled' : ''}>${whiteToken ?? ''}</button><button type="button" data-jump="${blackIndex}" ${blackIndex >= game.tokens.length ? 'disabled' : ''}>${blackToken ?? ''}</button></li>`);
    }
    movelistEl.innerHTML = rows.join('');
    movelistEl.querySelectorAll('[data-jump]').forEach(button => button.addEventListener('click', () => {
      index = Number(button.dataset.jump) + 1;
      error = null;
      refresh();
    }));
  }

  function refresh() {
    const { board, side } = currentPosition();
    draw(board, side);
    renderMoveList();
    updateMessage();
  }

  function step(delta) {
    const game = games[selected];
    if (!game) return;
    error = null;
    index = Math.max(0, Math.min(game.tokens.length, index + delta));
    refresh();
  }

  function stopAuto() {
    if (autoTimer) { clearInterval(autoTimer); autoTimer = null; playButton.textContent = '▶'; }
  }

  el.querySelector('#pdn-load').addEventListener('click', loadGames);
  el.querySelector('#pdn-sample').addEventListener('click', () => { input.value = SAMPLE; loadGames(); });
  el.querySelector('#pdn-first').addEventListener('click', () => { stopAuto(); index = 0; error = null; refresh(); });
  el.querySelector('#pdn-prev').addEventListener('click', () => { stopAuto(); step(-1); });
  el.querySelector('#pdn-next').addEventListener('click', () => { stopAuto(); step(1); });
  el.querySelector('#pdn-last').addEventListener('click', () => { stopAuto(); const game = games[selected]; if (game) { index = game.tokens.length; error = null; refresh(); } });
  playButton.addEventListener('click', () => {
    if (autoTimer) { stopAuto(); return; }
    const game = games[selected];
    if (!game) return;
    if (index >= game.tokens.length) { index = 0; error = null; }
    playButton.textContent = '⏸';
    autoTimer = setInterval(() => {
      if (disposed) { stopAuto(); return; }
      const current = games[selected];
      if (!current || index >= current.tokens.length || error) { stopAuto(); return; }
      step(1);
    }, AUTO_PLAY_DELAY);
  });

  analyzeButton.addEventListener('click', () => {
    const { board, side } = currentPosition();
    store.positionDraft = { board: board.slice(), side };
    navigate('analyse');
  });

  exportButton.addEventListener('click', () => {
    const game = games[0];
    if (!game) return;
    const text = gameToPdn({
      headers: { ...game.headers, Result: game.result ?? '*' },
      moves: game.tokens.map(token => tokenToMove(game, token)),
      result: game.result ?? '*',
    });
    download('partie.pdn', text);
    toast('Partie exportée en PDN.');
  });

  function tokenToMove(game, token) {
    // Reconstruct a local move object from the token for serialization.
    const numbers = token.split(/[x-]/).map(Number);
    return { from: numbers[0], to: numbers[numbers.length - 1], path: numbers, captured: token.includes('x') ? [0] : [] };
  }

  function download(filename, text) {
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  }

  el.querySelector('#pdn-file').addEventListener('change', event => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { input.value = String(reader.result); loadGames(); toast(`Fichier « ${file.name} » lu.`); };
    reader.readAsText(file);
    event.target.value = '';
  });

  function onKeydown(event) {
    if (event.target.tagName === 'TEXTAREA' || event.target.tagName === 'INPUT') return;
    if (event.key === 'ArrowLeft') { stopAuto(); step(-1); }
    else if (event.key === 'ArrowRight') { stopAuto(); step(1); }
    else if (event.key === 'Home') { stopAuto(); index = 0; error = null; refresh(); }
    else if (event.key === 'End') { stopAuto(); const game = games[selected]; if (game) { index = game.tokens.length; error = null; refresh(); } }
  }
  document.addEventListener('keydown', onKeydown);

  // Initial empty board.
  renderBoard(boardEl, { board: createInitialBoard(), onSquareClick: null });

  return {
    el,
    dispose() { disposed = true; stopAuto(); document.removeEventListener('keydown', onKeydown); },
  };
}
