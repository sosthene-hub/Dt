import { ScanEngine, engine as sharedScan } from '../engine.js';
import { renderBoard } from '../board-view.js';
import { generateLegalMoves, moveMatchesEngine, boardToHub } from '../game-rules.js';
import { initialState, appendState } from '../game-history.js';
import { adjudicate, drawStatus } from '../draw-rules.js';
import { moveToPdn, gameToPdn } from '../pdn.js';
import { positionToPdn } from '../position.js';
import { store } from '../store.js';

const DEPTH_OPTIONS = [2, 3, 4, 5, 6, 8, 10, 12, 14, 16, 18, 20];
const TIME_OPTIONS = [
  { value: 200, label: '0,2 s' },
  { value: 500, label: '0,5 s' },
  { value: 1000, label: '1 s' },
  { value: 2000, label: '2 s' },
  { value: 4000, label: '4 s' },
  { value: 8000, label: '8 s' },
  { value: 15000, label: '15 s' },
];

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function selectHtml(id, values, selected, label) {
  return `<label class="field-block"><span class="field-label">${label}</span><select id="${id}">${values
    .map(v => `<option value="${v.value ?? v}"${String(v.value ?? v) === String(selected) ? ' selected' : ''}>${v.label ?? v}</option>`)
    .join('')}</select></label>`;
}

export function createScanVsScanPage({ toast = () => {}, navigate = null } = {}) {
  const el = document.createElement('div');
  el.innerHTML = `
    <div class="section-heading">
      <div class="eyebrow">IA CONTRE IA · DEUX MOTEURS SCAN</div>
      <h1>PIONICIDE contre PIONICIDE</h1>
      <p>Deux instances de PIONICIDE jouent l’une contre l’autre, coup par coup. Chaque camp a sa propre profondeur et son propre temps. L’interface reste libre pendant les calculs.</p>
    </div>

    <section class="panel">
      <div class="game-setup svs-setup">
        <div class="svs-side">
          <div class="player-row"><div class="avatar light-avatar">A</div><div class="player-name"><b>PIONICIDE A</b><span id="svs-a-name">Blancs</span></div></div>
          ${selectHtml('svs-a-depth', DEPTH_OPTIONS, 8, 'Profondeur A')}
          ${selectHtml('svs-a-time', TIME_OPTIONS, 1000, 'Temps par coup A')}
        </div>
        <div class="svs-side">
          <div class="player-row"><div class="avatar dark-avatar">B</div><div class="player-name"><b>PIONICIDE B</b><span id="svs-b-name">Noirs</span></div></div>
          ${selectHtml('svs-b-depth', DEPTH_OPTIONS, 4, 'Profondeur B')}
          ${selectHtml('svs-b-time', TIME_OPTIONS, 500, 'Temps par coup B')}
        </div>
      </div>

      <div class="game-setup svs-setup">
        <label class="field-block"><span class="field-label">Position de départ</span>
          <select id="svs-start">
            <option value="initial">Position initiale</option>
            <option value="draft" id="svs-draft-option" disabled>Position préparée (éditeur ou combinaison)</option>
          </select>
        </label>
        <label class="field-block"><span class="field-label">Parties à enchaîner</span>
          <select id="svs-games"><option value="1">1 partie</option><option value="2">2 parties</option><option value="3">3 parties</option><option value="4">4 parties</option><option value="6">6 parties</option></select>
        </label>
        <label class="field-block"><span class="field-label">Vitesse d’affichage</span>
          <input id="svs-speed" type="range" min="0" max="2000" step="100" value="700" aria-label="Pause entre les coups en millisecondes">
          <span id="svs-speed-label" class="counts">0,7 s entre les coups</span>
        </label>
        <label class="field-block"><span class="field-label">Mémoire par moteur</span>
          <select id="svs-mem">
            <option value="64" selected>60 Mo (64 Mio) · recommandé, deux moteurs</option>
            <option value="128">120 Mo (128 Mio) · appareil avec mémoire disponible</option>
          </select>
        </label>
      </div>

      <div class="replay-toolbar">
        <button class="primary-button" id="svs-start-btn">Démarrer</button>
        <button class="secondary-button" id="svs-pause">Pause</button>
        <button class="secondary-button" id="svs-resume" disabled>Reprendre</button>
        <button class="secondary-button" id="svs-stop" disabled>Arrêter</button>
        <button class="secondary-button" id="svs-pdn" disabled>⤓ PDN</button>
        <button class="secondary-button" id="svs-pdn-current" disabled>⤓ PDN de la partie en cours</button>
        <button class="secondary-button" id="svs-pdn-show" disabled>Afficher / copier le PDN</button>
      </div>
      <p id="svs-score" class="eval-score" aria-live="polite"></p>
      <p id="svs-status" class="message center" role="status">Choisissez les réglages, puis « Démarrer ».</p>
      <p class="study-context">Deux Web Workers distincts, avec la mémoire choisie pour chacun. Si l’appareil refuse la taille demandée, le moteur réessaie automatiquement en 32 Mio au lieu d’échouer. Le moteur de l’accueil est libéré pendant le match pour laisser la place aux deux joueurs.</p>
    </section>

    <section class="game-card">
      <div class="player-row"><div class="avatar dark-avatar" id="svs-top-avatar">B</div><div class="player-name"><b id="svs-top-name">PIONICIDE · Noirs</b><span id="svs-top-info">—</span></div><span id="svs-turn" class="turn-indicator"></span></div>
      <div class="board-wrap"><div id="svs-board"></div></div>
      <div class="player-row bottom-player"><div class="avatar light-avatar" id="svs-bottom-avatar">A</div><div class="player-name"><b id="svs-bottom-name">PIONICIDE · Blancs</b><span id="svs-bottom-info">—</span></div></div>
    </section>

    <section class="panel">
      <h3>Partie en cours</h3>
      <p id="svs-eval" class="study-context">Aucune évaluation.</p>
      <div id="svs-moves" class="game-history" aria-label="Coups joués (notation FMJD)"></div>
      <p id="svs-draw" class="counts"></p>
    </section>

    <section class="panel svs-pdn-panel">
      <div class="section-heading">
        <div class="eyebrow">ARCHIVE · PDN</div>
        <h2>Parties et PDN</h2>
        <p>Chaque partie terminée reste disponible dans la session, avec ses couleurs, ses profondeurs et son résultat. La partie en cours s’exporte à tout moment (résultat « * ») : le fichier se rouvre dans « Importer » et s’ouvre directement dans le damier d’analyse avec « Étudier ».</p>
      </div>
      <p id="svs-pdn-status" class="study-context" role="status">Aucune partie à exporter pour l’instant.</p>
      <div id="svs-archive" class="svs-archive"></div>
      <textarea id="svs-pdn-text" class="svs-pdn-text" rows="9" hidden readonly aria-label="PDN des parties de la session"></textarea>
      <div class="replay-toolbar" id="svs-pdn-actions" hidden>
        <button class="secondary-button" id="svs-pdn-copy">Copier le PDN</button>
        <button class="secondary-button" id="svs-pdn-close">Fermer le texte</button>
      </div>
    </section>
  `;

  const q = id => el.querySelector(`#${id}`);
  const engines = { a: null, b: null };
  let running = false;
  let paused = false;
  let token = 0;
  let states = [];
  let moves = [];
  let scores = { a: 0, b: 0 };
  let gamesTotal = 1;
  let gameIndex = 0;
  let startPosition = null;
  let colors = { a: 'w', b: 'b' };
  let gameLogs = [];
  let active = true;
  let matchSettings = null; // profondeurs/temps réellement utilisés par le match
  let gameInProgress = false; // une partie non archivée est affichée sur le damier
  let pdnText = '';

  function engine(side) {
    const key = colors.a === side ? 'a' : 'b';
    if (!engines[key]) {
      const hashMiB = Number(q('svs-mem').value) === 128 ? 128 : 64;
      engines[key] = new ScanEngine(import.meta.env.BASE_URL, { hashMiB });
      engines[key].start();
    }
    return engines[key];
  }

  function settings(key) {
    return {
      depth: Number(q(`svs-${key}-depth`).value),
      timeMs: Number(q(`svs-${key}-time`).value),
    };
  }

  function delay() {
    return Number(q('svs-speed').value);
  }

  function nameOf(side) {
    return colors.a === side ? 'PIONICIDE A' : 'PIONICIDE B';
  }

  function startDraft() {
    return store.playDraft || null;
  }

  function refreshDraftOption() {
    const draft = startDraft();
    const option = q('svs-draft-option');
    option.disabled = !draft;
    option.textContent = draft ? `Position préparée · ${draft.label || 'sans titre'}` : 'Position préparée (aucune)';
    if (!draft && q('svs-start').value === 'draft') q('svs-start').value = 'initial';
  }

  function renderScore() {
    const pct = scores.a + scores.b || 1;
    q('svs-score').textContent = `PIONICIDE A ${scores.a} — ${scores.b} PIONICIDE B`;
    q('svs-score').title = `${Math.round((scores.a / pct) * 100)} % pour A`;
    q('svs-a-name').textContent = colors.a === 'w' ? 'Blancs' : 'Noirs';
    q('svs-b-name').textContent = colors.b === 'w' ? 'Blancs' : 'Noirs';
  }

  function drawBoard() {
    const state = states.at(-1);
    if (!state) return;
    renderBoard(q('svs-board'), {
      board: state.board,
      orientation: colors.a === 'w' ? 'w' : 'b',
      lastMove: state.lastMove,
    });
    q('svs-turn').textContent = running ? (paused ? 'En pause' : 'En cours') : (gameIndex >= gamesTotal && moves.length ? 'Terminé' : 'Prêt');
    q('svs-top-name').textContent = `${nameOf(colors.a === 'w' ? 'b' : 'w')} · ${colors.a === 'w' ? 'Noirs' : 'Blancs'}`;
    q('svs-bottom-name').textContent = `${nameOf(colors.a === 'w' ? 'w' : 'b')} · ${colors.a === 'w' ? 'Blancs' : 'Noirs'}`;
    q('svs-draw').textContent = drawStatus(state.drawState);
    renderArchive();
    const list = q('svs-moves');
    list.replaceChildren();
    moves.forEach((entry, index) => {
      const b = document.createElement('button');
      b.className = 'secondary-button';
      b.textContent = `${Math.floor(index / 2) + 1}${index % 2 ? '…' : '.'} ${entry.pdn}`;
      b.title = `Évaluation : ${entry.evalText}`;
      list.append(b);
    });
  }

  function status(text) {
    q('svs-status').textContent = text;
  }

  function todayPdn() {
    return new Date().toISOString().slice(0, 10).replaceAll('-', '.');
  }

  /** Profondeurs utilisées pour une couleur, même après un changement des menus. */
  function depthOf(side) {
    const key = colors.a === side ? 'a' : 'b';
    const cfg = matchSettings?.[key] || settings(key);
    return cfg.depth;
  }

  function timeOf(side) {
    const key = colors.a === side ? 'a' : 'b';
    const cfg = matchSettings?.[key] || settings(key);
    return cfg.timeMs;
  }

  /** En-têtes PDN de la partie courante (ou terminée), couleurs et moteurs inclus. */
  function headersFor(result, extra = {}) {
    const names = { w: `PIONICIDE ${colors.a === 'w' ? 'A' : 'B'}`, b: `PIONICIDE ${colors.a === 'b' ? 'A' : 'B'}` };
    const headers = {
      Event: 'PIONICIDE contre PIONICIDE',
      Site: 'PIONICIDE · dames internationales 10×10',
      Date: todayPdn(),
      Round: String(gameIndex + 1),
      White: `${names.w} · profondeur ${depthOf('w')} · ${timeOf('w') / 1000} s/coup`,
      Black: `${names.b} · profondeur ${depthOf('b')} · ${timeOf('b') / 1000} s/coup`,
      Result: result,
      ...extra,
    };
    if (startPosition && startPosition.label !== 'Position initiale') {
      headers.FEN = positionToPdn(startPosition.board, startPosition.side);
    }
    return headers;
  }

  function safeName(value, fallback) {
    return String(value || fallback).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || fallback;
  }

  function downloadPdn(text, name) {
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  /** PDN de la partie en cours : résultat « * » tant qu'elle n'est pas terminée. */
  function currentGamePdn() {
    if (!moves.length) return '';
    return gameToPdn({ headers: headersFor('*', { Termination: 'partie en cours' }), moves: moves.map(entry => entry.move), result: '*' });
  }

  /** Archive complète : parties terminées puis partie en cours. */
  function archivePdn() {
    const parts = gameLogs.map(entry => entry.pdn).filter(Boolean);
    const current = gameInProgress ? currentGamePdn() : '';
    if (current) parts.push(current);
    return parts.join('\n');
  }

  function renderArchive() {
    const container = q('svs-archive');
    container.replaceChildren();
    const rows = gameLogs.map(entry => ({
      label: `Partie ${entry.game} · ${entry.result}`,
      detail: `${entry.reason} · ${entry.plies} demi-coups · Blancs ${entry.whiteDepth} / Noirs ${entry.blackDepth}`,
      pdn: entry.pdn,
      headers: entry.headers,
      result: entry.result,
      moves: entry.moves,
      start: entry.start,
      finished: true,
    }));
    if (moves.length && gameInProgress) {
      rows.push({
        label: `Partie ${gameIndex + 1} en cours · ${moves.length} demi-coups`,
        detail: `Résultat provisoire « * » · Blancs ${depthOf('w')} / Noirs ${depthOf('b')}`,
        pdn: currentGamePdn(),
        headers: headersFor('*', { Termination: 'partie en cours' }),
        result: '*',
        moves: moves.map(entry => entry.move),
        start: startPosition,
        current: true,
        finished: false,
      });
    }
    for (const row of rows) {
      const line = document.createElement('div');
      line.className = 'svs-archive-row' + (row.current ? ' current' : '');
      const text = document.createElement('div');
      text.className = 'svs-archive-text';
      text.innerHTML = `<b>${row.label}</b><span>${row.detail}</span>`;
      const actions = document.createElement('div');
      actions.className = 'replay-toolbar';
      const download = document.createElement('button');
      download.type = 'button';
      download.className = 'secondary-button';
      download.textContent = '⤓ PDN';
      download.onclick = () => {
        downloadPdn(row.pdn, `${safeName(`pionicide-partie-${row.label}`, 'pionicide')}.pdn`);
        toast(`PDN de « ${row.label} » téléchargé.`);
      };
      const study = document.createElement('button');
      study.type = 'button';
      study.className = 'secondary-button';
      study.textContent = 'Étudier';
      study.onclick = () => studyPdn(row);
      actions.append(download, study);
      line.append(text, actions);
      container.append(line);
    }
    const live = moves.length && gameInProgress ? 1 : 0;
    const total = gameLogs.length + live;
    q('svs-pdn').disabled = !gameLogs.length && !(moves.length && gameInProgress);
    q('svs-pdn-current').disabled = !(moves.length && gameInProgress);
    q('svs-pdn-show').disabled = !total;
    q('svs-pdn-status').textContent = !total
      ? 'Aucune partie à exporter pour l’instant.'
      : `${gameLogs.length} partie${gameLogs.length > 1 ? 's' : ''} dans l’archive${live ? ' et la partie en cours' : ''} · ${total} PDN disponible${total > 1 ? 's' : ''}.`;
  }

  /** Ouvre une partie de l'archive dans le damier d'analyse (la partie reste jouée). */
  function studyPdn(row) {
    if (!navigate) return;
    if (row.finished && !row.moves?.length) return;
    store.analysisDraft = {
      start: row.start ? { board: row.start.board.slice(), side: row.start.side } : undefined,
      moves: row.moves,
      cursor: 0,
      headers: row.headers,
      result: row.result,
      title: `${row.headers.White} — ${row.headers.Black} · ${row.label}`,
    };
    navigate('analyse');
  }

  function clearEngines() {
    for (const key of ['a', 'b']) {
      try { engines[key]?.dispose(); } catch { /* déjà arrêté */ }
      engines[key] = null;
    }
  }

  function makeStart() {
    const mode = q('svs-start').value;
    if (mode === 'draft' && startDraft()) {
      const d = startDraft();
      return { board: d.board.slice(), side: d.side, label: d.label || 'Position préparée' };
    }
    return { board: initialState().board, side: 'w', label: 'Position initiale' };
  }

  function resetGame() {
    startPosition = makeStart();
    states = [initialState(startPosition.board, startPosition.side)];
    moves = [];
    q('svs-eval').textContent = 'Aucune évaluation.';
    drawBoard();
  }

  async function playOneGame(myToken) {
    while (myToken === token) {
      if (paused) { await sleep(150); continue; }
      const state = states.at(-1);
      const decision = adjudicate(state.board, state.side, state.drawState);
      if (decision) return { result: decision.result, reason: decision.reason };
      if (moves.length >= 300) return { result: '*', reason: 'Partie arrêtée après 300 demi-coups (aucune conclusion).' };
      const side = state.side;
      const key = colors.a === side ? 'a' : 'b';
      const cfg = settings(key);
      const label = `Profondeur ${cfg.depth} · ${cfg.timeMs / 1000} s`;
      q(`svs-${key === 'a' ? 'top' : 'bottom'}-info`).textContent = 'En calcul…';
      status(`${nameOf(side)} (${side === 'w' ? 'Blancs' : 'Noirs'}) réfléchit · ${label}`);
      let result;
      try {
        result = await engine(side).search({
          position: `pos=${boardToHub(state.board, side)}`,
          depth: cfg.depth,
          maxTimeMs: cfg.timeMs,
          mode: 'think',
          onInfo: info => {
            if (myToken !== token || !active) return;
            if (Number.isFinite(info.score)) {
              q('svs-eval').textContent = `Évaluation ${nameOf(side)} : ${info.score > 0 ? '+' : ''}${info.score.toFixed(2)} (vue du trait) · profondeur ${info.depth ?? '—'}`;
            }
          },
        });
      } catch (error) {
        if (myToken !== token) return { result: '*', reason: `Erreur moteur : ${error.message}` };
        return { result: '*', reason: `Erreur moteur : ${error.message}` };
      }
      if (myToken !== token || !active) return null;
      const legal = generateLegalMoves(state.board, side);
      const move = result.move ? legal.find(m => moveMatchesEngine(m, result.move)) : null;
      q(`svs-${key === 'a' ? 'top' : 'bottom'}-info`).textContent = label;
      if (!move) {
        if (result.stale) return null;
        return { result: side === 'w' ? '0-1' : '1-0', reason: 'PIONICIDE n’a pas renvoyé de coup légal.' };
      }
      const info = result.infos?.at(-1);
      const score = Number(info?.score);
      const evalText = Number.isFinite(score) ? `${score > 0 ? '+' : ''}${score.toFixed(2)} (d${info?.depth ?? '—'})` : '—';
      const next = appendState(states, move);
      states = next;
      moves.push({ move, pdn: moveToPdn(move), evalText, side, depth: info?.depth ?? null, ms: result.wallMs });
      drawBoard();
      q('svs-eval').textContent = `Dernier coup : ${nameOf(side)} ${moveToPdn(move)} · évaluation ${evalText}`;
      if (delay()) await sleep(delay());
    }
    return null;
  }

  async function runSeries(myToken) {
    gamesTotal = Number(q('svs-games').value);
    gameIndex = 0;
    scores = { a: 0, b: 0 };
    colors = { a: 'w', b: 'b' };
    renderScore();
    while (gameIndex < gamesTotal && myToken === token) {
      resetGame();
      gameInProgress = true;
      renderArchive();
      status(`Partie ${gameIndex + 1} / ${gamesTotal} · ${nameOf('w')} joue les Blancs.`);
      const outcome = await playOneGame(myToken);
      if (myToken !== token || !outcome) break;
      if (outcome.result === '1-0') scores[colors.a === 'w' ? 'a' : 'b'] += 1;
      else if (outcome.result === '0-1') scores[colors.a === 'b' ? 'a' : 'b'] += 1;
      else if (outcome.result === '1/2-1/2') { scores.a += 0.5; scores.b += 0.5; }
      renderScore();
      const headers = headersFor(outcome.result, { Termination: outcome.reason });
      gameLogs.push({
        game: gameLogs.length + 1,
        colors: { ...colors },
        result: outcome.result,
        reason: outcome.reason,
        plies: moves.length,
        whiteDepth: depthOf('w'),
        blackDepth: depthOf('b'),
        headers: { ...headers, Round: String(gameLogs.length + 1) },
        start: { board: startPosition.board.slice(), side: startPosition.side },
        moves: moves.map(entry => entry.move),
        moveText: moves.map(entry => ({ pdn: entry.pdn, side: entry.side, eval: entry.evalText, depth: entry.depth })),
        pdn: gameToPdn({ headers: { ...headers, Round: String(gameLogs.length + 1) }, moves: moves.map(entry => entry.move), result: outcome.result }),
      });
      gameInProgress = false;
      renderArchive();
      status(`Partie ${gameIndex + 1} : ${outcome.result} · ${outcome.reason} (${moves.length} demi-coups).`);
      gameIndex += 1;
      if (gameIndex < gamesTotal) {
        colors = { a: colors.b, b: colors.a };
        renderScore();
        await sleep(400);
      }
    }
    if (myToken === token) {
      running = false;
      paused = false;
      q('svs-start-btn').disabled = false;
      q('svs-pause').disabled = true;
      q('svs-resume').disabled = true;
      q('svs-stop').disabled = true;
      q('svs-turn').textContent = 'Terminé';
      renderArchive();
      if (gameLogs.length) {
        const last = gameLogs.at(-1);
        status(`Série terminée · ${scores.a} — ${scores.b} sur ${gameIndex} partie(s) jouée(s) dans cette série. Dernier résultat : ${last.result} (${last.reason}). ${gameLogs.length} partie(s) dans l’archive.`);
      }
    }
  }

  function begin() {
    if (running) return;
    refreshDraftOption();
    if (q('svs-start').value === 'draft' && !startDraft()) {
      toast('Aucune position préparée : ouvrez l’éditeur ou une combinaison.');
      return;
    }
    token += 1;
    running = true;
    paused = false;
    matchSettings = { a: settings('a'), b: settings('b') };
    resetGame();
    renderArchive();
    q('svs-start-btn').disabled = true;
    q('svs-pause').disabled = false;
    q('svs-resume').disabled = true;
    q('svs-stop').disabled = false;
    const myToken = token;
    // Le moteur de l'accueil occupe 64 Mio : on le libère avant de lancer les deux joueurs.
    sharedScan.release();
    clearEngines();
    q('svs-status').textContent = 'Chargement des deux moteurs PIONICIDE…';
    Promise.all([engine('w').waitForReady(), engine('b').waitForReady()])
      .then(() => {
        if (myToken !== token) return;
        const used = [...new Set(['a', 'b'].map(key => engines[key]?.settings.hashMiB).filter(Boolean))];
        const reduced = engines.a?.reduced || engines.b?.reduced;
        status(`Moteurs prêts (${used.join(' / ')} Mio${reduced ? ' après réduction automatique' : ''}). La partie commence.`);
      })
      .catch(error => { if (myToken === token) status(`Moteur indisponible : ${error.message} Réduisez la mémoire ou fermez les autres onglets.`); });
    runSeries(myToken).catch(error => {
      if (myToken !== token) return;
      running = false;
      status(`Erreur : ${error.message}`);
    });
  }

  q('svs-speed').addEventListener('input', () => {
    const ms = Number(q('svs-speed').value);
    q('svs-speed-label').textContent = ms ? `${(ms / 1000).toFixed(1).replace('.', ',')} s entre les coups` : 'immédiat';
  });

  q('svs-start-btn').addEventListener('click', begin);
  q('svs-pause').addEventListener('click', () => {
    paused = true;
    q('svs-pause').disabled = true;
    q('svs-resume').disabled = false;
    q('svs-turn').textContent = 'En pause';
    status('Pause : le calcul en cours se termine, puis la partie attend.');
  });
  q('svs-resume').addEventListener('click', () => {
    paused = false;
    q('svs-pause').disabled = false;
    q('svs-resume').disabled = true;
    status('Reprise.');
  });
  q('svs-stop').addEventListener('click', () => {
    token += 1;
    running = false;
    paused = false;
    clearEngines();
    // La partie interrompue rejoint l'archive : elle reste exportable et étudiable.
    if (moves.length && gameInProgress) {
      const headers = headersFor('*', { Termination: `Partie arrêtée après ${moves.length} demi-coups.` });
      gameLogs.push({
        game: gameLogs.length + 1,
        colors: { ...colors },
        result: '*',
        reason: `Partie arrêtée après ${moves.length} demi-coups.`,
        plies: moves.length,
        whiteDepth: depthOf('w'),
        blackDepth: depthOf('b'),
        headers: { ...headers, Round: String(gameLogs.length + 1) },
        start: { board: startPosition.board.slice(), side: startPosition.side },
        moves: moves.map(entry => entry.move),
        moveText: moves.map(entry => ({ pdn: entry.pdn, side: entry.side, eval: entry.evalText, depth: entry.depth })),
        pdn: gameToPdn({ headers: { ...headers, Round: String(gameLogs.length + 1) }, moves: moves.map(entry => entry.move), result: '*' }),
      });
      gameInProgress = false;
    }
    renderArchive();
    q('svs-start-btn').disabled = false;
    q('svs-pause').disabled = true;
    q('svs-resume').disabled = true;
    q('svs-stop').disabled = true;
    q('svs-turn').textContent = 'Arrêté';
    renderArchive();
    status(`Partie arrêtée. ${moves.length} demi-coups joués : la partie rejoint l’archive, son PDN reste disponible.`);
  });

  // PDN : toutes les parties de la session (terminées + partie en cours).
  q('svs-pdn').addEventListener('click', () => {
    const text = archivePdn();
    if (!text) {
      toast('Aucun coup à exporter : lancez une partie.');
      return;
    }
    const count = gameLogs.length + (moves.length ? 1 : 0);
    downloadPdn(text, `pionicide-contre-pionicide-${count}-partie${count > 1 ? 's' : ''}.pdn`);
    status(`PDN téléchargé : ${count} partie${count > 1 ? 's' : ''} (${text.length} octets).`);
    toast('PDN téléchargé : « Importer » ou « Étudier » pour l’analyser.');
  });

  // PDN de la seule partie en cours, sans attendre la fin du match.
  q('svs-pdn-current').addEventListener('click', () => {
    const text = currentGamePdn();
    if (!text) {
      toast('La partie en cours n’a encore aucun coup.');
      return;
    }
    downloadPdn(text, 'pionicide-partie-en-cours.pdn');
    status(`PDN de la partie en cours téléchargé (${moves.length} demi-coups, résultat « * »).`);
  });

  // Affichage du texte : secours utile quand le téléchargement est bloqué (Android, aperçu intégré).
  q('svs-pdn-show').addEventListener('click', () => {
    pdnText = archivePdn();
    if (!pdnText) {
      toast('Rien à afficher pour l’instant.');
      return;
    }
    q('svs-pdn-text').value = pdnText;
    q('svs-pdn-text').hidden = false;
    q('svs-pdn-actions').hidden = false;
    q('svs-pdn-text').scrollIntoView({ block: 'nearest' });
  });
  q('svs-pdn-copy').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(pdnText || q('svs-pdn-text').value);
      toast('PDN copié dans le presse-papiers.');
    } catch {
      q('svs-pdn-text').select();
      toast('Sélectionnez le texte puis copiez-le.');
    }
  });
  q('svs-pdn-close').addEventListener('click', () => {
    q('svs-pdn-text').hidden = true;
    q('svs-pdn-actions').hidden = true;
  });

  // Le sélecteur de position se met à jour à chaque montage.
  const originalMount = () => { refreshDraftOption(); renderScore(); };

  return {
    el,
    mount() {
      active = true;
      originalMount();
      if (!states.length) resetGame();
    },
    unmount() {
      active = false;
      token += 1;
      running = false;
      paused = false;
      clearEngines();
    },
    // Exposé pour les tests navigateur : résultats détaillés de la série.
    getReport() {
      return {
        scores,
        games: gameLogs.map(g => ({ ...g })),
        start: startPosition,
        archivePdn: archivePdn(),
        currentPdn: currentGamePdn(),
      };
    },
    getPdn() {
      return { archive: archivePdn(), current: currentGamePdn(), games: gameLogs.length, moves: moves.length };
    },
  };
}
