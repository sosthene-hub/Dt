import { renderBoard } from '../board-view.js';
import { generateLegalMoves, applyMove, moveToHub, sideOf } from '../game-rules.js';
import { engine as sharedScan } from '../engine.js';
import { loadCombinationDb, importCombinationDb } from '../combinations/db.js';
import { parseRouteInput, routeText, entryRoute, routeMatches, replayHubs } from '../combinations/model.js';
import { generateVerified, findModels } from '../combinations/generate.js';
import { DEFAULT_VALIDATION, validateCombinationPosition, validatePlayablePosition } from '../combinations/validator.js';
import { store } from '../store.js';

function pdnOf(move) {
  return `${move.from}${move.captured.length ? 'x' : '-'}${move.to}`;
}

function moveParts(hub) {
  const numbers = String(hub).split(/[x-]/).map(Number);
  return { from: numbers[0], to: numbers[1], capture: hub.includes('x') };
}

export function createCombinaisonsPage({ toast = () => {}, navigate = () => {} } = {}) {
  const el = document.createElement('div');
  el.innerHTML = `
    <div class="section-heading">
      <div class="eyebrow">ENTRAÎNEMENT · PC BLUES DEEL 66</div>
      <h1>Combinaisons</h1>
      <p>Demandez une rafle, choisissez un niveau : l’application tire une combinaison vérifiée par rejeu des règles FMJD.</p>
    </div>
    <section class="panel">
      <div class="game-setup">
        <label class="field-block"><span class="field-label">Rafle demandée</span>
          <input id="cb-route" inputmode="numeric" placeholder="38x ou 38x27 ou 38x27x16" autocomplete="off" aria-describedby="cb-route-help">
        </label>
        <label class="field-block"><span class="field-label">Niveau</span>
          <select id="cb-level">
            <option value="1">1 · position du livre</option>
            <option value="2">2 · +2 à 4 pièces neutres</option>
            <option value="3">3 · leurres</option>
            <option value="4">4 · difficile, plusieurs leurres</option>
          </select>
        </label>
        <label class="field-block"><span class="field-label">Pièces (total)</span>
          <select id="cb-pieces">
            <option value="">indifférent</option>
            <option value="0-20">20 ou moins</option>
            <option value="21-30">21 à 30</option>
            <option value="31-50">31 et plus</option>
          </select>
        </label>
        <label class="field-block"><span class="field-label">Longueur solution</span>
          <select id="cb-length">
            <option value="">indifférent</option>
            <option value="0-5">5 demi-coups ou moins</option>
            <option value="6-9">6 à 9</option>
            <option value="10-99">10 et plus</option>
          </select>
        </label>
        <label class="field-block"><span class="field-label">Vérification Scan</span>
          <select id="cb-scan-depth">
            <option value="0">sans Scan (rapide)</option>
            <option value="12" selected>profondeur 12</option>
            <option value="16">profondeur 16</option>
            <option value="20">profondeur 20</option>
          </select>
        </label>
        <label class="field-block"><span class="field-label">Écart de matériel max</span>
          <select id="cb-maxgap"><option value="1">1 pièce</option><option value="2">2 pièces</option><option value="3" selected>3 pièces</option><option value="4">4 pièces</option><option value="5">5 pièces</option></select>
        </label>
        <label class="field-block"><span class="field-label">Avancée des leurres</span>
          <select id="cb-advance"><option value="strict" selected>stricte · blancs rangées 1-2, noirs 9-10</option><option value="promotion">promotion seulement</option></select>
        </label>
        <label class="field-block"><span class="field-label">Pions isolés ajoutés</span>
          <select id="cb-isolated"><option value="reject" selected>refuser</option><option value="allow">tolérer</option></select>
        </label>
        <button id="cb-generate" class="primary-button">Générer</button>
      </div>
      <p id="cb-route-help" class="study-context">Tout préfixe est accepté : <b>38x</b> (départ), <b>38x27</b> (départ et première arrivée), <b>38x27x16</b> (route plus longue). Laissez vide pour un tirage libre.</p>
      <p id="cb-db" class="study-context">Chargement de la base…</p>
      <p id="cb-generate-status" class="study-context" role="status"></p>
      <div id="cb-import" hidden>
        <p class="study-context">La base n’a pas été trouvée sur cet appareil. Importez une fois le fichier <code>combinations-app.json</code> fourni avec l’application ; il reste stocké localement.</p>
        <label class="secondary-button">Importer la base<input id="cb-file" type="file" accept="application/json,.json" hidden></label>
      </div>
    </section>

    <section class="panel" id="cb-exercise" hidden>
      <div class="player-row"><b id="cb-title">Les Blancs jouent et gagnent</b><span id="cb-status" class="turn-indicator" role="status">À vous</span></div>
      <div class="board-wrap"><div id="cb-board"></div></div>
      <p id="cb-message" class="message" role="status"></p>
      <div class="replay-toolbar">
        <button class="secondary-button" id="cb-hint">Indice</button>
        <button class="secondary-button" id="cb-solution">Solution</button>
        <button class="secondary-button" id="cb-undo">↶ Annuler</button>
        <button class="secondary-button" id="cb-flip">Retourner</button>
        <button class="secondary-button" id="cb-next">Autre exercice</button>
      </div>
      <div id="cb-meta" class="study-context"></div>
      <p id="cb-validation" class="study-context"></p>
      <div id="cb-line-wrap" hidden><p class="study-context">Solution pas à pas</p><div id="cb-line" class="solution-line" aria-label="Solution"></div></div>
      <details class="play-launcher" id="cb-play">
        <summary>Jouer cette position contre Scan</summary>
        <div class="play-launcher-body">
          <label class="field-block"><span class="field-label">Ma couleur</span>
            <select id="cb-play-color"><option value="w">Blancs</option><option value="b">Noirs</option></select></label>
          <label class="field-block"><span class="field-label">Camp au trait</span>
            <select id="cb-play-side"><option value="w">Blancs</option><option value="b">Noirs</option></select></label>
          <label class="field-block"><span class="field-label">Niveau de Scan</span>
            <select id="cb-play-level"><option value="facile">Facile · 12</option><option value="normal" selected>Normal · 16</option><option value="fort">Fort · 20</option></select></label>
          <p id="cb-play-status" class="import-status" role="status"></p>
          <button class="start-game-button" id="cb-play-start" type="button">Jouer cette position <span>→</span></button>
        </div>
      </details>
    </section>

    <section class="panel" id="cb-report-panel" hidden>
      <h3>Rapport de génération</h3>
      <p class="study-context">Comptes de cette session. Un rejet n’est pas une erreur : c’est une position qui ne respectait pas les contraintes.</p>
      <div id="cb-report" class="study-context"></div>
      <button class="secondary-button" id="cb-report-reset">Remettre à zéro</button>
    </section>
  `;
  const q = id => el.querySelector(`#${id}`);
  let db = null;
  let dbOrigin = null;
  let entries = [];
  let exercise = null;
  let exerciseCounter = 0;
  let scan = null;
  let busy = false;
  let active = true;
  const report = loadReport();

  function loadReport() {
    try { return JSON.parse(localStorage.getItem('comb-report') || '{}'); } catch { return {}; }
  }
  function saveReport() {
    try { localStorage.setItem('comb-report', JSON.stringify(report)); } catch { /* stockage plein */ }
    renderReport();
  }
  function renderReport() {
    const lines = Object.entries(report);
    q('cb-report-panel').hidden = !lines.length;
    q('cb-report').innerHTML = lines.map(([level, s]) => {
      const causes = Object.entries(s.rejected || {}).sort((a, b) => b[1] - a[1]).slice(0, 4)
        .map(([cause, count]) => ` · ${count}× ${cause}`).join('');
      return `<p><b>Niveau ${level}</b> — ${s.attempted} essais, ${s.accepted} acceptées${s.scanChecked ? `, ${s.scanChecked} vérifiées par Scan` : ''}${causes}</p>`;
    }).join('') || '<p>Aucune génération pour l’instant.</p>';
  }

  function scanEngine() {
    // Un seul moteur pour toute l'application : moins de mémoire sur téléphone.
    sharedScan.ensureStarted();
    return sharedScan;
  }

  function setDb(data, origin) {
    db = data;
    entries = data?.entries || [];
    dbOrigin = origin;
    if (!data) {
      q('cb-db').textContent = 'Base non disponible sur cet appareil : importez le fichier combinations-app.json fourni.';
      q('cb-import').hidden = false;
      q('cb-generate').disabled = false;
      return;
    }
    const departures = Object.values(data.index || {}).filter(list => list.length).length;
    q('cb-db').textContent = `Base ${origin} : ${entries.length} combinaisons validées par rejeu, ${departures} cases de départ de rafle.`;
    q('cb-import').hidden = true;
  }

  /* ---------------- Exercice ---------------- */
  function startExercise(item) {
    const validation = validateCombinationPosition(
      { board: item.board, side: item.trait, solution: item.solution, added: item.added || null },
      currentLimits(),
      { scope: item.level === 1 ? 'all' : 'added' },
    );
    item = { ...item, validation };
    exercise = {
      item,
      board: item.board.slice(),
      history: [],
      step: 0,
      selected: null,
      revealed: false,
      orientation: 'w',
      message: 'Trouvez le premier coup gagnant. Cliquez la pièce puis la case d’arrivée.',
    };
    q('cb-exercise').hidden = false;
    q('cb-exercise').dataset.exid = String(++exerciseCounter);
    // Notation complète conservée en données (tests, copie) : l'écran, lui,
    // n'affiche qu'un demi-coup à la fois dans la ligne de solution.
    q('cb-exercise').dataset.solution = item.solution.map(hub => {
      const { from, to, capture } = moveParts(hub);
      return `${from}${capture ? 'x' : '-'}${to}`;
    }).join(' ');
    q('cb-generate-status').textContent = '';
    q('cb-title').textContent = item.level === 1 ? 'Les Blancs jouent et gagnent' : `Combinaison générée · niveau ${item.level}`;
    draw();
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function status() {
    if (!exercise) return '';
    return exercise.step >= exercise.item.solution.length ? 'Terminé' : (exercise.step % 2 === 0 ? 'Aux Blancs' : 'Aux Noirs');
  }

  function draw() {
    if (!exercise) return;
    const { item, board, step } = exercise;
    const replay = replayHubs(item.board, item.trait, item.solution);
    const last = step > 0 ? replay.moves[step - 1] : null;
    const markers = new Map();
    if (exercise.selected) markers.set(exercise.selected, 'selected');
    renderBoard(q('cb-board'), {
      board,
      orientation: exercise.orientation,
      selected: exercise.selected,
      lastMove: last ? last.path : null,
      markers,
      onSquareClick: playSquare,
    });
    q('cb-status').textContent = busy ? 'Vérification…' : status();
    q('cb-message').textContent = exercise.message || '';
    const meta = [];
    if (item.level === 1) {
      meta.push(`Livre p. ${item.page}`, `rafle ${routeText(item.rafle_complete)}`, `départ ${item.rafle_depart}`);
      if (item.herkomst_origine) meta.push(`herkomst ${item.herkomst_origine}`);
      const source = (item.source || '').trim();
      if (source && !/^\d+\s*\./.test(source) && /[A-Za-zÀ-ÿ]{3}/.test(source)) meta.push(source.slice(0, 80));
    } else {
      meta.push(`modèle ${item.origin} (p. ${item.page})`, `rafle ${routeText(item.rafle_complete)}`, `+${item.added.length} pièces ajoutées`);
      if (item.scan?.accepted) meta.push(`Scan d${item.scan.depth} : gagnant après le coup (+${item.scan.value?.toFixed(2)}), écart au meilleur ${item.scan.gap?.toFixed(2)}`);
    }
    q('cb-meta').textContent = meta.join(' · ');
    const validation = item.validation;
    if (validation && !validation.ok) {
      q('cb-validation').innerHTML = `<span class="status-error">⚠ Position signalée : ${validation.violations.map(v => v.message).join(' ')}</span>`;
    } else {
      q('cb-validation').innerHTML = '<span class="status-ok">✓ Position cohérente : pions hors lignes de promotion, matériel équilibré, aucune prise parasite.</span>';
    }
    // Solution compacte : une seule ligne de commande au lieu de la liste complète
    // des demi-coups, qui occupait tout l'écran sur téléphone.
    const line = q('cb-line');
    line.innerHTML = '';
    const total = item.solution.length;
    const visible = exercise.revealed || step > 0;
    q('cb-line-wrap').hidden = !visible;
    if (visible) {
      const start = document.createElement('button');
      start.className = 'secondary-button';
      start.id = 'cb-sol-start';
      start.textContent = '⏮';
      start.setAttribute('aria-label', 'Début de la solution');
      start.disabled = step <= 0;
      start.addEventListener('click', () => stepSolution(-exercise.step));
      const previous = document.createElement('button');
      previous.className = 'secondary-button';
      previous.id = 'cb-sol-prev';
      previous.textContent = '◀';
      previous.setAttribute('aria-label', 'Demi-coup précédent');
      previous.disabled = step <= 0;
      previous.addEventListener('click', () => stepSolution(-1));
      const label = document.createElement('span');
      label.className = 'solution-step';
      label.id = 'cb-sol-label';
      if (step === 0) {
        label.textContent = `${total} demi-coups · appuyez sur ▶`;
      } else {
        const { from, to, capture } = moveParts(item.solution[step - 1]);
        const index = step - 1;
        const whiteMove = item.trait === 'w' ? index % 2 === 0 : index % 2 === 1;
        const number = Math.floor((index + (item.trait === 'w' ? 0 : 1)) / 2) + 1;
        label.textContent = `${step}/${total} · ${whiteMove ? `${number}.` : '…'} ${from}${capture ? 'x' : '-'}${to}`;
      }
      const next = document.createElement('button');
      next.className = 'secondary-button';
      next.id = 'cb-sol-next';
      next.textContent = '▶';
      next.setAttribute('aria-label', 'Demi-coup suivant');
      next.disabled = step >= total;
      next.addEventListener('click', () => { exercise.revealed = true; stepSolution(1); });
      const end = document.createElement('button');
      end.className = 'secondary-button';
      end.id = 'cb-sol-end';
      end.textContent = '⏭';
      end.setAttribute('aria-label', 'Fin de la solution');
      end.disabled = step >= total;
      end.addEventListener('click', () => { exercise.revealed = true; stepSolution(total); });
      line.append(start, previous, label, next, end);
    }
  }

  function stepSolution(delta) {
    if (!exercise) return;
    const total = exercise.item.solution.length;
    const replay = replayHubs(exercise.item.board, exercise.item.trait, exercise.item.solution);
    exercise.revealed = true;
    exercise.step = Math.max(0, Math.min(total, exercise.step + delta));
    exercise.board = replay.states[exercise.step];
    exercise.selected = null;
    exercise.history = [];
    exercise.message = exercise.step === total
      ? 'Solution complète.'
      : `Solution : demi-coup ${exercise.step} sur ${total}.`;
    draw();
  }

  function playSquare(n) {
    if (!exercise || busy) return;
    const { item } = exercise;
    const replay = replayHubs(item.board, item.trait, item.solution);
    if (exercise.step >= item.solution.length) return;
    const expected = replay.moves[exercise.step];
    const state = replay.states[exercise.step];
    const turn = exercise.step % 2 === 0 ? item.trait : (item.trait === 'w' ? 'b' : 'w');
    if (exercise.selected === null) {
      if (sideOf(state[n]) === turn) exercise.selected = n;
      else exercise.message = 'Choisissez une pièce du camp au trait.';
      draw();
      return;
    }
    const legal = generateLegalMoves(state, turn).filter(m => m.from === exercise.selected && m.to === n);
    exercise.selected = null;
    if (!legal.length) { exercise.message = 'Coup illégal (prise majoritaire obligatoire).'; draw(); return; }
    const move = legal[0];
    if (move.from !== expected.from || move.to !== expected.to) {
      exercise.message = 'Ce n’est pas le coup de la solution. Réessayez ou demandez un indice.';
      draw();
      return;
    }
    exercise.history.push({ step: exercise.step, board: exercise.board.slice() });
    exercise.board = replay.states[exercise.step + 1];
    exercise.step += 1;
    exercise.message = exercise.step >= item.solution.length ? 'Combinaison terminée.' : 'Bon coup.';
    // Les réponses des Noirs font partie de la solution : elles sont enchaînées.
    if (exercise.step < item.solution.length && exercise.step % 2 === 1) {
      exercise.board = replay.states[exercise.step + 1];
      exercise.step += 1;
      exercise.message = replay.moves[exercise.step - 1].captured.length
        ? 'Prise forcée des Noirs enchaînée.'
        : 'Réponse des Noirs enchaînée.';
    }
    draw();
  }

  function undo() {
    if (!exercise?.history.length) return;
    const previous = exercise.history.pop();
    exercise.step = previous.step;
    exercise.board = previous.board;
    exercise.selected = null;
    exercise.message = 'Coup annulé.';
    draw();
  }

  function reveal() {
    if (!exercise) return;
    exercise.revealed = true;
    exercise.step = exercise.item.solution.length;
    const replay = replayHubs(exercise.item.board, exercise.item.trait, exercise.item.solution);
    exercise.board = replay.board;
    exercise.message = 'Solution complète.';
    draw();
  }

  function currentLimits() {
    return {
      ...DEFAULT_VALIDATION,
      maxMaterialGap: Number(q('cb-maxgap').value) || 3,
      whiteManMinRow: q('cb-advance').value === 'promotion' ? 2 : 3,
      blackManMaxRow: q('cb-advance').value === 'promotion' ? 9 : 8,
      rejectIsolated: q('cb-isolated').value !== 'allow',
    };
  }

  /* ---------------- Génération ---------------- */
  async function generate() {
    if (busy) return;
    const request = q('cb-route').value.trim() ? parseRouteInput(q('cb-route').value) : null;
    if (q('cb-route').value.trim() && !request) { toast('Route invalide : écrivez par exemple 38x27x16.'); return; }
    const level = Number(q('cb-level').value);
    const depth = Number(q('cb-scan-depth').value);
    busy = true;
    q('cb-generate').disabled = true;
    exercise = null;
    q('cb-exercise').hidden = true;
    q('cb-generate-status').textContent = 'Recherche…';
    q('cb-status').textContent = 'Recherche…';
    try {
      if (!entries.length) {
        // Sans base : proposer une position de démonstration minimale est refusé par choix de conception.
        toast('Importez la base privée pour tirer une combinaison.');
        return;
      }
      const piecesRange = q('cb-pieces').value;
      const lengthRange = q('cb-length').value;
      const [minP, maxP] = piecesRange ? piecesRange.split('-').map(Number) : [0, 50];
      const [minL, maxL] = lengthRange ? lengthRange.split('-').map(Number) : [0, 99];
      const matchesFilters = entry => {
        const total = entry.nb_pieces_blanc + entry.nb_pieces_noir;
        return total >= minP && total <= maxP && entry.solution.length >= minL && entry.solution.length <= maxL;
      };
      const filtered = entries.filter(matchesFilters);
      const models = findModels(filtered, request);
      const pool = models.direct.concat(models.translated);
      q('cb-generate-status').textContent = `Modèles disponibles : ${pool.length}.`;
      if (!pool.length) {
        const departure = request?.squares[0];
        const nearby = entries.filter(e => e.rafle_depart === departure).slice(0, 40);
        toast(`Aucune combinaison pour ${routeText(request.squares)}.`);
        q('cb-generate-status').textContent = nearby.length
          ? `Aucune route ${routeText(request.squares)}. Routes disponibles depuis ${departure} : ${[...new Set(nearby.map(e => routeText(entryRoute(e))))].slice(0, 8).join(' · ')}`
          : `Aucune combinaison ne part de la case ${departure}. Essayez une autre case.`;
        return;
      }
      if (level === 1) {
        const entry = pool[Math.floor(Math.random() * pool.length)];
        startExercise({ ...entry, level: 1 });
        return;
      }
      q('cb-generate-status').textContent = 'Recherche d’un candidat…';
      const stats = report[level] || { attempted: 0, accepted: 0, rejected: {}, scanChecked: 0 };
      const result = await generateVerified(filtered, {
        level,
        request,
        attempts: level === 4 ? 80 : level === 3 ? 60 : 30,
        search: depth ? opts => scanEngine().search({ ...opts }) : null,
        depth: depth || 12,
        minScore: 1.5,
        seed: (Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0,
        timeBudgetMs: 45000,
        limits: currentLimits(),
        onProgress: ({ attempt }) => { q('cb-generate-status').textContent = `Essai ${attempt}, vérification Scan…`; },
      });
      stats.attempted += result.stats.attempted;
      stats.accepted += result.stats.accepted;
      stats.scanChecked += result.stats.scanChecked;
      for (const [cause, count] of Object.entries(result.stats.rejected)) {
        stats.rejected[cause] = (stats.rejected[cause] || 0) + count;
      }
      report[level] = stats;
      saveReport();
      if (!result.candidate) {
        toast(result.reason || 'Aucune position n’a passé les contrôles.');
        const causes = Object.entries(result.stats.rejected || {}).sort((a, b) => b[1] - a[1]).slice(0, 3)
          .map(([cause, count]) => `${count}× ${cause}`).join(' · ');
        q('cb-generate-status').textContent = `Échec : ${result.reason || 'contraintes non satisfaites'}${causes ? ` (${causes})` : ''}.`;
        return;
      }
      startExercise(result.candidate);
      exercise.message = depth
        ? 'Position générée et vérifiée par Scan : trouvez le premier coup gagnant.'
        : 'Position générée sans vérification Scan : traitez-la comme un exercice non certifié.';
      draw();
    } catch (error) {
      toast(error.message || 'Erreur de génération.');
      q('cb-generate-status').textContent = `Erreur : ${error.message || 'génération interrompue'}.`;
    } finally {
      busy = false;
      q('cb-generate').disabled = false;
      if (exercise) draw();
    }
  }

  /* ---------------- Événements ---------------- */
  q('cb-play').addEventListener('toggle', () => {
    if (!q('cb-play').open || !exercise) return;
    q('cb-play-side').value = exercise.item.trait;
    q('cb-play-color').value = exercise.item.trait;
  });
  q('cb-play-start').onclick = () => {
    if (!exercise) return;
    const playSide = q('cb-play-side').value;
    const errors = validatePlayablePosition(exercise.item.board, playSide);
    if (errors.length) {
      q('cb-play-status').innerHTML = `<span class="status-error">⚠ ${errors.join(' ')}</span>`;
      return;
    }
    store.playDraft = {
      board: exercise.item.board.slice(),
      side: playSide,
      human: q('cb-play-color').value,
      level: q('cb-play-level').value,
      label: `Combinaison p. ${exercise.item.page}`,
    };
    store.difficulty = q('cb-play-level').value;
    navigate('jouer');
    toast('Partie lancée depuis la combinaison.');
  };
  q('cb-generate').onclick = generate;
  q('cb-next').onclick = () => { if (entries.length) generate(); };
  q('cb-hint').onclick = () => {
    if (!exercise) return;
    const replay = replayHubs(exercise.item.board, exercise.item.trait, exercise.item.solution);
    const move = replay.moves[exercise.step];
    if (!move) return;
    exercise.selected = move.from;
    exercise.message = `Indice : la pièce en ${move.from} joue.`;
    draw();
  };
  q('cb-solution').onclick = reveal;
  q('cb-undo').onclick = undo;
  q('cb-flip').onclick = () => { if (exercise) { exercise.orientation = exercise.orientation === 'w' ? 'b' : 'w'; draw(); } };
  q('cb-file').onchange = async event => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const data = await importCombinationDb(file);
      setDb(data, 'importée');
      toast('Base de combinaisons importée.');
    } catch (error) {
      toast(error.message);
    }
  };
  q('cb-report-reset').onclick = () => {
    for (const key of Object.keys(report)) delete report[key];
    saveReport();
  };
  q('cb-route').addEventListener('keydown', event => { if (event.key === 'Enter') generate(); });
  function rememberSettings() {
    try {
      localStorage.setItem('comb-settings', JSON.stringify({
        route: q('cb-route').value,
        level: q('cb-level').value,
        depth: q('cb-scan-depth').value,
        pieces: q('cb-pieces').value,
        length: q('cb-length').value,
        maxgap: q('cb-maxgap').value,
        advance: q('cb-advance').value,
        isolated: q('cb-isolated').value,
      }));
    } catch { /* stockage indisponible */ }
  }
  for (const id of ['cb-route', 'cb-level', 'cb-scan-depth', 'cb-pieces', 'cb-length', 'cb-maxgap', 'cb-advance', 'cb-isolated']) {
    q(id).addEventListener('change', rememberSettings);
  }
  q('cb-route').addEventListener('input', rememberSettings);
  try {
    const saved = JSON.parse(localStorage.getItem('comb-settings') || '{}');
    if (saved.route) q('cb-route').value = saved.route;
    if (saved.level) q('cb-level').value = saved.level;
    if (saved.depth) q('cb-scan-depth').value = saved.depth;
    if (saved.pieces) q('cb-pieces').value = saved.pieces;
    if (saved.length) q('cb-length').value = saved.length;
    if (saved.maxgap) q('cb-maxgap').value = saved.maxgap;
    if (saved.advance) q('cb-advance').value = saved.advance;
    if (saved.isolated) q('cb-isolated').value = saved.isolated;
  } catch { /* réglages absents */ }

  renderReport();
  loadCombinationDb({ baseUrl: import.meta.env.BASE_URL }).then(({ data, origin }) => {
    if (!active) return;
    setDb(data, origin);
  }).catch(() => setDb(null, null));

  return {
    el,
    mount() { active = true; },
    unmount() {
      active = false;
      sharedScan.release();
    },
  };
}
