import {engine as sharedScan} from '../engine.js';
import {renderBoard} from '../board-view.js';
import {generateLegalMoves,sideOf,moveMatchesEngine,moveToHub,boardToHub} from '../game-rules.js';
import {initialState,appendState} from '../game-history.js';
import {positionToPdn,validatePosition} from '../position.js';
import {moveToPdn} from '../pdn.js';
import {probeTable,wdlLabel} from '../bitbases.js';
import {adjudicate,drawStatus} from '../draw-rules.js';
import {annotateGame,withPlayedMoves} from '../analysis/annotate.js';
import {buildAnnotatedPdn,openPrintSheet} from '../analysis/export.js';
import {createMemoSearch} from '../analysis/threats.js';
import {createThreatPanel} from './threat-panel.js';
import {store} from '../store.js';
export function createAnalysisPage({navigate,toast}){
 const el=document.createElement('div');let original=[initialState()],played=[],cursor=0,current=original[0],title='Position libre',orientation='w',selected=null,scan=sharedScan,thinking=false,active=false,token=0,auto=null,variant=null,branch=false,undos=[];
 el.innerHTML=`<div class="section-heading"><div class="eyebrow">ÉTUDE · DEUX LIGNES DISTINCTES</div><h1>Damier d’analyse</h1><p>La partie jouée reste intacte. Explorez séparément la variante légale proposée par PIONICIDE.</p></div><section class="panel"><div class="analysis-grid"><div><div class="player-row"><b id="an-side">Trait blanc</b><span id="an-status" class="turn-indicator" role="status">Prêt</span></div><div class="board-wrap"><div id="analysis-board"></div></div><p class="threat-onboard" id="an-threat-note" role="status"></p><p class="study-context" id="an-context"></p><div class="replay-toolbar"><button class="secondary-button" id="an-first">⏮ Partie</button><button class="secondary-button" id="an-prev">◀</button><button class="secondary-button" id="an-play">▶ Auto</button><button class="secondary-button" id="an-next">▶</button><button class="secondary-button" id="an-last">Fin ⏭</button><button class="secondary-button" id="an-flip">Retourner</button></div></div><aside class="analysis-side"><h3>PIONICIDE</h3><div class="eval-score" id="an-score">—</div><p id="an-meta" class="study-context">Aucune évaluation</p><label>Profondeur<select id="an-depth"><option value="3">3</option><option value="5">5</option><option value="7">7</option><option value="9">9</option><option value="12">12</option><option value="16" selected>16</option><option value="20">20</option><option value="22">22</option><option value="25">25</option></select></label><label class="check-row"><input type="checkbox" id="an-auto" checked>Évaluer après chaque position</label><div class="replay-toolbar"><button class="secondary-button" id="an-evaluate">Évaluer</button><button class="secondary-button" id="an-hint">Coup conseillé</button><button class="secondary-button" id="an-undo">↶ Annuler</button><button class="secondary-button" id="an-reset">Position initiale</button><button class="secondary-button" id="an-edit">Éditer</button></div><div class="code-row"><input id="an-code" readonly aria-label="Code de position"><button id="an-copy" class="secondary-button">Copier</button></div></aside></div></section>
 <section class="panel study-lanes"><div class="study-lane"><h3>1 · Coups de la partie jouée</h3><p id="played-title" class="study-context"></p><div id="played-moves" class="study-moves"></div></div><div class="study-lane"><h3>2 · Variante proposée par PIONICIDE</h3><p id="variant-origin" class="study-context">Lancez une évaluation.</p><div id="an-pv" class="study-moves"></div><div class="replay-toolbar"><button class="secondary-button" id="pv-root">Racine</button><button class="secondary-button" id="pv-prev">◀ Variante</button><button class="secondary-button" id="pv-next">Variante ▶</button><button class="secondary-button" id="back-played">Revenir à la partie</button></div></div></section>
 <section class="panel"><h2>Tables de finales hors ligne</h2><p id="tb-result" role="status"></p><p id="tb-counters" class="study-context"></p><div id="tb-moves" class="replay-toolbar"></div><p class="study-context">Tables PIONICIDE : 2 à 4 pièces au total. WDL théorique, sans distance au gain. Les règles de nulle et l’historique sont examinés séparément. Pour un damier chargé sans partie, les compteurs commencent à zéro.</p></section>`;
 const q=id=>el.querySelector('#'+id);const stateCopy=s=>structuredClone(s);const labelAt=(index,startSide)=>`${Math.floor((index+(startSide==='b'?1:0))/2)+1}${(index+(startSide==='b'?1:0))%2?'…':'.'}`;
 /* ---- Export annoté : PDN, diagrammes, impression ---- */
 let annot=null,annotBusy=false,annotStop=false,annotToken=0,marks=new Set(),gameHeaders={},gameResult='*',gameTitle='';
 const exportPanel=document.createElement('section');exportPanel.className='panel analysis-export';
 exportPanel.innerHTML=`<div class="section-heading"><div class="eyebrow">EXPORT · PDN ANNOTÉ ET PDF</div><h2>Partie annotée par PIONICIDE</h2><p>Chaque position est évaluée une seule fois. Le symbole du coup se déduit de l’écart avec le meilleur coup de PIONICIDE ; la variante conseillée est la ligne principale du moteur.</p></div>
 <div class="export-grid">
  <div class="export-main">
   <div class="replay-toolbar">
    <button class="primary-button" id="an-annotate">Analyser et annoter la partie</button>
    <button class="secondary-button" id="an-annotate-stop" hidden>Arrêter</button>
    <button class="secondary-button" id="an-export-pdn" disabled>Exporter PDN annoté</button>
    <button class="secondary-button" id="an-print" disabled>Imprimer / PDF</button>
    <button class="secondary-button" id="an-mark">Ajouter un diagramme à l’export</button>
   </div>
   <progress id="an-annot-progress" max="1" value="0" hidden></progress>
   <p id="an-annot-status" class="study-context" role="status">Aucune analyse de partie. Lancez « Analyser et annoter la partie ».</p>
   <p id="an-mark-info" class="study-context"></p>
  </div>
  <div class="export-settings">
   <label>Niveau de détail<select id="an-detail"><option value="errors">Erreurs et grosses erreurs (par défaut)</option><option value="all">Toute la partie</option></select></label>
   <label>Profondeur d’annotation<select id="an-annot-depth"><option value="9">9</option><option value="12" selected>12</option><option value="16">16</option><option value="20">20</option></select></label>
   <div class="export-thresholds">
    <label>Seuil « ? » (pions perdus)<input id="an-thr-error" type="number" min="0.1" max="5" step="0.1" value="0.5" inputmode="decimal"></label>
    <label>Seuil « ?? » (pions perdus)<input id="an-thr-blunder" type="number" min="0.1" max="9" step="0.1" value="1.5" inputmode="decimal"></label>
   </div>
   <label class="check-row"><input type="checkbox" id="an-opt-arrow" checked>Flèche du meilleur coup sur les diagrammes</label>
   <label class="check-row"><input type="checkbox" id="an-opt-numbers">Numéroter les cases de 1 à 50</label>
   <label class="check-row"><input type="checkbox" id="an-opt-auto">Diagramme automatique après chaque « ?? »</label>
  </div>
 </div>`;
 el.insertBefore(exportPanel,el.querySelectorAll('section.panel')[2]||null);
 /* ---- Menaces : cache d'évaluations partagé, panneau et flèches ---- */
 const memo=createMemoSearch(options=>scan.search(options));
 const memory=new Map(); // signature de la partie → {annot, threats}
 let threatOverlay=null;
 const gameSignature=()=>`${boardToHub(original[0].board,original[0].side)}|${played.map(moveToPdn).join(',')}`;
 const panel=createThreatPanel({toast,host:{
  states:()=>original.slice(0,played.length+1),
  moves:()=>played,
  memo:()=>memo,
  search:options=>scan.search(options),
  cursor:()=>cursor,
  selectPly:index=>selectPlayed(index),
  setOverlay:overlay=>{threatOverlay=overlay;draw();},
  afterUpdate:()=>draw(),
  isActive:()=>active,
  progress:{update:(done,total,label)=>progressUpdate(done,total,label)},
 }});
 exportPanel.after(panel.el);
 function progressUpdate(done,total,label){const bar=q('an-annot-progress');bar.hidden=false;bar.max=total;bar.value=done;setAnnotStatus(`Menaces · ${label||'analyse'} ${done}/${total} positions (profondeur ${panel.options().depth})`);}

 function thresholds(){const error=Math.max(0.1,Math.min(5,Number(q('an-thr-error').value)||0.5)),blunder=Math.max(error,Math.min(9,Number(q('an-thr-blunder').value)||1.5));return {error,blunder};}
 function annotValid(){return !!annot&&annot.plies&&annot.plies.length===played.length&&played.length>0;}
 function refreshExport(){const ready=annotValid(),manual=[...marks].filter(i=>i>0).length;
  q('an-export-pdn').disabled=!ready;q('an-print').disabled=!ready;
  q('an-annotate').disabled=annotBusy||!played.length;q('an-annotate-stop').hidden=!annotBusy;
  q('an-mark').disabled=branch||cursor===0||!played.length;
  q('an-mark').textContent=!branch&&marks.has(cursor)?`Retirer le diagramme du coup ${Math.ceil(cursor/2)}`:`Ajouter un diagramme à l’export${!branch&&cursor>0?` (coup ${Math.ceil(cursor/2)})`:''}`;
  const auto=q('an-opt-auto').checked&&annotValid()?annot.plies.filter(p=>p.symbol==='??').length:0;
  q('an-mark-info').textContent=manual||auto?`Diagrammes joints : ${manual} choisi${manual>1?'s':''}${auto?` + ${auto} automatique${auto>1?'s':''} (grosses erreurs)`:' (aucun automatique)'} · diagrammes toujours orientés Blancs en bas.`:'';}
 // Placements non standard : le diagramme reste toujours du point de vue des Blancs, comme le PDF.
 function setAnnotStatus(text){q('an-annot-status').textContent=text;}
 async function annotateCurrentGame(){if(annotBusy)return;if(!played.length){toast('Importez une partie ou jouez quelques coups avant d’annoter.');return;}
  cancelSearch();annotBusy=true;annotStop=false;const myToken=++annotToken;const depth=Number(q('an-annot-depth').value);
  q('an-annot-progress').hidden=false;q('an-annot-progress').max=played.length+1;q('an-annot-progress').value=0;setAnnotStatus('Annotation en cours…');refreshExport();
  try{scan.start();const states=original.slice(0,played.length+1);
   const res=await annotateGame({states,search:memo,depth,maxTimeMs:1500,pvLength:6,
    onProgress:(done,total)=>{if(myToken!==annotToken)return;q('an-annot-progress').max=total;q('an-annot-progress').value=done;setAnnotStatus(`Annotation en cours… ${done}/${total} positions (profondeur ${depth})`);},
    shouldStop:()=>!active||annotStop||myToken!==annotToken});
   if(myToken!==annotToken||!active)return;
   if(res.cancelled){setAnnotStatus('Annotation interrompue. Aucun export modifié.');toast('Annotation interrompue.');return;}
   annot={...res,headers:gameHeaders,result:gameResult};annot.plies=withPlayedMoves(res,played,thresholds());
   const errors=annot.plies.filter(p=>p.symbol==='?').length,blunders=annot.plies.filter(p=>p.symbol==='??').length,bests=annot.plies.filter(p=>p.symbol==='!').length;
   setAnnotStatus(`${annot.plies.length} coups évalués à la profondeur ${depth} · ${bests} « ! », ${errors} « ? », ${blunders} « ?? » · seuils ${thresholds().error.toFixed(1).replace('.',',')} / ${thresholds().blunder.toFixed(1).replace('.',',')} pion`);
   toast(`Partie annotée : ${errors} erreur${errors>1?'s':''}, ${blunders} grosse${blunders>1?'s':''} erreur${blunders>1?'s':''}.`);
   memory.set(gameSignature(),{annot,threats:panel.meta()?{results:panel.results(),summary:panel.summary(),depth:panel.meta().depth,threshold:panel.meta().threshold}:null});
   if(active&&panel.options().combine){
    const threatReport=await panel.run({combined:true,depth});
    if(myToken!==annotToken||!active)return;
    if(threatReport){
     memory.set(gameSignature(),{annot,threats:threatReport});
     setAnnotStatus(`Passage unique · ${annot.plies.length} coups annotés et ${threatReport.summary.analysed} coups examinés pour les menaces, profondeur ${depth}.`);
     panel.showPly(cursor-1);
    }
   }
   if(active&&q('an-auto').checked)runAnalysis();
  }catch(e){if(myToken!==annotToken)return;console.error(e);setAnnotStatus('Annotation impossible : '+e.message);toast('Annotation impossible : '+e.message);}
  finally{if(myToken===annotToken){annotBusy=false;q('an-annot-progress').hidden=true;refreshExport();}}}
 function downloadText(text,name){const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
 function safeName(value,fallback){return String(value||fallback).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Za-z0-9]+/g,'-').replace(/^-+|-+$/g,'')||fallback;}
 function exportAnnotatedPdn(){if(!annotValid()){toast('Analysez d’abord la partie.');return;}
  const threatOptions=panel.options();
  const text=buildAnnotatedPdn({headers:annot.headers,moves:played,plies:annot.plies,result:gameResult,depth:annot.depth,detail:q('an-detail').value,thresholds:thresholds(),
   threats:threatOptions.inExport?panel.results():null,threatDepth:panel.meta()?.depth??threatOptions.depth,threatThreshold:panel.meta()?.threshold??threatOptions.threshold});
  downloadText(text,`${safeName(annot.headers?.White,'blancs')}-${safeName(annot.headers?.Black,'noirs')}-annote.pdn`);toast('PDN annoté téléchargé : il se rouvre dans Importer.');}
 function printAnnotatedSheet(){if(!annotValid()){toast('Analysez d’abord la partie.');return;}
  const threatOptions=panel.options();
  openPrintSheet({headers:annot.headers,plies:annot.plies,states:original.slice(0,played.length+1),positions:annot.positions,marks,
   threats:threatOptions.inExport?panel.results():null,threatDepth:panel.meta()?.depth??threatOptions.depth,
   options:{detail:q('an-detail').value,arrow:q('an-opt-arrow').checked,numbers:q('an-opt-numbers').checked,autoBlunder:q('an-opt-auto').checked,thresholds:thresholds()},
   depth:annot.depth,result:gameResult,title:''});}
 function toggleMark(){if(branch||cursor===0||!played.length){toast('Placez-vous sur une position de la partie, après un coup.');return;}
  if(marks.has(cursor)){marks.delete(cursor);toast(`Diagramme du coup ${Math.ceil(cursor/2)} retiré.`);}else{marks.add(cursor);toast(`Diagramme ajouté après le coup ${Math.ceil(cursor/2)}.`);}
  refreshExport();}
 const baseDraw=draw;draw=()=>{baseDraw();refreshExport();};
 q('an-annotate').onclick=()=>annotateCurrentGame();
 q('an-annotate-stop').onclick=()=>{annotStop=true;setAnnotStatus('Arrêt demandé…');};
 q('an-export-pdn').onclick=()=>exportAnnotatedPdn();
 q('an-print').onclick=()=>printAnnotatedSheet();
 q('an-mark').onclick=()=>toggleMark();
 q('an-detail').onchange=()=>refreshExport();q('an-opt-auto').onchange=()=>refreshExport();
 q('an-thr-error').onchange=()=>{const t=thresholds();if(t.blunder<t.error)q('an-thr-blunder').value=String(t.error);refreshExport();};
 q('an-thr-blunder').onchange=()=>{const t=thresholds();if(t.blunder<t.error)q('an-thr-error').value=String(t.blunder);refreshExport();};
 function stopAuto(){if(auto)clearInterval(auto);auto=null;q('an-play').textContent='▶ Auto';}
 function cancelSearch(release=false){token++;thinking=false;if(release)scan.release();else if(scan.current)scan.restart();}
 function draw(){const decision=adjudicate(current.board,current.side,current.drawState);const legalTargets=new Set(selected===null?[]:generateLegalMoves(current.board,current.side).filter(m=>m.from===selected).map(m=>m.to));
 renderBoard(q('analysis-board'),{board:current.board,orientation,lastMove:current.lastMove,selected,targets:legalTargets,onSquareClick:handleSquare,arrows:threatOverlay&&threatOverlay.boardCursor===cursor?threatOverlay.arrows:[]});
 q('an-threat-note').textContent=threatOverlay?.text||'';q('an-threat-note').className='threat-onboard'+(threatOverlay?' visible '+(threatOverlay.kind==='created'?'is-created':'is-avoided'):'');q('an-code').value=positionToPdn(current.board,current.side);q('an-side').textContent='Trait : '+(current.side==='w'?'Blancs':'Noirs');q('an-status').textContent=decision?decision.reason:thinking?'PIONICIDE analyse…':'Prêt';q('an-context').textContent=branch?'Exploration séparée — la partie jouée n’est pas modifiée.':`Partie jouée · demi-coup ${cursor}/${played.length}`;q('played-title').textContent=title;q('tb-counters').textContent=drawStatus(current.drawState);q('an-undo').disabled=!undos.length&&cursor===0;
 q('played-moves').replaceChildren();const first=document.createElement('button');first.className='secondary-button'+(!branch&&cursor===0?' active':'');first.textContent='Départ';first.onclick=()=>selectPlayed(0);q('played-moves').append(first);played.forEach((m,i)=>{const b=document.createElement('button');b.className='secondary-button'+(!branch&&cursor===i+1?' active':'');b.append(document.createTextNode(labelAt(i,original[0].side)+' '+moveToPdn(m)));const mark=panel.entryFor(i);if(mark?.created){const badge=document.createElement('span');badge.className='threat-badge threat-created';badge.textContent='▲';badge.title='Menace créée';b.append(badge);}if(mark?.avoided){const badge=document.createElement('span');badge.className='threat-badge threat-avoided';badge.textContent='▼';badge.title='Menace évitée';b.append(badge);}if(mark){b.title=[mark.created?'Menace créée':'',mark.avoided?'Menace évitée':'',mark.note||''].filter(Boolean).join(' · ');}b.onclick=()=>selectPlayed(i+1);q('played-moves').append(b);});
 q('an-pv').replaceChildren();if(variant){q('variant-origin').textContent=`Depuis ${variant.originLabel} · ${variant.moves.length} demi-coups légaux vérifiés${variant.truncated?' · suite arrêtée au premier coup non reconnu':''}`;variant.moves.forEach((m,i)=>{const b=document.createElement('button');b.className='secondary-button'+(branch&&variant.index===i+1?' active':'');b.textContent=labelAt(i,variant.states[0].side)+' '+moveToPdn(m);b.onclick=()=>selectVariant(i+1);q('an-pv').append(b);});}
 q('tb-moves').replaceChildren();if(decision){q('tb-result').textContent=decision.result+' · '+decision.reason;return;}const tb=probeTable(current.board,current.side);q('tb-result').textContent=tb.available?`${wdlLabel(tb.value)} pour le trait · ${tb.source} · WDL théorique, sans historique.`:tb.reason;if(tb.available)for(const t of tb.moves){const b=document.createElement('button');b.className='secondary-button';b.textContent=t.notation+' : '+wdlLabel(t.value);b.onclick=()=>{if(thinking)return;const m=generateLegalMoves(current.board,current.side).find(m=>moveToHub(m)===t.notation);if(m)playManual(m);};q('tb-moves').append(b);}}
 function selectPlayed(index,evaluate=true){stopAuto();if(thinking){toast('Attendez la fin du calcul PIONICIDE.');return;}cursor=Math.max(0,Math.min(played.length,index));current=original[cursor];selected=null;branch=false;undos=[];threatOverlay=null;draw();if(!branch&&panel.results().length)panel.showPly(cursor-1);if(evaluate&&q('an-auto').checked&&active)runAnalysis();}
 function selectVariant(index){stopAuto();if(thinking||!variant)return;variant.index=Math.max(0,Math.min(variant.moves.length,index));undos.push(stateCopy(current));current=variant.states[variant.index];selected=null;branch=true;draw();}
 function playManual(move){undos.push(stateCopy(current));current=appendState([current],move).at(-1);branch=true;selected=null;draw();if(q('an-auto').checked)runAnalysis();}
 function handleSquare(n){if(thinking||adjudicate(current.board,current.side,current.drawState))return;const legal=generateLegalMoves(current.board,current.side);if(selected!==null){const m=legal.find(m=>m.from===selected&&m.to===n);if(m){playManual(m);return;}}selected=sideOf(current.board[n])===current.side?(selected===n?null:n):null;draw();}
 async function runAnalysis(showHint=false){if(thinking||!active||annotBusy)return;const error=validatePosition(current.board,current.side);if(error){toast(error);return;}if(adjudicate(current.board,current.side,current.drawState)){draw();return;}scan.start();const anchor=stateCopy(current),originLabel=branch?'une position explorée':`la partie au demi-coup ${cursor}`,myToken=++token;thinking=true;draw();try{const result=await scan.search({position:'pos='+boardToHub(anchor.board,anchor.side),depth:Number(q('an-depth').value),mode:'analyze',onInfo:info=>{if(myToken!==token||!active)return;q('an-score').textContent=Number.isFinite(info.score)?`${info.score>0?'+':''}${info.score.toFixed(2)} (vu du trait)`:'—';q('an-meta').textContent=`Profondeur ${info.depth??'—'} · ${info.nodes??'—'} nœuds · ${Math.round(info.knps||0)} kn/s · ${(info.time||0).toFixed(2)} s${info.completed?' · itération terminée':''}`;}});if(myToken!==token||!active)return;thinking=false;const info=result.infos.at(-1),texts=info?.pv?.length?info.pv:result.move?[result.move]:[],vm=[],vs=[anchor];let truncated=false;for(const text of texts){const state=vs.at(-1);const m=generateLegalMoves(state.board,state.side).find(m=>moveMatchesEngine(m,text));if(!m){truncated=true;break;}vm.push(m);vs.push(appendState([state],m).at(-1));}variant={states:vs,moves:vm,index:0,originLabel,truncated};q('an-meta').textContent+=(result.timeLimited?' · limite de temps : dernière itération terminée':result.timedOut?' · délai de sécurité atteint':'');draw();if(showHint&&vm.length)toast('Coup conseillé : '+moveToPdn(vm[0]));}catch(e){if(myToken!==token)return;thinking=false;draw();toast(e.message);}}
 q('an-evaluate').onclick=()=>runAnalysis();q('an-hint').onclick=()=>runAnalysis(true);q('an-depth').onchange=()=>{if(q('an-auto').checked)runAnalysis();};q('an-auto').onchange=()=>{if(q('an-auto').checked)runAnalysis();};q('an-flip').onclick=()=>{orientation=orientation==='w'?'b':'w';draw();};q('an-first').onclick=()=>selectPlayed(0);q('an-prev').onclick=()=>selectPlayed(cursor-1);q('an-next').onclick=()=>selectPlayed(cursor+1);q('an-last').onclick=()=>selectPlayed(played.length);q('pv-root').onclick=()=>selectVariant(0);q('pv-prev').onclick=()=>selectVariant((variant?.index||0)-1);q('pv-next').onclick=()=>selectVariant((variant?.index||0)+1);q('back-played').onclick=()=>selectPlayed(cursor,false);
 q('an-play').onclick=()=>{if(auto){stopAuto();return;}if(thinking)return;if(cursor===played.length)cursor=0;branch=false;current=original[cursor];draw();q('an-play').textContent='⏸ Auto';auto=setInterval(()=>{if(thinking||cursor>=played.length){stopAuto();return;}cursor++;current=original[cursor];branch=false;selected=null;draw();if(cursor>=played.length)stopAuto();},800);};q('an-undo').onclick=()=>{if(thinking)return;if(undos.length){current=undos.pop();branch=true;selected=null;draw();}else selectPlayed(cursor-1,false);};
 function load(draft){cancelSearch();original=[initialState(draft?.start?.board,draft?.start?.side)];played=[];for(const m of draft?.moves||[]){const s=original.at(-1),legal=generateLegalMoves(s.board,s.side).find(x=>moveToHub(x)===moveToHub(m));if(!legal)break;played.push(legal);original=appendState(original,legal);}cursor=Math.min(draft?.cursor??played.length,played.length);current=original[cursor];title=draft?.title||'Position chargée';gameTitle=title;gameHeaders=draft?.headers||{};gameResult=draft?.result||'*';variant=null;branch=false;selected=null;undos=[];annotStop=true;annotToken++;annotBusy=false;marks.clear();threatOverlay=null;q('variant-origin').textContent='Lancez une évaluation.';
 const saved=memory.get(gameSignature());
 if(saved&&saved.annot&&saved.annot.plies&&saved.annot.plies.length===played.length&&played.length){annot=saved.annot;if(saved.threats)panel.restore(saved.threats,{restored:true});else panel.reset();setAnnotStatus(`Résultats mémorisés · annotation profondeur ${annot.depth}${saved.threats?` · menaces profondeur ${saved.threats.depth}`:''} · aucun recalcul.`);}
 else{annot=null;panel.reset();setAnnotStatus('Aucune analyse de partie. Lancez « Analyser et annoter la partie ».');}
 draw();}
 q('an-reset').onclick=()=>{if(thinking)return;load(null);};q('an-edit').onclick=()=>{store.positionDraft={board:current.board.slice(),side:current.side};navigate('editeur');};q('an-copy').onclick=()=>navigator.clipboard?.writeText(q('an-code').value).then(()=>toast('Code copié.')).catch(()=>q('an-code').select());
 draw();return {el,mount(){active=true;scan.ensureStarted();if(store.analysisDraft){const d=store.analysisDraft;store.analysisDraft=null;store.positionDraft=null;load(d);}else if(store.positionDraft){const d=store.positionDraft;store.positionDraft=null;load({start:d,title:'Position sans historique'});}if(q('an-auto').checked)runAnalysis();},unmount(){active=false;annotStop=true;annotToken++;stopAuto();panel.clearOverlay();threatOverlay=null;cancelSearch();scan.dispose();scan=sharedScan;}};
}
