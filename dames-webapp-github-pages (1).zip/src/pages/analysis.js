import { engine as sharedScan } from '../engine.js';
import { renderBoard } from '../board-view.js';
import { generateLegalMoves, sideOf, moveMatchesEngine, moveToHub, boardToHub } from '../game-rules.js';
import { initialState, appendState } from '../game-history.js';
import { positionToPdn, validatePosition } from '../position.js';
import { moveToPdn } from '../pdn.js';
import { probeTable, wdlLabel } from '../bitbases.js';
import { adjudicate, drawStatus } from '../draw-rules.js';
import { annotateGame, withPlayedMoves } from '../analysis/annotate.js';
import { buildAnnotatedPdn, openPrintSheet } from '../analysis/export.js';
import { openGameSheet } from '../analysis/print-sheet.js';
import { createMemoSearch } from '../analysis/threats.js';
import { createThreatPanel } from './threat-panel.js';
import { createRefutationPanel } from './refutation-panel.js';
import { formatBadMoveStudyComment } from '../analysis/refutations.js';
import {
  ALLOWED_SYMBOLS,
  createManualTree,
  getNode,
  getParent,
  nodeDepth,
  variationRootOf,
  mainLineNodes,
  describeMoveNode,
  playMoveOnTree,
  addLineToTree,
  updateNodeAnnotation,
  deleteSubtree,
  promoteVariation,
  convertMainToVariation,
  countTreeStats,
  serializeManualTree,
  deserializeManualTree,
  treeToPdn,
  parsePdnToTree,
} from '../analysis/manual-tree.js';
import { renderNotationDom, openManualPrintSheet } from '../analysis/manual-print.js';
import { installAnalysisShell } from '../ui/mobile-analysis-shell.js';
import { store } from '../store.js';

const ANALYSIS_DEPTHS = [3, 5, 7, 9, 12, 16, 20, 22, 25];
const MANUAL_STORAGE_PREFIX = 'pionicide.manual-analysis.v1:';

export function createAnalysisPage({ navigate, toast }) {
  const el = document.createElement('div');
  let original = [initialState()];
  let played = [];
  let cursor = 0;
  let current = original[0];
  let title = 'Position libre';
  let orientation = 'w';
  let selected = null;
  let scan = sharedScan;
  let thinking = false;
  let active = false;
  let token = 0;
  let auto = null;
  let variant = null;
  let branch = false;
  let undos = [];
  let inPvPreview = false;
  let inRefutationPreview = false;
  let refutationOverlay = null;

  /* ---- État de l'arbre d'analyse manuelle ---- */
  let manualTree = createManualTree({ start: original[0], moves: [] });
  let activeNodeId = manualTree.root.id;
  let pendingAltTarget = null;     // { parentId, targetLabel, returnNodeId }
  let forceNextVariation = false;
  let showPreviewDiagrams = false;

  el.innerHTML = `<div class="section-heading"><div class="eyebrow">ÉTUDE · ANALYSE MANUELLE ET MOTEUR</div><h1>Damier d’analyse</h1><p>Jouez librement d’autres coups sur le damier pour créer des variantes <b>[ … ]</b> et sous-variantes <i>( … )</i>, rédigez vos commentaires, insérez des diagrammes à n’importe quelle position et imprimez votre analyse.</p></div>
  <section class="panel" id="an-board-panel"><div class="analysis-grid"><div><div class="player-row"><b id="an-side">Trait blanc</b><span id="an-status" class="turn-indicator" role="status">Prêt</span></div><div class="board-wrap"><div id="analysis-board"></div></div><p class="threat-onboard" id="an-threat-note" role="status"></p><p class="study-context" id="an-context"></p><div class="replay-toolbar"><button class="secondary-button" id="an-first">⏮ Partie</button><button class="secondary-button" id="an-prev">◀</button><button class="secondary-button" id="an-play">▶ Auto</button><button class="secondary-button" id="an-next">▶</button><button class="secondary-button" id="an-last">Fin ⏭</button><button class="secondary-button" id="an-flip">Retourner</button></div></div><aside class="analysis-side"><h3>PIONICIDE</h3><div class="eval-score" id="an-score">—</div><p id="an-meta" class="study-context">Aucune évaluation</p><label>Profondeur<select id="an-depth"><option value="3">3</option><option value="5">5</option><option value="7">7</option><option value="9">9</option><option value="12">12</option><option value="16" selected>16</option><option value="20">20</option><option value="22">22</option><option value="25">25</option></select></label><label class="check-row"><input type="checkbox" id="an-auto" checked>Évaluer après chaque position</label><div class="replay-toolbar"><button class="secondary-button" id="an-evaluate">Évaluer</button><button class="secondary-button" id="an-hint">Coup conseillé</button><button class="secondary-button" id="an-bad-moves" title="Détecter les mauvais coups possibles dans cette position et la suite pour les exploiter">🎯 Mauvais coups</button><button class="secondary-button" id="an-undo">↶ Annuler</button><button class="secondary-button" id="an-reset">Position initiale</button><button class="secondary-button" id="an-edit">Éditer</button><button class="secondary-button" id="an-print-position">Imprimer la position</button></div><div class="code-row"><input id="an-code" readonly aria-label="Code de position"><button id="an-copy" class="secondary-button">Copier</button></div></aside></div></section>
  <section class="panel manual-workshop" id="manual-workshop">
    <div>
      <div class="eyebrow">ANALYSE MANUELLE · VARIANTES · COMMENTAIRES · IMPRESSION</div>
      <div class="manual-head-row">
        <h2>Votre analyse commentée</h2>
        <span class="manual-stats-pill" id="man-stats">0 coup · 0 variante</span>
      </div>
      <p class="study-context">Sur n’importe quelle position (partie ou variante), jouez un coup différent directement sur le damier pour ouvrir une variante <b>[ verte ]</b> puis une sous-variante <i>( bleue )</i>. Cliquez sur n’importe quel coup dans la feuille ci-dessous pour le commenter ou y attacher un diagramme.</p>
    </div>

    <div class="manual-alt-banner" id="man-alt-banner" hidden>
      <span id="man-alt-text">Jouez sur le damier l’autre coup souhaité.</span>
      <button class="secondary-button" type="button" id="man-alt-cancel">Annuler</button>
    </div>

    <div class="replay-toolbar" style="margin:0">
      <button class="primary-button" type="button" id="man-print">🖨 Imprimer mon analyse / PDF</button>
      <button class="secondary-button" type="button" id="man-diagram-toggle">▦ Insérer un diagramme ici</button>
      <button class="secondary-button" type="button" id="man-alt-move">⑂ Autre coup à la place de celui-ci</button>
      <button class="secondary-button" type="button" id="man-insert-pv" disabled>+ Insérer la variante PIONICIDE</button>
      <button class="secondary-button" type="button" id="man-export-pdn">⤓ PDN (variantes + notes)</button>
      <button class="secondary-button" type="button" id="man-import-toggle">⇧ Charger un PDN annoté</button>
    </div>

    <div class="man-import-box" id="man-import-box" hidden>
      <div class="replay-toolbar" style="margin:0">
        <label class="secondary-button file-button">Choisir un fichier PDN<input type="file" id="man-import-file" accept=".pdn,.txt,text/plain" hidden></label>
        <span class="study-context">Les variantes <code>( … )</code> / <code>[ … ]</code>, commentaires <code>{ … }</code> et diagrammes sont récupérés.</span>
      </div>
      <textarea id="man-import-text" rows="5" spellcheck="false" placeholder="Collez ici un PDN contenant des variantes et commentaires…"></textarea>
      <div class="replay-toolbar" style="margin:0">
        <button class="primary-button" type="button" id="man-import-apply">Charger dans l’analyse</button>
        <button class="secondary-button" type="button" id="man-import-close">Fermer</button>
      </div>
    </div>

    <div class="man-editor-card">
      <div class="man-node-bar">
        <div class="man-node-ident">
          <span class="man-depth-badge man-depth-0" id="man-depth-badge">Ligne principale</span>
          <span class="man-node-label" id="man-node-label">Position initiale</span>
        </div>
        <div class="replay-toolbar" style="margin:0">
          <button class="secondary-button" type="button" id="man-force-var" title="Forcer le prochain coup joué sur le damier à s’ouvrir entre crochets [ … ]">[ + ] Prochain coup en variante</button>
          <button class="secondary-button" type="button" id="man-to-var" hidden>Mettre en [ variante ]</button>
          <button class="secondary-button" type="button" id="man-promote" disabled>↑ Promouvoir</button>
          <button class="secondary-button" type="button" id="man-delete" disabled>✕ Supprimer cette suite</button>
        </div>
      </div>

      <div class="man-symbols" id="man-symbols">
        <span>Symbole :</span>
        ${ALLOWED_SYMBOLS.map(sym => `<button type="button" class="man-sym-btn" data-sym="${sym}">${sym || '—'}</button>`).join('')}
      </div>

      <label class="man-field">
        <span id="man-comment-title">Commentaire après ce coup</span>
        <textarea id="man-comment" rows="2" placeholder="Écrivez votre analyse ou commentaire ici…"></textarea>
      </label>

      <details class="man-pre-details" id="man-pre-details">
        <summary>Texte d’introduction avant ce coup (ex. « Mieux vaut », « Sur »…)</summary>
        <label class="man-field" style="margin-top:6px">
          <input type="text" id="man-pre-comment" placeholder="Ex. : Mieux vaut / Au lieu de cela, sur…">
        </label>
      </details>

      <label class="man-field" id="man-diag-cap-wrap" hidden>
        <span>Légende personnalisée du diagramme (facultatif)</span>
        <input type="text" id="man-diag-caption" placeholder="Ex. : Position clé de l’encerclement (hekstelling)">
      </label>
    </div>

    <div class="td-preview-wrap">
      <div class="td-preview-bar">
        <span><b>Feuille d’analyse interactive</b> — cliquez sur un coup pour vous y placer</span>
        <label class="check-row"><input type="checkbox" id="man-preview-diags">Afficher les diagrammes en grand dans l’aperçu</label>
      </div>
      <div class="td-preview-card" id="man-preview-card" aria-label="Aperçu de l’analyse manuelle"></div>
    </div>

    <details class="man-headers-details">
      <summary>Informations de la partie pour l’en-tête d’impression & gestion</summary>
      <div class="man-headers-grid">
        <label>Blancs<input type="text" id="man-h-white" placeholder="Blancs"></label>
        <label>Noirs<input type="text" id="man-h-black" placeholder="Noirs"></label>
        <label>Événement / Titre<input type="text" id="man-h-event" placeholder="Analyse"></label>
        <label>Lieu<input type="text" id="man-h-site" placeholder=""></label>
        <label>Date<input type="text" id="man-h-date" placeholder="2026.11.08"></label>
        <label>Résultat
          <select id="man-h-result">
            <option value="*">* (en cours / étude)</option>
            <option value="2-0">2-0 (gain Blancs FMJD)</option>
            <option value="1-1">1-1 (remise FMJD)</option>
            <option value="0-2">0-2 (gain Noirs FMJD)</option>
            <option value="1-0">1-0</option>
            <option value="1/2-1/2">1/2-1/2</option>
            <option value="0-1">0-1</option>
          </select>
        </label>
      </div>
      <div class="replay-toolbar" style="margin:10px 0 0">
        <button class="secondary-button" type="button" id="man-clear-notes">Effacer toutes mes variantes et commentaires</button>
      </div>
    </details>
  </section>
  <section class="panel study-lanes"><div class="study-lane"><h3>1 · Coups de la partie jouée</h3><p id="played-title" class="study-context"></p><div id="played-moves" class="study-moves"></div></div><div class="study-lane"><h3>2 · Variante proposée par PIONICIDE</h3><p id="variant-origin" class="study-context">Lancez une évaluation.</p><div id="an-pv" class="study-moves"></div><div class="replay-toolbar"><button class="secondary-button" id="pv-root">Racine</button><button class="secondary-button" id="pv-prev">◀ Variante</button><button class="secondary-button" id="pv-next">Variante ▶</button><button class="secondary-button" id="back-played">Revenir à la partie</button></div></div></section>
  <section class="panel"><h2>Tables de finales hors ligne</h2><p id="tb-result" role="status"></p><p id="tb-counters" class="study-context"></p><div id="tb-moves" class="replay-toolbar"></div><p class="study-context">Tables PIONICIDE : 2 à 4 pièces au total. WDL théorique, sans distance au gain. Les règles de nulle et l’historique sont examinés séparément. Pour un damier chargé sans partie, les compteurs commencent à zéro.</p></section>`;

  const q = id => el.querySelector('#' + id);
  const stateCopy = s => structuredClone(s);
  const labelAt = (index, startSide) => `${Math.floor((index + (startSide === 'b' ? 1 : 0)) / 2) + 1}${(index + (startSide === 'b' ? 1 : 0)) % 2 ? '…' : '.'}`;

  /* ---- Export annoté automatique : PDN, diagrammes, impression ---- */
  let annot = null, annotBusy = false, annotStop = false, annotToken = 0, marks = new Set(), gameHeaders = {}, gameResult = '*', gameTitle = '';
  const exportPanel = document.createElement('section');
  exportPanel.className = 'panel analysis-export';
  exportPanel.innerHTML = `<div class="section-heading"><div class="eyebrow">EXPORT AUTOMATIQUE · PDN ANNOTÉ ET PDF</div><h2>Partie annotée automatiquement par PIONICIDE</h2><p>Chaque position est évaluée une seule fois. Le symbole du coup se déduit de l’écart avec le meilleur coup de PIONICIDE ; la variante conseillée est la ligne principale du moteur.</p></div>
  <div class="export-grid">
   <div class="export-main">
    <div class="replay-toolbar">
     <button class="primary-button" id="an-annotate">Analyser et annoter la partie</button>
     <button class="secondary-button" id="an-annotate-stop" hidden>Arrêter</button>
     <button class="secondary-button" id="an-export-pdn" disabled>Exporter PDN annoté</button>
     <button class="secondary-button" id="an-print" disabled>Imprimer / PDF</button>
     <button class="secondary-button" id="an-mark">Ajouter un diagramme à l’export</button>
    </div>
    <progress id="an-annot-progress" max="1" value="0" hidden></progress>
    <p id="an-annot-status" class="study-context" role="status">Aucune analyse de partie. Lancez « Analyser et annoter la partie ».</p>
    <p id="an-mark-info" class="study-context"></p>
   </div>
   <div class="export-settings">
    <label>Niveau de détail<select id="an-detail"><option value="errors">Erreurs et grosses erreurs (par défaut)</option><option value="all">Toute la partie</option></select></label>
    <p class="study-context">Annotation, menaces et évaluation utilisent la même profondeur : celle du sélecteur « Profondeur » du damier d’analyse (16 par défaut, jusqu’à 25).</p>
    <div class="export-thresholds">
     <label>Seuil « ? » (pions perdus)<input id="an-thr-error" type="number" min="0.1" max="5" step="0.1" value="0.5" inputmode="decimal"></label>
     <label>Seuil « ?? » (pions perdus)<input id="an-thr-blunder" type="number" min="0.1" max="9" step="0.1" value="1.5" inputmode="decimal"></label>
    </div>
    <label class="check-row"><input type="checkbox" id="an-opt-arrow" checked>Flèche du meilleur coup sur les diagrammes</label>
    <label class="check-row"><input type="checkbox" id="an-opt-numbers">Numéroter les cases de 1 à 50</label>
    <label class="check-row"><input type="checkbox" id="an-opt-auto">Diagramme automatique après chaque « ?? »</label>
   </div>
  </div>`;
  const sections = el.querySelectorAll('section.panel');
  el.insertBefore(exportPanel, sections[sections.length - 1] || null);

  /* ---- Menaces : cache d'évaluations partagé, panneau et flèches ---- */
  const memo = createMemoSearch(options => scan.search(options));
  const memory = new Map();
  let threatOverlay = null;
  const gameSignature = () => `${boardToHub(original[0].board, original[0].side)}|${played.map(moveToPdn).join(',')}`;
  const manualStorageKey = () => {
    const sig = gameSignature();
    let hash = 2166136261;
    for (let i = 0; i < sig.length; i += 1) {
      hash ^= sig.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return `${MANUAL_STORAGE_PREFIX}${(hash >>> 0).toString(16)}_${played.length}`;
  };

  function saveManualToStorage() {
    try {
      const stats = countTreeStats(manualTree);
      const hasExtraMoves = stats.mainMoves > played.length;
      if (!stats.hasManualEnrichment && !hasExtraMoves) {
        localStorage.removeItem(manualStorageKey());
        return;
      }
      localStorage.setItem(manualStorageKey(), JSON.stringify({
        signature: gameSignature(),
        headers: gameHeaders,
        result: gameResult,
        title: gameTitle,
        tree: serializeManualTree(manualTree),
      }));
    } catch {
      // Stockage local indisponible ou plein : sans blocage
    }
  }

  function loadManualFromStorage() {
    try {
      const raw = localStorage.getItem(manualStorageKey());
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (parsed?.signature !== gameSignature()) return null;
      const restored = deserializeManualTree(parsed.tree);
      if (!restored) return null;
      return { tree: restored, headers: parsed.headers, result: parsed.result, title: parsed.title };
    } catch {
      return null;
    }
  }

  const panel = createThreatPanel({
    toast,
    host: {
      states: () => original.slice(0, played.length + 1),
      moves: () => played,
      memo: () => memo,
      search: options => scan.search(options),
      cursor: () => cursor,
      selectPly: index => selectPlayed(index),
      setOverlay: overlay => { threatOverlay = overlay; draw(); },
      afterUpdate: () => draw(),
      isActive: () => active,
      analysisDepth: () => analysisDepth(),
      progress: { update: (done, total, label) => progressUpdate(done, total, label) },
    },
  });
  exportPanel.after(panel.el);

  /* ---- Mauvais coups & réfutations à la demande (entraînement) ---- */
  const refutationPanel = createRefutationPanel({
    toast,
    navigate,
    host: {
      memo: () => { scan.start(); return memo; },
      search: options => { scan.start(); return scan.search(options); },
      isActive: () => active,
      isBusy: () => annotBusy,
      cancelEngineSearch: () => cancelSearch(false),
      currentSnapshot: () => {
        // Si l'utilisateur était dans un aperçu PV, on matérialise le nœud dans l'arbre manuel pour pouvoir y greffer les variantes
        let nodeId = pendingAltTarget ? pendingAltTarget.parentId : activeNodeId;
        if (inPvPreview && variant && variant.index > 0 && variant.anchorNodeId && getNode(manualTree, variant.anchorNodeId)) {
          const { lastNode } = addLineToTree(manualTree, variant.anchorNodeId, variant.moves.slice(0, variant.index), { asVariation: true });
          if (lastNode) {
            activeNodeId = lastNode.id;
            nodeId = lastNode.id;
            inPvPreview = false;
            saveManualToStorage();
          }
        }
        const anchorNode = getNode(manualTree, nodeId);
        const baseOffset = anchorNode
          ? anchorNode.ply + (manualTree.rootSide === 'b' ? 1 : 0)
          : cursor + (original[0].side === 'b' ? 1 : 0);
        return { state: stateCopy(current), nodeId, baseOffset };
      },
      previewState: (st, { arrows = [], note = '' } = {}) => {
        stopAuto();
        cancelSearch(false);
        current = stateCopy(st);
        selected = null;
        branch = true;
        inPvPreview = false;
        inRefutationPreview = true;
        refutationOverlay = (arrows.length || note) ? { arrows, text: note, kind: 'created' } : null;
        draw({ syncFields: false });
      },
      restoreAnalyzedPosition: (savedState, savedNodeId) => {
        inRefutationPreview = false;
        refutationOverlay = null;
        if (savedNodeId && getNode(manualTree, savedNodeId)) {
          selectManualNode(savedNodeId, false, false);
        } else {
          current = stateCopy(savedState);
          selected = null;
          draw({ syncFields: false });
        }
      },
      setOverlay: ov => {
        refutationOverlay = ov;
        draw({ syncFields: false });
      },
      ensureOrientation: wantedSide => {
        if (wantedSide && orientation !== wantedSide) {
          orientation = wantedSide;
        }
      },
      scrollToBoard: () => {
        q('an-board-panel')?.scrollIntoView?.({ behavior: 'smooth', block: 'nearest' });
      },
      launchGameFromState: ({ board, side, human, label }) => {
        store.playDraft = { board, side, human, label };
        navigate('jouer');
        setTimeout(() => { store.playDraft = null; }, 0);
        toast(`Partie d’entraînement lancée : ${label}`);
      },
      insertBadMoveVariation: (anchorId, item, punisherSide, { silent = false } = {}) => {
        const parentNode = (anchorId && getNode(manualTree, anchorId)) || getNode(manualTree, activeNodeId) || manualTree.root;
        // Sur une position isolée sans ligne principale, joint automatiquement le diagramme de référence
        if (parentNode.id === manualTree.root.id && !manualTree.root.main && !manualTree.root.diagram) {
          updateNodeAnnotation(manualTree, manualTree.root.id, {
            diagram: true,
            diagramCaption: manualTree.root.diagramCaption || 'Position étudiée',
          });
        }
        const seq = [item.move, ...item.refutationMoves];
        const { firstNode } = addLineToTree(manualTree, parentNode.id, seq, { asVariation: true });
        if (!firstNode) return false;
        updateNodeAnnotation(manualTree, firstNode.id, {
          symbol: item.symbol || '?',
          preComment: firstNode.preComment || 'Si',
          comment: formatBadMoveStudyComment(item, punisherSide),
        });
        if (firstNode.main) {
          updateNodeAnnotation(manualTree, firstNode.main.id, { symbol: '!' });
        }
        saveManualToStorage();
        renderManualPreviewOnly(false);
        refreshManualWorkshop({ syncFields: false });
        if (!silent) {
          toast(`Variante « Si ${item.pdn}${item.symbol} » et sa réfutation ajoutées à votre analyse.`);
        }
        return true;
      },
    },
  });
  q('an-board-panel').after(refutationPanel.el);

  function progressUpdate(done, total, label) {
    const bar = q('an-annot-progress');
    bar.hidden = false;
    bar.max = total;
    bar.value = done;
    setAnnotStatus(`Menaces · ${label || 'analyse'} ${done}/${total} positions (profondeur ${panel.options().depth})`);
  }

  function analysisDepth() {
    const value = Number(q('an-depth').value);
    return ANALYSIS_DEPTHS.includes(value) ? value : 16;
  }
  function thresholds() {
    const error = Math.max(0.1, Math.min(5, Number(q('an-thr-error').value) || 0.5));
    const blunder = Math.max(error, Math.min(9, Number(q('an-thr-blunder').value) || 1.5));
    return { error, blunder };
  }
  function annotValid() {
    return !!annot && annot.plies && annot.plies.length === played.length && played.length > 0;
  }
  function refreshExport() {
    const ready = annotValid();
    const manual = [...marks].filter(i => i > 0).length;
    q('an-export-pdn').disabled = !ready;
    q('an-print').disabled = !ready;
    q('an-annotate').disabled = annotBusy || !played.length;
    q('an-annotate-stop').hidden = !annotBusy;
    q('an-mark').disabled = branch || cursor === 0 || !played.length;
    q('an-mark').textContent = !branch && marks.has(cursor)
      ? `Retirer le diagramme du coup ${Math.ceil(cursor / 2)}`
      : `Ajouter un diagramme à l’export${!branch && cursor > 0 ? ` (coup ${Math.ceil(cursor / 2)})` : ''}`;
    const autoCount = q('an-opt-auto').checked && annotValid() ? annot.plies.filter(p => p.symbol === '??').length : 0;
    q('an-mark-info').textContent = manual || autoCount
      ? `Diagrammes joints : ${manual} choisi${manual > 1 ? 's' : ''}${autoCount ? ` + ${autoCount} automatique${autoCount > 1 ? 's' : ''} (grosses erreurs)` : ' (aucun automatique)'} · diagrammes toujours orientés Blancs en bas.`
      : '';
  }

  function setAnnotStatus(text) { q('an-annot-status').textContent = text; }

  async function annotateCurrentGame() {
    if (annotBusy) return;
    if (!played.length) { toast('Importez une partie ou jouez quelques coups avant d’annoter.'); return; }
    cancelSearch();
    annotBusy = true;
    annotStop = false;
    const myToken = ++annotToken;
    const depth = analysisDepth();
    q('an-annot-progress').hidden = false;
    q('an-annot-progress').max = played.length + 1;
    q('an-annot-progress').value = 0;
    setAnnotStatus('Annotation en cours…');
    refreshExport();
    try {
      scan.start();
      const states = original.slice(0, played.length + 1);
      const res = await annotateGame({
        states,
        search: memo,
        depth,
        maxTimeMs: 1500,
        pvLength: 6,
        onProgress: (done, total) => {
          if (myToken !== annotToken) return;
          q('an-annot-progress').max = total;
          q('an-annot-progress').value = done;
          setAnnotStatus(`Annotation en cours… ${done}/${total} positions (profondeur ${depth})`);
        },
        shouldStop: () => !active || annotStop || myToken !== annotToken,
      });
      if (myToken !== annotToken || !active) return;
      if (res.cancelled) { setAnnotStatus('Annotation interrompue. Aucun export modifié.'); toast('Annotation interrompue.'); return; }
      annot = { ...res, headers: gameHeaders, result: gameResult };
      annot.plies = withPlayedMoves(res, played, thresholds());
      const errors = annot.plies.filter(p => p.symbol === '?').length;
      const blunders = annot.plies.filter(p => p.symbol === '??').length;
      const bests = annot.plies.filter(p => p.symbol === '!').length;
      setAnnotStatus(`${annot.plies.length} coups évalués à la profondeur ${depth} · ${bests} « ! », ${errors} « ? », ${blunders} « ?? » · seuils ${thresholds().error.toFixed(1).replace('.', ',')} / ${thresholds().blunder.toFixed(1).replace('.', ',')} pion`);
      toast(`Partie annotée : ${errors} erreur${errors > 1 ? 's' : ''}, ${blunders} grosse${blunders > 1 ? 's' : ''} erreur${blunders > 1 ? 's' : ''}.`);
      memory.set(gameSignature(), {
        annot,
        threats: panel.meta() ? { results: panel.results(), summary: panel.summary(), depth: panel.meta().depth, threshold: panel.meta().threshold } : null,
      });
      if (active && panel.options().combine) {
        const threatReport = await panel.run({ combined: true, depth });
        if (myToken !== annotToken || !active) return;
        if (threatReport) {
          memory.set(gameSignature(), { annot, threats: threatReport });
          setAnnotStatus(`Passage unique · ${annot.plies.length} coups annotés et ${threatReport.summary.analysed} coups examinés pour les menaces, profondeur ${depth}.`);
          panel.showPly(cursor - 1);
        }
      }
      if (active && q('an-auto').checked) runAnalysis();
    } catch (e) {
      if (myToken !== annotToken) return;
      console.error(e);
      setAnnotStatus('Annotation impossible : ' + e.message);
      toast('Annotation impossible : ' + e.message);
    } finally {
      if (myToken === annotToken) {
        annotBusy = false;
        q('an-annot-progress').hidden = true;
        refreshExport();
      }
    }
  }

  function downloadText(text, name) {
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  function safeName(value, fallback) {
    return String(value || fallback).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || fallback;
  }

  function exportAnnotatedPdn() {
    if (!annotValid()) { toast('Analysez d’abord la partie.'); return; }
    const threatOptions = panel.options();
    const text = buildAnnotatedPdn({
      headers: annot.headers,
      moves: played,
      plies: annot.plies,
      result: gameResult,
      depth: annot.depth,
      detail: q('an-detail').value,
      thresholds: thresholds(),
      threats: threatOptions.inExport ? panel.results() : null,
      threatDepth: panel.meta()?.depth ?? threatOptions.depth,
      threatThreshold: panel.meta()?.threshold ?? threatOptions.threshold,
    });
    downloadText(text, `${safeName(annot.headers?.White, 'blancs')}-${safeName(annot.headers?.Black, 'noirs')}-annote.pdn`);
    toast('PDN annoté téléchargé : il se rouvre dans Importer.');
  }

  function printAnnotatedSheet() {
    if (!annotValid()) { toast('Analysez d’abord la partie.'); return; }
    const threatOptions = panel.options();
    openPrintSheet({
      headers: annot.headers,
      plies: annot.plies,
      states: original.slice(0, played.length + 1),
      positions: annot.positions,
      marks,
      threats: threatOptions.inExport ? panel.results() : null,
      threatDepth: panel.meta()?.depth ?? threatOptions.depth,
      options: {
        detail: q('an-detail').value,
        arrow: q('an-opt-arrow').checked,
        numbers: q('an-opt-numbers').checked,
        autoBlunder: q('an-opt-auto').checked,
        thresholds: thresholds(),
      },
      depth: annot.depth,
      result: gameResult,
      title: '',
    });
  }

  function toggleMark() {
    if (branch || cursor === 0 || !played.length) { toast('Placez-vous sur une position de la partie, après un coup.'); return; }
    if (marks.has(cursor)) { marks.delete(cursor); toast(`Diagramme du coup ${Math.ceil(cursor / 2)} retiré.`); }
    else { marks.add(cursor); toast(`Diagramme ajouté après le coup ${Math.ceil(cursor / 2)}.`); }
    refreshExport();
  }

  q('an-annotate').onclick = () => annotateCurrentGame();
  q('an-annotate-stop').onclick = () => { annotStop = true; setAnnotStatus('Arrêt demandé…'); };
  q('an-export-pdn').onclick = () => exportAnnotatedPdn();
  q('an-print').onclick = () => printAnnotatedSheet();
  q('an-mark').onclick = () => toggleMark();
  q('an-detail').onchange = () => refreshExport();
  q('an-opt-auto').onchange = () => refreshExport();
  q('an-thr-error').onchange = () => { const t = thresholds(); if (t.blunder < t.error) q('an-thr-blunder').value = String(t.error); refreshExport(); };
  q('an-thr-blunder').onchange = () => { const t = thresholds(); if (t.blunder < t.error) q('an-thr-error').value = String(t.blunder); refreshExport(); };

  /* ---- Atelier d'analyse manuelle : synchronisation UI & actions ---- */
  function syncHeaderInputs() {
    q('man-h-white').value = gameHeaders?.White || '';
    q('man-h-black').value = gameHeaders?.Black || '';
    q('man-h-event').value = gameHeaders?.Event || '';
    q('man-h-site').value = gameHeaders?.Site || '';
    q('man-h-date').value = gameHeaders?.Date || '';
    const knownRes = ['*', '2-0', '1-1', '0-2', '1-0', '1/2-1/2', '0-1'];
    q('man-h-result').value = knownRes.includes(gameResult) ? gameResult : '*';
  }

  function readHeaderInputs() {
    gameHeaders = {
      ...gameHeaders,
      White: q('man-h-white').value.trim() || gameHeaders?.White || 'Blancs',
      Black: q('man-h-black').value.trim() || gameHeaders?.Black || 'Noirs',
      Event: q('man-h-event').value.trim(),
      Site: q('man-h-site').value.trim(),
      Date: q('man-h-date').value.trim(),
    };
    gameResult = q('man-h-result').value || '*';
    saveManualToStorage();
    renderManualPreviewOnly();
  }

  for (const id of ['man-h-white', 'man-h-black', 'man-h-event', 'man-h-site', 'man-h-date', 'man-h-result']) {
    q(id).addEventListener('change', readHeaderInputs);
    if (id !== 'man-h-result') q(id).addEventListener('input', readHeaderInputs);
  }

  function renderManualPreviewOnly(scrollToActive = false) {
    const stats = countTreeStats(manualTree);
    const parts = [
      `${stats.mainMoves} demi-coup${stats.mainMoves > 1 ? 's' : ''}`,
      `${stats.variationCount} variante${stats.variationCount > 1 ? 's' : ''}`,
      stats.commentCount ? `${stats.commentCount} commentaire${stats.commentCount > 1 ? 's' : ''}` : '',
      stats.diagramCount ? `${stats.diagramCount} diagramme${stats.diagramCount > 1 ? 's' : ''}` : '',
    ].filter(Boolean);
    q('man-stats').textContent = parts.join(' · ');

    const previewHost = q('man-preview-card');
    const dom = renderNotationDom(manualTree, {
      interactive: true,
      showFullDiagramsInPreview: showPreviewDiagrams,
      activeNodeId,
      onSelectNode: nodeId => selectManualNode(nodeId, true, false),
      orientation,
      numbers: false,
      arrow: false,
      result: gameResult,
    });
    previewHost.replaceChildren(dom);
    if (scrollToActive) {
      const activeBtn = previewHost.querySelector('.is-active');
      activeBtn?.scrollIntoView?.({ block: 'nearest' });
    }
  }

  function refreshManualWorkshop({ syncFields = true, scrollToActive = false } = {}) {
    const node = getNode(manualTree, activeNodeId) || manualTree.root;
    const depth = nodeDepth(manualTree, node.id);
    const varInfo = variationRootOf(manualTree, node.id);

    const badge = q('man-depth-badge');
    badge.className = `man-depth-badge man-depth-${Math.min(depth, 3)}`;
    badge.textContent = !node.move
      ? 'Position de départ'
      : depth === 0
        ? 'Ligne principale'
        : depth === 1
          ? 'Variante [ … ]'
          : depth === 2
            ? 'Sous-variante ( … )'
            : `Sous-variante niv. ${depth}`;

    q('man-node-label').textContent = describeMoveNode(node, manualTree.rootSide);
    q('man-comment-title').textContent = node.move
      ? `Commentaire après ${describeMoveNode(node, manualTree.rootSide)}`
      : 'Commentaire d’introduction (avant le 1er coup)';

    q('man-alt-banner').hidden = !pendingAltTarget;
    if (pendingAltTarget) {
      q('man-alt-text').textContent = `Jouez maintenant sur le damier un autre coup à la place de ${pendingAltTarget.targetLabel}.`;
    }

    q('man-diagram-toggle').classList.toggle('is-toggled', Boolean(node.diagram));
    q('man-diagram-toggle').textContent = node.diagram
      ? '✓ Diagramme inséré ici (retirer)'
      : `▦ Insérer un diagramme ici (${node.move ? describeMoveNode(node, manualTree.rootSide) : 'départ'})`;

    q('man-diag-cap-wrap').hidden = !node.diagram;

    q('man-alt-move').disabled = !node.move || Boolean(pendingAltTarget);
    q('man-alt-move').textContent = node.move
      ? `⑂ Autre coup à la place de ${describeMoveNode(node, manualTree.rootSide)}`
      : '⑂ Autre coup à la place de celui-ci';

    q('man-insert-pv').disabled = !variant || !variant.moves?.length;
    q('man-force-var').classList.toggle('is-toggled', forceNextVariation);

    const canConvertToVar = Boolean(node.move && !node.originMain && depth === 0 && getParent(manualTree, node.id)?.main === node);
    q('man-to-var').hidden = !canConvertToVar;
    q('man-promote').disabled = !varInfo || (varInfo.index === 0 && Boolean(varInfo.parent.main?.originMain));
    q('man-delete').disabled = !node.move || Boolean(node.originMain);

    q('man-symbols').querySelectorAll('.man-sym-btn').forEach(btn => {
      const sym = btn.dataset.sym || '';
      btn.disabled = !node.move;
      btn.classList.toggle('active', Boolean(node.move) && (node.symbol || '') === sym);
    });

    if (syncFields) {
      if (document.activeElement !== q('man-comment')) q('man-comment').value = node.comment || '';
      if (document.activeElement !== q('man-pre-comment')) q('man-pre-comment').value = node.preComment || '';
      if (document.activeElement !== q('man-diag-caption')) q('man-diag-caption').value = node.diagramCaption || '';
      const isVarFirstMove = Boolean(varInfo && varInfo.varRoot.id === node.id);
      if (node.preComment || isVarFirstMove) q('man-pre-details').open = true;
    }

    const stats = countTreeStats(manualTree);
    q('man-print').disabled = stats.mainMoves === 0 && stats.variationCount === 0 && stats.commentCount === 0 && stats.diagramCount === 0;
    renderManualPreviewOnly(scrollToActive);
  }

  function isOriginalMainNode(node) {
    if (!node || nodeDepth(manualTree, node.id) !== 0) return false;
    if (node.ply > played.length) return false;
    const mains = mainLineNodes(manualTree);
    return mains[node.ply]?.id === node.id && Boolean(node.originMain);
  }

  function selectManualNode(nodeId, evaluate = true, keepUndos = false) {
    stopAuto();
    if (thinking) { toast('Attendez la fin du calcul PIONICIDE.'); return; }
    const node = getNode(manualTree, nodeId);
    if (!node) return;
    activeNodeId = node.id;
    pendingAltTarget = null;
    forceNextVariation = false;
    inPvPreview = false;
    inRefutationPreview = false;
    refutationOverlay = null;
    selected = null;
    if (!keepUndos) undos = [];

    if (isOriginalMainNode(node)) {
      cursor = node.ply;
      current = original[cursor];
      branch = false;
      threatOverlay = null;
      draw({ syncFields: true, scrollToActive: true });
      if (panel.results().length) panel.showPly(cursor - 1);
    } else {
      current = node.state;
      branch = true;
      threatOverlay = null;
      draw({ syncFields: true, scrollToActive: true });
    }
    refutationPanel.notifyPositionChanged(boardToHub(current.board, current.side));
    if (evaluate && q('an-auto').checked && active) runAnalysis();
  }

  q('man-symbols').addEventListener('click', event => {
    const btn = event.target.closest('.man-sym-btn');
    if (!btn || btn.disabled) return;
    const sym = btn.dataset.sym || '';
    updateNodeAnnotation(manualTree, activeNodeId, { symbol: sym });
    saveManualToStorage();
    refreshManualWorkshop({ syncFields: false });
  });

  q('man-comment').addEventListener('input', () => {
    updateNodeAnnotation(manualTree, activeNodeId, { comment: q('man-comment').value });
    saveManualToStorage();
    renderManualPreviewOnly(false);
  });

  q('man-pre-comment').addEventListener('input', () => {
    updateNodeAnnotation(manualTree, activeNodeId, { preComment: q('man-pre-comment').value });
    saveManualToStorage();
    renderManualPreviewOnly(false);
  });

  q('man-diag-caption').addEventListener('input', () => {
    updateNodeAnnotation(manualTree, activeNodeId, { diagramCaption: q('man-diag-caption').value });
    saveManualToStorage();
    renderManualPreviewOnly(false);
  });

  q('man-diagram-toggle').addEventListener('click', () => {
    const node = getNode(manualTree, activeNodeId);
    if (!node) return;
    const next = !node.diagram;
    updateNodeAnnotation(manualTree, activeNodeId, { diagram: next });
    saveManualToStorage();
    refreshManualWorkshop({ syncFields: true });
    toast(next
      ? `Diagramme inséré à l’impression (${describeMoveNode(node, manualTree.rootSide)}).`
      : 'Diagramme retiré de cette position.');
  });

  q('man-alt-move').addEventListener('click', () => {
    if (thinking) return;
    const node = getNode(manualTree, activeNodeId);
    const parent = node ? getParent(manualTree, node.id) : null;
    if (!node || !parent) return;
    pendingAltTarget = {
      parentId: parent.id,
      targetLabel: describeMoveNode(node, manualTree.rootSide),
      returnNodeId: node.id,
    };
    current = parent.state;
    selected = null;
    inPvPreview = false;
    draw({ syncFields: false });
    toast(`Jouez sur le damier un autre coup à la place de ${pendingAltTarget.targetLabel}.`);
  });

  q('man-alt-cancel').addEventListener('click', () => {
    if (!pendingAltTarget) return;
    const retId = pendingAltTarget.returnNodeId;
    pendingAltTarget = null;
    selectManualNode(retId, false, true);
  });

  q('man-force-var').addEventListener('click', () => {
    forceNextVariation = !forceNextVariation;
    refreshManualWorkshop({ syncFields: false });
    if (forceNextVariation) toast('Le prochain coup joué sur le damier ouvrira une nouvelle variante [ … ].');
  });

  q('man-to-var').addEventListener('click', () => {
    if (convertMainToVariation(manualTree, activeNodeId)) {
      branch = true;
      saveManualToStorage();
      draw({ syncFields: false, scrollToActive: true });
      toast('Suite convertie en variante [ … ].');
    }
  });

  q('man-promote').addEventListener('click', () => {
    if (promoteVariation(manualTree, activeNodeId, { swapWithMain: true })) {
      saveManualToStorage();
      draw({ syncFields: false, scrollToActive: true });
      toast('Variante promue.');
    }
  });

  q('man-delete').addEventListener('click', () => {
    const node = getNode(manualTree, activeNodeId);
    if (!node || !node.move || node.originMain) return;
    const parent = deleteSubtree(manualTree, node.id, { allowOriginMain: false });
    if (parent) {
      saveManualToStorage();
      selectManualNode(parent.id, false, false);
      toast('Suite supprimée.');
    }
  });

  q('man-insert-pv').addEventListener('click', () => {
    if (!variant || !variant.moves?.length) {
      toast('Lancez d’abord une évaluation PIONICIDE.');
      return;
    }
    const anchorId = variant.anchorNodeId && getNode(manualTree, variant.anchorNodeId)
      ? variant.anchorNodeId
      : activeNodeId;
    const { firstNode } = addLineToTree(manualTree, anchorId, variant.moves.slice(0, 8), { asVariation: true });
    if (firstNode) {
      saveManualToStorage();
      selectManualNode(firstNode.id, false, false);
      toast('Variante PIONICIDE ajoutée à votre analyse.');
    }
  });

  q('man-preview-diags').addEventListener('change', () => {
    showPreviewDiagrams = q('man-preview-diags').checked;
    renderManualPreviewOnly(false);
  });

  q('man-print').addEventListener('click', () => {
    readHeaderInputs();
    openManualPrintSheet({
      tree: manualTree,
      headers: gameHeaders,
      result: gameResult,
      title: gameHeaders?.Event || gameTitle || '',
      orientation,
      options: {
        columns: 1,
        diagramSize: 'medium',
        numbers: q('an-opt-numbers')?.checked || false,
        arrow: false,
        colorScheme: 'classic',
      },
    });
  });

  q('man-export-pdn').addEventListener('click', () => {
    readHeaderInputs();
    const pdn = treeToPdn(manualTree, { headers: gameHeaders, result: gameResult });
    downloadText(pdn, `${safeName(gameHeaders?.White, 'blancs')}-${safeName(gameHeaders?.Black, 'noirs')}-analyse-manuelle.pdn`);
    toast('PDN complet (variantes, commentaires et diagrammes) téléchargé.');
  });

  q('man-import-toggle').addEventListener('click', () => {
    q('man-import-box').hidden = !q('man-import-box').hidden;
  });
  q('man-import-close').addEventListener('click', () => {
    q('man-import-box').hidden = true;
  });
  q('man-import-file').addEventListener('change', async () => {
    const file = q('man-import-file').files?.[0];
    if (!file) return;
    if (file.size > 2000000) { toast('Fichier limité à 2 Mo.'); return; }
    q('man-import-text').value = await file.text();
    q('man-import-file').value = '';
  });
  q('man-import-apply').addEventListener('click', () => {
    const text = q('man-import-text').value.trim();
    if (!text) { toast('Collez ou choisissez d’abord un fichier PDN.'); return; }
    try {
      const parsed = parsePdnToTree(text);
      const mains = mainLineNodes(parsed.tree);
      const mainMoves = mains.slice(1).map(n => n.move);
      load({
        start: parsed.tree.root.state,
        moves: mainMoves,
        cursor: 0,
        headers: parsed.headers,
        result: parsed.result,
        rawPdn: text,
        fresh: true,
        title: parsed.headers?.White || parsed.headers?.Black
          ? `${parsed.headers.White || 'Blancs'} — ${parsed.headers.Black || 'Noirs'}`
          : 'Analyse importée',
      });
      q('man-import-box').hidden = true;
      toast('PDN chargé avec ses variantes, commentaires et diagrammes.');
    } catch (e) {
      toast('Lecture PDN impossible : ' + e.message);
    }
  });

  q('man-clear-notes').addEventListener('click', () => {
    manualTree = createManualTree({ start: original[0], moves: played });
    const mains = mainLineNodes(manualTree);
    activeNodeId = (mains[Math.min(cursor, mains.length - 1)] || manualTree.root).id;
    pendingAltTarget = null;
    forceNextVariation = false;
    inPvPreview = false;
    branch = false;
    current = original[cursor];
    undos = [];
    try { localStorage.removeItem(manualStorageKey()); } catch {}
    draw({ syncFields: true });
    toast('Variantes et commentaires manuels effacés (la partie d’origine est conservée).');
  });

  function stopAuto() {
    if (auto) clearInterval(auto);
    auto = null;
    q('an-play').textContent = '▶ Auto';
  }
  function cancelSearch(release = false) {
    token++;
    thinking = false;
    if (release) scan.release();
    else if (scan.current) scan.restart();
  }

  function describeBranchContext() {
    if (inRefutationPreview) return 'Exploration d’un mauvais coup et de sa réfutation — la partie jouée reste intacte.';
    if (inPvPreview) return 'Exploration de la variante proposée par PIONICIDE — la partie jouée n’est pas modifiée.';
    const node = getNode(manualTree, activeNodeId);
    if (!node) return 'Exploration séparée — la partie jouée n’est pas modifiée.';
    const depth = nodeDepth(manualTree, node.id);
    if (depth === 0) {
      return `Suite manuelle · ${describeMoveNode(node, manualTree.rootSide)}`;
    }
    const vInfo = variationRootOf(manualTree, node.id);
    const rootLabel = vInfo ? describeMoveNode(vInfo.varRoot, manualTree.rootSide) : '';
    const kind = depth === 1 ? `Variante [ ${rootLabel} ]` : `Sous-variante ( ${rootLabel} )`;
    return `${kind} · position ${describeMoveNode(node, manualTree.rootSide)} — la partie jouée reste intacte.`;
  }

  function draw(workshopOpts = { syncFields: true, scrollToActive: false }) {
    const decision = adjudicate(current.board, current.side, current.drawState);
    const legalTargets = new Set(selected === null ? [] : generateLegalMoves(current.board, current.side).filter(m => m.from === selected).map(m => m.to));
    const boardArrows = refutationOverlay
      ? refutationOverlay.arrows
      : (threatOverlay && threatOverlay.boardCursor === cursor ? threatOverlay.arrows : []);
    const activeNote = refutationOverlay || threatOverlay;
    renderBoard(q('analysis-board'), {
      board: current.board,
      orientation,
      lastMove: current.lastMove,
      selected,
      targets: legalTargets,
      onSquareClick: handleSquare,
      arrows: boardArrows,
    });
    q('an-threat-note').textContent = activeNote?.text || '';
    q('an-threat-note').className = 'threat-onboard' + (activeNote?.text ? ' visible ' + (activeNote.kind === 'created' ? 'is-created' : 'is-avoided') : '');
    q('an-code').value = positionToPdn(current.board, current.side);
    q('an-side').textContent = 'Trait : ' + (current.side === 'w' ? 'Blancs' : 'Noirs');
    q('an-status').textContent = decision ? decision.reason : thinking ? 'PIONICIDE analyse…' : 'Prêt';
    q('an-context').textContent = branch ? describeBranchContext() : `Partie jouée · demi-coup ${cursor}/${played.length}`;
    q('played-title').textContent = title;
    q('tb-counters').textContent = drawStatus(current.drawState);
    q('an-undo').disabled = !undos.length && !branch && cursor === 0;

    q('played-moves').replaceChildren();
    const first = document.createElement('button');
    first.className = 'secondary-button' + (!branch && cursor === 0 ? ' active' : '');
    first.textContent = 'Départ';
    first.onclick = () => selectPlayed(0);
    q('played-moves').append(first);
    played.forEach((m, i) => {
      const b = document.createElement('button');
      b.className = 'secondary-button' + (!branch && cursor === i + 1 ? ' active' : '');
      b.append(document.createTextNode(labelAt(i, original[0].side) + ' ' + moveToPdn(m)));
      const mark = panel.entryFor(i);
      if (mark?.created) {
        const badge = document.createElement('span');
        badge.className = 'threat-badge threat-created';
        badge.textContent = '▲';
        badge.title = 'Menace créée';
        b.append(badge);
      }
      if (mark?.avoided) {
        const badge = document.createElement('span');
        badge.className = 'threat-badge threat-avoided';
        badge.textContent = '▼';
        badge.title = 'Menace évitée';
        b.append(badge);
      }
      if (mark) {
        b.title = [mark.created ? 'Menace créée' : '', mark.avoided ? 'Menace évitée' : '', mark.note || ''].filter(Boolean).join(' · ');
      }
      b.onclick = () => selectPlayed(i + 1);
      q('played-moves').append(b);
    });

    q('an-pv').replaceChildren();
    if (variant) {
      q('variant-origin').textContent = `Depuis ${variant.originLabel} · ${variant.moves.length} demi-coups légaux vérifiés${variant.truncated ? ' · suite arrêtée au premier coup non reconnu' : ''}`;
      variant.moves.forEach((m, i) => {
        const b = document.createElement('button');
        b.className = 'secondary-button' + (inPvPreview && variant.index === i + 1 ? ' active' : '');
        b.textContent = labelAt(i, variant.states[0].side) + ' ' + moveToPdn(m);
        b.onclick = () => selectVariant(i + 1);
        q('an-pv').append(b);
      });
    }

    refreshExport();
    refreshManualWorkshop(workshopOpts);

    q('tb-moves').replaceChildren();
    if (decision) {
      q('tb-result').textContent = decision.result + ' · ' + decision.reason;
      return;
    }
    const tb = probeTable(current.board, current.side);
    q('tb-result').textContent = tb.available ? `${wdlLabel(tb.value)} pour le trait · ${tb.source} · WDL théorique, sans historique.` : tb.reason;
    if (tb.available) {
      for (const t of tb.moves) {
        const b = document.createElement('button');
        b.className = 'secondary-button';
        b.textContent = t.notation + ' : ' + wdlLabel(t.value);
        b.onclick = () => {
          if (thinking) return;
          const m = generateLegalMoves(current.board, current.side).find(m => moveToHub(m) === t.notation);
          if (m) playManual(m);
        };
        q('tb-moves').append(b);
      }
    }
  }

  function selectPlayed(index, evaluate = true) {
    stopAuto();
    if (thinking) { toast('Attendez la fin du calcul PIONICIDE.'); return; }
    cursor = Math.max(0, Math.min(played.length, index));
    current = original[cursor];
    const mains = mainLineNodes(manualTree);
    activeNodeId = (mains[cursor] || manualTree.root).id;
    pendingAltTarget = null;
    forceNextVariation = false;
    inPvPreview = false;
    inRefutationPreview = false;
    refutationOverlay = null;
    selected = null;
    branch = false;
    undos = [];
    threatOverlay = null;
    draw({ syncFields: true, scrollToActive: true });
    refutationPanel.notifyPositionChanged(boardToHub(current.board, current.side));
    if (panel.results().length) panel.showPly(cursor - 1);
    if (evaluate && q('an-auto').checked && active) runAnalysis();
  }

  function selectVariant(index) {
    stopAuto();
    if (thinking || !variant) return;
    variant.index = Math.max(0, Math.min(variant.moves.length, index));
    undos.push({
      kind: 'pv',
      prevState: stateCopy(current),
      prevNodeId: activeNodeId,
      prevBranch: branch,
      prevCursor: cursor,
      prevInPv: inPvPreview,
    });
    current = variant.states[variant.index];
    selected = null;
    branch = true;
    inPvPreview = true;
    inRefutationPreview = false;
    refutationOverlay = null;
    pendingAltTarget = null;
    draw({ syncFields: false });
  }

  function playManual(move) {
    const prevRecord = {
      kind: 'manual',
      prevState: stateCopy(current),
      prevNodeId: activeNodeId,
      prevBranch: branch,
      prevCursor: cursor,
      prevInPv: inPvPreview,
      createdNodeId: null,
    };

    // Si l'utilisateur explorait l'aperçu PV de PIONICIDE puis joue sur le damier, on matérialise le préfixe PV
    if (inPvPreview && variant && variant.index > 0 && variant.anchorNodeId && getNode(manualTree, variant.anchorNodeId)) {
      const { lastNode } = addLineToTree(manualTree, variant.anchorNodeId, variant.moves.slice(0, variant.index), { asVariation: true });
      if (lastNode) activeNodeId = lastNode.id;
      inPvPreview = false;
    }

    const anchorId = pendingAltTarget ? pendingAltTarget.parentId : activeNodeId;
    const asVariation = Boolean(pendingAltTarget) || forceNextVariation;
    pendingAltTarget = null;
    forceNextVariation = false;

    const { node, created } = playMoveOnTree(manualTree, anchorId, move, { asVariation });
    prevRecord.createdNodeId = created ? node.id : null;
    undos.push(prevRecord);

    activeNodeId = node.id;
    selected = null;
    inPvPreview = false;
    inRefutationPreview = false;
    refutationOverlay = null;

    if (isOriginalMainNode(node)) {
      cursor = node.ply;
      current = original[cursor];
      branch = false;
    } else {
      current = node.state;
      branch = true;
    }

    saveManualToStorage();
    draw({ syncFields: true, scrollToActive: true });
    refutationPanel.notifyPositionChanged(boardToHub(current.board, current.side));
    if (q('an-auto').checked) runAnalysis();
  }

  function handleSquare(n) {
    if (thinking || refutationPanel.isBusy() || adjudicate(current.board, current.side, current.drawState)) return;
    const legal = generateLegalMoves(current.board, current.side);
    if (selected !== null) {
      const m = legal.find(m => m.from === selected && m.to === n);
      if (m) {
        if (refutationPanel.isDrilling()) {
          selected = null;
          refutationPanel.handleBoardMove(m);
          return;
        }
        playManual(m);
        return;
      }
    }
    selected = sideOf(current.board[n]) === current.side ? (selected === n ? null : n) : null;
    draw({ syncFields: false });
  }

  async function runAnalysis(showHint = false) {
    if (thinking || !active || annotBusy) return;
    const error = validatePosition(current.board, current.side);
    if (error) { toast(error); return; }
    if (adjudicate(current.board, current.side, current.drawState)) { draw({ syncFields: false }); return; }
    scan.start();
    const anchor = stateCopy(current);
    const anchorNodeId = pendingAltTarget ? pendingAltTarget.parentId : activeNodeId;
    const originLabel = branch ? 'une position explorée' : `la partie au demi-coup ${cursor}`;
    const myToken = ++token;
    thinking = true;
    draw({ syncFields: false });
    try {
      const result = await scan.search({
        position: 'pos=' + boardToHub(anchor.board, anchor.side),
        depth: Number(q('an-depth').value),
        mode: 'analyze',
        onInfo: info => {
          if (myToken !== token || !active) return;
          q('an-score').textContent = Number.isFinite(info.score) ? `${info.score > 0 ? '+' : ''}${info.score.toFixed(2)} (vu du trait)` : '—';
          q('an-meta').textContent = `Profondeur ${info.depth ?? '—'} · ${info.nodes ?? '—'} nœuds · ${Math.round(info.knps || 0)} kn/s · ${(info.time || 0).toFixed(2)} s${info.completed ? ' · itération terminée' : ''}`;
        },
      });
      if (myToken !== token || !active) return;
      thinking = false;
      const info = result.infos.at(-1);
      const texts = info?.pv?.length ? info.pv : result.move ? [result.move] : [];
      const vm = [];
      const vs = [anchor];
      let truncated = false;
      for (const text of texts) {
        const state = vs.at(-1);
        const m = generateLegalMoves(state.board, state.side).find(m => moveMatchesEngine(m, text));
        if (!m) { truncated = true; break; }
        vm.push(m);
        vs.push(appendState([state], m).at(-1));
      }
      variant = { states: vs, moves: vm, index: 0, originLabel, truncated, anchorNodeId };
      q('an-meta').textContent += (result.timeLimited ? ' · limite de temps : dernière itération terminée' : result.timedOut ? ' · délai de sécurité atteint' : '');
      draw({ syncFields: false });
      if (showHint && vm.length) toast('Coup conseillé : ' + moveToPdn(vm[0]));
    } catch (e) {
      if (myToken !== token) return;
      thinking = false;
      draw({ syncFields: false });
      toast(e.message);
    }
  }

  q('an-evaluate').onclick = () => runAnalysis();
  q('an-hint').onclick = () => runAnalysis(true);
  q('an-bad-moves').onclick = () => {
    refutationPanel.el.scrollIntoView?.({ behavior: 'smooth', block: 'start' });
    refutationPanel.run();
  };
  q('an-depth').onchange = () => { if (q('an-auto').checked) runAnalysis(); };
  q('an-auto').onchange = () => { if (q('an-auto').checked) runAnalysis(); };
  q('an-flip').onclick = () => { orientation = orientation === 'w' ? 'b' : 'w'; draw({ syncFields: false }); };
  q('an-first').onclick = () => selectPlayed(0);
  q('an-prev').onclick = () => {
    if (thinking) return;
    if (branch && !inPvPreview) {
      const parent = getParent(manualTree, activeNodeId);
      if (parent) { selectManualNode(parent.id, true, false); return; }
    }
    selectPlayed(cursor - 1);
  };
  q('an-next').onclick = () => {
    if (thinking) return;
    if (branch && !inPvPreview) {
      const node = getNode(manualTree, activeNodeId);
      if (node?.main) { selectManualNode(node.main.id, true, false); return; }
      return;
    }
    const activeNode = getNode(manualTree, activeNodeId);
    if (cursor >= played.length && activeNode?.main) {
      selectManualNode(activeNode.main.id, true, false);
      return;
    }
    selectPlayed(cursor + 1);
  };
  q('an-last').onclick = () => selectPlayed(played.length);
  q('pv-root').onclick = () => selectVariant(0);
  q('pv-prev').onclick = () => selectVariant((variant?.index || 0) - 1);
  q('pv-next').onclick = () => selectVariant((variant?.index || 0) + 1);
  q('back-played').onclick = () => selectPlayed(cursor, false);

  q('an-play').onclick = () => {
    if (auto) { stopAuto(); return; }
    if (thinking) return;
    if (cursor === played.length) cursor = 0;
    branch = false;
    inPvPreview = false;
    pendingAltTarget = null;
    current = original[cursor];
    const mains = mainLineNodes(manualTree);
    activeNodeId = (mains[cursor] || manualTree.root).id;
    draw({ syncFields: true, scrollToActive: true });
    q('an-play').textContent = '⏸ Auto';
    auto = setInterval(() => {
      if (thinking || cursor >= played.length) { stopAuto(); return; }
      cursor++;
      current = original[cursor];
      const mNodes = mainLineNodes(manualTree);
      activeNodeId = (mNodes[cursor] || manualTree.root).id;
      branch = false;
      selected = null;
      draw({ syncFields: true, scrollToActive: true });
      if (cursor >= played.length) stopAuto();
    }, 800);
  };

  q('an-undo').onclick = () => {
    if (thinking) return;
    if (pendingAltTarget) {
      const retId = pendingAltTarget.returnNodeId;
      pendingAltTarget = null;
      selectManualNode(retId, false, true);
      return;
    }
    if (undos.length) {
      const rec = undos.pop();
      if (rec.createdNodeId) {
        const created = getNode(manualTree, rec.createdNodeId);
        if (created && !created.main && !created.variations.length && !created.comment && !created.preComment && !created.diagram) {
          deleteSubtree(manualTree, created.id, { allowOriginMain: false });
          saveManualToStorage();
        }
      }
      if (rec.kind === 'pv') {
        current = rec.prevState;
        activeNodeId = rec.prevNodeId;
        branch = rec.prevBranch;
        cursor = rec.prevCursor;
        inPvPreview = rec.prevInPv;
        selected = null;
        draw({ syncFields: true });
        return;
      }
      if (rec.prevNodeId && getNode(manualTree, rec.prevNodeId)) {
        selectManualNode(rec.prevNodeId, false, true);
        return;
      }
    }
    if (branch && !inPvPreview) {
      const parent = getParent(manualTree, activeNodeId);
      if (parent) { selectManualNode(parent.id, false, false); return; }
    }
    selectPlayed(cursor - 1, false);
  };

  function load(draft) {
    cancelSearch();
    original = [initialState(draft?.start?.board, draft?.start?.side)];
    played = [];
    for (const m of draft?.moves || []) {
      const s = original.at(-1);
      const legal = generateLegalMoves(s.board, s.side).find(x => moveToHub(x) === moveToHub(m));
      if (!legal) break;
      played.push(legal);
      original = appendState(original, legal);
    }
    cursor = Math.min(draft?.cursor ?? played.length, played.length);
    current = original[cursor];
    title = draft?.title || 'Position chargée';
    gameTitle = title;
    gameHeaders = draft?.headers ? { ...draft.headers } : {};
    gameResult = draft?.result || '*';
    variant = null;
    branch = false;
    inPvPreview = false;
    inRefutationPreview = false;
    refutationOverlay = null;
    pendingAltTarget = null;
    forceNextVariation = false;
    selected = null;
    undos = [];
    annotStop = true;
    annotToken++;
    annotBusy = false;
    marks.clear();
    threatOverlay = null;
    refutationPanel.reset();
    q('variant-origin').textContent = 'Lancez une évaluation.';

    // Construction ou restauration de l'arbre d'analyse manuelle
    let treeBuilt = null;
    if (draft?.rawPdn) {
      try {
        const parsed = parsePdnToTree(draft.rawPdn);
        if (parsed?.tree) treeBuilt = parsed.tree;
      } catch {
        treeBuilt = null;
      }
    }
    if (!treeBuilt && !draft?.fresh) {
      const cached = loadManualFromStorage();
      if (cached?.tree) {
        treeBuilt = cached.tree;
        if (cached.headers && !Object.keys(gameHeaders).length) gameHeaders = cached.headers;
        if (cached.result && gameResult === '*') gameResult = cached.result;
      }
    }
    manualTree = treeBuilt || createManualTree({ start: original[0], moves: played });
    const mains = mainLineNodes(manualTree);
    activeNodeId = (mains[cursor] || manualTree.root).id;
    syncHeaderInputs();
    if (draft?.rawPdn) saveManualToStorage();

    const saved = memory.get(gameSignature());
    if (saved && saved.annot && saved.annot.plies && saved.annot.plies.length === played.length && played.length) {
      annot = saved.annot;
      if (saved.threats) panel.restore(saved.threats, { restored: true });
      else panel.reset();
      setAnnotStatus(`Résultats mémorisés · annotation profondeur ${annot.depth}${saved.threats ? ` · menaces profondeur ${saved.threats.depth}` : ''} · aucun recalcul.`);
    } else {
      annot = null;
      panel.reset();
      setAnnotStatus('Aucune analyse de partie. Lancez « Analyser et annoter la partie ».');
    }
    draw({ syncFields: true, scrollToActive: true });
  }

  q('an-reset').onclick = () => { if (thinking) return; load({ fresh: true }); };
  q('an-edit').onclick = () => { store.positionDraft = { board: current.board.slice(), side: current.side }; navigate('editeur'); };
  q('an-print-position').onclick = () => openGameSheet({
    title: gameTitle || 'Position du damier d’analyse',
    subtitle: gameHeaders && (gameHeaders.White || gameHeaders.Black) ? `${gameHeaders.White || 'Blancs'} — ${gameHeaders.Black || 'Noirs'}` : '',
    meta: [(gameHeaders && gameHeaders.Event) || '', (gameHeaders && gameHeaders.Date) || '', `position ${cursor} demi-coup${cursor > 1 ? 's' : ''}`].filter(Boolean).join(' · '),
    board: current.board,
    orientation,
    numbers: true,
    moves: played.map(moveToPdn),
    cursor,
    side: current.side,
  });
  q('an-copy').onclick = () => navigator.clipboard?.writeText(q('an-code').value).then(() => toast('Code copié.')).catch(() => q('an-code').select());

  syncHeaderInputs();
  draw({ syncFields: true });

  /* ---- Réorganisation téléphone : page principale épurée + panneaux à la demande ---- */
  installAnalysisShell({ el, q, navigate });

  return {
    el,
    mount() {
      active = true;
      scan.ensureStarted();
      if (store.analysisDraft) {
        const d = store.analysisDraft;
        store.analysisDraft = null;
        store.positionDraft = null;
        load(d);
      } else if (store.positionDraft) {
        const d = store.positionDraft;
        store.positionDraft = null;
        load({ start: d, title: 'Position sans historique', fresh: true });
      }
      if (q('an-auto').checked) runAnalysis();
    },
    unmount() {
      active = false;
      annotStop = true;
      annotToken++;
      stopAuto();
      panel.clearOverlay();
      refutationPanel.reset();
      threatOverlay = null;
      refutationOverlay = null;
      cancelSearch();
      scan.dispose();
      scan = sharedScan;
    },
  };
}
