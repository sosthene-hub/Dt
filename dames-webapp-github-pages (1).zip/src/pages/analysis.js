import {probeTable,wdlLabel} from '../bitbases.js';
import {newDrawState,advanceDraw,adjudicate,drawStatus} from '../draw-rules.js';
import {savePositions} from '../position-library.js';
import { engine } from '../engine.js';
import { renderBoard } from '../board-view.js';
import { applyMove, createInitialBoard, generateLegalMoves, moveToHub, sideOf } from '../game-rules.js';
import { positionToPdn, validatePosition } from '../position.js';
import { store } from '../store.js';

function formatScore(score, side) {
  if (score >= 90) return side === 'w' ? 'Mate pour les Blancs' : 'Mate pour les Noirs';
  if (score <= -90) return side === 'w' ? 'Mate pour les Noirs' : 'Mate pour les Blancs';
  const rounded = Math.round(Math.abs(score) * 100) / 100;
  if (rounded < 0.05) return 'Évaluation équilibrée';
  const who = score > 0 ? (side === 'w' ? 'Blancs' : 'Noirs') : (side === 'w' ? 'Noirs' : 'Blancs');
  return `${who} +${rounded.toFixed(2).replace('.', ',')}`;
}

export function createAnalysisPage({ navigate, toast }) {
  const el = document.createElement('div');
  let board = store.positionDraft?.board ?? createInitialBoard();
  let side = store.positionDraft?.side ?? 'w';
  store.positionDraft = null;

  let legalMoves = generateLegalMoves(board, side);
  let selected = null;
  let lastMove = null;
  let history = [];
  let undoStack = [];
  let drawState=newDrawState(board,side);
  let depth = 5;
  let autoEval = true;
  let thinking = false;
  let disposed = false;
  let searchToken = 0;

  el.innerHTML = `
    <div class="section-heading"><div class="eyebrow">OUTILS · ANALYSE</div><h1>Damier d’analyse</h1><p>Jouez librement les deux camps ou laissez Scan évaluer la position et proposer la meilleure suite.</p></div>
    <section class="panel analysis-panel">
      <div class="analysis-grid">
        <div>
          <div class="player-row"><div class="avatar dark-avatar">N</div><div class="player-name"><b>Noirs</b><span>Clic pour jouer selon le trait</span></div><span class="turn-indicator" id="an-side">Trait : Blancs</span></div>
          <div class="board-wrap"><div id="analysis-board"></div></div>
          <div class="player-row bottom-player"><div class="avatar light-avatar">B</div><div class="player-name"><b>Blancs</b><span>Prises obligatoires · capture maximale</span></div><span class="turn-indicator" id="an-status">Prêt</span></div>
        </div>
        <aside class="analysis-side">
          <div class="field-block">
            <span class="field-label">Moteur Scan 3.1</span>
            <div class="eval-display" id="an-eval">
              <div class="eval-score" id="an-score">—</div>
              <div class="eval-bar"><div class="eval-fill" id="an-fill"></div></div>
              <div class="eval-meta" id="an-meta">Aucune évaluation</div>
            </div>
          </div>
          <div class="field-block">
            <span class="field-label">Profondeur</span>
            <select id="an-depth" aria-label="Profondeur d’analyse">
              <option value="3">Facile · 3</option>
              <option value="5" selected>Normale · 5</option>
              <option value="7">Forte · 7</option>
              <option value="9">Experte · 9</option>
            </select>
          </div>
          <label class="check-row"><input type="checkbox" id="an-auto" checked /> <span>Évaluer après chaque coup</span></label>
          <div class="editor-actions">
            <button class="secondary-button" id="an-evaluate" type="button">⚖ Évaluer</button>
            <button class="secondary-button" id="an-hint" type="button">✦ Coup conseillé</button>
          </div>
          <div class="editor-actions">
            <button class="secondary-button" id="an-undo" type="button" disabled>↶ Annuler</button>
            <button class="secondary-button" id="an-reset" type="button">Position initiale</button>
          </div>
          <button class="secondary-button wide" id="an-edit" type="button">Éditer cette position…</button>
          <div class="field-block">
            <span class="field-label">Variante principale</span>
            <ol class="pv-list" id="an-pv"><li class="pv-empty">Lancez une évaluation.</li></ol>
          </div>
          <div class="field-block">
            <span class="field-label">Code de position</span>
            <div class="code-row"><input id="an-code" type="text" readonly aria-label="Code de position au format PDN"><button class="secondary-button" id="an-copy" type="button">Copier</button></div>
          </div>
        </aside>
      </div>
    </section>
  `;

  const boardEl = el.querySelector('#analysis-board');
  const sideLabel = el.querySelector('#an-side');
  const statusLabel = el.querySelector('#an-status');
  const scoreEl = el.querySelector('#an-score');
  const fillEl = el.querySelector('#an-fill');
  const metaEl = el.querySelector('#an-meta');
  const pvEl = el.querySelector('#an-pv');
  const undoButton = el.querySelector('#an-undo');
  const depthSelect = el.querySelector('#an-depth');
  const autoCheckbox = el.querySelector('#an-auto');
  const codeEl = el.querySelector('#an-code');

  depthSelect.value = String(depth);

  const endPanel=document.createElement('section');endPanel.className='panel';endPanel.innerHTML='<h2>Tables de finales hors ligne</h2><p>Tables officielles Scan : 2 à 4 pièces au total, pions et dames. Gain/nulle/perte théorique, sans distance au gain. Les compteurs réglementaires restent prioritaires.</p><p id="tb-result" role="status"></p><p id="tb-counters"></p><div id="tb-moves" class="editor-actions"></div><p>Position chargée sans historique : compteurs démarrés à zéro. Une ancienne répétition ou des coups antérieurs ne peuvent pas être déduits du seul damier.</p>';
  el.append(endPanel);
  function renderEndgame(){const text=endPanel.querySelector('#tb-result'),moves=endPanel.querySelector('#tb-moves');moves.replaceChildren();const decision=adjudicate(board,side,drawState);endPanel.querySelector('#tb-counters').textContent=drawStatus(drawState);if(decision){text.textContent=decision.result+' · '+decision.reason;return;}const tb=probeTable(board,side);if(!tb.available){text.textContent=tb.reason;return;}text.textContent=`${wdlLabel(tb.value)} pour le camp au trait · ${tb.source} · ${tb.notice}`;for(const m of tb.moves){const b=document.createElement('button');b.className='secondary-button';b.textContent=m.notation+' : '+wdlLabel(m.value);b.disabled=thinking;b.onclick=()=>{if(thinking)return;const legal=generateLegalMoves(board,side).find(x=>moveToHub(x)===m.notation);if(legal)playMove(legal);};moves.append(b);}}

  function markers(hint) {
    const map = new Map();
    if (hint) {
      const numbers = hint.split(/[x-]/).map(Number);
      if (numbers[0]) map.set(numbers[0], 'engine-from');
      if (numbers[1]) map.set(numbers[1], 'engine-to');
    }
    return map;
  }

  function draw(hint) {
    renderEndgame();
    renderBoard(boardEl, {
      board,
      orientation: 'w',
      selected,
      lastMove,
      targets: selected === null ? new Set() : new Set(legalMoves.filter(move => move.from === selected).map(move => move.to)),
      markers: markers(hint),
      onSquareClick: handleSquare,
    });
  }

  function handleSquare(square) {
    if (thinking || adjudicate(board,side,drawState)) return;
    if (selected !== null) {
      const choices = legalMoves.filter(move => move.from === selected && move.to === square);
      if (choices.length) { playMove(choices[0]); return; }
    }
    if (sideOf(board[square]) === side) {
      selected = selected === square ? null : square;
      statusLabel.textContent = selected === null ? 'Prêt' : `Pièce ${square} sélectionnée`;
      draw();
    } else {
      selected = null;
      draw();
    }
  }

  function playMove(move) {
    undoStack.push({ board: board.slice(), side, history: [...history], lastMove: lastMove ? [...lastMove] : null,drawState:structuredClone(drawState) });
    const before=board;board = applyMove(board, move);
    drawState=advanceDraw(drawState,before,move,board,side==='w'?'b':'w');
    lastMove = [...move.path];
    history.push(moveToHub(move));
    side = side === 'w' ? 'b' : 'w';
    selected = null;
    legalMoves = generateLegalMoves(board, side);
    undoButton.disabled = undoStack.length === 0;
    sideLabel.textContent = `Trait : ${side === 'w' ? 'Blancs' : 'Noirs'}`;
    const decision=adjudicate(board,side,drawState);
    updateCode();
    if (decision) {
      statusLabel.textContent=decision.reason;draw();return;
    }
    if (!legalMoves.length) {
      statusLabel.textContent = `Fin de partie : ${side === 'w' ? 'les Blancs' : 'les Noirs'} n’ont aucun coup légal.`;
      draw();
      return;
    }
    statusLabel.textContent = 'Prêt';
    draw();
    updateCode();
    if (autoEval) evaluate(false);
  }

  function updateCode() {
    codeEl.value = positionToPdn(board, side);
  }

  async function evaluate(showHint) {
    const decision=adjudicate(board,side,drawState);if(decision){statusLabel.textContent=decision.reason;return;}
    const error = validatePosition(board, side);
    if (error) { toast(error); return; }
    if (!legalMoves.length) { toast('Aucun coup légal pour le trait.'); return; }
    thinking = true;
    statusLabel.textContent = 'Scan analyse…';
    const token = ++searchToken;
    try {
      const result = await engine.search({
        position: `pos=${(side === 'w' ? 'W' : 'B') + board.slice(1).join('')}`,
        moves: history.join(' '),
        depth: Number(depthSelect.value),
        mode: 'analyze',
        onInfo: info => {
          if (disposed || token !== searchToken) return;
          renderEval(info, null);
        },
      });
      if (disposed || token !== searchToken) return;
      thinking = false;
      statusLabel.textContent = 'Prêt';
      if (result.move) renderEval(result.infos[result.infos.length - 1], result.move);
      else if (!result.timedOut) {
        scoreEl.textContent = 'Fin';
        metaEl.textContent = 'Aucun coup légal : position terminale.';
        fillEl.style.width = '50%';
      } else {
        metaEl.textContent = 'Analyse interrompue (délai dépassé).';
      }
      if (showHint && result.move) {
        draw(result.move);
        toast(`Coup conseillé : ${result.move}`);
      }
    } catch (error) {
      if (disposed || token !== searchToken) return;
      thinking = false;
      statusLabel.textContent = 'Prêt';
      toast(String(error.message ?? error));
    }
  }

  function renderEval(info, bestMove) {
    if(!info)return;
    const score = info.score;
    if (score === undefined) return;
    scoreEl.textContent = formatScore(score, side);
    const clamped = Math.max(-5, Math.min(5, score));
    const portion = (Math.abs(clamped) / 5) * 50;
    fillEl.style.left = clamped >= 0 ? '50%' : `${50 - portion}%`;
    fillEl.style.width = `${Math.max(portion, 2)}%`;
    fillEl.classList.toggle('right', clamped >= 0);
    const nodes = info.nodes !== undefined ? `${info.nodes.toLocaleString('fr-FR')} nœuds` : '';
    metaEl.textContent = `Profondeur ${info.depth ?? '—'}${info.time !== undefined ? ` · ${info.time.toFixed(2).replace('.', ',')} s` : ''}${nodes ? ` · ${nodes}` : ''}${bestMove ? ` · meilleur coup ${bestMove}` : ''}`;
    const pv = info.pv ?? [];
    pvEl.innerHTML = pv.length
      ? pv.slice(0, 12).map(move => `<li>${move}</li>`).join('')
      : '<li class="pv-empty">Recherche en cours…</li>';
  }

  const saveButton=document.createElement('button');saveButton.className='secondary-button wide';saveButton.textContent='Enregistrer dans la bibliothèque';saveButton.onclick=()=>{try{const name=prompt('Nom de la position :','Position');if(name===null)return;const n=savePositions([{board,side,name,tags:'analyse'}]);toast(n?'Position enregistrée.':'Position déjà enregistrée.');}catch(e){toast(e.message);}};el.querySelector('.analysis-side').append(saveButton);
  el.querySelector('#an-evaluate').addEventListener('click', () => evaluate(false));
  el.querySelector('#an-hint').addEventListener('click', () => evaluate(true));
  undoButton.addEventListener('click', () => {
    if (thinking || !undoStack.length) return;
    const snapshot = undoStack.pop();
    drawState=structuredClone(snapshot.drawState);
    board = snapshot.board.slice(); side = snapshot.side; history = [...snapshot.history];
    lastMove = snapshot.lastMove ? [...snapshot.lastMove] : null;
    selected = null;
    legalMoves = generateLegalMoves(board, side);
    undoButton.disabled = undoStack.length === 0;
    sideLabel.textContent = `Trait : ${side === 'w' ? 'Blancs' : 'Noirs'}`;
    statusLabel.textContent = 'Coup annulé.';
    updateCode();
    draw();
  });
  el.querySelector('#an-reset').addEventListener('click', () => {
    board = createInitialBoard(); side = 'w'; drawState=newDrawState(board,side); history = []; undoStack = [];
    selected = null; lastMove = null;
    legalMoves = generateLegalMoves(board, side);
    undoButton.disabled = true;
    sideLabel.textContent = 'Trait : Blancs';
    statusLabel.textContent = 'Prêt';
    scoreEl.textContent = '—'; metaEl.textContent = 'Aucune évaluation';
    fillEl.style.width = '50%';
    pvEl.innerHTML = '<li class="pv-empty">Lancez une évaluation.</li>';
    updateCode();
    draw();
    if (autoEval) evaluate(false);
  });
  el.querySelector('#an-edit').addEventListener('click', () => {
    store.positionDraft = { board: board.slice(), side };
    navigate('editeur');
  });
  el.querySelector('#an-copy').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(codeEl.value);
      toast('Code de position copié.');
    } catch {
      codeEl.select();
      toast('Sélectionnez le code puis copiez-le (Ctrl+C).');
    }
  });
  depthSelect.addEventListener('change', () => { depth = Number(depthSelect.value); if (autoEval) evaluate(false); });
  autoCheckbox.addEventListener('change', () => { autoEval = autoCheckbox.checked; });

  function mount() {
    if (store.positionDraft) {
      board = store.positionDraft.board.slice();
      side = store.positionDraft.side;
      drawState=newDrawState(board,side);
      store.positionDraft = null;
      history = []; undoStack = []; selected = null; lastMove = null;
      legalMoves = generateLegalMoves(board, side);
      undoButton.disabled = true;
      sideLabel.textContent = `Trait : ${side === 'w' ? 'Blancs' : 'Noirs'}`;
      statusLabel.textContent = 'Position chargée.';
      updateCode();
      draw();
      if (autoEval && legalMoves.length) evaluate(false);
    }
  }

  updateCode();
  draw();
  if (autoEval) evaluate(false);

  return {
    el,
    mount,
    dispose() { disposed = true; },
  };
}
