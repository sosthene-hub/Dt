import {probeTable} from '../bitbases.js';
import {newDrawState,advanceDraw,adjudicate,drawStatus} from '../draw-rules.js';
import { engine, DEPTHS } from '../engine.js';
import { renderBoard } from '../board-view.js';
import { applyMove, createInitialBoard, generateLegalMoves, moveMatchesEngine, moveToHub, opponent, positionKey, sideOf } from '../game-rules.js';
import { gameToPdn } from '../pdn.js';
import { store } from '../store.js';

// Local game against Scan 3.1. Behaviour preserved from the Phase 2 prototype.
export function createGamePage({ toast }) {
  const el = document.createElement('div');
  el.innerHTML = `
    <section class="welcome"><div class="eyebrow">DAMES INTERNATIONALES · 10×10</div><h1>À vous de jouer.</h1><p>Une partie locale contre Scan 3.1.</p></section>
    <div class="game-options"><div class="game-mode"><span class="mode-dot"></span><div><b>Partie locale</b><small>Blancs contre Scan</small></div></div><label class="level-control" for="difficulty">Niveau<select id="difficulty" aria-label="Niveau de Scan"><option value="facile">Facile</option><option value="normal" selected>Normal</option><option value="fort">Fort</option></select></label></div>
    <section class="game-card">
      <div class="player-row"><div class="avatar dark-avatar">S</div><div class="player-name"><b>Scan 3.1</b><span>Adversaire · noirs</span></div><span class="engine-pill"><i></i> <span id="engine-label">Démarrage…</span></span></div>
      <div class="board-wrap"><div id="game-board"></div></div>
      <div class="player-row bottom-player"><div class="avatar light-avatar">V</div><div class="player-name"><b>Vous</b><span>Blancs</span></div><span class="turn-indicator" id="turn-label">À vous</span></div>
    </section>
      <section class="control-row">
        <button class="secondary-button" id="undo" disabled>↶ <span>Annuler le tour</span></button>
        <div class="message" id="message">Chargement du moteur Scan…</div>
        <button class="secondary-button" id="export">⤓ <span>PDN</span></button>
        <button class="secondary-button" id="help">ⓘ <span>Règles</span></button>
      </section>
    <p id="draw-counters" class="counts"></p>
    <section class="phase-note"><div class="note-icon">✓</div><div><b>Jeu local · hors ligne</b><p>Scan 3.1 fonctionne sur cet appareil. L’application sera mise en cache après le premier chargement.</p></div><span class="phase-tag">SCAN 3.1</span></section>
  `;

  const boardEl = el.querySelector('#game-board');
  const messageEl = el.querySelector('#message');
  const engineLabel = el.querySelector('#engine-label');
  const undoButton = el.querySelector('#undo');
  const turnLabel = el.querySelector('#turn-label');
  const difficultySelect = el.querySelector('#difficulty');

  let board = createInitialBoard();
  let sideToMove = 'w';
  let legalMoves = generateLegalMoves(board, sideToMove);
  let selected = null;
  let isThinking = false;
  let gameOver = false;
  let moveCount = 0;
  let lastMove = null;
  let moveHistory = [];
  let movePaths = [];
  let repetitions = new Map([[positionKey(board, sideToMove), 1]]);
  let undoStack = [];
  let pendingRoundSnapshot = null;
  let drawState = newDrawState(board,sideToMove);
  let disposed = false;
  let endResult = '*';

  difficultySelect.value = store.difficulty;

  function drawBoard() {
    renderBoard(boardEl, {
      board,
      selected,
      lastMove,
      targets: selected === null ? new Set() : new Set(legalMoves.filter(move => move.from === selected).map(move => move.to)),
      onSquareClick: handleSquare,
    });
  }

  function availableMoves(from) { return legalMoves.filter(move => move.from === from); }

  function handleSquare(square) {
    if (isThinking || gameOver || sideToMove !== 'w') return;
    if (selected !== null) {
      const choices = availableMoves(selected).filter(move => move.to === square);
      if (choices.length) { playHumanMove(choices[0]); return; }
    }
    if (sideOf(board[square]) === sideToMove) {
      selected = selected === square ? null : square;
      updateBoardAndStatus(selected === null ? 'À vous de jouer.' : `Choisissez une destination pour la pièce ${square}.`);
    } else {
      selected = null;
      drawBoard();
    }
  }

  function takeSnapshot() {
    return { board: board.slice(), sideToMove, moveCount, lastMove: lastMove ? [...lastMove] : null, moveHistory: [...moveHistory], movePaths: [...movePaths], repetitions: new Map(repetitions), drawState:structuredClone(drawState) };
  }

  function restoreSnapshot(snapshot) {
    board = snapshot.board.slice(); sideToMove = snapshot.sideToMove; moveCount = snapshot.moveCount;
    lastMove = snapshot.lastMove ? [...snapshot.lastMove] : null; moveHistory = [...snapshot.moveHistory]; movePaths = [...snapshot.movePaths];
    drawState=structuredClone(snapshot.drawState);endResult='*';
    repetitions = new Map(snapshot.repetitions); selected = null; gameOver = false;
    legalMoves = generateLegalMoves(board, sideToMove);
    engineLabel.textContent = 'Prêt'; turnLabel.textContent = sideToMove === 'w' ? 'À vous' : 'Scan joue';
    messageEl.textContent = 'Tour annulé. À vous de jouer.';
    undoButton.disabled = undoStack.length === 0;
    drawBoard();
  }

  function updateBoardAndStatus(message) {
    drawBoard();
    messageEl.textContent = message;
    el.querySelector('#draw-counters').textContent=drawStatus(drawState);
    undoButton.disabled = undoStack.length === 0 || isThinking;
  }

  function addPositionOccurrence() {
    const key = positionKey(board, sideToMove);
    const count = (repetitions.get(key) ?? 0) + 1;
    repetitions.set(key, count);
    return count;
  }

  function endIfNeeded() {
    legalMoves = generateLegalMoves(board, sideToMove);
    if (!legalMoves.length) {
      gameOver = true;
      endResult = opponent(sideToMove) === 'w' ? '1-0' : '0-1';
      const winner = opponent(sideToMove);
      const winnerLabel = winner === 'w' ? 'Vous gagnez' : 'Scan gagne';
      engineLabel.textContent = 'Partie terminée';
      turnLabel.textContent = 'Terminé';
      updateBoardAndStatus(`${winnerLabel} : aucune prise ni aucun déplacement légal.`);
      if (pendingRoundSnapshot) { undoStack.push(pendingRoundSnapshot); pendingRoundSnapshot = null; }
      undoButton.disabled = undoStack.length === 0;
      return true;
    }
    const decision=adjudicate(board,sideToMove,drawState);
    if(decision){gameOver=true;endResult=decision.result;engineLabel.textContent='Partie nulle';turnLabel.textContent='Nulle';updateBoardAndStatus(decision.reason);if(pendingRoundSnapshot){undoStack.push(pendingRoundSnapshot);pendingRoundSnapshot=null;}undoButton.disabled=undoStack.length===0;return true;}
    return false;
  }

  function playHumanMove(move) {
    pendingRoundSnapshot = takeSnapshot();
    const before=board;board = applyMove(board, move);
    drawState=advanceDraw(drawState,before,move,board,opponent(sideToMove));
    lastMove = [...move.path];
    moveHistory.push(moveToHub(move));
    movePaths.push(move);
    moveCount++; sideToMove = 'b'; selected = null;
    addPositionOccurrence();
    if (endIfNeeded()) return;
    isThinking = true; engineLabel.textContent = 'En calcul'; turnLabel.textContent = 'Scan réfléchit…';
    updateBoardAndStatus('Scan réfléchit…');
    // Scan.js has a fast-path for forced moves that omits the Hub `done` message.
    // Since the legal move generator already proved there is only one choice, play it directly.
    const tb=board.filter(p=>sideOf(p)).length<=4?probeTable(board,sideToMove):null;
    const optimal=tb?.available?legalMoves.filter(m=>tb.moves.some(t=>t.value===tb.value&&t.notation===moveToHub(m))):legalMoves;
    if (optimal.length === 1) {
      const forced = optimal[0];
      window.setTimeout(() => {
        if (!disposed && isThinking && sideToMove === 'b' && !gameOver) playEngineMove(moveToHub(forced));
      }, 120);
    } else {
      sendPositionAndThink();
    }
  }

  async function sendPositionAndThink() {
    const depth = DEPTHS[difficultySelect.value] ?? DEPTHS.normal;
    store.difficulty = difficultySelect.value;
    try {
      const result = await engine.search({ position: `start moves="${moveHistory.join(' ')}"`, depth, mode: 'think' });
      if (disposed || !isThinking || sideToMove !== 'b' || gameOver) return; // stale reply from a reset game
      if (!result.move) {
        isThinking = false;
        engineLabel.textContent = 'Erreur moteur';
        updateBoardAndStatus('Scan n’a pas renvoyé de coup. Réessayez ou démarrez une nouvelle partie.');
        return;
      }
      playEngineMove(result.move);
    } catch (error) {
      if (disposed) return;
      isThinking = false; engineLabel.textContent = 'Erreur moteur';
      updateBoardAndStatus(String(error.message ?? error));
    }
  }

  function playEngineMove(notation) {
    const candidates = legalMoves.filter(move => moveMatchesEngine(move, notation));
    if (!candidates.length) {
      isThinking = false; gameOver = true; engineLabel.textContent = 'Erreur moteur'; turnLabel.textContent = 'À vérifier';
      updateBoardAndStatus(`Le coup annoncé par Scan (${notation}) n’a pas été reconnu comme légal.`);
      return;
    }
    const move = candidates[0];
    const before=board;board = applyMove(board, move);
    drawState=advanceDraw(drawState,before,move,board,opponent(sideToMove)); lastMove = [...move.path];
    moveHistory.push(notation); movePaths.push(move); moveCount++; sideToMove = 'w'; isThinking = false;
    addPositionOccurrence();
    engineLabel.textContent = 'Prêt'; turnLabel.textContent = 'À vous';
    if (pendingRoundSnapshot) { undoStack.push(pendingRoundSnapshot); pendingRoundSnapshot = null; }
    if (!endIfNeeded()) updateBoardAndStatus(`Scan a joué ${notation}. À vous !`);
    undoButton.disabled = undoStack.length === 0;
  }

  function startNewGame() {
    board = createInitialBoard(); sideToMove = 'w'; legalMoves = generateLegalMoves(board, sideToMove);
    selected = null; isThinking = false; gameOver = false; moveCount = 0; lastMove = null;
    moveHistory = []; movePaths = []; repetitions = new Map([[positionKey(board, sideToMove), 1]]); undoStack = []; pendingRoundSnapshot = null;
    drawState=newDrawState(board,sideToMove);
    endResult = '*';
    engineLabel.textContent = engine.ready ? 'Prêt' : 'Démarrage…'; turnLabel.textContent = 'À vous';
    updateBoardAndStatus(engine.ready ? 'Nouvelle partie. À vous de jouer.' : 'Chargement du moteur Scan…');
    engine.newGame();
    undoButton.disabled = true;
  }

  function undoLastTurn() {
    if (isThinking || !undoStack.length) return;
    restoreSnapshot(undoStack.pop());
    engine.newGame();
    // The next engine search receives the full move list from the restored game state.
  }

  function download(filename, text) {
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  }

  function exportPdn() {
    if (!movePaths.length) { toast('Jouez d’abord quelques coups pour exporter une partie.'); return; }
    const text = gameToPdn({
      headers: { White: 'Vous', Black: 'Scan 3.1', Result: endResult },
      moves: movePaths,
      result: endResult,
    });
    download(`partie-dames-${new Date().toISOString().slice(0, 10)}.pdn`, text);
    toast('Partie téléchargée au format PDN.');
  }

  el.querySelector('#help').addEventListener('click', () => toast('Les prises sont obligatoires, et il faut choisir une séquence qui capture le maximum de pièces. Les dames se déplacent sur toute diagonale libre.'));
  el.querySelector('#export').addEventListener('click', exportPdn);
  undoButton.addEventListener('click', undoLastTurn);
  difficultySelect.addEventListener('change', () => { store.difficulty = difficultySelect.value; toast(`Niveau Scan : ${difficultySelect.options[difficultySelect.selectedIndex].text}`); });

  function onEngineReady() {
    if (disposed) return;
    engineLabel.textContent = 'Prêt';
    if (!gameOver && moveCount === 0 && !isThinking) messageEl.textContent = 'À vous : sélectionnez une pièce blanche pour voir ses coups légaux.';
    drawBoard();
  }
  const unsubscribeReady = engine.onReady(onEngineReady);
  if (engine.ready) onEngineReady();

  return {
    el,
    mount() {
      difficultySelect.value = store.difficulty;
      if (store.pendingNewGame) {
        store.pendingNewGame = false;
        startNewGame();
      }
      if (!gameOver && sideToMove === 'b' && isThinking) {
        // Engine may have finished while the page was hidden.
        updateBoardAndStatus('Scan réfléchit…');
      }
    },
    dispose() { disposed = true; unsubscribeReady(); },
  };
}
