import { engine } from '../engine.js';
import { renderBoard } from '../board-view.js';
import { applyMove, generateLegalMoves, moveMatchesEngine, moveToHub, sideOf } from '../game-rules.js';
import { moveToPdn } from '../pdn.js';
import { generatePuzzle, puzzleDifficultyLabel, puzzleSeed, puzzleTitle, movePathsEqual } from '../puzzles.js';

export function createProblemsPage({ toast }) {
  const el = document.createElement('div');
  let puzzle = null;
  let board = [];
  let side = 'w';
  let legalMoves = [];
  let selected = null;
  let solved = false;
  let solvedCount = 0;
  let streak = 0;
  let seed = puzzleSeed();
  let thinking = false;
  let disposed = false;
  let searchToken = 0;

  el.innerHTML = `
    <div class="section-heading"><div class="eyebrow">ENTRAÎNEMENT · TACTIQUE</div><h1>Problèmes</h1><p>Positions tactiques générées et vérifiées : trouvez la prise maximale ou la seule parade.</p></div>
    <section class="panel problems-panel">
      <div class="problems-grid">
        <div>
          <div class="player-row"><div class="avatar gold-avatar">?</div><div class="player-name"><b id="pb-title">—</b><span id="pb-meta">Chargement…</span></div><span class="difficulty-chip" id="pb-difficulty">—</span></div>
          <div class="board-wrap"><div id="puzzle-board"></div></div>
          <div class="player-row bottom-player"><div class="avatar light-avatar">V</div><div class="player-name"><b>Vous</b><span>Trouvez le coup demandé</span></div><span class="turn-indicator" id="pb-status">—</span></div>
        </div>
        <aside class="problems-side">
          <div class="field-block">
            <span class="field-label">Objectif</span>
            <div class="position-status" id="pb-goal">—</div>
          </div>
          <div class="field-block">
            <span class="field-label">Progression</span>
            <div class="score-row">
              <div class="score-box"><b id="pb-solved">0</b><small>résolus</small></div>
              <div class="score-box"><b id="pb-streak">0</b><small>série</small></div>
            </div>
          </div>
          <div class="editor-actions">
            <button class="secondary-button" id="pb-hint" type="button">✦ Indice Scan</button>
            <button class="secondary-button" id="pb-retry" type="button">↶ Recommencer</button>
          </div>
          <button class="start-game-button" id="pb-next" type="button">Puzzle suivant <span>→</span></button>
          <button class="secondary-button wide" id="pb-daily" type="button">☀ Puzzle du jour</button>
          <div class="message center" id="pb-message">Le coup demandé s’affiche ici.</div>
        </aside>
      </div>
    </section>
  `;

  const boardEl = el.querySelector('#puzzle-board');
  const titleEl = el.querySelector('#pb-title');
  const metaEl = el.querySelector('#pb-meta');
  const difficultyEl = el.querySelector('#pb-difficulty');
  const statusEl = el.querySelector('#pb-status');
  const goalEl = el.querySelector('#pb-goal');
  const messageEl = el.querySelector('#pb-message');
  const solvedEl = el.querySelector('#pb-solved');
  const streakEl = el.querySelector('#pb-streak');

  function loadPuzzle(newSeed) {
    seed = newSeed;
    let generated = generatePuzzle(seed);
    let salt = 0;
    while (!generated && salt < 50) {
      salt++;
      generated = generatePuzzle(seed + salt * 7919);
    }
    if (!generated) {
      messageEl.textContent = 'Aucun puzzle trouvé pour cette graine. Essayez le suivant.';
      return;
    }
    puzzle = generated;
    board = puzzle.board.slice();
    side = puzzle.side;
    legalMoves = generateLegalMoves(board, side);
    selected = null;
    solved = false;
    titleEl.textContent = puzzleTitle(puzzle);
    metaEl.textContent = `Graine ${seed} · ${side === 'w' ? 'trait aux Blancs' : 'trait aux Noirs'}`;
    difficultyEl.textContent = puzzleDifficultyLabel(puzzle);
    goalEl.textContent = puzzle.description;
    statusEl.textContent = 'À vous';
    messageEl.textContent = 'Jouez le coup demandé sur le damier.';
    draw();
  }

  function draw() {
    renderBoard(boardEl, {
      board,
      orientation: 'w',
      selected,
      targets: selected === null ? new Set() : new Set(legalMoves.filter(move => move.from === selected).map(move => move.to)),
      onSquareClick: handleSquare,
    });
  }

  function handleSquare(square) {
    if (solved || thinking) return;
    if (selected !== null) {
      const choices = legalMoves.filter(move => move.from === selected && move.to === square);
      if (choices.length) { answer(choices[0]); return; }
    }
    if (sideOf(board[square]) === side) {
      selected = selected === square ? null : square;
      statusEl.textContent = selected === null ? 'À vous' : `Pièce ${square} sélectionnée`;
      draw();
    } else {
      selected = null;
      draw();
    }
  }

  function answer(move) {
    const preMoveHub = `pos=${(side === 'w' ? 'W' : 'B') + board.slice(1).join('')}`;
    if (movePathsEqual(move, puzzle.solution)) {
      solved = true;
      solvedCount++;
      streak++;
      solvedEl.textContent = String(solvedCount);
      streakEl.textContent = String(streak);
      const after = applyMove(board, move);
      board = after;
      selected = null;
      draw();
      const notation = moveToPdn(move);
      messageEl.innerHTML = `<span class="status-ok">✓ Bravo !</span> Solution : <b>${notation}</b> (${puzzle.solution.captured.length} pièce${puzzle.solution.captured.length > 1 ? 's' : ''}).`;
      statusEl.textContent = 'Résolu';
      toast('Puzzle résolu !');
      confirmWithEngine(notation, preMoveHub);
    } else {
      streak = 0;
      streakEl.textContent = '0';
      messageEl.innerHTML = `<span class="status-error">⚠ Coup légal, mais ce n’est pas la solution.</span> Recommencez.`;
      toast('Coup légal mais incorrect.');
      loadPuzzle(seed);
    }
  }

  function confirmWithEngine(notation, position) {
    const token = ++searchToken;
    engine.search({ position, depth: 7, mode: 'analyze' }).then(result => {
      if (disposed || token !== searchToken) return;
      if (result.move && result.move === notation) goalEl.textContent = `Scan confirme : ${notation} est le meilleur coup.`;
    }).catch(() => {});
  }

  el.querySelector('#pb-next').addEventListener('click', () => loadPuzzle(Math.floor(Math.random() * 1e9)));
  el.querySelector('#pb-daily').addEventListener('click', () => loadPuzzle(puzzleSeed()));
  el.querySelector('#pb-retry').addEventListener('click', () => loadPuzzle(seed));
  el.querySelector('#pb-hint').addEventListener('click', async () => {
    if (solved || thinking || !legalMoves.length) return;
    thinking = true;
    statusEl.textContent = 'Scan réfléchit…';
    const token = ++searchToken;
    try {
      const result = await engine.search({
        position: `pos=${(side === 'w' ? 'W' : 'B') + board.slice(1).join('')}`,
        depth: 7,
        mode: 'analyze',
      });
      if (disposed || token !== searchToken) return;
      thinking = false;
      statusEl.textContent = 'À vous';
      if (result.move) {
        const hint = legalMoves.find(move => moveMatchesEngine(move, result.move));
        if (hint) {
          draw();
          messageEl.innerHTML = `Indice Scan : <b>${moveToHub(hint)}</b> (départ ${hint.from}).`;
          return;
        }
      }
      messageEl.textContent = 'Scan n’a pas pu donner d’indice sur cette position.';
    } catch {
      if (disposed || token !== searchToken) return;
      thinking = false;
      statusEl.textContent = 'À vous';
      toast('Moteur indisponible pour l’indice.');
    }
  });

  loadPuzzle(seed);
  return { el, dispose() { disposed = true; } };
}
