/* PIONICIDE · Panneau d'entraînement : détection à la demande des mauvais coups
   (imprécisions ?!, erreurs ?, grosses erreurs ??) dans la position affichée,
   variantes de réfutation vers le gain, quiz interactif sur le damier et
   passerelle « Mener au gain contre PIONICIDE ». */

import { generateLegalMoves, moveToHub, boardToHub } from '../game-rules.js';
import { appendState } from '../game-history.js';
import { moveToPdn } from '../pdn.js';
import {
  REFUTATION_DEFAULTS,
  analyzeBadMoves,
  formatBadMoveStudyComment,
} from '../analysis/refutations.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}

export function createRefutationPanel({ toast, navigate, host }) {
  const root = el('section', 'panel refutation-panel');
  root.id = 'refutation-panel';

  let busy = false;
  let stopFlag = false;
  let runToken = 0;
  let report = null;              // Résultat courant d'analyzeBadMoves
  let anchorState = null;         // Copie de la position analysée
  let anchorNodeId = null;        // Nœud de l'arbre manuel correspondant
  let anchorBaseOffset = 0;       // Décalage de demi-coup pour la numérotation FMJD réelle
  let anchorKey = '';
  let filterMode = 'all';         // 'all' | 'wins' | 'errors'
  let activePreview = null;       // { itemIndex, stepIndex } (-1 = racine, 0 = après erreur, 1..n = réfutation)
  let drill = null;               // { item, stepIndex, currentState, maxPlies, finished, hintShown }
  let replyTimer = null;

  root.innerHTML = `
    <div class="section-heading" style="padding-bottom:10px">
      <div class="eyebrow">ENTRAÎNEMENT · PIÈGES, ERREURS ADVERSES & RÉFUTATIONS</div>
      <h2>Mauvais coups possibles et comment les exploiter</h2>
      <p>À votre demande, PIONICIDE examine tous les coups légaux de la position affichée pour isoler les <b>imprécisions (?!)</b>, <b>erreurs (?)</b> et <b>grosses erreurs (??)</b>, avec la <b>variante de réfutation</b> permettant d’en tirer avantage ou d’aboutir au gain.</p>
    </div>

    <div class="replay-toolbar" style="margin:0 0 10px">
      <button class="primary-button" type="button" id="rf-run">🎯 Chercher les mauvais coups de cette position</button>
      <button class="secondary-button" type="button" id="rf-stop" hidden>Arrêter</button>
      <button class="secondary-button" type="button" id="rf-drill-random" disabled>🎲 S’exercer (erreur au hasard)</button>
      <button class="secondary-button" type="button" id="rf-add-all" disabled>+ Tout ajouter à mon analyse</button>
      <button class="secondary-button" type="button" id="rf-back-pos" hidden>Revenir à la position étudiée</button>
    </div>

    <details class="rf-settings-details">
      <summary>Réglages de détection (profondeur et seuils d’imprécision / erreur)</summary>
      <div class="rf-settings-grid">
        <label>Profondeur de calcul
          <select id="rf-depth">
            <option value="12">12 — Rapide</option>
            <option value="14" selected>14 — Équilibrée (recommandé)</option>
            <option value="16">16 — Approfondie</option>
            <option value="18">18 — Très profonde</option>
          </select>
        </label>
        <label>Seuil imprécision « ?! » (pions)
          <input type="number" id="rf-thr-inac" min="0.1" max="2" step="0.05" value="0.25" inputmode="decimal">
        </label>
        <label>Seuil erreur « ? » (pions)
          <input type="number" id="rf-thr-err" min="0.2" max="4" step="0.1" value="0.6" inputmode="decimal">
        </label>
        <label>Seuil grosse erreur « ?? » (pions)
          <input type="number" id="rf-thr-blun" min="0.5" max="9" step="0.1" value="1.5" inputmode="decimal">
        </label>
      </div>
    </details>

    <progress id="rf-progress" max="1" value="0" hidden></progress>
    <p class="study-context" id="rf-status" role="status">Placez-vous sur la position de votre choix puis cliquez sur « Chercher les mauvais coups de cette position ».</p>

    <div class="rf-drill-card" id="rf-drill-card" hidden>
      <div class="rf-drill-head">
        <b id="rf-drill-title">Exercice de réfutation</b>
        <span class="manual-stats-pill" id="rf-drill-progress">Coup 1</span>
      </div>
      <p id="rf-drill-prompt" class="rf-drill-prompt"></p>
      <p id="rf-drill-feedback" class="rf-drill-feedback" role="status"></p>
      <div class="replay-toolbar" style="margin:6px 0 0">
        <button class="secondary-button" type="button" id="rf-drill-hint">💡 Indice</button>
        <button class="secondary-button" type="button" id="rf-drill-reveal">👁 Voir la suite gagnante</button>
        <button class="secondary-button" type="button" id="rf-drill-next">🎲 Autre erreur</button>
        <button class="secondary-button" type="button" id="rf-drill-play-engine">⚔ Mener au gain contre PIONICIDE</button>
        <button class="secondary-button" type="button" id="rf-drill-quit">Quitter l’exercice</button>
      </div>
    </div>

    <div id="rf-filters" class="rf-filters" hidden>
      <button type="button" class="secondary-button is-toggled" data-filter="all" id="rf-f-all">Tous</button>
      <button type="button" class="secondary-button" data-filter="wins" id="rf-f-wins">Suites gagnantes</button>
      <button type="button" class="secondary-button" data-filter="errors" id="rf-f-errors">Erreurs ? et ??</button>
    </div>

    <div id="rf-list" class="rf-list"></div>
    <details id="rf-good-wrap" class="rf-good-wrap" hidden>
      <summary id="rf-good-summary">Coups sains dans cette position</summary>
      <div id="rf-good-list" class="rf-good-list"></div>
    </details>
  `;

  const q = id => root.querySelector('#' + id);

  function clearReplyTimer() {
    if (replyTimer) {
      clearTimeout(replyTimer);
      replyTimer = null;
    }
  }

  function readSettings() {
    const depth = Number(q('rf-depth').value) || REFUTATION_DEFAULTS.depth;
    const inaccuracy = Math.max(0.1, Math.min(2, Number(q('rf-thr-inac').value) || 0.25));
    const error = Math.max(inaccuracy + 0.05, Math.min(5, Number(q('rf-thr-err').value) || 0.6));
    const blunder = Math.max(error + 0.1, Math.min(9, Number(q('rf-thr-blun').value) || 1.5));
    return {
      depth,
      maxTimeMs: depth <= 12 ? 700 : depth <= 14 ? 1200 : depth <= 16 ? 2200 : 4000,
      thresholds: { ...REFUTATION_DEFAULTS, inaccuracy, error, blunder },
    };
  }

  function campLabel(side) {
    return side === 'w' ? 'les Blancs' : 'les Noirs';
  }
  function campCap(side) {
    return side === 'w' ? 'Blancs' : 'Noirs';
  }

  function stopDrill(restoreAnchor = false) {
    clearReplyTimer();
    drill = null;
    q('rf-drill-card').hidden = true;
    host.setOverlay(null);
    if (restoreAnchor && anchorState) {
      activePreview = null;
      q('rf-back-pos').hidden = true;
      host.restoreAnalyzedPosition(anchorState, anchorNodeId);
    }
    renderReport();
  }

  function restoreOriginPosition() {
    stopDrill(false);
    activePreview = null;
    q('rf-back-pos').hidden = true;
    host.setOverlay(null);
    if (anchorState) {
      host.restoreAnalyzedPosition(anchorState, anchorNodeId);
    }
    renderReport();
  }

  /** Affiche une étape précise d'un mauvais coup et de sa variante de réfutation sur le damier. */
  function previewItemStep(itemIndex, stepIndex) {
    if (!report || !anchorState) return;
    const item = report.badMoves[itemIndex];
    if (!item) return;
    stopDrill(false);
    const maxStep = item.refutationMoves.length;
    const clamped = Math.max(-1, Math.min(maxStep, stepIndex));
    activePreview = { itemIndex, stepIndex: clamped };
    q('rf-back-pos').hidden = false;

    if (clamped === -1) {
      // Position avant le mauvais coup : flèche rouge pointillée sur la faute + flèche verte sur la réfutation
      const arrows = [{ path: item.move.path, color: '#d9534f', dashed: true, label: item.symbol || '?' }];
      host.previewState(anchorState, {
        arrows,
        note: `Position étudiée : si ${campLabel(report.side)} jouent ${item.pdn}${item.symbol} (−${item.lossText}), ${campLabel(report.punisherSide)} réfutent par ${item.refutationMoves[0] ? moveToPdn(item.refutationMoves[0]) : '—'}.`,
      });
    } else if (clamped === 0) {
      // Juste après le mauvais coup : flèche verte sur le 1er coup de réfutation !
      const firstRef = item.refutationMoves[0];
      const arrows = firstRef
        ? [{ path: firstRef.path, color: '#2f9e5b', dashed: false, label: '!' }]
        : [];
      host.previewState(item.afterState, {
        arrows,
        note: `Après l’erreur ${item.pdn}${item.symbol} : ${campLabel(report.punisherSide)} exploitent par ${firstRef ? moveToPdn(firstRef) + '!' : '—'} (${item.verdict.badge}, ${item.punisherScoreText}).`,
      });
    } else {
      // Étape `clamped` dans la variante de réfutation
      const st = item.refutationStates[clamped];
      const nextMove = item.refutationMoves[clamped];
      const arrows = nextMove
        ? [{ path: nextMove.path, color: clamped % 2 === 0 ? '#2f9e5b' : '#3b82f6', dashed: clamped % 2 === 1, label: String(clamped + 1) }]
        : [];
      const playedMove = item.refutationMoves[clamped - 1];
      host.previewState(st, {
        arrows,
        note: `Réfutation de ${item.pdn}${item.symbol} (${clamped}/${maxStep}) : coup joué ${moveToPdn(playedMove)}.`,
      });
    }
    renderReport();
    host.scrollToBoard?.();
  }

  /** Lance une partie réelle contre PIONICIDE à partir de l'erreur adverse, pour s'entraîner à mener au gain. */
  function launchPlayToWin(item) {
    if (!report || !item) return;
    stopDrill(false);
    host.launchGameFromState({
      board: item.afterState.board.slice(),
      side: item.afterState.side,
      human: report.punisherSide,
      label: `Exploiter l’erreur ${item.pdn}${item.symbol} (${item.verdict.badge})`,
    });
  }

  /** Démarre l'exercice interactif sur le damier : l'adversaire joue la faute, à l'utilisateur de punir. */
  function startDrillForItem(item) {
    if (!report || !item || !item.refutationMoves.length) {
      toast('Aucune suite de réfutation à exercer sur ce coup.');
      return;
    }
    clearReplyTimer();
    activePreview = null;
    const punisherMovesCount = Math.min(3, Math.ceil(item.refutationMoves.length / 2));
    drill = {
      item,
      pvMoves: [...item.refutationMoves],
      pvStates: [...item.refutationStates],
      stepIndex: 0, // indice dans pvMoves attendu de l'utilisateur (pair : 0, 2, 4)
      currentState: item.afterState,
      targetSteps: punisherMovesCount,
      completedSteps: 0,
      finished: false,
      checking: false,
    };

    q('rf-drill-card').hidden = false;
    q('rf-back-pos').hidden = false;
    q('rf-drill-title').textContent = `🎯 Punir l’erreur ${item.pdn}${item.symbol} (${item.label})`;
    q('rf-drill-progress').textContent = `Coup 1 / ${drill.targetSteps}`;
    q('rf-drill-prompt').textContent = `L’adversaire (${campCap(report.side)}) vient de jouer ${item.pdn}${item.symbol} (−${item.lossText} pion). Vous avez ${campLabel(report.punisherSide)} : jouez sur le damier le coup qui exploite cette erreur !`;
    q('rf-drill-feedback').textContent = item.verdict.leadsToWin
      ? `Objectif : ${item.verdict.badge.toLowerCase()}${item.motif ? ' · ' + item.motif.toLowerCase() : ''}.`
      : `Objectif : prendre un ${item.verdict.badge.toLowerCase()}.`;
    q('rf-drill-feedback').className = 'rf-drill-feedback';

    host.ensureOrientation?.(report.punisherSide);
    host.previewState(item.afterState, {
      arrows: [],
      note: `À vous (${campCap(report.punisherSide)}) : trouvez la réfutation de ${item.pdn}${item.symbol} !`,
    });
    renderReport();
    host.scrollToBoard?.();
  }

  function startRandomDrill() {
    if (!report?.badMoves?.length) return;
    const pool = report.badMoves.filter(b => b.refutationMoves.length > 0);
    if (!pool.length) { toast('Aucune variante de réfutation disponible.'); return; }
    const currentPdn = drill?.item?.pdn;
    const candidates = pool.length > 1 ? pool.filter(b => b.pdn !== currentPdn) : pool;
    const picked = candidates[Math.floor(Math.random() * candidates.length)];
    startDrillForItem(picked);
  }

  /** Intercepte un coup joué sur le damier pendant un exercice de réfutation. */
  async function handleDrillBoardMove(move) {
    if (!drill || drill.finished || drill.checking) return true;
    const expected = drill.pvMoves[drill.stepIndex];
    if (!expected) return true;

    const playedHub = moveToHub(move);
    const expectedHub = moveToHub(expected);
    let accepted = playedHub === expectedHub;
    let updatedPvMoves = null;
    let updatedPvStates = null;

    if (!accepted) {
      // Vérifie si l'utilisateur a trouvé un autre coup tout aussi fort !
      drill.checking = true;
      q('rf-drill-feedback').textContent = 'Vérification de votre coup par PIONICIDE…';
      try {
        const candAfter = appendState([drill.currentState], move).at(-1);
        const nextLegal = generateLegalMoves(candAfter.board, candAfter.side);
        if (!nextLegal.length) {
          accepted = true;
          updatedPvMoves = [move];
          updatedPvStates = [drill.currentState, candAfter];
        } else {
          const res = await host.search({
            position: `pos=${boardToHub(candAfter.board, candAfter.side)}`,
            depth: 10,
            mode: 'analyze',
            maxTimeMs: 500,
          });
          const oppScore = Number(res.infos?.at(-1)?.score);
          const myScore = Number.isFinite(oppScore) ? -oppScore : -99;
          const targetScore = drill.item.punisherScore;
          if (myScore >= targetScore - 0.22 || (drill.item.verdict.leadsToWin && myScore >= 1.35)) {
            accepted = true;
            // Reconstruit la suite depuis ce coup alternatif gagnant
            const info = res.infos?.at(-1);
            const rawPv = info?.pv || (res.move ? [res.move] : []);
            const tailMoves = [move];
            let stList = [drill.currentState, candAfter];
            for (const tok of rawPv.slice(0, 5)) {
              const st = stList.at(-1);
              const lm = generateLegalMoves(st.board, st.side).find(c => moveToPdn(c) === tok || moveToHub(c) === tok);
              if (!lm) break;
              tailMoves.push(lm);
              stList = appendState(stList, lm);
            }
            updatedPvMoves = [...drill.pvMoves.slice(0, drill.stepIndex), ...tailMoves];
            updatedPvStates = [...drill.pvStates.slice(0, drill.stepIndex), ...stList];
          }
        }
      } catch {
        accepted = false;
      } finally {
        drill.checking = false;
      }
    }

    if (!accepted) {
      q('rf-drill-feedback').textContent = `✗ ${moveToPdn(move)} laisse échapper la meilleure exploitation. Essayez un autre coup ou cliquez sur « 💡 Indice » !`;
      q('rf-drill-feedback').className = 'rf-drill-feedback is-wrong';
      host.previewState(drill.currentState, {
        arrows: [],
        note: `Réessayez : ${moveToPdn(move)} ne punit pas suffisamment ${drill.item.pdn}${drill.item.symbol}.`,
      });
      toast(`Ce n’est pas la réfutation optimale (${moveToPdn(move)}) — réessayez !`);
      return true;
    }

    if (updatedPvMoves) {
      drill.pvMoves = updatedPvMoves;
      drill.pvStates = updatedPvStates;
    }

    const afterMyMove = drill.pvStates[drill.stepIndex + 1] || appendState([drill.currentState], move).at(-1);
    drill.completedSteps += 1;
    drill.currentState = afterMyMove;

    host.previewState(afterMyMove, {
      arrows: [],
      note: `✓ Bien joué (${moveToPdn(move)}) !`,
    });

    const oppReply = drill.pvMoves[drill.stepIndex + 1];
    const nextUserMove = drill.pvMoves[drill.stepIndex + 2];

    if (!oppReply || !nextUserMove || drill.completedSteps >= drill.targetSteps) {
      drill.finished = true;
      q('rf-drill-progress').textContent = '✓ Réussi !';
      q('rf-drill-feedback').textContent = `🏆 Bravo ! Vous avez trouvé la réfutation (${moveToPdn(move)}) ! Vous pouvez maintenant cliquer sur « ⚔ Mener au gain contre PIONICIDE » pour jouer la fin de partie jusqu’à la victoire.`;
      q('rf-drill-feedback').className = 'rf-drill-feedback is-ok';
      toast('Bravo ! Réfutation maîtrisée.');
      return true;
    }

    q('rf-drill-feedback').textContent = `✓ Exact (${moveToPdn(move)}) ! L’adversaire répond ${moveToPdn(oppReply)}… trouvez la suite !`;
    q('rf-drill-feedback').className = 'rf-drill-feedback is-ok';

    clearReplyTimer();
    replyTimer = setTimeout(() => {
      if (!drill || drill.finished) return;
      const afterOpp = drill.pvStates[drill.stepIndex + 2] || appendState([afterMyMove], oppReply).at(-1);
      drill.stepIndex += 2;
      drill.currentState = afterOpp;
      q('rf-drill-progress').textContent = `Coup ${drill.completedSteps + 1} / ${drill.targetSteps}`;
      host.previewState(afterOpp, {
        arrows: [],
        note: `L’adversaire a répondu ${moveToPdn(oppReply)}. À vous de continuer la réfutation !`,
      });
    }, 450);

    return true;
  }

  async function runDetection() {
    if (busy) return;
    if (host.isBusy?.()) {
      toast('Attendez la fin du calcul en cours.');
      return;
    }
    stopDrill(false);
    activePreview = null;
    q('rf-back-pos').hidden = true;
    host.cancelEngineSearch?.();

    const snap = host.currentSnapshot();
    anchorState = structuredClone(snap.state);
    anchorNodeId = snap.nodeId;
    anchorBaseOffset = Number.isFinite(snap.baseOffset) ? snap.baseOffset : (anchorState.side === 'b' ? 1 : 0);
    anchorKey = boardToHub(anchorState.board, anchorState.side);

    const legal = generateLegalMoves(anchorState.board, anchorState.side);
    if (!legal.length) {
      q('rf-status').textContent = 'Position terminale : aucun coup légal disponible.';
      return;
    }
    if (legal.length === 1) {
      q('rf-status').textContent = `Un seul coup légal dans cette position (${moveToPdn(legal[0])}, prise ou coup forcé) : l’adversaire ne peut pas commettre d’erreur de choix ici.`;
      report = null;
      renderReport();
      return;
    }

    const settings = readSettings();
    busy = true;
    stopFlag = false;
    const myToken = ++runToken;
    q('rf-run').disabled = true;
    q('rf-stop').hidden = false;
    q('rf-progress').hidden = false;
    q('rf-progress').max = legal.length + 1;
    q('rf-progress').value = 0;

    try {
      const res = await analyzeBadMoves(anchorState, {
        search: host.memo(),
        depth: settings.depth,
        maxTimeMs: settings.maxTimeMs,
        thresholds: settings.thresholds,
        onProgress: (done, total, label) => {
          if (myToken !== runToken) return;
          q('rf-progress').max = total;
          q('rf-progress').value = done;
          q('rf-status').textContent = `Analyse des coups possibles (profondeur ${settings.depth}) · ${label}`;
        },
        shouldStop: () => stopFlag || myToken !== runToken || !host.isActive(),
      });

      if (myToken !== runToken || !host.isActive()) return;
      if (res.cancelled) {
        q('rf-status').textContent = 'Recherche des mauvais coups interrompue.';
        return;
      }

      report = res;
      const winCount = res.badMoves.filter(b => b.verdict.leadsToWin).length;
      if (!res.badMoves.length) {
        q('rf-status').textContent = `Aucun mauvais coup détecté parmi les ${res.candidates.length} coups légaux (profondeur ${res.depth}) : tous les coups restent proches du meilleur (${res.bestPdn}, ${res.bestEvalText}).`;
      } else {
        q('rf-status').textContent = `${res.badMoves.length} mauvais coup${res.badMoves.length > 1 ? 's' : ''} détecté${res.badMoves.length > 1 ? 's' : ''} sur ${res.candidates.length} coups légaux pour ${campLabel(res.side)}`
          + `${winCount ? ` · dont ${winCount} permettant une suite gagnante pour ${campLabel(res.punisherSide)}` : ''}`
          + ` · Meilleur coup de référence : ${res.bestPdn} (${res.bestEvalText}, prof. ${res.depth}).`;
      }
      renderReport();
    } catch (err) {
      if (myToken !== runToken) return;
      q('rf-status').textContent = 'Analyse impossible : ' + err.message;
      toast('Analyse impossible : ' + err.message);
    } finally {
      if (myToken === runToken) {
        busy = false;
        q('rf-run').disabled = false;
        q('rf-stop').hidden = true;
        q('rf-progress').hidden = true;
      }
    }
  }

  function formatStepLabel(plyOffset, _startSide, move) {
    const off = anchorBaseOffset + plyOffset;
    const num = Math.floor(off / 2) + 1;
    const isWhite = off % 2 === 0;
    return `${num}${isWhite ? '.' : '…'}${moveToPdn(move)}`;
  }

  function renderReport() {
    const list = q('rf-list');
    list.replaceChildren();

    const hasBad = Boolean(report?.badMoves?.length);
    q('rf-drill-random').disabled = busy || !hasBad;
    q('rf-add-all').disabled = busy || !hasBad;
    q('rf-filters').hidden = !hasBad;
    q('rf-good-wrap').hidden = !report?.goodMoves?.length;

    if (!report) return;

    // Mise à jour des compteurs de filtres
    const winItems = report.badMoves.filter(b => b.verdict.leadsToWin);
    const errItems = report.badMoves.filter(b => b.severity === 'blunder' || b.severity === 'error');
    q('rf-f-all').textContent = `Tous (${report.badMoves.length})`;
    q('rf-f-wins').textContent = `Suites gagnantes (${winItems.length})`;
    q('rf-f-errors').textContent = `Erreurs ? / ?? (${errItems.length})`;
    for (const [mode, id] of [['all', 'rf-f-all'], ['wins', 'rf-f-wins'], ['errors', 'rf-f-errors']]) {
      q(id).classList.toggle('is-toggled', filterMode === mode);
    }

    const filtered = report.badMoves
      .map((item, idx) => ({ item, idx }))
      .filter(({ item }) => {
        if (filterMode === 'wins') return item.verdict.leadsToWin;
        if (filterMode === 'errors') return item.severity === 'blunder' || item.severity === 'error';
        return true;
      });

    if (hasBad && !filtered.length) {
      list.append(el('p', 'study-context', 'Aucun coup dans ce filtre — cliquez sur « Tous » pour voir les autres imprécisions.'));
    }

    for (const { item, idx } of filtered) {
      const isSelected = activePreview?.itemIndex === idx;
      const curStep = isSelected ? activePreview.stepIndex : null;
      const card = el('article', `rf-card rf-sev-${item.severity}${isSelected ? ' is-selected' : ''}`);

      const head = el('div', 'rf-card-head');
      const leftBadges = el('div', 'rf-badges');
      leftBadges.append(
        el('span', `rf-move-pill rf-pill-${item.severity}`, `${item.pdn}${item.symbol}`),
        el('span', 'rf-loss-tag', `${item.label} · perte −${item.lossText} pion`),
      );
      const rightBadges = el('div', 'rf-badges');
      rightBadges.append(
        el('span', `rf-verdict-pill${item.verdict.leadsToWin ? ' is-win' : ''}`,
          `${item.verdict.leadsToWin ? '🏆 ' : ''}${item.verdict.badge} (${item.punisherScoreText})`),
      );
      if (item.motif) {
        rightBadges.append(el('span', 'rf-motif-tag', item.motif));
      }
      head.append(leftBadges, rightBadges);
      card.append(head);

      // Ligne de réfutation cliquable pas à pas
      const lineWrap = el('div', 'rf-pv-wrap');
      const lineTitle = el('span', 'rf-pv-label',
        item.refutationMoves.length
          ? `Exploitation par ${campLabel(report.punisherSide)} :`
          : 'Réfutation :');
      lineWrap.append(lineTitle);

      const errBtn = el('button', `rf-step-btn rf-step-err${curStep === 0 ? ' active' : ''}`,
        `Erreur ${formatStepLabel(0, report.side, item.move)}${item.symbol}`);
      errBtn.type = 'button';
      errBtn.addEventListener('click', () => previewItemStep(idx, 0));
      lineWrap.append(errBtn);

      item.refutationMoves.forEach((rm, rIdx) => {
        const stepNum = rIdx + 1;
        const isPunisherMove = rIdx % 2 === 0;
        const btn = el('button',
          `rf-step-btn${isPunisherMove ? ' rf-step-punish' : ''}${curStep === stepNum ? ' active' : ''}`,
          formatStepLabel(stepNum, report.side, rm) + (rIdx === 0 ? '!' : ''));
        btn.type = 'button';
        btn.addEventListener('click', () => previewItemStep(idx, stepNum));
        lineWrap.append(btn);
      });
      card.append(lineWrap);

      // Barre d'actions : pas-à-pas, quiz, jouer jusqu'au gain, ajouter à l'analyse
      const actions = el('div', 'replay-toolbar rf-card-actions');

      if (item.refutationMoves.length) {
        const prevStepBtn = el('button', 'secondary-button', '◀');
        prevStepBtn.type = 'button';
        prevStepBtn.title = 'Coup précédent de la réfutation';
        prevStepBtn.addEventListener('click', () => previewItemStep(idx, (curStep ?? 0) - 1));

        const nextStepBtn = el('button', 'secondary-button', '▶ Suite');
        nextStepBtn.type = 'button';
        nextStepBtn.title = 'Avancer dans la variante qui mène au gain';
        nextStepBtn.addEventListener('click', () => previewItemStep(idx, curStep === null ? 0 : curStep + 1));

        actions.append(prevStepBtn, nextStepBtn);

        const drillBtn = el('button', 'secondary-button', '🎯 S’entraîner à réfuter');
        drillBtn.type = 'button';
        drillBtn.addEventListener('click', () => startDrillForItem(item));
        actions.append(drillBtn);
      }

      const playWinBtn = el('button', 'secondary-button', '⚔ Mener au gain contre PIONICIDE');
      playWinBtn.type = 'button';
      playWinBtn.addEventListener('click', () => launchPlayToWin(item));
      actions.append(playWinBtn);

      const addTreeBtn = el('button', 'secondary-button', '+ Ajouter à mon analyse');
      addTreeBtn.type = 'button';
      addTreeBtn.addEventListener('click', () => {
        host.insertBadMoveVariation(anchorNodeId, item, report.punisherSide);
      });
      actions.append(addTreeBtn);

      card.append(actions);
      list.append(card);
    }

    // Liste repliée des coups sains
    if (report.goodMoves.length) {
      q('rf-good-summary').textContent = `Voir aussi les ${report.goodMoves.length} coup${report.goodMoves.length > 1 ? 's' : ''} sain${report.goodMoves.length > 1 ? 's' : ''} / jouable${report.goodMoves.length > 1 ? 's' : ''} dans cette position`;
      const goodBox = q('rf-good-list');
      goodBox.replaceChildren();
      for (const gm of report.goodMoves) {
        const chip = el('span', `rf-good-chip${gm.isBest ? ' is-best' : ''}`,
          `${gm.pdn}${gm.isBest ? '! (meilleur)' : ''} · ${gm.evalText}${gm.loss > 0 ? ` (−${gm.lossText})` : ''}`);
        goodBox.append(chip);
      }
    }
  }

  /* ---- Écouteurs d'interface ---- */
  q('rf-run').addEventListener('click', () => runDetection());
  q('rf-stop').addEventListener('click', () => {
    stopFlag = true;
    q('rf-status').textContent = 'Arrêt demandé…';
  });
  q('rf-drill-random').addEventListener('click', () => startRandomDrill());
  q('rf-back-pos').addEventListener('click', () => restoreOriginPosition());

  q('rf-add-all').addEventListener('click', () => {
    if (!report?.badMoves?.length) return;
    let added = 0;
    for (const item of report.badMoves) {
      if (host.insertBadMoveVariation(anchorNodeId, item, report.punisherSide, { silent: true })) added += 1;
    }
    if (added) toast(`${added} mauvais coup${added > 1 ? 's' : ''} et leurs réfutations ajoutés à votre analyse manuelle.`);
  });

  q('rf-filters').addEventListener('click', event => {
    const btn = event.target.closest('[data-filter]');
    if (!btn) return;
    filterMode = btn.dataset.filter;
    renderReport();
  });

  q('rf-drill-hint').addEventListener('click', () => {
    if (!drill || drill.finished) return;
    const expected = drill.pvMoves[drill.stepIndex];
    if (!expected) return;
    host.previewState(drill.currentState, {
      arrows: [{ path: expected.path, color: '#2f9e5b', dashed: false, label: '!' }],
      note: `Indice : jouez ${moveToPdn(expected)} !`,
    });
    q('rf-drill-feedback').textContent = `💡 Indice affiché sur le damier : ${moveToPdn(expected)} !`;
    q('rf-drill-feedback').className = 'rf-drill-feedback';
    host.scrollToBoard?.();
  });

  q('rf-drill-reveal').addEventListener('click', () => {
    if (!drill) return;
    const idx = report?.badMoves?.indexOf(drill.item) ?? -1;
    if (idx >= 0) previewItemStep(idx, 1);
  });

  q('rf-drill-next').addEventListener('click', () => startRandomDrill());
  q('rf-drill-play-engine').addEventListener('click', () => {
    if (drill?.item) launchPlayToWin(drill.item);
  });
  q('rf-drill-quit').addEventListener('click', () => stopDrill(true));

  return {
    el: root,
    run: () => runDetection(),
    isBusy: () => busy,
    isDrilling: () => Boolean(drill && !drill.finished),
    handleBoardMove: move => (drill ? handleDrillBoardMove(move) : false),
    notifyPositionChanged(newBoardHub) {
      clearReplyTimer();
      drill = null;
      q('rf-drill-card').hidden = true;
      activePreview = null;
      q('rf-back-pos').hidden = true;
      if (report && anchorKey && newBoardHub !== anchorKey) {
        // La position a changé sur le damier : on signale clairement que la liste correspondait à une autre position
        q('rf-status').textContent = 'Position modifiée sur le damier — cliquez sur « 🎯 Chercher les mauvais coups de cette position » pour analyser cette nouvelle position.';
      }
    },
    reset() {
      stopFlag = true;
      runToken += 1;
      busy = false;
      clearReplyTimer();
      drill = null;
      report = null;
      anchorState = null;
      anchorNodeId = null;
      anchorKey = '';
      activePreview = null;
      q('rf-drill-card').hidden = true;
      q('rf-back-pos').hidden = true;
      q('rf-progress').hidden = true;
      q('rf-stop').hidden = true;
      q('rf-run').disabled = false;
      q('rf-list').replaceChildren();
      q('rf-filters').hidden = true;
      q('rf-good-wrap').hidden = true;
      q('rf-status').textContent = 'Placez-vous sur la position de votre choix puis cliquez sur « Chercher les mauvais coups de cette position ».';
    },
  };
}
