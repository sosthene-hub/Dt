/* PIONICIDE · Page « Partie commentée ».

   Une partie (jouée ici, importée en PDN ou tirée de la base) est confrontée à
   deux sources : les statistiques de la base de parties locale et les
   évaluations du moteur PIONICIDE. Le résultat est un document imprimable où
   chaque commentaire est étiqueté par sa source.

   Aucune phrase n'est écrite à la main ici : tout vient de src/study/facts.js.
*/
import '../study/study.css';
import { engine } from '../engine.js';
import { store } from '../store.js';
import { parsePdnGames, replayPdnGame, moveToPdn } from '../pdn.js';
import { initialState, appendState } from '../game-history.js';
import { createInitialBoard } from '../game-rules.js';
import { annotateGame } from '../analysis/annotate.js';
import { createMemoSearch } from '../analysis/threats.js';
import { createBaseClient, positionKeyOf } from '../study/base-client.js';
import {
  buildPlyFacts, selectMoments, buildStudyModel, momentBadge, momentTitle,
  STUDY_DEFAULTS,
} from '../study/facts.js';
import { openStudySheet } from '../study/document.js';

const DEPTHS = [10, 12, 16, 20];
const TIME_CAPS = [600, 1500, 3000];

const esc = text => String(text ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const nb = value => (Number.isFinite(value) ? String(Math.round(value * 10) / 10).replace('.', ',') : '—');

export function createStudyPage({ navigate, toast }) {
  const el = document.createElement('div');
  let game = null;              // {start, moves, headers, result, source}
  let busy = false;
  let stopRequested = false;
  let token = 0;
  let base = null;
  let model = null;
  let mounted = false;

  el.innerHTML = `
  <div class="section-heading">
    <div class="eyebrow">ÉTUDE · PARTIE COMMENTÉE</div>
    <h1>Partie commentée</h1>
    <p>Choisissez une partie, puis lancez l’étude. Chaque commentaire est produit à partir de deux sources
    vérifiables : les statistiques de votre base de parties locale et les évaluations du moteur PIONICIDE.
    Le résultat s’imprime en document structuré, avec sommaire, diagrammes numérotés et parties de référence.</p>
  </div>

  <section class="panel">
    <h2>1 · La partie à étudier</h2>
    <p class="study-context" id="st-source">Aucune partie chargée.</p>
    <div class="replay-toolbar">
      <label class="file-button secondary-button">Choisir un fichier PDN
        <input type="file" id="st-file" accept=".pdn,.txt,text/plain" hidden>
      </label>
      <button class="secondary-button" id="st-paste-toggle" type="button">Coller un PDN</button>
      <button class="secondary-button" id="st-clear" type="button">Retirer la partie</button>
    </div>
    <div id="st-paste" hidden>
      <textarea id="st-text" rows="7" spellcheck="false"
        placeholder="[Event &quot;…&quot;]&#10;[White &quot;…&quot;]&#10;[Black &quot;…&quot;]&#10;1. 32-28 18-22 2. 37-32 …"></textarea>
      <div class="replay-toolbar">
        <button class="primary-button" id="st-load-text" type="button">Charger ce PDN</button>
      </div>
    </div>
    <p class="study-context">Une partie jouée contre PIONICIDE, une partie de la base ou un PDN importé conviennent.
    Les boutons « Étudier et commenter » de la page de jeu et de la base remplissent ce champ automatiquement.</p>
  </section>

  <section class="panel">
    <h2>2 · Réglages</h2>
    <div class="study-settings">
      <label>Profondeur du moteur
        <select id="st-depth">${DEPTHS.map(depth => `<option value="${depth}"${depth === 12 ? ' selected' : ''}>${depth}</option>`).join('')}</select>
      </label>
      <label>Temps maximal par position
        <select id="st-time">${TIME_CAPS.map(ms => `<option value="${ms}"${ms === 600 ? ' selected' : ''}>${nb(ms / 1000)} s</option>`).join('')}</select>
      </label>
      <label>Seuil « erreur »
        <select id="st-error">
          <option value="0.3">0,3 pion</option>
          <option value="0.5" selected>0,5 pion</option>
          <option value="1">1 pion</option>
        </select>
      </label>
      <label>Seuil « grosse erreur »
        <select id="st-blunder">
          <option value="1">1 pion</option>
          <option value="1.5" selected>1,5 pion</option>
          <option value="2.5">2,5 pions</option>
        </select>
      </label>
      <label>Écart de rendement retenu
        <select id="st-gap">
          <option value="5">5 points</option>
          <option value="10" selected>10 points</option>
          <option value="20">20 points</option>
        </select>
      </label>
      <label>Échantillon minimal
        <select id="st-min">
          <option value="3">3 parties</option>
          <option value="5" selected>5 parties</option>
          <option value="10">10 parties</option>
          <option value="20">20 parties</option>
        </select>
      </label>
      <label>Moments commentés
        <select id="st-max">
          <option value="8">8 au maximum</option>
          <option value="14" selected>14 au maximum</option>
          <option value="24">24 au maximum</option>
        </select>
      </label>
      <label class="check-row"><input type="checkbox" id="st-engine" checked>Interroger le moteur</label>
      <label class="check-row"><input type="checkbox" id="st-base" checked>Interroger la base de parties</label>
    </div>
    <p class="study-context">Une profondeur faible et un temps court suffisent pour un premier passage ; augmentez la profondeur
    pour une étude définitive. Le document rappelle toujours la profondeur employée.</p>
  </section>

  <section class="panel">
    <h2>3 · Lancer l’étude</h2>
    <div class="replay-toolbar">
      <button class="primary-button" id="st-run" disabled>Étudier et commenter</button>
      <button class="secondary-button" id="st-stop" hidden>Arrêter</button>
      <button class="secondary-button" id="st-doc" disabled>Ouvrir le document imprimable</button>
    </div>
    <progress id="st-progress" max="100" value="0" hidden></progress>
    <p class="study-context" id="st-status" role="status">Chargez une partie pour commencer.</p>
  </section>

  <section class="panel" id="st-results" hidden>
    <h2>Résultat de l’étude</h2>
    <div id="st-summary"></div>
    <div id="st-moments"></div>
  </section>

  <section class="panel">
    <h2>Ce que l’étude ne fait pas</h2>
    <ul class="study-limits">
      <li>Elle n’invente pas de commentaire : quand la base et le moteur se taisent, le document l’écrit.</li>
      <li>Elle ne compare pas deux coups sur moins de parties que l’échantillon minimal choisi.</li>
      <li>Elle ne cite aucun joueur, tournoi ou combinaison absent des données chargées.</li>
      <li>Elle ne modifie ni la base de parties ni la partie d’origine.</li>
    </ul>
  </section>`;

  const q = id => el.querySelector('#' + id);
  const setStatus = text => { q('st-status').textContent = text; };

  /* ------------------------------- chargement ------------------------------- */

  function describeGame() {
    if (!game) return 'Aucune partie chargée.';
    const white = game.headers?.White || game.headers?.Blancs || 'Blancs';
    const black = game.headers?.Black || game.headers?.Noirs || 'Noirs';
    const bits = [
      `${white} — ${black}`,
      game.headers?.Event,
      game.headers?.Date,
      game.result && `résultat ${game.result}`,
      `${game.moves.length} demi-coups`,
      game.source,
    ].filter(Boolean);
    return bits.join(' · ');
  }

  function refreshSource() {
    q('st-source').textContent = describeGame();
    q('st-run').disabled = busy || !game || !game.moves.length;
  }

  function adoptGame(next) {
    game = next;
    model = null;
    q('st-doc').disabled = true;
    q('st-results').hidden = true;
    refreshSource();
  }

  function loadDraft(draft) {
    if (!draft || !Array.isArray(draft.moves) || !draft.moves.length) return false;
    const start = draft.start?.board ? draft.start : { board: createInitialBoard(), side: 'w' };
    adoptGame({
      start: { board: start.board.slice(), side: start.side || 'w' },
      moves: draft.moves.slice(),
      headers: draft.headers || {},
      result: draft.result || draft.headers?.Result || '*',
      source: draft.source || 'Partie transmise par l’application',
    });
    return true;
  }

  function loadPdn(text) {
    const parsed = parsePdnGames(text);
    if (!parsed.length) { toast('Aucun bloc PDN reconnu dans ce texte.'); return false; }
    const picked = parsed[0];
    const replay = replayPdnGame(picked);
    if (replay.problem) {
      toast(`PDN illisible au coup ${replay.problem.index + 1} (${replay.problem.token}) : ${replay.problem.reason}`);
      return false;
    }
    if (!replay.moves.length) { toast('Ce PDN ne contient aucun coup jouable.'); return false; }
    adoptGame({
      start: { board: replay.start.board.slice(), side: replay.start.side },
      moves: replay.moves.slice(),
      headers: picked.headers || {},
      result: picked.headers?.Result || picked.result || '*',
      source: parsed.length > 1 ? `Premier PDN du fichier (${parsed.length} blocs)` : 'PDN importé',
    });
    if (parsed.length > 1) toast(`${parsed.length} parties dans le fichier : la première est chargée.`);
    return true;
  }

  /* -------------------------------- l'étude -------------------------------- */

  function readOptions() {
    return {
      ...STUDY_DEFAULTS,
      error: Number(q('st-error').value),
      blunder: Number(q('st-blunder').value),
      gapPoints: Number(q('st-gap').value),
      minSample: Number(q('st-min').value),
      maxMoments: Number(q('st-max').value),
    };
  }

  function buildStates() {
    let states = [initialState(game.start.board, game.start.side)];
    for (let index = 0; index < game.moves.length; index += 1) {
      try {
        states = appendState(states, game.moves[index]);
      } catch (error) {
        return { states, broken: index };
      }
    }
    return { states, broken: -1 };
  }

  async function run() {
    if (!game || busy) return;
    busy = true;
    stopRequested = false;
    const myToken = ++token;
    q('st-run').disabled = true;
    q('st-stop').hidden = false;
    q('st-doc').disabled = true;
    q('st-results').hidden = true;
    q('st-progress').hidden = false;
    q('st-progress').value = 0;
    const options = readOptions();
    // Portée de l'index : au-delà, la base ne se prononce pas (et on le dit).
    let indexPly = null;
    const total = game.moves.length;

    const built = buildStates();
    if (built.broken >= 0) {
      setStatus(`Partie incohérente au demi-coup ${built.broken + 1} : l’étude est impossible.`);
      finish();
      return;
    }
    const { states } = built;
    const moves = game.moves;
    const labels = moves.map(move => moveToPdn(move));

    let baseAt;
    let baseInfo = null;
    let useBase = q('st-base').checked;

    try {
      if (useBase) {
        base = base || createBaseClient();
        setStatus('Lecture de la base de parties…');
        const stats = await base.stats();
        const games = stats?.games || 0;
        const coveredPly = stats?.index?.ply ?? 0;
        baseInfo = { games, indexPly: coveredPly };
        indexPly = coveredPly;
        if (!games || !coveredPly) {
          useBase = false;
          setStatus('Base de parties vide : l’étude s’appuiera sur le moteur seul.');
          toast('Base vide : importez des parties dans « Base de parties » pour obtenir les statistiques.');
        } else {
          const known = new Map();
          for (let index = 0; index < total; index += 1) {
            if (stopRequested || myToken !== token) break;
            // L'index ne couvre que les premiers demi-coups : au-delà, la base est
            // muette par construction, et non parce que la position est inédite.
            if (index >= coveredPly) { known.set(index, null); continue; }
            try {
              const result = await base.explorer(states[index].board, states[index].side);
              known.set(index, { moves: result?.moves || [] });
            } catch (error) {
              known.set(index, null);
            }
            if (index % 8 === 0) {
              q('st-progress').value = Math.round(35 * (index + 1) / total);
              setStatus(`Base de parties : position ${index + 1} / ${total}…`);
            }
          }
          baseAt = index => (known.has(index) ? known.get(index) : null);
        }
      }
    } catch (error) {
      useBase = false;
      baseInfo = null;
      console.warn('Base indisponible pour l’étude :', error.message);
      toast('Base de parties indisponible : étude limitée au moteur.');
    }
    if (!baseAt) baseAt = () => null;
    if (stopRequested || myToken !== token) { finish(true); return; }

    /* ---- moteur ---- */
    let enginePlies = [];
    let engineDepth = null;
    let engineFailed = false;
    if (q('st-engine').checked) {
      const depth = Number(q('st-depth').value);
      const maxTimeMs = Number(q('st-time').value);
      engineDepth = depth;
      q('st-progress').value = 35;
      setStatus(`Moteur PIONICIDE : évaluation des ${total + 1} positions à la profondeur ${depth}…`);
      try {
        const memo = createMemoSearch(options_ => engine.search(options_));
        const result = await annotateGame({
          states,
          search: memo,
          depth,
          maxTimeMs,
          pvLength: 0,
          onProgress: (done, count) => {
            if (myToken !== token) return;
            q('st-progress').value = 35 + Math.round(60 * done / count);
            setStatus(`Moteur : position ${done} / ${count} (profondeur ${depth})…`);
          },
          shouldStop: () => stopRequested || myToken !== token,
        });
        if (result.cancelled) { finish(true); return; }
        enginePlies = result.plies;
      } catch (error) {
        engineFailed = true;
        engineDepth = null;
        console.warn('Moteur indisponible pour l’étude :', error.message);
        toast('Moteur indisponible : l’étude s’appuiera sur la base seule.');
      }
    }
    if (stopRequested || myToken !== token) { finish(true); return; }

    /* ---- faits ---- */
    setStatus('Assemblage des commentaires…');
    q('st-progress').value = 96;
    const plies = buildPlyFacts({
      states, moves, labels, baseAt, engine: enginePlies,
      options: { ...options, indexPly: useBase ? indexPly : null },
    });
    const moments = selectMoments(plies, options);

    /* ---- parties de référence, pour les seuls moments retenus ---- */
    const references = new Map();
    if (useBase && base) {
      for (const ply of moments) {
        if (stopRequested || myToken !== token) break;
        const after = states[ply.index + 1];
        if (!after) continue;
        try {
          const found = await base.gamesAt(positionKeyOf(after.board, after.side));
          const rows = (found?.rows || []).slice(0, 5);
          if (rows.length) references.set(ply.index, rows);
        } catch (error) { /* base partielle : on n'affiche simplement pas de référence */ }
      }
    }

    model = buildStudyModel({
      headers: game.headers || {},
      result: game.result,
      source: game.source,
      labels,
      plies,
      references: index => references.get(index) || [],
      options,
      baseInfo: useBase ? baseInfo : null,
      engineInfo: enginePlies.length ? { depth: engineDepth } : null,
    });
    model.baseAvailable = useBase && !!baseInfo?.games;
    model.engineFailed = engineFailed;

    renderResults(model);
    q('st-progress').value = 100;
    q('st-doc').disabled = false;
    setStatus(`Étude terminée : ${model.chapters.reduce((sum, chapter) => sum + chapter.entries.length, 0)} moment(s) commenté(s) `
      + `sur ${total} demi-coups. Ouvrez le document pour l’imprimer ou l’enregistrer en PDF.`);
    finish();
    toast('Étude terminée.');
  }

  function finish(cancelled = false) {
    busy = false;
    q('st-run').disabled = !game;
    q('st-stop').hidden = true;
    if (cancelled) setStatus('Étude interrompue. Aucun document n’a été produit.');
  }

  function renderResults(built) {
    const summary = q('st-summary');
    summary.innerHTML = `<ul class="study-summary-list">${built.summaryLines.map(line => `<li>${esc(line)}</li>`).join('')}</ul>`
      + `<p class="study-context">${esc(built.sources.join(' · '))}</p>`;
    const box = q('st-moments');
    const entries = built.chapters.flatMap(chapter => chapter.entries.map(entry => ({ chapter, entry })));
    box.innerHTML = entries.length
      ? entries.map(({ chapter, entry }, index) => `
        <article class="study-moment">
          <div class="study-moment-head">
            <span class="study-badge">${esc(entry.badge)}</span>
            <b>${esc(entry.title)}</b>
            <span class="study-moment-chapter">${esc(chapter.numeral)}</span>
          </div>
          <p class="study-moment-fact"><span class="study-tag">BASE</span> ${entry.base.map(esc).join(' ')}</p>
          <p class="study-moment-fact"><span class="study-tag study-tag-engine">MOTEUR</span> ${entry.engine.map(esc).join(' ')}</p>
          ${entry.references.length ? `<p class="study-moment-fact"><span class="study-tag study-tag-ref">PARTIES</span> ${
            entry.references.map(ref => esc([`${ref.w} — ${ref.b}`, ref.ev, ref.dt, ref.r].filter(Boolean).join(' · '))).join(' ; ')
          }</p>` : ''}
          <p class="study-moment-reading">${esc(entry.reading)}</p>
          <button class="secondary-button" type="button" data-goto="${entry.ply.index}">Voir la position ${index + 1}</button>
        </article>`).join('')
      : '<p class="study-context">Aucun moment ne dépasse les seuils choisis. Le document reste disponible avec le tableau complet des coups.</p>';
    box.querySelectorAll('[data-goto]').forEach(button => {
      button.addEventListener('click', () => {
        const ply = built.table[Number(button.dataset.goto)];
        toast(ply ? `Coup ${ply.number} ${ply.label} · ${ply.n} partie(s) dans la base` : 'Position indisponible.');
      });
    });
    q('st-results').hidden = false;
  }

  /* -------------------------------- écouteurs -------------------------------- */

  q('st-file').addEventListener('change', event => {
    const file = event.target.files?.[0];
    if (!file) return;
    file.text().then(text => { if (loadPdn(text)) toast('Partie chargée.'); })
      .catch(() => toast('Fichier illisible.'));
    event.target.value = '';
  });
  q('st-paste-toggle').addEventListener('click', () => { q('st-paste').hidden = !q('st-paste').hidden; });
  q('st-load-text').addEventListener('click', () => {
    const text = q('st-text').value.trim();
    if (!text) { toast('Collez d’abord un PDN.'); return; }
    if (loadPdn(text)) { q('st-paste').hidden = true; toast('Partie chargée.'); }
  });
  q('st-clear').addEventListener('click', () => {
    token += 1;
    game = null; model = null;
    q('st-results').hidden = true;
    q('st-doc').disabled = true;
    q('st-text').value = '';
    refreshSource();
    setStatus('Chargez une partie pour commencer.');
  });
  q('st-run').addEventListener('click', () => { run().catch(error => { console.error(error); setStatus('Étude impossible : ' + error.message); finish(); }); });
  q('st-stop').addEventListener('click', () => { stopRequested = true; setStatus('Interruption demandée…'); });
  q('st-doc').addEventListener('click', () => {
    if (!model) return;
    openStudySheet(model);
  });

  return {
    el,
    mount() {
      mounted = true;
      if (store.studyDraft) {
        const draft = store.studyDraft;
        store.studyDraft = null;
        if (loadDraft(draft)) {
          setStatus('Partie chargée depuis l’application. Lancez l’étude, ou ajustez d’abord les réglages.');
          return;
        }
      }
      if (!game) {
        if (store.analysisDraft) {
          const draft = store.analysisDraft;
          if (loadDraft({
            start: draft.start, moves: draft.moves, headers: draft.headers,
            result: draft.result, source: 'Partie du damier d’analyse',
          })) {
            setStatus('Partie du damier d’analyse chargée. Lancez l’étude.');
            return;
          }
        }
        refreshSource();
      }
    },
    unmount() {
      mounted = false;
      token += 1;
      stopRequested = true;
      base?.close();
      base = null;
    },
    get mounted() { return mounted; },
  };
}
