import { createRetroPage } from './retro.js';

export function createRetroOnlyPage(options){const el=document.createElement('div');const retro=createRetroPage(options);el.append(retro.el);return {el,mount(){retro.mount?.();},unmount(){retro.unmount?.();}};}
