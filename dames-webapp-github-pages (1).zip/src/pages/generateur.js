import { renderBoard } from '../board-view.js';
import { generateLegalMoves, opponent, sideOf } from '../game-rules.js';
import { positionToPdn, validatePosition } from '../position.js';
import { mulberry32, randomPosition } from '../puzzles.js';
import { store } from '../store.js';

export function createGeneratorPage({ navigate, toast }) {
  const el = document.createElement('div');
  let board = [];
  let side = 'w';
  let seed = Math.floor(Math.random() * 1e9);

  el.innerHTML = `
    <div class="section-heading"><div class="eyebrow">OUTILS · POSITIONS</div><h1>Générateur de positions</h1><p>Créez des positions d’entraînement selon vos contraintes, puis analysez-les ou éditez-les.</p></div>
    <section class="panel generator-panel">
      <div class="editor-grid">
        <div class="generator-left">
          <div class="board-wrap"><div id="gen-board"></div></div>
          <div class="position-status" id="gen-status">Génération…</div>
        </div>
        <aside class="editor-side">
          <div class="field-block">
            <span class="field-label">Contraintes</span>
            <label class="range-row">Pièces par camp <b id="gen-count-label">6</b>
              <input type="range" id="gen-count" min="2" max="20" value="6" />
            </label>
            <label class="check-row"><input type="checkbox" id="gen-kings" checked /> <span>Dames autorisées</span></label>
            <label class="check-row"><input type="checkbox" id="gen-capture" checked /> <span>Avec prise disponible</span></label>
          </div>
          <div class="field-block">
            <span class="field-label">Trait</span>
            <div class="segmented" role="group" aria-label="Trait">
              <button type="button" class="segment active" data-side="w">Blancs</button>
              <button type="button" class="segment" data-side="b">Noirs</button>
            </div>
          </div>
          <div class="field-block">
            <span class="field-label">Graine</span>
            <div class="code-row"><input id="gen-seed" type="number" aria-label="Graine du générateur"><button class="secondary-button" id="gen-apply" type="button">Appliquer</button></div>
          </div>
          <button class="start-game-button" id="gen-generate" type="button">⚄ Générer <span>↻</span></button>
          <div class="editor-actions">
            <button class="secondary-button" id="gen-analyze" type="button">⌕ Analyser</button>
            <button class="secondary-button" id="gen-edit" type="button">▧ Éditer</button>
          </div>
          <div class="code-row"><input id="gen-code" type="text" readonly aria-label="Code de position au format PDN"><button class="secondary-button" id="gen-copy" type="button">Copier</button></div>
        </aside>
      </div>
    </section>
  `;

  const boardEl = el.querySelector('#gen-board');
  const statusEl = el.querySelector('#gen-status');
  const countInput = el.querySelector('#gen-count');
  const countLabel = el.querySelector('#gen-count-label');
  const kingsInput = el.querySelector('#gen-kings');
  const captureInput = el.querySelector('#gen-capture');
  const seedInput = el.querySelector('#gen-seed');
  const codeEl = el.querySelector('#gen-code');

  function generate() {
    const pieces = Number(countInput.value);
    const kings = kingsInput.checked;
    const wantCapture = captureInput.checked;
    const chosenSide = el.querySelector('.segment.active').dataset.side;
    const rng = mulberry32(seed);
    let attempts = 0;
    while (attempts < 200) {
      const candidate = randomPosition(rng, { pieces, kings });
      candidate.side = chosenSide;
      const legal = generateLegalMoves(candidate.board, candidate.side);
      if (!legal.length) { attempts++; seed++; continue; }
      const hasCapture = legal.some(move => move.captured.length > 0);
      if (wantCapture && !hasCapture) { attempts++; seed++; continue; }
      board = candidate.board;
      side = candidate.side;
      render();
      return;
    }
    statusEl.innerHTML = '<span class="status-error">⚠ Aucune position trouvée avec ces contraintes. Assouplissez-les.</span>';
  }

  function render() {
    const legal = generateLegalMoves(board, side);
    const captures = legal.filter(move => move.captured.length > 0);
    const error = validatePosition(board, side);
    const counts = { white: 0, black: 0 };
    for (let square = 1; square <= 50; square++) {
      if (sideOf(board[square]) === 'w') counts.white++;
      else if (sideOf(board[square]) === 'b') counts.black++;
    }
    statusEl.innerHTML = error
      ? `<span class="status-error">⚠ ${error}</span>`
      : `<span class="status-ok">✓ Position valide</span><div class="counts">Blancs : ${counts.white} · Noirs : ${counts.black} · ${legal.length} coup${legal.length > 1 ? 's' : ''} légal${legal.length > 1 ? 's' : ''} dont ${captures.length} prise${captures.length > 1 ? 's' : ''}. Graine : ${seed}.</div>`;
    codeEl.value = positionToPdn(board, side);
    draw();
  }

  function draw() {
    renderBoard(boardEl, { board, orientation: 'w', onSquareClick: null });
  }

  countInput.addEventListener('input', () => { countLabel.textContent = countInput.value; });
  el.querySelector('#gen-generate').addEventListener('click', () => { seed = Math.floor(Math.random() * 1e9); seedInput.value = seed; generate(); });
  el.querySelector('#gen-apply').addEventListener('click', () => {
    const value = Number.parseInt(seedInput.value, 10);
    if (!Number.isInteger(value)) { toast('Graine invalide.'); return; }
    seed = value;
    generate();
  });
  el.querySelectorAll('.segment').forEach(button => button.addEventListener('click', () => {
    el.querySelectorAll('.segment').forEach(other => other.classList.toggle('active', other === button));
    generate();
  }));
  [countInput, kingsInput, captureInput].forEach(input => input.addEventListener('change', generate));

  el.querySelector('#gen-analyze').addEventListener('click', () => {
    if (validatePosition(board, side)) { toast('Position invalide.'); return; }
    store.positionDraft = { board: board.slice(), side };
    navigate('analyse');
  });
  el.querySelector('#gen-edit').addEventListener('click', () => {
    store.positionDraft = { board: board.slice(), side };
    navigate('editeur');
  });
  el.querySelector('#gen-copy').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(codeEl.value);
      toast('Code de position copié.');
    } catch {
      codeEl.select();
      toast('Sélectionnez le code puis copiez-le (Ctrl+C).');
    }
  });

  seedInput.value = seed;
  generate();
  return { el };
}
