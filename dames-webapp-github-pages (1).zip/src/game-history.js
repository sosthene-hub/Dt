import {createInitialBoard,applyMove,opponent} from './game-rules.js';
import {newDrawState,advanceDraw} from './draw-rules.js';
export function initialState(board=createInitialBoard(),side='w'){return {board:board.slice(),side,lastMove:null,drawState:newDrawState(board,side)};}
export function appendState(states,move){const before=states.at(-1),board=applyMove(before.board,move),side=opponent(before.side);return [...states,{board,side,lastMove:[...move.path],drawState:advanceDraw(before.drawState,before.board,move,board,side)}];}
