// FMJD Annexes 2024, Annex 1 articles 6.1–6.4. A move means one move per player.
import {coordinate,sideOf,positionKey,generateLegalMoves,opponent} from './game-rules.js';
export function materialLimit(board){
 const pieces={w:[],b:[]};for(let n=1;n<=50;n++)if(sideOf(board[n]))pieces[sideOf(board[n])].push({piece:board[n],n});
 for(const lone of ['w','b']){const a=pieces[lone],b=pieces[opponent(lone)];if(a.length!==1||a[0].piece!==lone.toUpperCase()||!b.some(x=>x.piece===opponent(lone).toUpperCase()))continue;
 if(b.length<=2)return 5;
 if(b.length===3){const diagonal=n=>{const c=coordinate(n);return c.row+c.col===9;};return diagonal(a[0].n)&&b.every(x=>!diagonal(x.n))?5:16;}}
 return null;
}
export function newDrawState(board,side){const limit=materialLimit(board);return {moves:{w:0,b:0},quiet:{w:0,b:0},limits:limit?[{limit,w:limit,b:limit}]:[],repetitions:{[positionKey(board,side)]:1}};}
export function advanceDraw(state,before,move,after,nextSide){const next=structuredClone(state),mover=opponent(nextSide);next.moves[mover]++;
 if(move.captured.length||before[move.from]===before[move.from].toLowerCase())next.quiet={w:0,b:0};else next.quiet[mover]++;
 const key=positionKey(after,nextSide);next.repetitions[key]=(next.repetitions[key]||0)+1;
 const limit=materialLimit(after);if(limit&&!next.limits.some(x=>x.limit===limit))next.limits.push({limit,w:next.moves.w+limit,b:next.moves.b+limit});
 return next;}
export function adjudicate(board,side,state){
 if(!generateLegalMoves(board,side).length)return {result:opponent(side)==='w'?'1-0':'0-1',reason:'Aucun coup légal : victoire adverse.'};
 if((state.repetitions[positionKey(board,side)]||0)>=3)return {result:'1/2-1/2',reason:'Même position et même trait pour la troisième fois (FMJD 6.1).'};
 if(state.quiet.w>=25&&state.quiet.b>=25)return {result:'1/2-1/2',reason:'25 coups de chaque camp, uniquement des dames, sans prise ni mouvement de pion (FMJD 6.2).'};
 const expired=state.limits.find(l=>state.moves.w>=l.w&&state.moves.b>=l.b);if(expired)return {result:'1/2-1/2',reason:`Limite de finale : ${expired.limit} coups par camp atteints (FMJD 6.3–6.4).`};return null;
}
export function drawStatus(s){return `Dames sans progrès : ${s.quiet.w}/25 blancs, ${s.quiet.b}/25 noirs`+s.limits.map(l=>` · finale ${l.limit} : reste ${Math.max(0,l.w-s.moves.w)} B / ${Math.max(0,l.b-s.moves.b)} N`).join('');}
