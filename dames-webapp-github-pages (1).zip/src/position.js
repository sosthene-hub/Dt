import { createInitialBoard, sideOf } from './game-rules.js';

// Position validation for the editor / analysis boards.
export function validatePosition(board, side) {
  let white = 0;
  let black = 0;
  for (let square = 1; square <= 50; square++) {
    if (sideOf(board[square]) === 'w') white++;
    else if (sideOf(board[square]) === 'b') black++;
  }
  if (white + black === 0) return 'Placez au moins une pièce sur le damier.';
  if (white > 20) return 'Les blancs ont plus de 20 pièces (maximum réglementaire).';
  if (black > 20) return 'Les noirs ont plus de 20 pièces (maximum réglementaire).';
  return null;
}

export function countPieces(board) {
  let white = 0;
  let black = 0;
  let whiteKings = 0;
  let blackKings = 0;
  for (let square = 1; square <= 50; square++) {
    const piece = board[square];
    if (piece === 'w') white++;
    else if (piece === 'W') { white++; whiteKings++; }
    else if (piece === 'b') black++;
    else if (piece === 'B') { black++; blackKings++; }
  }
  return { white, black, whiteKings, blackKings };
}

// Standard PDN position notation: W:W31,32K50:B18,19
export function positionToPdn(board, side) {
  const list = color => {
    const men = [];
    const kings = [];
    for (let square = 1; square <= 50; square++) {
      const piece = board[square];
      if (piece === color) men.push(square);
      else if (piece === color.toUpperCase()) kings.push(square);
    }
    const parts = [];
    if (men.length) parts.push(men.join(','));
    if (kings.length) parts.push(kings.map(square => `K${square}`).join(','));
    return parts.join(',');
  };
  return `${side === 'w' ? 'W' : 'B'}:W${list('w')}:B${list('b')}`;
}

// Accepts PDN position notation or the 51-character Hub code (W/B + 50 squares).
export function parsePdnPosition(text) {
  const trimmed = String(text || '').trim();
  const hub = trimmed.match(/^([WB])([ewbWB]{50})$/);
  if (hub) {
    const board = Array(51).fill('e');
    const chars = hub[2].split('');
    for (let i = 0; i < 50; i++) board[i + 1] = chars[i];
    return { board, side: hub[1] === 'W' ? 'w' : 'b' };
  }
  const pdn = trimmed.match(/^([WB]):W([0-9K,]*):B([0-9K,]*)$/);
  if (pdn) {
    const board = Array(51).fill('e');
    const fill = (part, man, king) => {
      if (!part) return true;
      for (const token of part.split(',')) {
        if (!token) continue;
        const isKing = token.startsWith('K');
        const square = Number(isKing ? token.slice(1) : token);
        if (!Number.isInteger(square) || square < 1 || square > 50) return false;
        board[square] = isKing ? king : man;
      }
      return true;
    };
    if (!fill(pdn[2], 'w', 'W') || !fill(pdn[3], 'b', 'B')) return null;
    return { board, side: pdn[1] === 'W' ? 'w' : 'b' };
  }
  return null;
}

export function initialPosition() {
  return { board: createInitialBoard(), side: 'w' };
}
