// PDN (Portable Draughts Notation) parsing and serialization.
// Capture notation in PDN lists every landing square: 28x19x23 (captures are implicit).
// This differs from the Hub engine format, which lists captured squares — hence the
// dedicated matchers below that work on the full move path.

const RESULT_TOKENS = new Set(['1-0', '0-1', '1/2-1/2', '*']);

// Extract move tokens from raw movetext, ignoring numbers, comments, variations and NAGs.
export function extractMoveTokens(text) {
  const tokens = [];
  let buffer = '';
  let comment = false;
  let variation = 0;
  // Result markers are not moves; strip them before tokenizing.
  const cleaned = String(text).replace(/\b(?:1-0|0-1|1\/2-1\/2)\b/g, ' ').replace(/\*/g, ' ');
  const flush = () => {
    if (!buffer) return;
    const raw = buffer;
    buffer = '';
    if (/^\d+\.$/.test(raw)) return; // move number
    const move = raw.replace(/[!?]+$/, '');
    if (/^(\d+([-x]\d+)+)$/.test(move)) tokens.push(move);
  };
  for (const ch of cleaned) {
    if (comment) {
      if (ch === '}') comment = false;
      continue;
    }
    if (ch === '{') { flush(); comment = true; continue; }
    if (ch === '(') { flush(); variation++; continue; }
    if (ch === ')') { flush(); variation = Math.max(0, variation - 1); continue; }
    if (variation > 0) continue;
    if (ch === '$') { flush(); continue; } // NAG: drop following digits below
    if (/\s/.test(ch)) { flush(); continue; }
    if (ch === '!' || ch === '?') { buffer += ch; continue; }
    if (/[\d.x-]/.test(ch)) buffer += ch;
    else flush(); // any other character terminates the current token
  }
  flush();
  return tokens;
}

export function parseHeaders(block) {
  const headers = {};
  const re = /\[(\w+)\s+"((?:[^"\\]|\\.)*)"\]/g;
  let match;
  while ((match = re.exec(block))) headers[match[1]] = match[2].replace(/\\"/g, '"');
  return headers;
}

// Parse a PDN document into a list of games: {headers, tokens, result, fen?}.
export function parsePdnGames(text) {
  const games = [];
  const chunks = String(text).split(/(?=\[Event\s")/).filter(chunk => chunk.trim());
  for (const chunk of chunks) {
    const headerMatch = chunk.match(/^((?:\[[^\n]*\]\s*)+)/);
    const headerBlock = headerMatch ? headerMatch[0] : '';
    const headers = parseHeaders(headerBlock);
    const movetext = chunk.slice(headerBlock.length);
    const tokens = extractMoveTokens(movetext);
    if (!tokens.length && !headers.Event) continue;
    games.push({ headers, tokens, result: headers.Result ?? '*' });
  }
  return games;
}

// PDN notation for a local move object (path = every landing square).
export function moveToPdn(move) {
  return move.captured.length ? move.path.join('x') : `${move.from}-${move.to}`;
}

// Match a PDN token against a legal move (both describe the full path).
export function moveMatchesPdn(move, token) {
  const parts = token.split(/[x-]/).map(Number);
  return parts.length === move.path.length && parts.every((square, index) => square === move.path[index]);
}

// Serialize a game to PDN text. moves: local move objects.
export function gameToPdn({ headers = {}, moves = [], result = '*' } = {}) {
  const defaultHeaders = {
    Event: 'Partie d’entraînement',
    Site: 'Dames — entraînement',
    Date: new Date().toISOString().slice(0, 10).replaceAll('-', '.'),
    Round: '-',
    White: 'Blancs',
    Black: 'Noirs',
    Result: result,
  };
  const merged = { ...defaultHeaders, ...headers };
  const headerLines = Object.entries(merged).map(([key, value]) => `[${key} "${String(value).replace(/"/g, '\\"')}"]`);
  const lines = [];
  moves.forEach((move, index) => {
    if (index % 2 === 0) lines.push(`${Math.floor(index / 2) + 1}.`);
    lines.push(moveToPdn(move));
  });
  lines.push(result ?? '*');
  return `${headerLines.join('\n')}\n\n${lines.join(' ')}\n`;
}
