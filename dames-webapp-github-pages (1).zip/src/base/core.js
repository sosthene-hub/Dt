/* ==========================================================================
   PIONICIDE · BASE — noyau logique (aucune dépendance DOM)
   Dames internationales 10×10, 50 cases jouables.
   Utilisé par : le worker (import / index / recherche) et l'interface.
   ========================================================================== */

export const WHITE = 0;
export const BLACK = 1;
export const EMPTY = 0;
export const WMAN = 1;
export const WKING = 2;
export const BMAN = 3;
export const BKING = 4;

/* ---------- géométrie : case 1..50 ↔ ligne/colonne ---------- */
export const sqRow = new Int8Array(51);
export const sqCol = new Int8Array(51);
const rcToSq = new Int8Array(100);
(function buildGeometry() {
  let n = 0;
  for (let r = 0; r < 10; r++) {
    for (let c = 0; c < 10; c++) {
      if (((r + c) & 1) === 1) {
        n++;
        sqRow[n] = r;
        sqCol[n] = c;
        rcToSq[r * 10 + c] = n;
      }
    }
  }
  if (n !== 50) throw new Error('géométrie invalide');
})();

// voisins diagonaux : NB[(sq-1)*4 + dir], 0 = hors damier
// dir 0 = haut-gauche, 1 = haut-droite, 2 = bas-gauche, 3 = bas-droite
export const NB = new Int8Array(51 * 4);
export const DIR_DR = [-1, -1, 1, 1];
export const DIR_DC = [-1, 1, -1, 1];
(function buildNeighbors() {
  for (let s = 1; s <= 50; s++) {
    for (let d = 0; d < 4; d++) {
      const r = sqRow[s] + DIR_DR[d];
      const c = sqCol[s] + DIR_DC[d];
      if (r < 0 || r > 9 || c < 0 || c > 9) { NB[(s - 1) * 4 + d] = 0; continue; }
      NB[(s - 1) * 4 + d] = rcToSq[r * 10 + c] | 0;
    }
  }
})();

/* ---------- masques de bits (50 cases = 2 mots de 32 bits) ---------- */
export const BL = new Int32Array(51); // bit bas (cases 1..32)
export const BH = new Int32Array(51); // bit haut (cases 33..50)
for (let s = 1; s <= 50; s++) {
  if (s <= 32) BL[s] = 1 << (s - 1);
  else BH[s] = 1 << (s - 33);
}
export function sqFromRC(r, c) { return rcToSq[r * 10 + c] | 0; }

/* ---------- position ---------- */
export class Position {
  constructor() {
    this.wmL = 0; this.wmH = 0; this.wkL = 0; this.wkH = 0;
    this.bmL = 0; this.bmH = 0; this.bkL = 0; this.bkH = 0;
    this.side = WHITE;
  }
  clone() {
    const p = new Position();
    p.wmL = this.wmL; p.wmH = this.wmH; p.wkL = this.wkL; p.wkH = this.wkH;
    p.bmL = this.bmL; p.bmH = this.bmH; p.bkL = this.bkL; p.bkH = this.bkH;
    p.side = this.side;
    return p;
  }
  static initial() {
    const p = new Position();
    for (let s = 31; s <= 50; s++) p.setPiece(s, WMAN);
    for (let s = 1; s <= 20; s++) p.setPiece(s, BMAN);
    p.side = WHITE;
    return p;
  }
  pieceAt(s) {
    if (s <= 32) {
      const b = 1 << (s - 1);
      if (this.wmL & b) return WMAN;
      if (this.wkL & b) return WKING;
      if (this.bmL & b) return BMAN;
      if (this.bkL & b) return BKING;
    } else {
      const b = 1 << (s - 33);
      if (this.wmH & b) return WMAN;
      if (this.wkH & b) return WKING;
      if (this.bmH & b) return BMAN;
      if (this.bkH & b) return BKING;
    }
    return EMPTY;
  }
  setPiece(s, t) {
    const lo = s <= 32;
    const b = lo ? (1 << (s - 1)) : (1 << (s - 33));
    switch (t) {
      case WMAN: if (lo) this.wmL |= b; else this.wmH |= b; break;
      case WKING: if (lo) this.wkL |= b; else this.wkH |= b; break;
      case BMAN: if (lo) this.bmL |= b; else this.bmH |= b; break;
      case BKING: if (lo) this.bkL |= b; else this.bkH |= b; break;
    }
  }
  clearPiece(s) {
    const lo = s <= 32;
    const b = lo ? (1 << (s - 1)) : (1 << (s - 33));
    const nb = ~b;
    if (lo) { this.wmL &= nb; this.wkL &= nb; this.bmL &= nb; this.bkL &= nb; }
    else { this.wmH &= nb; this.wkH &= nb; this.bmH &= nb; this.bkH &= nb; }
  }
  count() {
    let w = 0, b = 0;
    for (let s = 1; s <= 50; s++) {
      const t = this.pieceAt(s);
      if (t === WMAN || t === WKING) w++;
      else if (t === BMAN || t === BKING) b++;
    }
    return { w, b };
  }
}

export function colorOf(t) { return t === 0 ? -1 : (t === WMAN || t === WKING ? WHITE : BLACK); }
function isOwn(t, side) { return t !== 0 && colorOf(t) === side; }
function isEnemy(t, side) { return t !== 0 && colorOf(t) !== side; }

/* ---------- générateur de coups (règles internationales) ---------- */
export function generateMoves(pos) {
  const caps = generateCaptures(pos);
  if (caps.length) return caps;
  return generateQuiet(pos);
}

function generateCaptures(pos) {
  const side = pos.side;
  const all = [];
  for (let s = 1; s <= 50; s++) {
    const t = pos.pieceAt(s);
    if (!isOwn(t, side)) continue;
    const king = (t === WKING || t === BKING);
    dfsCapture(pos, side, king, s, s, [], [], all);
  }
  if (!all.length) return all;
  let best = 0;
  for (const m of all) if (m.caps.length > best) best = m.caps.length;
  return all.filter(m => m.caps.length === best);
}

function dfsCapture(pos, side, king, sq, origin, captured, lands, out) {
  let extended = false;
  const isEmpty = (x) => {
    if (x === origin) return true;
    for (let i = 0; i < lands.length; i++) if (lands[i] === x) return true;
    return pos.pieceAt(x) === EMPTY;
  };
  for (let d = 0; d < 4; d++) {
    if (king) {
      let x = NB[(sq - 1) * 4 + d];
      while (x && isEmpty(x)) x = NB[(x - 1) * 4 + d];
      if (!x) continue;
      const victim = x;
      if (!isEnemy(pos.pieceAt(victim), side)) continue;
      if (captured.indexOf(victim) >= 0) continue;
      let y = NB[(victim - 1) * 4 + d];
      while (y && isEmpty(y)) {
        extended = true;
        captured.push(victim); lands.push(y);
        dfsCapture(pos, side, king, y, origin, captured, lands, out);
        captured.pop(); lands.pop();
        y = NB[(y - 1) * 4 + d];
      }
    } else {
      const victim = NB[(sq - 1) * 4 + d];
      if (!victim) continue;
      if (!isEnemy(pos.pieceAt(victim), side)) continue;
      if (captured.indexOf(victim) >= 0) continue;
      const y = NB[(victim - 1) * 4 + d];
      if (!y || !isEmpty(y)) continue;
      extended = true;
      captured.push(victim); lands.push(y);
      dfsCapture(pos, side, king, y, origin, captured, lands, out);
      captured.pop(); lands.pop();
    }
  }
  if (!extended && captured.length > 0) {
    out.push({
      from: origin,
      to: lands[lands.length - 1],
      caps: captured.slice(),
      path: lands.slice(),
    });
  }
}

function generateQuiet(pos) {
  const side = pos.side;
  const out = [];
  const dirs = side === WHITE ? [0, 1] : [2, 3];
  for (let s = 1; s <= 50; s++) {
    const t = pos.pieceAt(s);
    if (!isOwn(t, side)) continue;
    if (t === WKING || t === BKING) {
      for (let d = 0; d < 4; d++) {
        let x = NB[(s - 1) * 4 + d];
        while (x && pos.pieceAt(x) === EMPTY) {
          out.push({ from: s, to: x, caps: [], path: [] });
          x = NB[(x - 1) * 4 + d];
        }
      }
    } else {
      for (const d of dirs) {
        const x = NB[(s - 1) * 4 + d];
        if (x && pos.pieceAt(x) === EMPTY) out.push({ from: s, to: x, caps: [], path: [] });
      }
    }
  }
  return out;
}

export function applyMove(pos, mv) {
  const p = pos.clone();
  const t = p.pieceAt(mv.from);
  p.clearPiece(mv.from);
  for (let i = 0; i < mv.caps.length; i++) p.clearPiece(mv.caps[i]);
  let nt = t;
  if (t === WMAN && sqRow[mv.to] === 0) nt = WKING;
  else if (t === BMAN && sqRow[mv.to] === 9) nt = BKING;
  p.setPiece(mv.to, nt);
  p.side = pos.side === WHITE ? BLACK : WHITE;
  return p;
}

/* ---------- Zobrist (2 × 32 bits, déterministe) ---------- */
export const Z = (function makeZobrist(seed) {
  let s = seed >>> 0;
  const rnd = () => {
    s ^= s << 13; s >>>= 0;
    s ^= s >>> 17;
    s ^= s << 5; s >>>= 0;
    return s | 0;
  };
  const lo = new Int32Array(5 * 51), hi = new Int32Array(5 * 51);
  for (let i = 0; i < lo.length; i++) { lo[i] = rnd(); hi[i] = rnd(); }
  return { lo, hi, sideLo: rnd(), sideHi: rnd() };
})(0x9e3779b9);

export function hashPosition(pos, out) {
  let lo = 0, hi = 0;
  for (let s = 1; s <= 50; s++) {
    const t = pos.pieceAt(s);
    if (t) { lo ^= Z.lo[t * 51 + s]; hi ^= Z.hi[t * 51 + s]; }
  }
  if (pos.side === BLACK) { lo ^= Z.sideLo; hi ^= Z.sideHi; }
  out[0] = lo; out[1] = hi;
  return out;
}

/** Repli 64→32 bits du Zobrist (suffisant : ~0,001 collision attendue par million de positions). */
export function hash32From(lo, hi) {
  let h = (lo ^ Math.imul(hi, 0x85ebca6b)) | 0;
  h ^= h >>> 15; h = Math.imul(h, 0x2545f491) | 0;
  h ^= h >>> 13;
  return h | 0;
}

export function hash32Position(pos) {
  const t = [0, 0];
  hashPosition(pos, t);
  return hash32From(t[0], t[1]);
}

/* ---------- encodage compact des coups ---------- */
export function encodeMoveSeq(moves) {
  let size = 0;
  for (const m of moves) size += 3 + m.caps.length;
  const a = new Uint8Array(size);
  let i = 0;
  for (const m of moves) {
    a[i++] = m.from; a[i++] = m.to; a[i++] = m.caps.length;
    for (let k = 0; k < m.caps.length; k++) a[i++] = m.caps[k];
  }
  return a;
}

export function decodeMoves(buf) {
  const a = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  const out = [];
  let i = 0;
  while (i + 2 < a.length) {
    const from = a[i], to = a[i + 1], n = a[i + 2];
    i += 3;
    const caps = [];
    for (let k = 0; k < n; k++) caps.push(a[i + k]);
    i += n;
    out.push({ from, to, caps, path: [] });
  }
  return out;
}

export function moveHash(buf) {
  const a = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let h = 2166136261 >>> 0;
  for (let i = 0; i < a.length; i++) { h ^= a[i]; h = Math.imul(h, 16777619) >>> 0; }
  return h >>> 0;
}

/* ==========================================================================
   Rejeu « masques » (aucun générateur de coups) — utilisé par la recherche
   de structure et par l'index. bb = Int32Array(8) :
   0 wmL · 1 wmH · 2 wkL · 3 wkH · 4 bmL · 5 bmH · 6 bkL · 7 bkH
   ========================================================================== */
export function packedInitial() {
  const bb = new Int32Array(8);
  for (let s = 31; s <= 50; s++) setPacked(bb, s, WMAN);
  for (let s = 1; s <= 20; s++) setPacked(bb, s, BMAN);
  return bb;
}
function setPacked(bb, s, t) {
  if (s <= 32) { const b = 1 << (s - 1); bb[t * 2 - 2] |= b; }
  else { const b = 1 << (s - 33); bb[t * 2 - 1] |= b; }
}
function clearPacked(bb, s) {
  if (s <= 32) {
    const nb = ~(1 << (s - 1));
    bb[0] &= nb; bb[2] &= nb; bb[4] &= nb; bb[6] &= nb;
  } else {
    const nb = ~(1 << (s - 33));
    bb[1] &= nb; bb[3] &= nb; bb[5] &= nb; bb[7] &= nb;
  }
}
function packedType(bb, s) {
  if (s <= 32) {
    const b = 1 << (s - 1);
    if (bb[0] & b) return WMAN;
    if (bb[2] & b) return WKING;
    if (bb[4] & b) return BMAN;
    if (bb[6] & b) return BKING;
  } else {
    const b = 1 << (s - 33);
    if (bb[1] & b) return WMAN;
    if (bb[3] & b) return WKING;
    if (bb[5] & b) return BMAN;
    if (bb[7] & b) return BKING;
  }
  return EMPTY;
}

/** Applique un coup encodé sur le paquet de masques. Renvoie le hash mis à jour. */
export function applyPacked(bb, side, from, to, caps, capCount, capOff, hLo, hHi) {
  const t = packedType(bb, from);
  if (t === EMPTY) return null; // incohérence : on signale
  clearPacked(bb, from);
  hLo ^= Z.lo[t * 51 + from]; hHi ^= Z.hi[t * 51 + from];
  for (let k = 0; k < capCount; k++) {
    const cs = caps[capOff + k];
    const ct = packedType(bb, cs);
    if (ct) { hLo ^= Z.lo[ct * 51 + cs]; hHi ^= Z.hi[ct * 51 + cs]; }
    clearPacked(bb, cs);
  }
  let nt = t;
  if (t === WMAN && sqRow[to] === 0) nt = WKING;
  else if (t === BMAN && sqRow[to] === 9) nt = BKING;
  setPacked(bb, to, nt);
  hLo ^= Z.lo[nt * 51 + to]; hHi ^= Z.hi[nt * 51 + to];
  hLo ^= Z.sideLo; hHi ^= Z.sideHi;
  return [hLo | 0, hHi | 0];
}

/* ==========================================================================
   Structures : { wm:[..], wk:[..], bm:[..], bk:[..], empty:[..] }
   ========================================================================== */
export const CELL = { FREE: 0, WMAN: 1, WKING: 2, BMAN: 3, BKING: 4, MUST_EMPTY: 5 };

export function emptyStructure() {
  const cells = new Uint8Array(51); // index 1..50
  return { nom: 'Nouvelle structure', cells };
}

export function structureMasks(cells) {
  const m = { wmL: 0, wmH: 0, wkL: 0, wkH: 0, bmL: 0, bmH: 0, bkL: 0, bkH: 0, emptyL: 0, emptyH: 0, count: 0 };
  for (let s = 1; s <= 50; s++) {
    const c = cells[s];
    if (!c) continue;
    const lo = s <= 32;
    const b = lo ? (1 << (s - 1)) : (1 << (s - 33));
    m.count++;
    switch (c) {
      case CELL.WMAN: if (lo) m.wmL |= b; else m.wmH |= b; break;
      case CELL.WKING: if (lo) m.wkL |= b; else m.wkH |= b; break;
      case CELL.BMAN: if (lo) m.bmL |= b; else m.bmH |= b; break;
      case CELL.BKING: if (lo) m.bkL |= b; else m.bkH |= b; break;
      case CELL.MUST_EMPTY: if (lo) m.emptyL |= b; else m.emptyH |= b; break;
    }
  }
  return m;
}

export function swapColorMasks(m) {
  return {
    wmL: m.bmL, wmH: m.bmH, wkL: m.bkL, wkH: m.bkH,
    bmL: m.wmL, bmH: m.wmH, bkL: m.wkL, bkH: m.wkH,
    emptyL: m.emptyL, emptyH: m.emptyH, count: m.count,
  };
}

/** Test de correspondance ultra-rapide sur le paquet de masques. */
export function packedMatches(bb, m) {
  if ((bb[0] & m.wmL) !== m.wmL) return false;
  if ((bb[1] & m.wmH) !== m.wmH) return false;
  if ((bb[2] & m.wkL) !== m.wkL) return false;
  if ((bb[3] & m.wkH) !== m.wkH) return false;
  if ((bb[4] & m.bmL) !== m.bmL) return false;
  if ((bb[5] & m.bmH) !== m.bmH) return false;
  if ((bb[6] & m.bkL) !== m.bkL) return false;
  if ((bb[7] & m.bkH) !== m.bkH) return false;
  if (m.emptyL || m.emptyH) {
    const eL = m.emptyL, eH = m.emptyH;
    if ((bb[0] & eL) | (bb[2] & eL) | (bb[4] & eL) | (bb[6] & eL)) return false;
    if ((bb[1] & eH) | (bb[3] & eH) | (bb[5] & eH) | (bb[7] & eH)) return false;
  }
  return true;
}

/** Vérification de référence (lente, indépendante des masques) : sert aux tests. */
export function positionMatchesReference(p, cells) {
  for (let s = 1; s <= 50; s++) {
    const want = cells[s];
    if (!want) continue;
    const t = p.pieceAt(s);
    if (want === CELL.MUST_EMPTY) { if (t !== EMPTY) return false; }
    else if (want === CELL.WMAN) { if (t !== WMAN) return false; }
    else if (want === CELL.WKING) { if (t !== WKING) return false; }
    else if (want === CELL.BMAN) { if (t !== BMAN) return false; }
    else if (want === CELL.BKING) { if (t !== BKING) return false; }
  }
  return true;
}

/* ---------- (dé)sérialisation des structures ---------- */
const CH2CELL = {
  B: CELL.WMAN, b: CELL.WMAN, N: CELL.BMAN, n: CELL.BMAN,
  D: CELL.WKING, d: CELL.BKING, E: CELL.MUST_EMPTY, e: CELL.MUST_EMPTY,
  x: CELL.MUST_EMPTY, X: CELL.MUST_EMPTY, '.': CELL.FREE, '-': CELL.FREE, '0': CELL.FREE,
};
const CELL2CH = ['·', 'B', 'D', 'N', 'd', 'E'];

export function structureToJSON(st) {
  const blancs = [], noirs = [], vides = [], damesBlanches = [], damesNoires = [];
  for (let s = 1; s <= 50; s++) {
    switch (st.cells[s]) {
      case CELL.WMAN: blancs.push(s); break;
      case CELL.WKING: damesBlanches.push(s); break;
      case CELL.BMAN: noirs.push(s); break;
      case CELL.BKING: damesNoires.push(s); break;
      case CELL.MUST_EMPTY: vides.push(s); break;
    }
  }
  return {
    format: 'pionicide-structure/1',
    nom: st.nom || 'Structure',
    blancs, noirs, damesBlanches, damesNoires, vides,
  };
}

export function structureToLine(st) {
  let s = '';
  for (let i = 1; i <= 50; i++) s += st.cells[i] === CELL.FREE ? '.' : CELL2CH[st.cells[i]];
  return s;
}

export function parseStructure(obj) {
  const st = emptyStructure();
  if (typeof obj === 'string') {
    const txt = obj.trim();
    if (txt.startsWith('{')) obj = JSON.parse(txt);
    else {
      // chaîne de 50 caractères (on tolère espaces / séparateurs)
      const chars = txt.replace(/[\s,|/]/g, '');
      if (chars.length !== 50) throw new Error('La chaîne doit contenir 50 caractères (reçu ' + chars.length + ')');
      const bad = [];
      for (let i = 0; i < 50; i++) {
        const c = chars[i];
        const cell = CH2CELL[c];
        if (cell === undefined) { bad.push(i + 1 + ':' + c); continue; }
        st.cells[i + 1] = cell;
      }
      if (bad.length) throw new Error('Caractères non reconnus : ' + bad.join(' '));
      st.nom = 'Structure collée';
      return st;
    }
  }
  st.nom = obj.nom || obj.name || 'Structure importée';
  if (obj.cells) {
    const src = obj.cells;
    for (let s = 1; s <= 50; s++) {
      const v = src.length >= 51 ? src[s] : src[s - 1];
      const n = Number(v) || 0;
      st.cells[s] = n >= 0 && n <= 5 ? n : 0;
    }
    return st;
  }
  const put = (arr, cell) => {
    if (!arr) return;
    for (const v of arr) {
      const n = Number(v);
      if (!Number.isInteger(n) || n < 1 || n > 50) throw new Error('Case invalide : ' + v);
      st.cells[n] = cell;
    }
  };
  put(obj.blancs, CELL.WMAN);
  put(obj.damesBlanches, CELL.WKING);
  put(obj.noirs, CELL.BMAN);
  put(obj.damesNoires, CELL.BKING);
  put(obj.vides, CELL.MUST_EMPTY);
  return st;
}

/* ==========================================================================
   Normalisation des noms
   ========================================================================== */
export function stripAccents(s) {
  return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

export function cleanDisplayName(raw) {
  if (!raw) return '';
  let s = stripAccents(String(raw)).replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (s.includes(',')) {
    const parts = s.split(',').map(x => x.trim()).filter(Boolean);
    if (parts.length === 2) s = parts[1] + ' ' + parts[0];
  }
  s = s.replace(/[^A-Za-z0-9 .'-]/g, '').replace(/\s+/g, ' ').trim();
  s = s.toLowerCase().replace(/(^|[\s'.-])([a-z])/g, (_, a, b) => a + b.toUpperCase());
  return s;
}

export function nameKey(raw) {
  let s = stripAccents(String(raw || '')).toLowerCase();
  if (s.includes(',')) {
    const parts = s.split(',').map(x => x.trim()).filter(Boolean);
    if (parts.length === 2) s = parts[1] + ' ' + parts[0];
  }
  s = s.replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!s) return '';
  const tokens = s.split(' ').filter(Boolean);
  tokens.sort();
  return tokens.join(' ');
}

/* ==========================================================================
   Recherche approximative des noms de joueurs
   --------------------------------------------------------------------------
   Les noms sont souvent mal orthographiés dans les fichiers PDN, et personne
   n'écrit exactement « Kooistra » du premier coup. On accepte donc :
     - les accents, la casse et la ponctuation (Tembé = tembe) ;
     - l'ordre prénom / nom (Mbemba Sosthene = Sosthene Mbemba) ;
     - un nom seul quand la base contient le nom complet (Kooistra) ;
     - les fautes de frappe (Koistra, Kooistraa, Kostra) ;
     - les initiales (T. Kooistra).
   Tout est normalisé (ASCII, minuscules) puis comparé par distance d'édition
   plafonnée, mot par mot.
   ========================================================================== */

/** Nombre de fautes tolérées pour un mot de cette longueur. */
export function nameTolerance(length) {
  if (length <= 3) return 0;
  if (length <= 5) return 1;
  if (length <= 10) return 2;
  if (length <= 18) return 3;
  return 4;
}

/** Chaîne de recherche : ASCII, minuscules, espaces simples (ordre conservé). */
export function foldName(raw) {
  return stripAccents(String(raw || ''))
    .toLowerCase()
    .replace(/[^a-z0-9 ]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Distance d'édition plafonnée : au-delà de `max`, on renvoie `max + 1`. */
export function editDistance(a, b, max = Infinity) {
  if (a === b) return 0;
  const la = a.length, lb = b.length;
  if (!la) return lb;
  if (!lb) return la;
  if (Math.abs(la - lb) > max) return max + 1;
  let prev = new Array(lb + 1);
  let cur = new Array(lb + 1);
  for (let j = 0; j <= lb; j++) prev[j] = j;
  for (let i = 1; i <= la; i++) {
    cur[0] = i;
    let rowMin = cur[0];
    for (let j = 1; j <= lb; j++) {
      const cost = a.charCodeAt(i - 1) === b.charCodeAt(j - 1) ? 0 : 1;
      const value = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      cur[j] = value;
      if (value < rowMin) rowMin = value;
    }
    if (rowMin > max) return max + 1;
    const swap = prev; prev = cur; cur = swap;
  }
  return prev[lb];
}

/** Mots de liaison : ils ne portent pas le nom, ils ne comptent presque pas. */
const NAME_STOPWORDS = new Set(['de', 'den', 'der', 'van', 'von', 'jr', 'sr', 'dr', 'mr', 'la', 'le', 'du', 'di', 'da', 'bin', 'el', 'al', 'ul', 't']);

export function isNameStopword(word) {
  return NAME_STOPWORDS.has(String(word || '').toLowerCase());
}

/**
 * Proximité d'un mot **saisi** (`typed`) avec un mot du nom (`token`).
 * 1 = identiques, 0 = rien à voir. La comparaison est asymétrique : une
 * initiale tapée peut désigner un prénom, l'inverse n'est pas vrai.
 */
export function tokenScore(typed, token) {
  if (!typed || !token) return 0;
  if (typed === token) return 1;
  if (isNameStopword(token)) return 0.2; // « de », « van »… ne suffisent jamais
  if (typed.length === 1) return token.startsWith(typed) ? 0.8 : 0; // initiale
  if (token.length === 1) return 0; // le nom contient une initiale, on tape un mot plein
  if (token.startsWith(typed) && typed.length >= 2 && typed.length >= 0.45 * token.length) {
    // abréviation : « kost » → « kooistra »
    return 0.8 + 0.18 * (typed.length / token.length);
  }
  const tolerance = nameTolerance(token.length);
  if (!tolerance) return 0;
  const distance = editDistance(typed, token, tolerance);
  if (distance > tolerance) return 0;
  return Math.max(0.55, 0.95 - 0.11 * distance);
}

/** Note d'un nom saisi face à une clé normalisée (`nameKey`). 1 = exact. */
export function nameMatchScore(query, key) {
  const folded = foldName(query);
  if (!folded || !key) return 0;
  const typedKey = nameKey(query);
  if (!typedKey) return 0;
  if (typedKey === key) return 1;
  const typed = typedKey.split(' ').filter(Boolean);
  const target = String(key).split(' ').filter(Boolean);
  if (!typed.length || !target.length) return 0;
  const best = word => {
    let top = 0;
    for (const token of target) {
      const score = tokenScore(word, token);
      if (score > top) top = score;
    }
    return top;
  };
  let score = 0;
  if (typed.length === 1) {
    // un seul mot tapé : nom de famille, prénom, abréviation ou initiale
    score = Math.min(0.98, best(typed[0]));
  } else {
    let sum = 0;
    for (const word of typed) {
      const wordScore = best(word);
      if (wordScore < 0.55) { sum = -1; break; } // un mot saisi n'est retrouvé nulle part
      sum += wordScore;
    }
    if (sum >= 0) {
      // nom plus long que la saisie : petite marge, on reste au-dessus du seuil
      const extra = Math.max(0, target.length - typed.length);
      score = Math.min(0.97, (sum / typed.length) * (1 - 0.03 * extra));
    }
  }
  // filet de sécurité : la saisie apparaît telle quelle dans le nom
  // (« van der », « kooi ») — utile quand aucun mot ne correspond exactement.
  if (score < NAME_MATCH_THRESHOLD && folded.length >= 3 && target.join(' ').includes(folded)) {
    score = Math.max(score, 0.75);
  }
  return score;
}

/** Seuil commun à la recherche et aux suggestions. */
export const NAME_MATCH_THRESHOLD = 0.7;

/**
 * Classe des joueurs par proximité avec la saisie.
 * @param {string} query
 * @param {Array<{key: string, name: string}>} players
 * @param {{limit?: number, threshold?: number}} [options]
 */
export function rankPlayers(query, players, options = {}) {
  const threshold = options.threshold ?? NAME_MATCH_THRESHOLD;
  const limit = options.limit ?? 50;
  const out = [];
  for (const player of players || []) {
    if (!player || !player.key) continue;
    const score = nameMatchScore(query, player.key);
    if (score >= threshold) out.push({ key: player.key, name: player.name || player.key, score });
  }
  out.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name, 'fr'));
  return out.slice(0, limit);
}

/* ==========================================================================
   Lecture PDN
   ========================================================================== */
const HEADER_RE = /^\[\s*([A-Za-z0-9_:#]+)\s+"?([^"\]]*)"?\s*\]?\s*$/;

export function* pdnGames(text, startOffset = 0) {
  const len = text.length;
  let i = Math.max(0, Math.min(startOffset, len));
  let open = false, headers = null, moves = '', gameStart = i;
  while (i < len) {
    let j = text.indexOf('\n', i);
    if (j < 0) j = len; else j = j + 1;
    const line = text.slice(i, j).trim();
    const hm = line.charCodeAt(0) === 91 ? HEADER_RE.exec(line) : null;
    if (hm) {
      if (open && moves.trim() !== '') {
        yield { headers, moves, start: gameStart, end: i };
        open = false; moves = '';
      }
      if (!open) { open = true; headers = Object.create(null); moves = ''; gameStart = i; }
      headers[hm[1].toLowerCase()] = hm[2].trim();
      i = j; continue;
    }
    if (line === '') {
      if (open && moves.trim() !== '') {
        yield { headers, moves, start: gameStart, end: j };
        open = false; moves = '';
      }
      i = j; continue;
    }
    if (!open) { open = true; headers = Object.create(null); moves = ''; gameStart = i; }
    moves += (moves ? ' ' : '') + line;
    i = j;
  }
  if (open && moves.trim() !== '') yield { headers, moves, start: gameStart, end: len };
}

export const RESULTS = new Set(['2-0', '0-2', '1-1', '1/2-1/2', '0.5-0.5', '½-½', '0-0', '*', '+/-', '1-0', '0-1']);

/** Découpe le texte de coups : ignore commentaires, variantes, numéros, NAG. */
export function tokenizeMoves(s, stats) {
  const toks = [];
  let result = '';
  let i = 0;
  const n = s.length;
  let cur = '';
  const push = (tok) => {
    if (!tok) return;
    let t = tok.replace(/[!?]+$/g, '');
    if (!t) return;
    if (/^\d+\.+$/.test(t) || /^\.+$/.test(t) || /^\d+\.\.\.$/.test(t)) return;
    if (/^\$\d+$/.test(t)) return;
    if (RESULTS.has(t)) { result = t; return; }
    if (/^\d+([x-]\d+)+$/.test(t)) { toks.push(t); return; }
    if (stats) stats.badTokens = (stats.badTokens || 0) + 1;
  };
  while (i < n) {
    const ch = s[i];
    if (ch === '{') {
      let d = 1; i++;
      while (i < n && d > 0) { if (s[i] === '{') d++; else if (s[i] === '}') d--; i++; }
      continue;
    }
    if (ch === '(') { let d = 1; i++; while (i < n && d > 0) { if (s[i] === '(') d++; else if (s[i] === ')') d--; i++; } continue; }
    if (ch === ')') { i++; continue; }
    if (ch === ';') { const nl = s.indexOf('\n', i); i = nl < 0 ? n : nl + 1; continue; }
    if (/\s/.test(ch)) { if (cur) { push(cur); cur = ''; } i++; continue; }
    cur += ch; i++;
  }
  if (cur) push(cur);
  return { tokens: toks, result };
}

/** Résout un coup PDN contre la position (gère rafles et ambiguïtés). */
export function resolveMove(pos, token) {
  const nums = token.split(/[x-]/).map(Number);
  const isCapture = token.includes('x');
  const from = nums[0];
  const to = nums[nums.length - 1];
  if (!(from >= 1 && from <= 50) || !(to >= 1 && to <= 50)) return { move: null, reason: 'case hors damier' };
  const legal = generateMoves(pos);
  let cand = legal.filter(m => m.from === from && (isCapture ? m.caps.length > 0 : m.caps.length === 0) && m.to === to);
  if (cand.length > 1 && isCapture && nums.length > 2) {
    const wanted = nums.slice(1);
    // (a) la notation liste les cases d'arrivée intermédiaires (28x18x8)
    let exact = cand.filter(m => m.path.length === wanted.length && m.path.every((s, k) => s === wanted[k]));
    // (b) la notation liste les pièces prises (28x23x13x8)
    if (!exact.length) {
      const wcap = wanted.slice(0, -1);
      exact = cand.filter(m => m.caps.length === wcap.length && m.caps.every((s, k) => s === wcap[k]));
    }
    if (exact.length) cand = exact;
  }
  if (!cand.length) {
    const loose = legal.filter(m => m.from === from && m.to === to);
    if (loose.length === 1) return { move: loose[0], ambiguous: false, loose: true };
    return { move: null, reason: legal.some(m => m.from === from) ? 'arrivée illégale' : 'départ illégal' };
  }
  return { move: cand[0], ambiguous: cand.length > 1 };
}

/* ---------- construction d'une partie stockable ---------- */
export function buildGame(raw, opts = {}) {
  const stats = {};
  const { tokens, result } = tokenizeMoves(raw.moves || '', stats);
  const h = raw.headers || {};
  const pos = Position.initial();
  const moves = [];
  let error = null;
  let hLo = 0, hHi = 0;
  const tmp = [0, 0];
  hashPosition(pos, tmp);
  hLo = tmp[0]; hHi = tmp[1];
  const maxPly = opts.maxPly || 30;
  const hashTrail = []; // [lo,hi] par demi-coup 1..maxPly
  for (let k = 0; k < tokens.length; k++) {
    const r = resolveMove(pos, tokens[k]);
    if (!r.move) { error = 'coup ' + (k + 1) + ' (' + tokens[k] + ') : ' + r.reason; break; }
    const next = applyMove(pos, r.move);
    // hash incrémental
    const t = pos.pieceAt(r.move.from);
    hLo ^= Z.lo[t * 51 + r.move.from]; hHi ^= Z.hi[t * 51 + r.move.from];
    for (const c of r.move.caps) {
      const ct = pos.pieceAt(c);
      hLo ^= Z.lo[ct * 51 + c]; hHi ^= Z.hi[ct * 51 + c];
    }
    let nt = t;
    if (t === WMAN && sqRow[r.move.to] === 0) nt = WKING;
    else if (t === BMAN && sqRow[r.move.to] === 9) nt = BKING;
    hLo ^= Z.lo[nt * 51 + r.move.to]; hHi ^= Z.hi[nt * 51 + r.move.to];
    hLo ^= Z.sideLo; hHi ^= Z.sideHi;
    moves.push(r.move);
    if (moves.length <= maxPly) hashTrail.push([hLo, hHi]);
    // recopie de l'état
    pos.wmL = next.wmL; pos.wmH = next.wmH; pos.wkL = next.wkL; pos.wkH = next.wkH;
    pos.bmL = next.bmL; pos.bmH = next.bmH; pos.bkL = next.bkL; pos.bkH = next.bkH;
    pos.side = next.side;
  }
  const buf = encodeMoveSeq(moves);
  const resRaw = (h.result || result || '*').trim();
  const res = normalizeResult(resRaw);
  return {
    headers: h,
    moves,
    buf,
    hashTrail,
    ply: moves.length,
    result: res,
    error,
    badTokens: stats.badTokens || 0,
    white: h.white || h.blancs || '',
    black: h.black || h.noirs || '',
    event: h.event || '',
    site: h.site || h.place || '',
    date: h.date || '',
    eloW: pickElo(h, ['whiteelo', 'whiterating', 'elo', 'eloblanc', 'white_elo']),
    eloB: pickElo(h, ['blackelo', 'blackrating', 'eloblack', 'black_elo']),
  };
}

/** Devine pourquoi une partie du fichier n'a pas pu être lue (hors 10×10 ou coups manquants). */
export function classifyPdnFailure(rawMoves) {
  const cleaned = String(rawMoves || '')
    .replace(/\d+\.+/g, ' ').replace(/\$\d+/g, ' ').replace(/\{[^}]*\}/g, ' ').replace(/\([^)]*\)/g, ' ');
  const nums = cleaned.match(/\d+/g) || [];
  let maxSq = 0;
  for (const t of nums) { const v = +t; if (v > maxSq) maxSq = v; }
  if (maxSq > 50) return 'hors damier 10×10 (cases > 50)';
  return 'coups de début manquants / notation non 10×10';
}

function pickElo(h, keys) {
  for (const k of keys) if (h[k]) { const n = parseInt(h[k], 10); if (Number.isFinite(n)) return n; }
  return 0;
}

export function normalizeResult(r) {
  if (!r) return '*';
  const t = r.trim();
  if (t === '2-0' || t === '1-0' || t === '+/-' || t === '1-0 ') return '2-0';
  if (t === '0-2' || t === '0-1' || t === '-/+' || t === '0-1 ') return '0-2';
  if (t === '1-1' || t === '1/2-1/2' || t === '½-½' || t === '0.5-0.5' || t === '0-0') return '1-1';
  return '*';
}

export function normalizeDate(d) {
  if (!d) return { y: 0, m: 0, day: 0, iso: '' };
  const m = /^(\d{4})[.\-/]?(\d{2})?[.\-/]?(\d{2})?/.exec(d.trim());
  if (!m) return { y: 0, m: 0, day: 0, iso: d.trim() };
  const y = +m[1], mo = m[2] ? +m[2] : 0, day = m[3] ? +m[3] : 0;
  const iso = y + (mo ? '-' + String(mo).padStart(2, '0') : '') + (day ? '-' + String(day).padStart(2, '0') : '');
  return { y, m: mo, day, iso };
}

/* ==========================================================================
   Table de hachage ouverte (index d'ouvertures) — tableaux typés
   ========================================================================== */
export class OpenTable {
  constructor(pow = 10) {
    this.mode = 'hash';
    this.cap = 1 << pow;
    this.slots = new Int32Array(this.cap);   // rec+1, 0 = libre
    this.keys = new Int32Array(this.cap);    // hash 32 bits
    this.count = 0;
    this._alloc(2048);
    this.ent = new Int32Array(8192);     // valeur : (gameId << 8) | ply
    this.entNext = new Int32Array(8192); // chaînage : entrée suivante du même enregistrement
    this.entLen = 0;
  }
  _alloc(n) {
    const recN = new Uint32Array(n), recW = new Uint16Array(n),
      recD = new Uint16Array(n), recL = new Uint16Array(n),
      recStart = new Int32Array(n).fill(-1), recLen = new Int32Array(n);
    if (this.recN) {
      const m = Math.min(n, this.recN.length);
      recN.set(this.recN.subarray(0, m)); recW.set(this.recW.subarray(0, m));
      recD.set(this.recD.subarray(0, m)); recL.set(this.recL.subarray(0, m));
      recStart.set(this.recStart.subarray(0, m)); recLen.set(this.recLen.subarray(0, m));
    }
    this.recN = recN; this.recW = recW; this.recD = recD; this.recL = recL;
    this.recStart = recStart; this.recLen = recLen;
  }
  _growTable() {
    const oldSlots = this.slots, oldKeys = this.keys, cap = this.cap;
    this.cap = cap * 2;
    this.slots = new Int32Array(this.cap);
    this.keys = new Int32Array(this.cap);
    const mask = this.cap - 1;
    for (let i = 0; i < cap; i++) {
      const v = oldSlots[i];
      if (!v) continue;
      let j = oldKeys[i] & mask;
      while (this.slots[j]) j = (j + 1) & mask;
      this.slots[j] = v; this.keys[j] = oldKeys[i];
    }
  }
  /** Reconstruit la table ouverte à partir du mode compact (avant ajout de parties). */
  thaw() {
    if (this.mode !== 'sorted') return this;
    const n = this.count;
    const sortedKeys = this.keys;
    let cap = 1024;
    while (cap * 0.6 < (n + 1) * 1.7) cap *= 2;
    const slots = new Int32Array(cap), keys = new Int32Array(cap);
    const mask = cap - 1;
    for (let r = 0; r < n; r++) {
      const k = sortedKeys[r];
      let j = k & mask;
      while (slots[j]) j = (j + 1) & mask;
      slots[j] = r + 1; keys[j] = k;
    }
    this.slots = slots; this.keys = keys; this.cap = cap;
    const recN = new Uint32Array(Math.max(2048, n + 1024));
    for (let i = 0; i < n; i++) recN[i] = this.recLen[i];
    this.recN = recN;
    this.mode = 'hash';
    return this;
  }
  /** Renvoie l'indice d'enregistrement (créé au besoin). */
  record(key) {
    if (this.mode === 'sorted') this.thaw();
    if ((this.count + 1) * 10 >= this.cap * 6) this._growTable();
    const mask = this.cap - 1;
    let j = key & mask;
    while (true) {
      const v = this.slots[j];
      if (!v) {
        const rec = this.count;
        if (rec >= this.recN.length) this._alloc(this.recN.length * 2);
        this.slots[j] = rec + 1;
        this.keys[j] = key;
        this.count++;
        return rec;
      }
      if (this.keys[j] === key) return v - 1;
      j = (j + 1) & mask;
    }
  }
  addEntry(rec, gameId, ply) {
    if (this.entLen >= this.ent.length) {
      const ne = new Int32Array(this.ent.length * 2); ne.set(this.ent); this.ent = ne;
      const nn = new Int32Array(this.entNext.length * 2); nn.set(this.entNext); this.entNext = nn;
    }
    this.entNext[this.entLen] = this.recStart[rec];
    this.ent[this.entLen] = (gameId << 8) | ply;
    this.recStart[rec] = this.entLen;
    this.entLen++;
    this.recLen[rec]++;
    if (this.recN) this.recN[rec]++;
  }
  lookup(key) {
    if (this.mode === 'sorted') {
      let lo = 0, hi = this.count - 1;
      const k = this.keys;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        const v = k[mid];
        if (v === key) return mid;
        if (v < key) lo = mid + 1; else hi = mid - 1;
      }
      return -1;
    }
    const mask = this.cap - 1;
    let j = key & mask;
    while (true) {
      const v = this.slots[j];
      if (!v) return -1;
      if (this.keys[j] === key) return v - 1;
      j = (j + 1) & mask;
    }
  }
  /**
   * Passe en mode compact : clés triées + enregistrements contigus.
   * Supprime la table ouverte (≈ 50 % de mémoire en moins) ; la recherche
   * se fait alors par dichotomie. `thaw()` rétablit le mode ajout.
   */
  compact() {
    if (this.mode === 'sorted') return this;
    const n = this.count;
    const recKey = new Int32Array(n);
    for (let i = 0; i < this.cap; i++) {
      const v = this.slots[i];
      if (v) recKey[v - 1] = this.keys[i];
    }
    const order = new Int32Array(n);
    for (let i = 0; i < n; i++) order[i] = i;
    order.sort((a, b) => recKey[a] - recKey[b]);
    const keys = new Int32Array(n);
    const recW = new Uint16Array(n), recD = new Uint16Array(n), recL = new Uint16Array(n);
    const recStart = new Int32Array(n), recLen = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const o = order[i];
      keys[i] = recKey[o];
      recW[i] = this.recW[o]; recD[i] = this.recD[o]; recL[i] = this.recL[o];
      recStart[i] = this.recStart[o]; recLen[i] = this.recLen[o];
    }
    this.keys = keys;
    this.recW = recW; this.recD = recD; this.recL = recL;
    this.recStart = recStart; this.recLen = recLen;
    this.recN = null;
    this.slots = null;
    this.mode = 'sorted';
    this.cap = 0;
    return this;
  }
  stats(rec) {
    if (rec < 0) return { n: 0, w: 0, d: 0, l: 0 };
    const n = this.recN ? this.recN[rec] : this.recLen[rec];
    return { n, w: this.recW[rec], d: this.recD[rec], l: this.recL[rec] };
  }
  entries(rec, max = 5000) {
    if (rec < 0) return [];
    const out = [];
    let i = this.recStart[rec];
    let guard = 0;
    while (i >= 0 && out.length < max && guard++ < 1e7) {
      const v = this.ent[i];
      out.push({ gameId: v >>> 8, ply: v & 255 });
      i = this.entNext[i];
    }
    return out;
  }
  bytes() {
    if (this.mode === 'sorted') {
      return this.keys.byteLength + this.recW.byteLength + this.recD.byteLength +
        this.recL.byteLength + this.recStart.byteLength + this.recLen.byteLength + this.entLen * 8;
    }
    return this.slots.byteLength + this.keys.byteLength + (this.recN ? this.recN.byteLength : 0) +
      this.recW.byteLength + this.recD.byteLength + this.recL.byteLength +
      this.recStart.byteLength + this.recLen.byteLength + this.entLen * 8;
  }
  toBuffers() {
    return {
      mode: this.mode, cap: this.cap, count: this.count, entLen: this.entLen,
      slots: this.slots ? this.slots.buffer : new ArrayBuffer(0),
      keys: this.keys.buffer,
      recN: this.recN ? this.recN.buffer : new ArrayBuffer(0),
      recW: this.recW.buffer, recD: this.recD.buffer, recL: this.recL.buffer,
      recStart: this.recStart.buffer, recLen: this.recLen.buffer,
      ent: this.ent.buffer.slice(0, this.entLen * 4), entNext: this.entNext.buffer.slice(0, this.entLen * 4),
    };
  }
  static fromBuffers(b) {
    const t = Object.create(OpenTable.prototype);
    t.mode = b.mode || 'hash';
    t.cap = b.cap; t.count = b.count; t.entLen = b.entLen;
    t.slots = b.slots && b.slots.byteLength ? new Int32Array(b.slots) : null;
    t.keys = new Int32Array(b.keys);
    t.recN = b.recN && b.recN.byteLength ? new Uint32Array(b.recN) : null;
    t.recW = new Uint16Array(b.recW);
    t.recD = new Uint16Array(b.recD);
    t.recL = new Uint16Array(b.recL);
    t.recStart = new Int32Array(b.recStart);
    t.recLen = new Int32Array(b.recLen);
    t.ent = new Int32Array(b.ent);
    t.entNext = new Int32Array(b.entNext);
    return t;
  }
}

/** Incrémente les compteurs W/D/L d'un enregistrement selon la position. */
export function bumpResult(table, rec, result, sideToMove) {
  let w, d, l;
  if (result === '2-0') { w = 1; d = 0; l = 0; }
  else if (result === '0-2') { w = 0; d = 0; l = 1; }
  else if (result === '1-1') { w = 0; d = 1; l = 0; }
  else return; // résultat inconnu : seule la fréquence est comptée
  if (sideToMove === BLACK) { const t = w; w = l; l = t; }
  table.recW[rec] += w; table.recD[rec] += d; table.recL[rec] += l;
}

/* ==========================================================================
   Génération de coups pseudo-aléatoires (tests & jeu de démonstration)
   ========================================================================== */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function moveToPdn(m) {
  let s = String(m.from);
  for (const l of (m.path.length ? m.path : [m.to])) {
    s += (m.caps.length ? 'x' : '-') + l;
  }
  return s;
}

export function positionToAscii(p) {
  const chars = [' ', 'o', 'O', 'x', 'X'];
  const rows = [];
  for (let r = 0; r < 10; r++) {
    let line = '';
    for (let c = 0; c < 10; c++) {
      const sq = sqFromRC(r, c);
      line += sq ? (chars[p.pieceAt(sq)] || '?') : '.';
    }
    rows.push(line);
  }
  return rows.join('\n');
}
