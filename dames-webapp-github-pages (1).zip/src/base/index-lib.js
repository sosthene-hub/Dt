/* ==========================================================================
   PIONICIDE · BASE — bibliothèque d'indexation & de recherche (pure)
   Reçoit `Core` (noyau) en paramètre pour rester testable sous Node.
   ========================================================================== */

export function makeLib(Core) {
  const {
    Position, generateMoves, applyMove, hashPosition, hash32From, hash32Position, decodeMoves, moveHash,
    OpenTable, bumpResult, packedInitial, applyPacked, structureMasks, swapColorMasks,
    packedMatches, cleanDisplayName, nameKey, normalizeDate, normalizeResult, buildGame,
    sqRow, Z, CELL, structureToJSON, parseStructure, structureToLine, positionMatchesReference,
  } = Core;

  /* ---------------- table d'alias ---------------- */
  class AliasTable {
    constructor(rows) {
      this.rows = rows || []; // [{from, to}]  (clés normalisées)
      this._map = new Map();
      this.rebuild();
    }
    rebuild() {
      this._map = new Map();
      for (const r of this.rows) if (r && r.from && r.to) this._map.set(r.from, r.to);
    }
    resolve(key) {
      let k = key;
      for (let i = 0; i < 8; i++) {
        const n = this._map.get(k);
        if (!n || n === k) return k;
        k = n;
      }
      return k;
    }
    add(from, to) {
      this.rows.push({ from: nameKey(from), to: nameKey(to) });
      this.rebuild();
    }
    remove(i) { this.rows.splice(i, 1); this.rebuild(); }
  }

  /* ---------------- préparation d'un enregistrement ---------------- */
  function prepareRecord(raw, aliases) {
    const built = buildGame(raw, { maxPly: 30 });
    const whiteDisp = cleanDisplayName(built.white) || 'Inconnu';
    const blackDisp = cleanDisplayName(built.black) || 'Inconnu';
    let wk = nameKey(built.white) || 'inconnu';
    let bk = nameKey(built.black) || 'inconnu';
    if (aliases) { wk = aliases.resolve(wk); bk = aliases.resolve(bk); }
    const d = normalizeDate(built.date);
    const mh = moveHash(built.buf);
    const rec = {
      w: whiteDisp, b: blackDisp, wk, bk,
      ev: built.event || '', si: built.site || '',
      dt: d.iso || '', y: d.y || 0,
      r: built.result, ew: built.eloW || 0, eb: built.eloB || 0,
      pl: built.ply, mv: built.buf, mh,
      dv: dedupeHash(wk, bk, d.iso || built.date || '', mh),
      err: built.error || '',
    };
    return rec;
  }

  function dedupeHash(wk, bk, date, mh) {
    let h = 2166136261 >>> 0;
    const s = wk + '|' + bk + '|' + date;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    h ^= mh; h = Math.imul(h, 16777619) >>> 0;
    return h >>> 0;
  }

  /* ---------------- construction d'index ---------------- */
  class IndexBuilder {
    constructor(table) {
      this.table = table || new OpenTable(12);
    }
    add(rec, gameId) {
      const moves = decodeMoves(rec.mv);
      const bb = packedInitial();
      const tmp = [0, 0];
      const p = Position.initial();
      hashPosition(p, tmp);
      let hLo = tmp[0], hHi = tmp[1];
      const maxPly = Math.min(moves.length, 30);
      // position initiale
      this._bump(hash32From(hLo, hHi), gameId, 0, rec.r);
      for (let k = 0; k < moves.length; k++) {
        const m = moves[k];
        const r2 = applyPacked(bb, k % 2 === 0 ? 0 : 1, m.from, m.to, m.caps, m.caps.length, 0, hLo, hHi);
        if (!r2) break;
        hLo = r2[0]; hHi = r2[1];
        const ply = k + 1;
        if (ply <= maxPly) this._bump(hash32From(hLo, hHi), gameId, ply, rec.r);
      }
    }
    _bump(key, gameId, ply, result) {
      const t = this.table;
      const rec = t.record(key);
      t.addEntry(rec, gameId, ply);
      bumpResult(t, rec, result, ply % 2 === 1 ? 1 : 0); // trait après `ply` demi-coups
    }
    finish() { return this.table; }
  }

  /* ---------------- exploration ---------------- */
  function explorerMoves(position, table) {
    const pos = positionFromCells(position.cells, position.side);
    const legal = generateMoves(pos);
    const out = [];
    for (const m of legal) {
      const next = applyMove(pos, m);
      const rec = table ? table.lookup(hash32Position(next)) : -1;
      const st = rec >= 0 ? table.stats(rec) : { w: 0, d: 0, l: 0, n: 0 };
      out.push({
        from: m.from, to: m.to, caps: m.caps, path: m.path,
        n: st.n, w: st.w, d: st.d, l: st.l, rec,
      });
    }
    out.sort((a, b) => b.n - a.n || a.from - b.from);
    return out;
  }

  function positionFromCells(cells, side) {
    const p = new Position();
    const off = cells.length >= 51 ? 0 : -1;
    for (let s = 1; s <= 50; s++) {
      const t = cells[s + off] || 0;
      if (t) p.setPiece(s, t);
    }
    p.side = side === 1 || side === 'b' ? 1 : 0;
    return p;
  }

  function entriesForHash(table, key, filters) {
    if (!table) return [];
    const rec = table.lookup(key);
    if (rec < 0) return [];
    return table.entries(rec).filter(e => passFilters(e, filters));
  }

  function passFilters(e, f) {
    if (!f) return true;
    if (f.player) {
      if (f.color === 'w' && e.wk !== f.player) return false;
      if (f.color === 'b' && e.bk !== f.player) return false;
      if (!f.color && e.wk !== f.player && e.bk !== f.player) return false;
    }
    if (f.from && e.y && e.y < f.from) return false;
    if (f.to && e.y && e.y > f.to) return false;
    if (f.event) {
      const ev = (e.ev || '').toLowerCase();
      if (ev.indexOf(f.event.toLowerCase()) < 0) return false;
    }
    return true;
  }
  // les entrées de l'index ne portent que (gameId, ply) : le filtrage fin se fait
  // sur les enregistrements complets chargés ensuite.

  /* ---------------- recherche par structure ---------------- */
  function searchStructure(records, structure, opts, onProgress) {
    const st = parseStructure(structure);
    const m1 = structureMasks(st.cells);
    const m2 = swapColorMasks(m1);
    const mirror = !!opts.mirror;
    const maxPly = opts.maxPly || 60;
    const limit = opts.limit || 500;
    const filters = opts.filters || null;
    const results = [];
    let scanned = 0, matched = 0, tested = 0;
    for (const rec of records) {
      scanned++;
      if (filters && !passFilters(rec, filters)) { continue; }
      tested++;
      const plys = matchGame(rec, m1, mirror ? m2 : null, maxPly);
      if (plys.length) {
        matched++;
        if (results.length < limit) {
          results.push({
            id: rec.id, w: rec.w, b: rec.b, dt: rec.dt, ev: rec.ev, r: rec.r,
            ply: rec.pl, plys: plys.slice(0, 4), mir: plys.mir || 0,
          });
        }
      }
      if (onProgress && (scanned & 255) === 0) onProgress({ scanned, matched, tested });
    }
    if (onProgress) onProgress({ scanned, matched, tested, done: true });
    return { results, scanned, matched, tested };
  }

  function matchGame(rec, m1, m2, maxPly) {
    const moves = decodeMoves(rec.mv);
    const bb = packedInitial();
    const p = Position.initial();
    const tmp = [0, 0];
    hashPosition(p, tmp);
    let hLo = tmp[0], hHi = tmp[1];
    const plys = [];
    let mir = 0;
    if (packedMatches(bb, m1)) plys.push(0);
    else if (m2 && packedMatches(bb, m2)) { plys.push(0); mir = 2; }
    const n = Math.min(moves.length, maxPly);
    for (let k = 0; k < n && plys.length < 4; k++) {
      const m = moves[k];
      const r2 = applyPacked(bb, k % 2 === 0 ? 0 : 1, m.from, m.to, m.caps, m.caps.length, 0, hLo, hHi);
      if (!r2) break;
      hLo = r2[0]; hHi = r2[1];
      if (packedMatches(bb, m1)) plys.push(k + 1);
      else if (m2 && packedMatches(bb, m2)) { plys.push(k + 1); mir = 2; }
    }
    if (plys.length) plys.mir = mir;
    return plys;
  }

  /* ---------------- génération de PDN de test ---------------- */
  function randomGame(rng, opts) {
    const pos = Position.initial();
    const maxPly = opts.maxPly || 70;
    const out = [];
    let cur = pos;
    for (let k = 0; k < maxPly; k++) {
      const ms = generateMoves(cur);
      if (!ms.length) break;
      const m = ms[Math.floor(rng() * ms.length)];
      out.push(Core.moveToPdn(m));
      cur = applyMove(cur, m);
    }
    return out;
  }

  return {
    AliasTable, prepareRecord, dedupeHash, IndexBuilder, explorerMoves, positionFromCells,
    entriesForHash, passFilters, searchStructure, matchGame, randomGame,
  };
}
