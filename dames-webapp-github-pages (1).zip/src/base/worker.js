/* PIONICIDE · BASE — Web Worker (module Vite).
   Import PDN fichier par fichier, index d'ouvertures Zobrist, recherche par structure.
   Aucune dépendance au moteur Scan : le worker ne charge que le noyau de la base. */
import * as Core from './core.js';
import { makeLib } from './index-lib.js';

const Lib = makeLib(Core);
const DB_NAME = 'pionicide-base';
const DB_VERSION = 1;
const INDEX_PLY_MAX_DEFAULT = 30;
const CHUNK = 4 * 1024 * 1024;

let db = null;
let table = null;
let builder = null;
let indexPly = INDEX_PLY_MAX_DEFAULT;
let indexDirty = false;
let dvSet = new Set();
let playerSet = new Set();
let playerLabels = new Map(); // clé normalisée -> nom affiché

function notePlayer(key, label) {
  if (!key) return;
  playerSet.add(key);
  if (!playerLabels.has(key)) playerLabels.set(key, label || key);
}

function playerList() {
  const out = [];
  for (const key of playerSet) out.push({ key, name: playerLabels.get(key) || key });
  return out;
}

/**
 * Traduit un filtre joueur saisi à la main en ensemble de clés proches.
 * Une faute de frappe, un accent oublié, un nom seul ou des initiales
 * doivent quand même trouver le joueur.
 */
/* Filtres de recherche : joueur des Blancs, joueur des Noirs, année (facultative).
   Les deux noms passent par la même recherche approximative que le filtre simple. */
function resolveSearchFilters(raw) {
  const source = raw || {};
  const out = {};
  const notes = { whiteMatches: [], blackMatches: [], whiteCount: 0, blackCount: 0 };
  const pick = query => {
    const text = String(query || '').trim();
    if (!text) return null;
    const ranked = Core.rankPlayers(text, playerList(), { limit: 200 });
    const top = ranked.length ? ranked[0].score : 0;
    const kept = ranked.filter(row => row.score >= Math.max(Core.NAME_MATCH_THRESHOLD, top - 0.1));
    return {
      set: new Set(kept.map(row => row.key)),
      matches: kept.slice(0, 8).map(row => ({ key: row.key, name: row.name, score: Math.round(row.score * 100) / 100 })),
      count: kept.length,
      query: text,
    };
  };
  const white = pick(source.whiteQuery);
  const black = pick(source.blackQuery);
  if (white) { out.whitePlayers = white.set; notes.whiteMatches = white.matches; notes.whiteCount = white.count; }
  if (black) { out.blackPlayers = black.set; notes.blackMatches = black.matches; notes.blackCount = black.count; }
  const from = Number(source.yearFrom) || 0;
  const to = Number(source.yearTo) || 0;
  if (from) out.from = from;
  if (to) out.to = to;
  if (!from && !to && source.playerQuery) {
    // compatibilité : ancien filtre « un joueur, une couleur »
    const legacy = resolvePlayerFilters({ playerQuery: source.playerQuery, color: source.color });
    if (legacy.filters?.players) out.players = legacy.filters.players;
    if (source.color) out.color = source.color;
    notes.playerMatches = legacy.matches;
    notes.playerCount = legacy.matchedCount || 0;
  } else if (source.color && (white || black)) {
    out.color = source.color;
  }
  return { filters: out, notes };
}

function resolvePlayerFilters(rawFilters) {
  if (!rawFilters) return { filters: null, matches: [] };
  const filters = { ...rawFilters };
  const query = String(filters.playerQuery || filters.player || '').trim();
  delete filters.playerQuery;
  delete filters.player;
  if (!query) return { filters, matches: [] };
  const ranked = Core.rankPlayers(query, playerList(), { limit: 200 });
  const top = ranked.length ? ranked[0].score : 0;
  const kept = ranked.filter(r => r.score >= Math.max(Core.NAME_MATCH_THRESHOLD, top - 0.1));
  filters.players = new Set(kept.map(r => r.key));
  return {
    filters,
    matches: kept.slice(0, 12).map(r => ({ key: r.key, name: r.name, score: Math.round(r.score * 100) / 100 })),
    matchedCount: kept.length,
  };
}
let aliasRows = [];
let aliases = new Lib.AliasTable([]);
let job = null;              // import en cours
let paused = false;
let cancelled = false;
let statsCache = null;

/* ------------------------------- utilitaires IDB ------------------------------- */
function openDB() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in self)) { reject(new Error('IndexedDB indisponible')); return; }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains('games')) {
        const g = d.createObjectStore('games', { keyPath: 'id', autoIncrement: true });
        g.createIndex('wk', 'wk'); g.createIndex('bk', 'bk');
        g.createIndex('y', 'y'); g.createIndex('ev', 'ev'); g.createIndex('dv', 'dv');
      }
      if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'k' });
      if (!d.objectStoreNames.contains('open')) d.createObjectStore('open', { keyPath: 'k' });
      if (!d.objectStoreNames.contains('files')) d.createObjectStore('files', { keyPath: 'name' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function store(name, mode) {
  const t = db.transaction(name, mode);
  return { s: t.objectStore(name), t };
}
function reqP(req) {
  return new Promise((res, rej) => { req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); });
}
function txDone(t) {
  return new Promise((res, rej) => { t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
}
async function metaGet(k) { const { s, t } = store('meta', 'readonly'); const v = await reqP(s.get(k)); await txDone(t); return v ? v.v : undefined; }
async function metaSet(k, v) { const { s, t } = store('meta', 'readwrite'); s.put({ k, v }); await txDone(t); }
async function jobGet(name) { const { s, t } = store('files', 'readonly'); const v = await reqP(s.get(name)); await txDone(t); return v; }
async function jobPut(j) { const { s, t } = store('files', 'readwrite'); s.put(j); await txDone(t); }
async function jobAll() { const { s, t } = store('files', 'readonly'); const v = await reqP(s.getAll()); await txDone(t); return v || []; }
async function jobDel(name) { const { s, t } = store('files', 'readwrite'); s.delete(name); await txDone(t); }

/* ------------------------------- démarrage ------------------------------- */
async function init() {
  const stored = await metaGet('aliases');
  if (Array.isArray(stored)) { aliasRows = stored; aliases = new Lib.AliasTable(stored); }
  indexPly = (await metaGet('indexPly')) || INDEX_PLY_MAX_DEFAULT;
  table = await loadIndex();
  builder = table ? new Lib.IndexBuilder(table) : null;
  dvSet = new Set();
  playerSet = new Set();
  await new Promise((resolve, reject) => {
    const { s, t } = store('games', 'readonly');
    const rq = s.openCursor();
    rq.onsuccess = () => {
      const c = rq.result;
      if (!c) return;
      const g = c.value;
      dvSet.add(g.dv);
      notePlayer(g.wk, g.w); notePlayer(g.bk, g.b);
      c.continue();
    };
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
  statsCache = null;
  return {
    games: dvSet.size,
    players: playerSet.size,
    index: table ? { records: table.count, entries: table.entLen, bytes: table.bytes(), ply: indexPly } : null,
    pendingJobs: (await jobAll()).filter(j => !j.done),
    aliases: aliasRows,
  };
}

async function loadIndex() {
  const { s, t } = store('open', 'readonly');
  const rec = await reqP(s.get('index'));
  await txDone(t);
  if (!rec) return null;
  try {
    indexPly = rec.ply || INDEX_PLY_MAX_DEFAULT;
    return Core.OpenTable.fromBuffers(rec.data);
  } catch (e) { return null; }
}

let saveTimer = null;
function scheduleSaveIndex(force) {
  indexDirty = true;
  if (saveTimer && !force) return;
  saveTimer = setTimeout(() => { saveTimer = null; saveIndex(); }, 1500);
}
async function saveIndex() {
  if (!table) return;
  indexDirty = false;
  const { s, t } = store('open', 'readwrite');
  s.put({ k: 'index', ply: indexPly, data: table.toBuffers() });
  await txDone(t);
  statsCache = null;
}

/* ------------------------------- import ------------------------------- */
function safeUtf8Length(u8) {
  // recule de 1 à 3 octets si la fin coupe une séquence UTF-8
  let n = u8.length;
  if (n === 0) return 0;
  let i = n - 1, back = 0;
  while (i >= 0 && back < 3 && (u8[i] & 0xC0) === 0x80) { i--; back++; }
  if (i >= 0) {
    const b = u8[i];
    let need = 0;
    if ((b & 0x80) === 0) need = 1;
    else if ((b & 0xE0) === 0xC0) need = 2;
    else if ((b & 0xF0) === 0xE0) need = 3;
    else if ((b & 0xF8) === 0xF0) need = 4;
    else return n;
    if (i + need > n) return i; // séquence incomplète → on recule
  }
  return n;
}

function makeStats() {
  return { imported: 0, dupes: 0, skipped: 0, partial: 0, reasons: {}, bytes: 0, games: 0 };
}

async function insertBatch(recs) {
  const ids = [];
  const { s, t } = store('games', 'readwrite');
  for (const r of recs) {
    const req = s.add(r);
    req.onsuccess = () => { r.id = req.result; ids.push(req.result); };
  }
  await txDone(t);
  for (const r of recs) {
    if (!r.id) continue;
    if (!builder) { table = table || new Core.OpenTable(12); builder = new Lib.IndexBuilder(table); }
    builder.add(r, r.id);
    dvSet.add(r.dv);
    notePlayer(r.wk, r.w); notePlayer(r.bk, r.b);
  }
  scheduleSaveIndex(false);
}

async function importFiles(files, opts) {
  opts = opts || {};
  job = { total: files.length, index: 0, name: '', done: 0, stats: makeStats(), startedAt: Date.now() };
  paused = false; cancelled = false;
  if (!builder) { table = table || new Core.OpenTable(12); builder = new Lib.IndexBuilder(table); }
  const allStats = makeStats();
  for (let fi = 0; fi < files.length; fi++) {
    if (cancelled) break;
    job.index = fi;
    const f = files[fi];
    await importOneFile(f, opts, allStats);
  }
  if (builder) table = builder.finish().compact();
  await saveIndex();
  await metaSet('players', playerSet.size);
  await metaSet('gamesCount', dvSet.size);
  statsCache = null;
  job.done = 1;
  post({ type: 'importDone', stats: allStats, games: dvSet.size, players: playerSet.size, indexBytes: table ? table.bytes() : 0, indexPly });
  return { stats: allStats, games: dvSet.size, players: playerSet.size };
}

async function importOneFile(file, opts, allStats) {
  const prev = await jobGet(file.name);
  let offset = 0, carry = '';
  if (prev && prev.size === file.size && opts.resume !== false && prev.offset > 0 && !prev.done) {
    offset = prev.offset; carry = prev.carry || '';
    post({ type: 'notice', text: `Reprise de « ${file.name} » à l’octet ${offset.toLocaleString('fr-FR')}.` });
  } else if (prev) {
    await jobDel(file.name);
  }
  const st = { imported: 0, dupes: 0, skipped: 0, partial: 0, reasons: {}, bytes: 0, games: 0 };
  job.file = { name: file.name, size: file.size };
  let batch = [];
  let lastReport = Date.now();
  let lastCheckpoint = Date.now();

  const pull = async () => {
    if (offset >= file.size) return false;
    const buf = await file.slice(offset, Math.min(offset + CHUNK, file.size)).arrayBuffer();
    const u8 = new Uint8Array(buf);
    const safe = offset + u8.length < file.size ? safeUtf8Length(u8) : u8.length;
    offset += safe;
    carry += new TextDecoder('utf-8').decode(safe === u8.length ? u8 : u8.subarray(0, safe));
    st.bytes += safe;
    allStats.bytes += safe;
    return true;
  };

  const flush = async () => {
    if (!batch.length) return;
    await insertBatch(batch);
    batch = [];
    const now = Date.now();
    if (now - lastReport > 150) {
      lastReport = now;
      post({ type: 'importProgress', name: file.name, fileIndex: job.index, files: job.total, bytes: st.bytes, size: file.size, games: st.games, imported: st.imported + allStats.imported, dupes: st.dupes + allStats.dupes, skipped: st.skipped + allStats.skipped, ms: now - job.startedAt });
    }
  };

  while (true) {
    if (cancelled) break;
    if (paused) {
      await flush();
      await jobPut({ name: file.name, size: file.size, offset, carry, done: false });
      post({ type: 'paused', name: file.name, offset, imported: st.imported });
      while (paused && !cancelled) await new Promise(r => setTimeout(r, 120));
      post({ type: 'resumed' });
    }
    let cut = carry.lastIndexOf('\n\n');
    if (cut < 0 && carry.length > 8 * 1024 * 1024) cut = carry.length; // garde-fou : fichier sans ligne vide
    if (cut < 0) {
      if (!(await pull())) {
        // fin de fichier : traiter le reliquat
        if (!carry.trim()) break;
        await processText(carry, st, batch);
        if (batch.length >= 400) await flush();
        carry = '';
        break;
      }
      continue;
    }
    const part = carry.slice(0, cut);
    carry = carry.slice(cut + 2);
    await processText(part, st, batch);
    if (batch.length >= 400) await flush();
    if (Date.now() - lastCheckpoint > 1500) {
      lastCheckpoint = Date.now();
      await flush();
      await jobPut({ name: file.name, size: file.size, offset, carry, done: false });
    }
  }
  await flush();
  await jobPut({ name: file.name, size: file.size, offset, carry: '', done: cancelled ? false : true });
  allStats.imported += st.imported; allStats.dupes += st.dupes;
  allStats.skipped += st.skipped; allStats.partial += st.partial;
  allStats.games += st.games;
  for (const k in st.reasons) allStats.reasons[k] = (allStats.reasons[k] || 0) + st.reasons[k];
  post({ type: 'fileDone', name: file.name, st });
}

async function processText(text, st, batch) {
  for (const raw of Core.pdnGames(text)) {
    st.games++;
    let rec;
    try {
      rec = Lib.prepareRecord(raw, aliases);
    } catch (e) {
      st.skipped++;
      const k = 'erreur de lecture';
      st.reasons[k] = (st.reasons[k] || 0) + 1;
      continue;
    }
    if (!rec.pl) {
      st.skipped++;
      const k = rec.err ? Core.classifyPdnFailure(raw.moves) : 'partie vide';
      st.reasons[k] = (st.reasons[k] || 0) + 1;
      continue;
    }
    if (dvSet.has(rec.dv)) {
      st.dupes++;
      continue;
    }
    if (rec.err) {
      st.partial++;
      const k = 'tronquée (coup illégal)';
      st.reasons[k] = (st.reasons[k] || 0) + 1;
    }
    dvSet.add(rec.dv);
    st.imported++;
    batch.push(rec);
  }
}

/* ------------------------------- recherche ------------------------------- */
async function* gameCursor() {
  let lastId = 0;
  while (true) {
    const st2 = store('games', 'readonly');
    const range = IDBKeyRange.lowerBound(lastId, true);
    const batch = await reqP(st2.s.getAll(range, 600));
    await txDone(st2.t);
    if (!batch.length) return;
    for (const g of batch) yield g;
    lastId = batch[batch.length - 1].id;
  }
}

async function searchStructure(payload) {
  const st = Core.parseStructure(payload.structure);
  const masks = Core.structureMasks(st.cells);
  const mirror = Core.swapColorMasks(masks);
  const opts = payload.opts || {};
  const rawFilters = opts.filters || {};
  const pair = resolveSearchFilters(rawFilters);
  const filters = pair.filters;
  const maxPly = opts.maxPly || 60;
  const limit = opts.limit || 300;
  const useMirror = !!opts.mirror;
  const results = [];
  let scanned = 0, matched = 0, tested = 0;
  const t0 = Date.now();
  for await (const rec of gameCursor()) {
    scanned++;
    if (filters && !Lib.passFilters(rec, filters)) continue;
    tested++;
    const plys = Lib.matchGame(rec, masks, useMirror ? mirror : null, maxPly);
    if (plys.length) {
      matched++;
      if (results.length < limit) {
        results.push({ id: rec.id, w: rec.w, b: rec.b, dt: rec.dt, ev: rec.ev, r: rec.r, ply: rec.pl, plys: plys.slice(0, 4), mir: plys.mir || 0 });
      }
    }
    if ((scanned & 511) === 0) {
      post({ type: 'searchProgress', scanned, matched, total: dvSet.size, ms: Date.now() - t0 });
      await new Promise(r => setTimeout(r, 0));
    }
  }
  post({ type: 'searchProgress', scanned, matched, total: dvSet.size, ms: Date.now() - t0, done: true });
  return {
    results, scanned, matched, tested, ms: Date.now() - t0,
    players: pair.notes.playerMatches || [],
    playerCount: pair.notes.playerCount || 0,
    whiteMatches: pair.notes.whiteMatches, blackMatches: pair.notes.blackMatches,
    whiteCount: pair.notes.whiteCount, blackCount: pair.notes.blackCount,
  };
}

/* Recherche « joueur contre joueur » : sans structure, on parcourt les parties.
   L'année est facultative ; si elle est absente, rien n'est filtré à ce titre. */
async function searchGames(payload) {
  const pair = resolveSearchFilters(payload.filters || {});
  const filters = pair.filters;
  const hasConstraint = Object.keys(filters).length > 0;
  if (!hasConstraint) return { results: [], scanned: 0, matched: 0, ms: 0, empty: true };
  const limit = payload.limit || 300;
  const t0 = Date.now();
  const results = [];
  let scanned = 0, matched = 0;
  for await (const rec of gameCursor()) {
    scanned++;
    if (!Lib.passFilters(rec, filters)) continue;
    matched++;
    if (results.length < limit) {
      results.push({ id: rec.id, w: rec.w, b: rec.b, dt: rec.dt, ev: rec.ev, r: rec.r, ply: 0, pl: rec.pl || 0, plys: [], mir: 0 });
    }
    if ((scanned & 511) === 0) {
      post({ type: 'searchProgress', scanned, matched, total: dvSet.size, ms: Date.now() - t0 });
      await new Promise(resolve => setTimeout(resolve, 0));
    }
  }
  post({ type: 'searchProgress', scanned, matched, total: dvSet.size, ms: Date.now() - t0, done: true });
  return {
    results: results.sort((a, b) => (a.dt < b.dt ? 1 : -1)),
    scanned, matched, ms: Date.now() - t0,
    whiteMatches: pair.notes.whiteMatches, blackMatches: pair.notes.blackMatches,
    whiteCount: pair.notes.whiteCount, blackCount: pair.notes.blackCount,
  };
}

async function explorerMoves(payload) {
  if (!table) return { moves: [], total: 0 };
  const moves = Lib.explorerMoves({ cells: payload.cells, side: payload.side }, table);
  let total = 0;
  for (const m of moves) total += m.n;
  return { moves: moves.map(m => ({ from: m.from, to: m.to, caps: m.caps, path: m.path, n: m.n, w: m.w, d: m.d, l: m.l })), total };
}

async function positionGames(payload) {
  const key = payload.key;
  const resolved = resolvePlayerFilters(payload.filters);
  const rec = table ? table.lookup(key) : -1;
  if (rec < 0) return { rows: [], total: 0 };
  const entries = table.entries(rec, 4000);
  const ids = [...new Set(entries.map(e => e.gameId))];
  const plyOf = new Map();
  for (const e of entries) if (!plyOf.has(e.gameId)) plyOf.set(e.gameId, e.ply);
  const rows = [];
  for (let i = 0; i < ids.length; i += 400) {
    const slice = ids.slice(i, i + 400);
    const { s, t } = store('games', 'readonly');
    const raw = await Promise.all(slice.map(id => reqP(s.get(id))));
    await txDone(t);
    const games = raw.filter(Boolean);
    for (const g of games) if (Lib.passFilters(g, resolved.filters)) rows.push({ id: g.id, w: g.w, b: g.b, dt: g.dt, ev: g.ev, r: g.r, ply: g.pl, at: plyOf.get(g.id) || 0 });
  }
  rows.sort((a, b) => (a.dt < b.dt ? 1 : -1));
  return { rows: rows.slice(0, payload.limit || 300), total: rows.length, indexTotal: entries.length, players: resolved.matches, playerCount: resolved.matchedCount || 0 };
}

async function getGame(payload) {
  const { s, t } = store('games', 'readonly');
  const g = await reqP(s.get(payload.id));
  await txDone(t);
  if (!g) return null;
  const moves = Core.decodeMoves(g.mv).map(Core.moveToPdn);
  return { id: g.id, w: g.w, b: g.b, dt: g.dt, ev: g.ev, si: g.si, r: g.r, ew: g.ew, eb: g.eb, moves, mv: g.mv };
}

/* ------------------------------- export / import de la base ------------------------------- */
const MAGIC = 'PBASE1\n';

async function exportBase() {
  const games = [];
  let payloadBytes = 0;
  for await (const g of gameCursor()) {
    games.push({ w: g.w, b: g.b, wk: g.wk, bk: g.bk, ev: g.ev, si: g.si, dt: g.dt, y: g.y, r: g.r, ew: g.ew, eb: g.eb, pl: g.pl, mh: g.mh, dv: g.dv, len: g.mv.length });
    payloadBytes += g.mv.length;
  }
  const header = {
    format: 'pionicide-base/1', created: new Date().toISOString(),
    games, aliases: aliasRows, indexPly, players: playerSet.size,
  };
  const hJson = new TextEncoder().encode(JSON.stringify(header));
  const parts = [];
  const head = new Uint8Array(8 + 4);
  head.set(new TextEncoder().encode(MAGIC), 0);
  new DataView(head.buffer).setUint32(8, hJson.length, true);
  parts.push(head, hJson);
  // coups
  let chunk = [];
  let chunkBytes = 0;
  const FLUSH = 4 * 1024 * 1024;
  for await (const g of gameCursor()) {
    chunk.push(g.mv); chunkBytes += g.mv.length;
    if (chunkBytes >= FLUSH) { parts.push(new Blob(chunk)); chunk = []; chunkBytes = 0; }
  }
  if (chunk.length) parts.push(new Blob(chunk));
  const blob = new Blob(parts, { type: 'application/octet-stream' });
  post({ type: 'exportReady', size: blob.size, count: games.length });
  return { blob, size: blob.size, count: games.length };
}

async function importBase(file) {
  const buf = await file.arrayBuffer();
  const u8 = new Uint8Array(buf);
  const magic = new TextDecoder().decode(u8.subarray(0, 7));
  if (magic !== 'PBASE1\n') throw new Error('Fichier de base non reconnu');
  const hLen = new DataView(u8.buffer).getUint32(8, true);
  const header = JSON.parse(new TextDecoder().decode(u8.subarray(12, 12 + hLen)));
  let p = 12 + hLen;
  const games = header.games || [];
  aliasRows = header.aliases || [];
  aliases = new Lib.AliasTable(aliasRows);
  await metaSet('aliases', aliasRows);
  const added = [];
  const newDv = new Set();
  let off = p;
  let i = 0, batch = [];
  const t0 = Date.now();
  for (const g of games) {
    const mv = new Uint8Array(buf, off, g.len);
    off += g.len;
    if (dvSet.has(g.dv) || newDv.has(g.dv)) { i++; continue; }
    newDv.add(g.dv);
    batch.push({ w: g.w, b: g.b, wk: g.wk, bk: g.bk, ev: g.ev, si: g.si, dt: g.dt, y: g.y, r: g.r, ew: g.ew, eb: g.eb, pl: g.pl, mh: g.mh, dv: g.dv, mv: mv.slice() });
    if (batch.length >= 500) { await insertBatch(batch); batch = []; }
    if ((i++ & 1023) === 0) post({ type: 'importProgress', name: 'base', bytes: off, size: buf.byteLength, games: i, imported: i, dupes: 0, skipped: 0, ms: Date.now() - t0 });
  }
  if (batch.length) await insertBatch(batch);
  p = off;
  if (newDv.size) await rebuildIndex({ ply: header.indexPly || indexPly });
  await saveIndex();
  await metaSet('gamesCount', dvSet.size);
  statsCache = null;
  return { added: newDv.size, games: dvSet.size, players: playerSet.size };
}

/* ------------------------------- index ------------------------------- */
async function rebuildIndex(payload) {
  const ply = (payload && payload.ply) || INDEX_PLY_MAX_DEFAULT;
  indexPly = ply;
  await metaSet('indexPly', ply);
  const t = new Core.OpenTable(12);
  const b2 = new Lib.IndexBuilder(t);
  let n = 0;
  const t0 = Date.now();
  for await (const g of gameCursor()) {
    b2.add(g, g.id);
    n++;
    if ((n & 511) === 0) { post({ type: 'indexProgress', n, total: dvSet.size, ms: Date.now() - t0 }); await new Promise(r => setTimeout(r, 0)); }
  }
  table = b2.finish().compact();
  builder = new Lib.IndexBuilder(table);
  await saveIndex();
  post({ type: 'indexDone', n, records: table.count, entries: table.entLen, bytes: table.bytes(), ms: Date.now() - t0 });
  return { n, records: table.count, entries: table.entLen, bytes: table.bytes(), ms: Date.now() - t0 };
}

/* ------------------------------- alias ------------------------------- */
async function aliasAdd(payload) {
  aliasRows.push({ from: Core.nameKey(payload.from), to: Core.nameKey(payload.to), fromLabel: payload.from, toLabel: payload.to });
  aliases = new Lib.AliasTable(aliasRows);
  await metaSet('aliases', aliasRows);
  return aliasRows;
}
async function aliasRemove(payload) {
  aliasRows.splice(payload.i, 1);
  aliases = new Lib.AliasTable(aliasRows);
  await metaSet('aliases', aliasRows);
  return aliasRows;
}
async function aliasApply() {
  // réécrit les clés joueurs de toute la base
  let n = 0;
  const { s, t } = store('games', 'readwrite');
  const rq = s.openCursor();
  playerSet = new Set();
  playerLabels = new Map();
  rq.onsuccess = () => {
    const c = rq.result;
    if (!c) return;
    const g = c.value;
    const wk = aliases.resolve(g.wk), bk = aliases.resolve(g.bk);
    if (wk !== g.wk || bk !== g.bk) { g.wk = wk; g.bk = bk; c.update(g); }
    notePlayer(wk, g.w); notePlayer(bk, g.b);
    n++;
    if ((n & 2047) === 0) post({ type: 'notice', text: `Alias : ${n} parties examinées…` });
    c.continue();
  };
  await txDone(t);
  return { n, players: playerSet.size };
}

async function listPlayers(payload) {
  const query = String(payload.q || '').trim();
  const limit = payload.limit || 200;
  if (playerSet.size && playerLabels.size >= playerSet.size) {
    // registre déjà complet : pas besoin de relire la base
    if (!query) {
      const all = playerList().sort((a, b) => a.name.localeCompare(b.name, 'fr'));
      return all.slice(0, limit);
    }
    return Core.rankPlayers(query, playerList(), { limit });
  }
  const out = [];
  const { s, t } = store('games', 'readonly');
  const rq = s.openCursor();
  const seen = new Map();
  rq.onsuccess = () => {
    const c = rq.result; if (!c) return;
    const g = c.value;
    for (const [k, name] of [[g.wk, g.w], [g.bk, g.b]]) {
      if (!k) continue;
      if (!seen.has(k)) { seen.set(k, name); out.push({ key: k, name }); }
    }
    if (out.length > 6000) return;
    c.continue();
  };
  await txDone(t);
  for (const player of out) notePlayer(player.key, player.name);
  if (!query) {
    out.sort((a, b) => a.name.localeCompare(b.name, 'fr'));
    return out.slice(0, limit);
  }
  return Core.rankPlayers(query, out, { limit });
}

async function listEvents() {
  const out = new Set();
  const { s, t } = store('games', 'readonly');
  const rq = s.openCursor();
  rq.onsuccess = () => {
    const c = rq.result; if (!c) return;
    if (c.value.ev) out.add(c.value.ev);
    c.continue();
  };
  await txDone(t);
  return [...out].sort();
}

async function dbStats() {
  const count = dvSet.size;
  let bytes = 0;
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const e = await navigator.storage.estimate();
      bytes = e.usage || 0;
    }
  } catch (e) {}
  return {
    games: count, players: playerSet.size,
    index: table ? { records: table.count, entries: table.entLen, bytes: table.bytes(), ply: indexPly } : null,
    usage: bytes, jobs: (await jobAll()).filter(j => !j.done),
  };
}

async function clearBase() {
  const { s, t } = store('games', 'readwrite'); s.clear(); await txDone(t);
  const t2 = store('open', 'readwrite'); t2.s.clear(); await txDone(t2.t);
  const t3 = store('files', 'readwrite'); t3.s.clear(); await txDone(t3.t);
  dvSet = new Set(); playerSet = new Set(); playerLabels = new Map(); table = null; builder = null; statsCache = null;
  return true;
}

/* ------------------------------- dédoublonnage a posteriori ------------------------------- */
async function scanDuplicates() {
  const seen = new Map();
  let dupes = 0;
  for await (const g of gameCursor()) {
    const k = g.dv;
    if (seen.has(k)) dupes++; else seen.set(k, g.id);
  }
  return { dupes, games: seen.size };
}

/* ------------------------------- RPC ------------------------------- */
function post(msg) { self.postMessage(msg); }

const HANDLERS = {
  init: () => init(),
  stats: () => dbStats(),
  importFiles: (p) => importFiles(p.files, p.opts),
  pause: () => { paused = true; return true; },
  resume: () => { paused = false; return true; },
  cancel: () => { cancelled = true; paused = false; return true; },
  searchStructure: (p) => searchStructure(p),
  searchGames: (p) => searchGames(p),
  explorerMoves: (p) => explorerMoves(p),
  positionGames: (p) => positionGames(p),
  getGame: (p) => getGame(p),
  exportBase: () => exportBase(),
  importBase: (p) => importBase(p.file),
  rebuildIndex: (p) => rebuildIndex(p),
  aliasAdd: (p) => aliasAdd(p),
  aliasRemove: (p) => aliasRemove(p),
  aliasApply: () => aliasApply(),
  listPlayers: (p) => listPlayers(p),
  listEvents: () => listEvents(),
  clearBase: () => clearBase(),
  scanDuplicates: () => scanDuplicates(),
};

self.onmessage = async (ev) => {
  const msg = ev.data;
  if (!msg || !msg.type) return;
  const id = msg.id;
  const h = HANDLERS[msg.type];
  if (!h) { post({ id, ok: false, error: 'action inconnue : ' + msg.type }); return; }
  try {
    if (!db) db = await openDB();
    const result = await h(msg.payload || {});
    post({ id, ok: true, result });
  } catch (e) {
    post({ id, ok: false, error: (e && e.message) || String(e) });
  }
};
