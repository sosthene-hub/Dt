/* PIONICIDE · Base de parties — page intégrée.
   Explorateur d'ouvertures, recherche par structure, import PDN massif.
   Le moteur Scan n'est pas modifié : cette page ne parle qu'à son propre worker. */
import './base.css';
import { renderBoard } from '../board-view.js';
import { openGameSheet, positionCaption } from '../analysis/print-sheet.js';
import { store } from '../store.js';
import {
  Position, generateMoves, applyMove, hash32Position, decodeMoves,
  parseStructure, structureToJSON, structureToLine, CELL, nameKey,
} from './core.js';

const LS_STRUCTURES = 'pionicide-structures-v1';
const MARK_CLASS = ['', 'pb-mk-wm', 'pb-mk-wk', 'pb-mk-bm', 'pb-mk-bk', 'pb-mk-em'];
const fmt = n => (n === undefined || n === null || Number.isNaN(n)) ? '—' : Number(n).toLocaleString('fr-FR');
const mb = b => b ? (b / 1048576).toFixed(b > 10485760 ? 0 : 1) + ' Mo' : '—';
const pct = (a, n) => n > 0 ? Math.round(1000 * a / n) / 10 : 0;
const esc = s => String(s === undefined || s === null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function moveLabel(m) {
  let out = String(m.from);
  const seq = (m.path && m.path.length) ? m.path : [m.to];
  for (const q of seq) out += ((m.caps && m.caps.length) ? 'x' : '-') + q;
  return out;
}

/* Convertit un coup encodé de la base vers le format attendu par PIONICIDE. */
function toAppMove(m) {
  const captured = (m.caps || []).slice();
  const path = captured.length ? [m.from].concat(m.path && m.path.length ? m.path : [m.to]) : [m.from, m.to];
  return { from: m.from, to: m.to, captured, path };
}

function cellsToAppBoard(cells) {
  const board = Array(51).fill('e');
  for (let s = 1; s <= 50; s++) {
    const t = cells[s];
    if (t === 1) board[s] = 'w';
    else if (t === 2) board[s] = 'W';
    else if (t === 3) board[s] = 'b';
    else if (t === 4) board[s] = 'B';
  }
  return board;
}

function appBoardToCells(board) {
  const cells = new Uint8Array(51);
  for (let s = 1; s <= 50; s++) {
    const p = board[s];
    if (p === 'w') cells[s] = CELL.WMAN;
    else if (p === 'W') cells[s] = CELL.WKING;
    else if (p === 'b') cells[s] = CELL.BMAN;
    else if (p === 'B') cells[s] = CELL.BKING;
  }
  return cells;
}

export function createBasePage({ navigate, toast }) {
  const el = document.createElement('div');
  el.className = 'pb-page';
  let worker = null;
  let seq = 0;
  const waiting = new Map();
  const listeners = new Set();
  let mounted = false;

  /* ------------------------------- worker RPC ------------------------------- */
  function ensureWorker() {
    if (worker) return worker;
    worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });
    worker.onmessage = event => {
      const message = event.data;
      if (!message) return;
      if (message.id && waiting.has(message.id)) {
        const pending = waiting.get(message.id);
        waiting.delete(message.id);
        if (message.ok) pending.resolve(message.result);
        else pending.reject(new Error(message.error || 'erreur du worker'));
        return;
      }
      listeners.forEach(fn => fn(message));
    };
    worker.onerror = event => {
      console.warn('Base · worker', event.message);
      toast('Base de parties : worker indisponible (' + (event.message || 'erreur') + ')');
    };
    return worker;
  }
  function call(type, payload) {
    ensureWorker();
    const id = ++seq;
    return new Promise((resolve, reject) => {
      waiting.set(id, { resolve, reject });
      worker.postMessage({ id, type, payload: payload || {} });
    });
  }
  const onEvent = fn => { listeners.add(fn); return () => listeners.delete(fn); };

  /* ------------------------------- état ------------------------------- */
  let savedStructures = [];
  let editorMarks = new Uint8Array(51);
  let explorerHistory = [];      // coups du noyau
  let explorerMoves = [];        // coups légaux + statistiques
  let explorerSel = 0;
  let currentGame = null;        // partie ouverte depuis la base
  let gameCursor = 0;
  let activeTab = 'import';
  let searchToken = 0;
  let explorerOrientation = 'w';
  let lastImport = null;

  /* ------------------------------- gabarit ------------------------------- */
  el.innerHTML = `
    <div class="section-heading">
      <div class="eyebrow">BASE DE PARTIES · 100 000 PARTIES DE MAÎTRES</div>
      <h1>Base de parties</h1>
      <p>Explorez les ouvertures jouées, cherchez une structure sur le damier et retrouvez les parties qui la contiennent. Tout reste dans le téléphone.</p>
    </div>
    <div class="pb-tabs" role="tablist" aria-label="Sections de la base">
      <button class="pb-tab is-on" data-tab="import" role="tab">Importer</button>
      <button class="pb-tab" data-tab="explorer" role="tab">Explorateur</button>
      <button class="pb-tab" data-tab="structures" role="tab">Structures</button>
      <button class="pb-tab" data-tab="search" role="tab">Recherche</button>
      <button class="pb-tab" data-tab="base" role="tab">Base</button>
    </div>

    <section class="pb-view" data-view="import">
      <section class="panel">
        <h2 class="pb-h2">Importer des parties <span class="pb-tag">PDN</span></h2>
        <p class="study-context">Un ou plusieurs fichiers <code>.pdn</code> / <code>.txt</code>. Le traitement se fait fichier par fichier dans un Web Worker : l’interface reste fluide et l’import reprend après une interruption.</p>
        <div class="replay-toolbar">
          <label class="secondary-button">Choisir des fichiers<input id="pb-file" type="file" accept=".pdn,.txt,text/plain" multiple hidden></label>
          <button class="secondary-button" id="pb-pause" disabled>Pause</button>
          <button class="secondary-button" id="pb-cancel" disabled>Arrêter</button>
        </div>
        <div class="pb-resume" id="pb-resume" hidden>
          <b>Import interrompu</b>
          <p class="study-context" id="pb-resume-text"></p>
          <div class="replay-toolbar">
            <label class="secondary-button" id="pb-resume-pick-label">Reprendre<input id="pb-resume-file" type="file" accept=".pdn,.txt,text/plain" hidden></label>
            <button class="secondary-button" id="pb-resume-drop">Abandonner</button>
          </div>
        </div>
        <div id="pb-progress" hidden>
          <div class="pb-bar"><i id="pb-bar-fill"></i></div>
          <p class="message" id="pb-progress-line" style="text-align:left">—</p>
        </div>
        <div id="pb-report" hidden></div>
        <div class="pb-log" id="pb-log"></div>
      </section>
      <section class="panel">
        <h2 class="pb-h2">Mesures sur cet appareil</h2>
        <div class="pb-kv">
          <div><b id="pb-m-games">0</b><span>parties lues</span></div>
          <div><b id="pb-m-ms">—</b><span>ms / partie</span></div>
          <div><b id="pb-m-rate">—</b><span>parties / s</span></div>
          <div><b id="pb-m-store">—</b><span>stockage</span></div>
          <div><b id="pb-m-index">—</b><span>index en RAM</span></div>
          <div><b id="pb-m-heap">—</b><span>tas JS</span></div>
        </div>
        <p class="study-context">Mesures réelles de la session. Importez d’abord un échantillon (1 000 parties), relevez ces valeurs, puis poursuivez jusqu’à 100 000.</p>
      </section>
    </section>

    <section class="pb-view" data-view="explorer" hidden>
      <section class="panel">
        <h2 class="pb-h2">Explorateur d’ouvertures <span class="pb-tag">30 demi-coups</span></h2>
        <p class="study-context" id="pb-game-context">Position libre.</p>
        <div class="board-wrap"><div id="pb-board-explorer"></div></div>
        <div class="replay-toolbar">
          <button class="secondary-button" id="pb-first" title="Position initiale">⏮</button>
          <button class="secondary-button" id="pb-back" title="Coup précédent">◀</button>
          <button class="secondary-button" id="pb-fwd" title="Coup suivant">▶</button>
          <button class="secondary-button" id="pb-flip">Retourner</button>
          <button class="secondary-button" id="pb-reset">Position initiale</button>
          <button class="secondary-button" id="pb-use-struct">Vers l’éditeur de structure</button>
          <button class="secondary-button" id="pb-play-position">Jouer cette position</button>
          <button class="secondary-button" id="pb-print-position">Imprimer la position</button>
          <button class="secondary-button" id="pb-analyse" disabled>Analyser cette partie</button>
          <button class="secondary-button" id="pb-study" disabled>Étudier et commenter</button>
        </div>
        <p class="turn-indicator" id="pb-explorer-state">Position initiale · trait aux blancs</p>
        <h3 class="pb-h3">Coups joués depuis cette position</h3>
        <div class="pb-list" id="pb-explorer-moves"><p class="study-context">Chargement de l’index…</p></div>
      </section>
      <section class="panel" id="pb-position-games" hidden>
        <h2 class="pb-h2">Parties de cette position</h2>
        <div class="pb-filters">
          <label>Joueur<input type="text" id="pb-f-player" placeholder="nom…" list="pb-players" autocomplete="off"></label>
          <label>Couleur<select id="pb-f-color"><option value="">blancs ou noirs</option><option value="w">blancs</option><option value="b">noirs</option></select></label>
          <label>De<input type="number" id="pb-f-from" min="1900" max="2100" placeholder="1900"></label>
          <label>À<input type="number" id="pb-f-to" min="1900" max="2100" placeholder="2100"></label>
          <label>Événement<input type="text" id="pb-f-event" placeholder="championnat…"></label>
        </div>
        <p class="pb-hint" id="pb-f-player-note" role="status">Les fautes de frappe sont acceptées : accents, casse, nom seul, initiales.</p>
        <div class="replay-toolbar">
          <button class="secondary-button" id="pb-f-apply">Filtrer</button>
          <button class="secondary-button" id="pb-f-clear">Effacer</button>
        </div>
        <div class="pb-list" id="pb-position-list"></div>
      </section>
    </section>

    <section class="pb-view" data-view="structures" hidden>
      <section class="panel">
        <h2 class="pb-h2">Éditeur de structure <span class="pb-tag">6 états</span></h2>
        <p class="study-context">Appuyez sur une case : libre → pion blanc → dame blanche → pion noir → dame noire → case vide obligatoire. Les cases libres sont ignorées par la recherche.</p>
        <div class="board-wrap"><div id="pb-board-structures"></div></div>
        <div class="pb-legend">
          <span><i class="pb-dot pb-mk-wm"></i>pion blanc</span>
          <span><i class="pb-dot pb-mk-wk"></i>dame blanche</span>
          <span><i class="pb-dot pb-mk-bm"></i>pion noir</span>
          <span><i class="pb-dot pb-mk-bk"></i>dame noire</span>
          <span><i class="pb-dot pb-mk-em"></i>vide obligatoire</span>
        </div>
        <div class="pb-filters">
          <label>Nom de la structure<input type="text" id="pb-st-name" placeholder="ex. : blocage 4-6"></label>
        </div>
        <div class="replay-toolbar">
          <button class="start-game-button" id="pb-st-save" style="width:auto;margin:0">Enregistrer</button>
          <button class="secondary-button" id="pb-st-clear">Vider</button>
          <button class="secondary-button" id="pb-st-search">Chercher dans la base</button>
        </div>
        <div class="pb-filters" style="margin-top:10px">
          <label class="pb-wide">Chaîne de 50 caractères (B / D / N / d / E / .)<input type="text" id="pb-st-line" spellcheck="false" placeholder="B.D.N.E…"></label>
        </div>
        <div class="replay-toolbar">
          <button class="secondary-button" id="pb-st-line-apply">Appliquer la chaîne</button>
          <button class="secondary-button" id="pb-st-export">Exporter JSON</button>
          <label class="secondary-button">Importer JSON<input id="pb-st-import" type="file" accept=".json,application/json,text/plain" hidden></label>
        </div>
      </section>
      <section class="panel">
        <h2 class="pb-h2">Mes structures enregistrées</h2>
        <div class="pb-list" id="pb-st-list"></div>
      </section>
    </section>

    <section class="pb-view" data-view="search" hidden>
      <section class="panel">
        <h2 class="pb-h2">Recherche dans la base</h2>
        <p class="study-context">Deux entrées : <b>joueur contre joueur</b> (l’année est facultative) ou <b>structure</b> dessinée sur le damier. Les deux peuvent se combiner ; chaque résultat s’ouvre sur le damier ou s’imprime.</p>
        <div class="board-wrap"><div id="pb-board-search"></div></div>
        <p class="study-context" id="pb-search-summary">Aucune contrainte.</p>
        <h3 class="pb-h3">Joueur contre joueur</h3>
        <div class="pb-filters">
          <label>Joueur des Blancs<input type="text" id="pb-sr-white" placeholder="nom…" list="pb-players" autocomplete="off"></label>
          <label>Joueur des Noirs<input type="text" id="pb-sr-black" placeholder="nom…" list="pb-players" autocomplete="off"></label>
          <label>Année de (facultatif)<input type="number" id="pb-sr-year-from" min="1900" max="2100" placeholder="toutes"></label>
          <label>Année à (facultatif)<input type="number" id="pb-sr-year-to" min="1900" max="2100" placeholder="idem"></label>
        </div>
        <h3 class="pb-h3">Structure (facultatif)</h3>
        <div class="pb-filters">
          <label>Structure<select id="pb-sr-struct"><option value="">— aucune, ou dessinée dans l’éditeur —</option></select></label>
          <label>Demi-coups max<input type="number" id="pb-sr-maxply" value="60" min="1" max="200"></label>
          <label>Résultats max<input type="number" id="pb-sr-limit" value="200" min="10" max="2000"></label>
          <label>Symétrie de couleur<select id="pb-sr-mirror"><option value="">non</option><option value="1">oui</option></select></label>
        </div>
        <p class="pb-hint" id="pb-sr-player-note" role="status">Les fautes de frappe sont acceptées : accents, casse, nom seul, initiales. Sans structure, la recherche porte sur toutes les parties : indiquez au moins un joueur ou une année.</p>
        <div class="replay-toolbar">
          <button class="start-game-button" id="pb-sr-run" style="width:auto;margin:0">Lancer la recherche</button>
          <button class="secondary-button" id="pb-sr-stop" disabled>Arrêter</button>
        </div>
        <div class="pb-bar" id="pb-sr-progress" hidden><i></i></div>
        <p class="message" id="pb-sr-status" style="text-align:left"></p>
        <div class="pb-list" id="pb-sr-results"></div>
      </section>
    </section>

    <section class="pb-view" data-view="base" hidden>
      <section class="panel">
        <h2 class="pb-h2">État de la base</h2>
        <div class="pb-kv">
          <div><b id="pb-db-games">0</b><span>parties</span></div>
          <div><b id="pb-db-players">0</b><span>joueurs</span></div>
          <div><b id="pb-db-pos">—</b><span>positions indexées</span></div>
          <div><b id="pb-db-index">—</b><span>index (RAM)</span></div>
          <div><b id="pb-db-usage">—</b><span>stockage</span></div>
          <div><b id="pb-db-quota">—</b><span>quota</span></div>
        </div>
        <div class="replay-toolbar">
          <button class="secondary-button" id="pb-db-refresh">Rafraîchir</button>
          <button class="secondary-button" id="pb-db-persist">Stockage persistant</button>
          <span class="pb-badge" id="pb-db-persist-state">—</span>
        </div>
      </section>
      <section class="panel">
        <h2 class="pb-h2">Sauvegarde</h2>
        <div class="replay-toolbar">
          <button class="start-game-button" id="pb-db-export" style="width:auto;margin:0">Exporter le fichier de base</button>
          <label class="secondary-button">Importer un fichier<input id="pb-db-import" type="file" accept=".pbase,.bin,application/octet-stream" hidden></label>
        </div>
        <div class="pb-bar" id="pb-db-progress" hidden><i></i></div>
        <p class="message" id="pb-db-status" style="text-align:left"></p>
      </section>
      <section class="panel">
        <h2 class="pb-h2">Index et alias</h2>
        <div class="pb-filters">
          <label>Profondeur d’index (demi-coups)<input type="number" id="pb-idx-ply" value="30" min="6" max="30"></label>
        </div>
        <div class="replay-toolbar">
          <button class="secondary-button" id="pb-idx-rebuild">Reconstruire l’index</button>
          <button class="secondary-button" id="pb-mt-dupes">Analyser les doublons</button>
          <button class="secondary-button" id="pb-mt-clear">Vider la base</button>
        </div>
        <div class="pb-bar" id="pb-idx-progress" hidden><i></i></div>
        <p class="message" id="pb-idx-status" style="text-align:left"></p>
        <div class="pb-filters" style="margin-top:10px">
          <label>Variante<input type="text" id="pb-al-from" placeholder="ex. : Mbemba S."></label>
          <label>Nom canonique<input type="text" id="pb-al-to" placeholder="ex. : Sosthene Mbemba"></label>
        </div>
        <div class="replay-toolbar">
          <button class="secondary-button" id="pb-al-add">Ajouter l’alias</button>
          <button class="secondary-button" id="pb-al-apply">Appliquer à toute la base</button>
        </div>
        <div class="pb-list" id="pb-al-list"></div>
      </section>
      <section class="panel">
        <h2 class="pb-h2">Formats</h2>
        <p class="study-context"><b>Structure (JSON)</b> : <code>{"nom":"…","blancs":[28],"damesBlanches":[],"noirs":[23],"damesNoires":[],"vides":[19]}</code> — toutes les cases non citées sont libres.</p>
        <p class="study-context"><b>Chaîne 50 cases</b> : <code>B</code> pion blanc · <code>D</code> dame blanche · <code>N</code> pion noir · <code>d</code> dame noire · <code>E</code> vide obligatoire · <code>.</code> libre.</p>
        <p class="study-context"><b>PDN</b> : coups simples, prises <code>28x19</code>, rafles <code>28x19x8</code> (ou liste des pièces prises), commentaires, variantes ignorées, résultats 2-0 / 1-1 / 0-2.</p>
      </section>
    </section>

    <datalist id="pb-players"></datalist>
  `;

  const q = id => el.querySelector('#' + id);
  const qa = sel => Array.from(el.querySelectorAll(sel));

  /* ------------------------------- board helpers ------------------------------- */
  function paintExplorer() {
    const position = explorerPosition();
    const board = Array(51).fill('e');
    for (let s = 1; s <= 50; s++) {
      const t = position.pieceAt(s);
      if (t === 1) board[s] = 'w'; else if (t === 2) board[s] = 'W';
      else if (t === 3) board[s] = 'b'; else if (t === 4) board[s] = 'B';
    }
    const targets = new Map();
    for (const move of explorerMoves) {
      if (explorerSel && move.from === explorerSel) targets.set(move.to, move.caps && move.caps.length ? 'pb-capture' : 'hint-target');
    }
    const last = explorerHistory.length ? (() => {
      const m = explorerHistory[explorerHistory.length - 1];
      return (m.caps && m.caps.length) ? [m.from].concat(m.path || [m.to]) : [m.from, m.to];
    })() : null;
    renderBoard(q('pb-board-explorer'), {
      board,
      orientation: explorerOrientation,
      selected: explorerSel || null,
      lastMove: last,
      markers: new Map(Array.from(targets.entries())),
      targets: new Set(Array.from(targets.entries()).filter(([, cls]) => cls === 'hint-target').map(([sq]) => sq)),
      onSquareClick: onExplorerSquare,
      ariaLabel: 'Damier de l’explorateur d’ouvertures',
    });
  }

  function paintStructureBoard() {
    renderBoard(q('pb-board-structures'), {
      board: Array(51).fill('e'),
      markers: new Map(Array.from({ length: 50 }, (_, i) => i + 1).filter(s => editorMarks[s]).map(s => [s, MARK_CLASS[editorMarks[s]]])),
      onSquareClick: onStructureSquare,
      ariaLabel: 'Éditeur de structure, six états par case',
    });
  }

  function paintSearchBoard() {
    const marks = currentSearchMarks();
    renderBoard(q('pb-board-search'), {
      board: Array(51).fill('e'),
      markers: new Map(Array.from({ length: 50 }, (_, i) => i + 1).filter(s => marks[s]).map(s => [s, MARK_CLASS[marks[s]]])),
      ariaLabel: 'Aperçu de la structure recherchée',
    });
  }

  /* ------------------------------- explorateur ------------------------------- */
  function explorerPosition() {
    let position = Position.initial();
    for (const move of explorerHistory) position = applyMove(position, move);
    return position;
  }

  async function refreshExplorer(forceFetch = true) {
    const position = explorerPosition();
    paintExplorer();
    q('pb-explorer-state').textContent =
      (explorerHistory.length ? explorerHistory.length + ' demi-coup' + (explorerHistory.length > 1 ? 's' : '') : 'Position initiale') +
      ' · trait aux ' + (position.side === 1 ? 'noirs' : 'blancs');
    q('pb-analyse').disabled = !currentGame;
    q('pb-study').disabled = !currentGame;
    q('pb-game-context').textContent = currentGame
      ? `${currentGame.w} – ${currentGame.b} · ${currentGame.ev || 'événement inconnu'} · ${currentGame.dt || 'date inconnue'} · ${currentGame.r}`
      : 'Position libre : partez de la position initiale et suivez les coups de la base.';
    if (!forceFetch) return;
    try {
      const cells = Array.from({ length: 51 }, (_, i) => (i === 0 ? 0 : position.pieceAt(i)));
      const result = await call('explorerMoves', { cells, side: position.side });
      explorerMoves = result.moves;
      paintExplorer();
      renderExplorerMoves(result.total);
      loadPositionGames();
    } catch (error) {
      q('pb-explorer-moves').innerHTML = '<p class="study-context">Index indisponible : importez d’abord des parties.</p>';
    }
  }

  function renderExplorerMoves(total) {
    const box = q('pb-explorer-moves');
    if (!explorerMoves.length) { box.innerHTML = '<p class="study-context">Aucun coup légal.</p>'; return; }
    const known = explorerMoves.reduce((sum, move) => sum + move.n, 0);
    box.innerHTML = (known ? '' : '<p class="study-context">Position absente de la base : coups légaux affichés sans statistiques.</p>') +
      explorerMoves.map(move => {
        const n = move.n || 0;
        return `<button class="pb-row" data-from="${move.from}" data-to="${move.to}">
          <span class="pb-move">${moveLabel(move)}</span>
          <span class="pb-bars"><i class="pb-w" style="width:${pct(move.w, n)}%"></i><i class="pb-d" style="width:${pct(move.d, n)}%"></i><i class="pb-l" style="width:${pct(move.l, n)}%"></i></span>
          <span class="pb-row-meta">${fmt(n)} partie${n > 1 ? 's' : ''}${n ? ` · ${pct(move.w, n)}/${pct(move.d, n)}/${pct(move.l, n)} %` : ''}</span>
        </button>`;
      }).join('');
    box.querySelectorAll('.pb-row').forEach(button => button.addEventListener('click', () => {
      const move = explorerMoves.find(item => item.from === Number(button.dataset.from) && item.to === Number(button.dataset.to));
      if (move) playMove(move);
    }));
  }

  function playMove(move) {
    const position = explorerPosition();
    const legal = generateMoves(position).find(item => item.from === move.from && item.to === move.to && item.caps.length === (move.caps || []).length);
    explorerHistory.push(legal || { from: move.from, to: move.to, caps: move.caps || [], path: move.path || [] });
    explorerSel = 0;
    if (currentGame) gameCursor = explorerHistory.length;
    refreshExplorer();
  }

  /** Imprime la position affichée dans l'explorateur (et la partie, si elle est ouverte). */
  function printExplorerPosition() {
    const position = explorerPosition();
    const fullMoves = currentGame ? currentGame.internal.map(moveLabel) : explorerHistory.map(moveLabel);
    const cursor = explorerHistory.length;
    const meta = currentGame
      ? [currentGame.ev || 'événement inconnu', currentGame.dt || 'date inconnue', `résultat ${currentGame.r}`,
        cursor ? `position au demi-coup ${cursor}` : 'position initiale'].join(' · ')
      : [`${cursor} demi-coup${cursor > 1 ? 's' : ''} joué${cursor > 1 ? 's' : ''}`, 'position libre'].join(' · ');
    openGameSheet({
      title: currentGame ? 'Partie de la base de parties' : 'Position de l’explorateur',
      subtitle: currentGame ? `${currentGame.w} — ${currentGame.b}` : 'Position composée à la main',
      meta,
      board: boardFromPosition(position),
      orientation: explorerOrientation,
      numbers: true,
      moves: fullMoves,
      cursor,
      side: position.side === 1 ? 'b' : 'w',
    });
  }

  function onExplorerSquare(square) {
    const position = explorerPosition();
    if (explorerSel) {
      const hit = explorerMoves.find(move => move.from === explorerSel && move.to === square);
      if (hit) { playMove(hit); return; }
    }
    const piece = position.pieceAt(square);
    const mine = piece && ((position.side === 0 && (piece === 1 || piece === 2)) || (position.side === 1 && (piece === 3 || piece === 4)));
    if (!mine) { explorerSel = 0; paintExplorer(); return; }
    explorerSel = square;
    paintExplorer();
  }

  async function openGame(id, ply) {
    try {
      const game = await call('getGame', { id });
      if (!game) { toast('Partie introuvable'); return; }
      const moves = decodeMoves(game.mv);
      currentGame = Object.assign({}, game, { internal: moves });
      gameCursor = Math.max(0, Math.min(ply || 0, moves.length));
      explorerHistory = moves.slice(0, gameCursor);
      explorerSel = 0;
      setTab('explorer');
      await refreshExplorer();
      toast('Partie ouverte au demi-coup ' + gameCursor + '.');
    } catch (error) {
      toast('Erreur : ' + error.message);
    }
  }

  /**
   * Retour lisible sur la recherche approximative : quels joueurs la saisie
   * a réellement désignés (ou l'absence de nom proche dans la base).
   */
  /** Note lisible sur la résolution des deux noms saisis (recherche joueur contre joueur). */
  function updatePairNote(result) {
    const note = q('pb-sr-player-note');
    if (!note) return;
    const describe = (label, typed, matches, count) => {
      const query = String(typed || '').trim();
      if (!query) return '';
      if (!matches || !matches.length) return `${label} : aucun nom proche de « ${query} » dans la base.`;
      const exact = matches.some(match => match.score >= 0.98);
      const names = matches.slice(0, 3).map(match => match.name).join(', ');
      const more = count > matches.length ? ` (+${count - matches.length})` : '';
      return `${label} : ${exact ? '' : 'nom corrigé → '}${names}${more}`;
    };
    const parts = [
      describe('Blancs', q('pb-sr-white').value, result?.whiteMatches, result?.whiteCount || 0),
      describe('Noirs', q('pb-sr-black').value, result?.blackMatches, result?.blackCount || 0),
    ].filter(Boolean);
    if (!parts.length) {
      note.textContent = 'Les fautes de frappe sont acceptées : accents, casse, nom seul, initiales. Sans structure, indiquez au moins un joueur ou une année.';
      note.classList.remove('pb-warn');
      return;
    }
    note.textContent = parts.join(' · ');
    note.classList.toggle('pb-warn', /aucun nom proche/.test(note.textContent) || /nom corrigé/.test(note.textContent));
  }

  /** Damier de l'application à partir d'une position du noyau. */
  function boardFromPosition(position) {
    return cellsToAppBoard(Array.from({ length: 51 }, (_, index) => (index === 0 ? 0 : position.pieceAt(index))));
  }

  /** Imprime une partie de la base (position au demi-coup demandé, liste complète des coups). */
  async function printGameRow(row) {
    try {
      const game = await call('getGame', { id: row.id });
      if (!game) { toast('Partie introuvable'); return; }
      const internal = decodeMoves(game.mv);
      const ply = Math.max(0, Math.min(Number(row.ply) || 0, internal.length));
      let position = Position.initial();
      for (let index = 0; index < ply; index += 1) position = applyMove(position, internal[index]);
      const final = internal.length ? (() => {
        let end = Position.initial();
        for (const move of internal) end = applyMove(end, move);
        return end;
      })() : null;
      const boards = ply > 0 || !final
        ? [{ board: boardFromPosition(position), caption: positionCaption(ply, internal.length, position.side === 1 ? 'b' : 'w') }]
        : [
          { board: boardFromPosition(Position.initial()), caption: positionCaption(0, internal.length, 'w') },
          { board: boardFromPosition(final), caption: positionCaption(internal.length, internal.length, final.side === 1 ? 'b' : 'w') },
        ];
      openGameSheet({
        title: 'Partie de la base de parties',
        subtitle: `${game.w} — ${game.b}`,
        meta: [game.ev || 'événement inconnu', game.dt || 'date inconnue', `résultat ${game.r}`,
          `${internal.length} demi-coups`].join(' · '),
        boards,
        orientation: 'w',
        numbers: true,
        moves: game.moves,
        cursor: ply,
      });
    } catch (error) {
      toast('Impression impossible : ' + error.message);
    }
  }

  function showPlayerNote(elementId, typed, result) {
    const note = q(elementId);
    if (!note) return;
    const query = String(typed || '').trim();
    if (!query) {
      note.textContent = 'Les fautes de frappe sont acceptées : accents, casse, nom seul, initiales.';
      note.classList.remove('pb-warn');
      return;
    }
    const matches = result?.players || [];
    if (!matches.length) {
      note.textContent = `Aucun nom proche de « ${query} » dans la base : aucun résultat ne peut correspondre.`;
      note.classList.add('pb-warn');
      return;
    }
    const exact = matches.some(match => match.score >= 0.98);
    const names = matches.slice(0, 4).map(match => match.name).join(', ');
    const more = matches.length > 4 ? ` et ${matches.length - 4} autre(s)` : '';
    note.textContent = exact
      ? `Joueur : ${names}${more}.`
      : `Nom corrigé : ${names}${more}${result?.playerCount > matches.length ? ` (${result.playerCount} au total)` : ''}.`;
    note.classList.toggle('pb-warn', !exact);
  }

  async function loadPositionGames() {
    const position = explorerPosition();
    const key = hash32Position(position);
    const typedPlayer = q('pb-f-player').value.trim();
    const filters = {
      player: nameKey(typedPlayer) || '',
      playerQuery: typedPlayer,
      color: q('pb-f-color').value || '',
      from: parseInt(q('pb-f-from').value, 10) || 0,
      to: parseInt(q('pb-f-to').value, 10) || 0,
      event: (q('pb-f-event').value || '').trim(),
    };
    const box = q('pb-position-list');
    box.innerHTML = '<p class="study-context">Recherche…</p>';
    try {
      const result = await call('positionGames', { key, filters, limit: 300 });
      showPlayerNote('pb-f-player-note', q('pb-f-player').value, result);
      if (!result.rows.length) {
        box.innerHTML = '<p class="study-context">Aucune partie pour cette position. L’index couvre les 30 premiers demi-coups.</p>';
        return;
      }
      box.innerHTML = `<p class="study-context">${fmt(result.total)} partie(s) · ${fmt(result.indexTotal)} occurrence(s) indexée(s)</p>` +
        result.rows.map(row => `<div class="pb-row pb-row-game">
          <span class="pb-move-score">${esc(row.r)}</span>
          <span class="pb-row-text"><b>${esc(row.w)} – ${esc(row.b)}</b><small>${esc(row.dt || 'date inconnue')} · ${esc(row.ev || '—')}</small></span>
          <span class="pb-row-meta">coup ${row.at}</span>
          <button class="secondary-button pb-open" data-id="${row.id}" data-ply="${row.at}">Ouvrir</button>
          <button class="secondary-button pb-print" data-id="${row.id}" data-ply="${row.at}">Imprimer</button>
        </div>`).join('');
      box.querySelectorAll('.pb-open').forEach(button => button.addEventListener('click', () =>
        openGame(Number(button.dataset.id), Number(button.dataset.ply))));
      box.querySelectorAll('.pb-print').forEach(button => button.addEventListener('click', () =>
        printGameRow({ id: Number(button.dataset.id), ply: Number(button.dataset.ply) })));
    } catch (error) {
      box.innerHTML = `<p class="study-context">Erreur : ${esc(error.message)}</p>`;
    }
  }

  /* ------------------------------- structures ------------------------------- */
  function loadStructures() {
    try {
      const raw = JSON.parse(localStorage.getItem(LS_STRUCTURES) || '[]');
      savedStructures = Array.isArray(raw) ? raw : [];
    } catch { savedStructures = []; }
    renderStructures();
    fillStructureSelect();
  }
  function persistStructures() {
    try { localStorage.setItem(LS_STRUCTURES, JSON.stringify(savedStructures)); }
    catch { toast('Stockage local indisponible'); }
    renderStructures();
    fillStructureSelect();
  }
  function structureCounts(line) {
    const counts = { B: 0, D: 0, N: 0, d: 0, E: 0 };
    for (const character of line) if (counts[character] !== undefined) counts[character]++;
    const parts = [];
    if (counts.B) parts.push(counts.B + ' pion(s) blanc(s)');
    if (counts.D) parts.push(counts.D + ' dame(s) blanche(s)');
    if (counts.N) parts.push(counts.N + ' pion(s) noir(s)');
    if (counts.d) parts.push(counts.d + ' dame(s) noire(s)');
    if (counts.E) parts.push(counts.E + ' case(s) vide(s)');
    return parts.join(' · ') || 'structure vide';
  }
  function marksFromObject(object) { return parseStructure(object).cells; }
  function objectFromMarks(marks, name) { return structureToJSON({ nom: name || 'Structure', cells: marks }); }
  function syncLineFromMarks() { q('pb-st-line').value = structureToLine({ cells: editorMarks }); }

  function onStructureSquare(square) {
    editorMarks[square] = (editorMarks[square] + 1) % 6;
    paintStructureBoard();
    syncLineFromMarks();
    paintSearchBoard();
    updateSearchSummary();
  }

  function renderStructures() {
    const box = q('pb-st-list');
    if (!savedStructures.length) { box.innerHTML = '<p class="study-context">Aucune structure enregistrée.</p>'; return; }
    box.innerHTML = savedStructures.map((structure, index) => `<div class="pb-row pb-row-game">
        <span class="pb-row-text"><b>${esc(structure.nom)}</b><small>${structureCounts(structure.line)}</small></span>
        <button class="secondary-button" data-act="load" data-i="${index}">Charger</button>
        <button class="secondary-button" data-act="rename" data-i="${index}">Renommer</button>
        <button class="secondary-button" data-act="search" data-i="${index}">Chercher</button>
        <button class="secondary-button" data-act="export" data-i="${index}">JSON</button>
        <button class="secondary-button" data-act="delete" data-i="${index}">✕</button>
      </div>`).join('');
    box.querySelectorAll('[data-act]').forEach(button => button.addEventListener('click', () => {
      const index = Number(button.dataset.i);
      const structure = savedStructures[index];
      if (!structure) return;
      const act = button.dataset.act;
      if (act === 'load') {
        editorMarks = marksFromObject(structure.obj || { nom: structure.nom, cells: parseStructure(structure.line).cells });
        q('pb-st-name').value = structure.nom;
        paintStructureBoard(); syncLineFromMarks(); paintSearchBoard(); updateSearchSummary();
        toast('Structure chargée.');
      } else if (act === 'rename') {
        const name = window.prompt('Nouveau nom :', structure.nom);
        if (!name) return;
        structure.nom = name.trim();
        if (structure.obj) structure.obj.nom = structure.nom;
        persistStructures();
      } else if (act === 'search') {
        q('pb-sr-struct').value = String(index);
        setTab('search');
        runSearch();
      } else if (act === 'export') {
        download(JSON.stringify(structure.obj || objectFromMarks(parseStructure(structure.line).cells, structure.nom), null, 2),
          structure.nom.replace(/[^\w-]+/g, '_') + '.json', 'application/json');
      } else if (act === 'delete') {
        if (!window.confirm('Supprimer « ' + structure.nom + ' » ?')) return;
        savedStructures.splice(index, 1);
        persistStructures();
      }
    }));
  }

  function fillStructureSelect() {
    const select = q('pb-sr-struct');
    const current = select.value;
    select.innerHTML = '<option value="">— dessinée dans l’éditeur —</option>' +
      savedStructures.map((structure, index) => `<option value="${index}">${esc(structure.nom)}</option>`).join('');
    if (current && select.querySelector(`option[value="${current}"]`)) select.value = current;
  }

  function currentSearchMarks() {
    const value = q('pb-sr-struct').value;
    if (value !== '') {
      const structure = savedStructures[Number(value)];
      if (structure) return marksFromObject(structure.obj || { nom: structure.nom, cells: parseStructure(structure.line).cells });
    }
    return editorMarks;
  }
  function updateSearchSummary() {
    const line = structureToLine({ cells: currentSearchMarks() });
    q('pb-search-summary').textContent = line.replace(/\./g, '') ? structureCounts(line) : 'Aucune contrainte : dessinez une structure dans l’onglet Structures.';
  }

  async function runSearch() {
    const marks = currentSearchMarks();
    const line = structureToLine({ cells: marks });
    const hasStructure = !!line.replace(/\./g, '');
    const white = q('pb-sr-white').value.trim();
    const black = q('pb-sr-black').value.trim();
    const yearFrom = parseInt(q('pb-sr-year-from').value, 10) || 0;
    const yearTo = parseInt(q('pb-sr-year-to').value, 10) || 0;
    if (!hasStructure && !white && !black && !yearFrom && !yearTo) {
      toast('Indiquez au moins un joueur, une année ou une structure.');
      return;
    }
    if (yearFrom && yearTo && yearTo < yearFrom) {
      toast('L’année « à » doit être postérieure à l’année « de ».');
      return;
    }
    const filters = {
      whiteQuery: white,
      blackQuery: black,
      yearFrom,
      yearTo: yearTo || yearFrom,
    };
    const token = ++searchToken;
    q('pb-sr-run').disabled = true;
    q('pb-sr-stop').disabled = false;
    q('pb-sr-progress').hidden = false;
    q('pb-sr-progress').firstElementChild.style.width = '0%';
    q('pb-sr-status').textContent = hasStructure ? 'Recherche de la structure…' : 'Recherche des parties…';
    q('pb-sr-results').innerHTML = '';
    const limit = parseInt(q('pb-sr-limit').value, 10) || 200;
    try {
      const result = hasStructure
        ? await call('searchStructure', {
          structure: { cells: marks },
          opts: {
            mirror: q('pb-sr-mirror').value === '1',
            maxPly: parseInt(q('pb-sr-maxply').value, 10) || 60,
            limit,
            filters,
          },
        })
        : await call('searchGames', { filters, limit });
      if (token !== searchToken) return;
      q('pb-sr-progress').firstElementChild.style.width = '100%';
      updatePairNote(result);
      const shown = Math.min(result.results.length, limit);
      const found = hasStructure ? result.matched : result.matched;
      q('pb-sr-status').textContent = hasStructure
        ? `${fmt(found)} partie(s) trouvée(s) · ${fmt(result.scanned)} analysées en ${fmt(result.ms)} ms · ${fmt(shown)} affichée(s)`
        : `${fmt(found)} partie(s) trouvée(s) · ${fmt(result.scanned)} parcourues en ${fmt(result.ms)} ms · ${fmt(shown)} affichée(s)`;
      renderSearchResults(result.results);
      window.setTimeout(() => { q('pb-sr-progress').hidden = true; }, 500);
    } catch (error) {
      q('pb-sr-status').textContent = 'Erreur : ' + error.message;
      q('pb-sr-progress').hidden = true;
    } finally {
      q('pb-sr-run').disabled = false;
      q('pb-sr-stop').disabled = true;
    }
  }

  function renderSearchResults(rows) {
    const box = q('pb-sr-results');
    if (!rows.length) { box.innerHTML = '<p class="study-context">Aucune partie ne correspond à cette recherche.</p>'; return; }
    box.innerHTML = rows.map(row => {
      const plys = (row.plys && row.plys.length) ? row.plys : [row.ply || 0];
      return `<div class="pb-row pb-row-game">
      <span class="pb-move-score">${esc(row.r)}</span>
      <span class="pb-row-text"><b>${esc(row.w)} – ${esc(row.b)}</b><small>${esc(row.dt || 'date inconnue')} · ${esc(row.ev || '—')}</small></span>
      <span class="pb-row-meta">${(row.plys && row.plys.length) ? 'coup ' + row.plys.join(', ') : (row.pl || 0) + ' demi-coups'}${row.mir ? ' · symétrie' : ''}</span>
      <button class="secondary-button pb-open" data-id="${row.id}" data-ply="${plys[0]}">Ouvrir</button>
      <button class="secondary-button pb-print" data-id="${row.id}" data-ply="${plys[0]}">Imprimer</button>
    </div>`;
    }).join('');
    box.querySelectorAll('.pb-open').forEach(button => button.addEventListener('click', () =>
      openGame(Number(button.dataset.id), Number(button.dataset.ply))));
    box.querySelectorAll('.pb-print').forEach(button => button.addEventListener('click', () =>
      printGameRow({ id: Number(button.dataset.id), ply: Number(button.dataset.ply) })));
  }

  /* ------------------------------- import ------------------------------- */
  let importStart = 0;
  let resumeMode = false;
  async function startImport(files, options) {
    importStart = Date.now();
    q('pb-progress').hidden = false;
    q('pb-report').hidden = true;
    q('pb-log').innerHTML = '';
    q('pb-pause').disabled = false;
    q('pb-cancel').disabled = false;
    q('pb-pause').dataset.state = '';
    q('pb-pause').textContent = 'Pause';
    q('pb-resume').hidden = true;
    try {
      const result = await call('importFiles', { files, opts: options || {} });
      q('pb-progress').hidden = true;
      q('pb-pause').disabled = true;
      q('pb-cancel').disabled = true;
      showImportReport(result.stats, result.games, result.players);
      await refreshStats();
      await loadPlayersList();
    } catch (error) {
      toast('Import : ' + error.message);
      q('pb-pause').disabled = true;
      q('pb-cancel').disabled = true;
    }
  }

  function showImportReport(stats, games, players) {
    const reasons = Object.entries(stats.reasons || {}).sort((a, b) => b[1] - a[1]);
    const report = q('pb-report');
    report.hidden = false;
    report.innerHTML = `<div class="pb-kv" style="margin-top:10px">
        <div><b>${fmt(stats.imported)}</b><span>importées</span></div>
        <div><b>${fmt(stats.dupes)}</b><span>doublons</span></div>
        <div><b>${fmt(stats.skipped)}</b><span>ignorées</span></div>
        <div><b>${fmt(stats.partial)}</b><span>tronquées</span></div>
        <div><b>${fmt(games)}</b><span>en base</span></div>
        <div><b>${fmt(players)}</b><span>joueurs</span></div>
      </div>` +
      (reasons.length ? '<h3 class="pb-h3">Motifs d’ignorés</h3><div class="pb-list">' +
        reasons.map(([reason, count]) => `<div class="pb-row"><span class="pb-row-text">${esc(reason)}</span><span class="pb-row-meta"><b>${fmt(count)}</b></span></div>`).join('') + '</div>' : '');
    lastImport = { imported: stats.imported, ms: Date.now() - importStart };
  }

  function logLine(html) {
    const line = document.createElement('div');
    line.className = 'pb-row';
    line.innerHTML = html;
    q('pb-log').prepend(line);
    while (q('pb-log').children.length > 30) q('pb-log').lastElementChild.remove();
  }

  onEvent(message => {
    switch (message.type) {
      case 'importProgress': {
        const done = message.bytes || 0;
        const total = message.size || 1;
        const percent = Math.min(100, Math.round(1000 * done / total) / 10);
        q('pb-bar-fill').style.width = percent + '%';
        q('pb-progress-line').textContent = `${message.name || ''} · ${percent} % · ${fmt(message.games)} parties lues · ${fmt(message.imported)} importées · ${fmt(message.dupes)} doublons`;
        q('pb-m-games').textContent = fmt(message.games || 0);
        q('pb-m-ms').textContent = message.games ? (message.ms / message.games).toFixed(2) : '—';
        q('pb-m-rate').textContent = message.games ? Math.round(message.games / Math.max(0.001, message.ms / 1000)).toLocaleString('fr-FR') : '—';
        if (performance.memory) q('pb-m-heap').textContent = mb(performance.memory.usedJSHeapSize);
        break;
      }
      case 'fileDone':
        logLine(`<span class="pb-row-text"><b>${esc(message.name)}</b><small>${fmt(message.st.imported)} importées · ${fmt(message.st.dupes)} doublons · ${fmt(message.st.skipped)} ignorées · ${fmt(message.st.partial)} tronquées</small></span>`);
        break;
      case 'paused':
        toast('Import en pause : il reprendra au même octet.');
        break;
      case 'searchProgress': {
        const percent = message.total ? Math.min(100, Math.round(1000 * message.scanned / message.total) / 10) : 0;
        q('pb-sr-progress').hidden = false;
        q('pb-sr-progress').firstElementChild.style.width = percent + '%';
        q('pb-sr-status').textContent = `${fmt(message.scanned)} / ${fmt(message.total)} parties · ${fmt(message.matched)} correspondances · ${fmt(message.ms)} ms`;
        break;
      }
      case 'indexProgress':
        q('pb-idx-progress').hidden = false;
        q('pb-idx-progress').firstElementChild.style.width = (message.total ? Math.round(1000 * message.n / message.total) / 10 : 0) + '%';
        q('pb-idx-status').textContent = `Indexation : ${fmt(message.n)} / ${fmt(message.total)} parties`;
        break;
      case 'indexDone':
        q('pb-idx-progress').hidden = true;
        q('pb-idx-status').textContent = `Index reconstruit : ${fmt(message.records)} positions, ${mb(message.bytes)}, ${fmt(message.ms)} ms`;
        break;
      case 'notice':
        logLine(`<span class="pb-row-text"><small>${esc(message.text)}</small></span>`);
        break;
      default:
        break;
    }
  });

  /* ------------------------------- base ------------------------------- */
  async function refreshStats() {
    try {
      const stats = await call('stats');
      q('pb-db-games').textContent = fmt(stats.games);
      q('pb-db-players').textContent = fmt(stats.players);
      q('pb-db-pos').textContent = stats.index ? fmt(stats.index.records) : '—';
      q('pb-db-index').textContent = stats.index ? mb(stats.index.bytes) : '—';
      q('pb-db-usage').textContent = stats.usage ? mb(stats.usage) : '—';
      q('pb-m-store').textContent = stats.usage ? mb(stats.usage) : '—';
      q('pb-m-index').textContent = stats.index ? mb(stats.index.bytes) : '—';
      if (stats.index) q('pb-idx-ply').value = stats.index.ply || 30;
      if (navigator.storage && navigator.storage.estimate) {
        const estimate = await navigator.storage.estimate();
        q('pb-db-quota').textContent = estimate.quota ? mb(estimate.quota) : '—';
      }
      if (stats.jobs && stats.jobs.length) showResume(stats.jobs[0]);
    } catch (error) {
      console.warn('Base · stats', error.message);
    }
  }

  function showResume(job) {
    q('pb-resume').hidden = false;
    q('pb-resume-text').textContent = `Le fichier « ${job.name} » n’a été traité qu’en partie (${fmt(job.offset)} octets sur ${fmt(job.size)}). Sélectionnez à nouveau ce fichier pour poursuivre : les parties déjà importées ne seront pas dupliquées.`;
  }

  async function loadPlayersList() {
    try {
      const players = await call('listPlayers', { q: '', limit: 500 });
      q('pb-players').innerHTML = players.map(player => `<option value="${esc(player.name)}"></option>`).join('');
    } catch { /* base vide */ }
  }

  async function loadAliases() {
    try {
      const init = await call('init');
      renderAliases(init.aliases || []);
      if (init.pendingJobs && init.pendingJobs.length) showResume(init.pendingJobs[0]);
      if (init.index && init.index.ply) q('pb-idx-ply').value = init.index.ply;
      q('pb-m-games').textContent = fmt(init.games);
    } catch (error) {
      console.warn('Base · init', error.message);
    }
  }

  function renderAliases(rows) {
    const box = q('pb-al-list');
    if (!rows.length) { box.innerHTML = '<p class="study-context">Aucun alias.</p>'; return; }
    box.innerHTML = rows.map((row, index) => `<div class="pb-row">
      <span class="pb-row-text"><b>${esc(row.fromLabel || row.from)}</b><small>→ ${esc(row.toLabel || row.to)}</small></span>
      <button class="secondary-button" data-alias="${index}">✕</button>
    </div>`).join('');
    box.querySelectorAll('[data-alias]').forEach(button => button.addEventListener('click', async () => {
      const updated = await call('aliasRemove', { i: Number(button.dataset.alias) });
      renderAliases(updated);
    }));
  }

  /* ------------------------------- partage ------------------------------- */
  async function download(textOrBlob, filename, type) {
    const blob = textOrBlob instanceof Blob ? textOrBlob : new Blob([textOrBlob], { type: type || 'text/plain' });
    try {
      const file = new File([blob], filename, { type: blob.type || 'application/octet-stream' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: filename });
        return;
      }
    } catch { /* partage refusé : téléchargement */ }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
    toast('Fichier « ' + filename + ' » préparé.');
  }

  /* ------------------------------- interop PIONICIDE ------------------------------- */
  /* Charge une partie de la base au format attendu par les autres écrans. */
  async function gameDraft(row) {
    const game = await call('getGame', { id: row.id });
    if (!game) return null;
    const start = { board: Array(51).fill('e'), side: 'w' };
    for (let square = 1; square <= 50; square++) start.board[square] = 'e';
    for (let square = 31; square <= 50; square++) start.board[square] = 'w';
    for (let square = 1; square <= 20; square++) start.board[square] = 'b';
    const moves = decodeMoves(game.mv).map(toAppMove);
    return {
      start,
      moves,
      headers: { White: game.w, Black: game.b, Event: game.ev, Date: game.dt, Result: game.r },
      result: game.r,
      title: `${game.w} — ${game.b} · ${game.ev || 'partie de la base'} · résultat ${game.r}`,
    };
  }

  async function analyseInApp(row) {
    try {
      const draft = await gameDraft(row);
      if (!draft) { toast('Partie introuvable'); return; }
      store.analysisDraft = { ...draft, cursor: Math.min(row.ply || 0, draft.moves.length) };
      navigate('analyse');
    } catch (error) {
      toast('Erreur : ' + error.message);
    }
  }

  /* Ouvre la même partie dans l'écran « Partie commentée ». */
  async function studyInApp(row) {
    try {
      const draft = await gameDraft(row);
      if (!draft) { toast('Partie introuvable'); return; }
      store.studyDraft = {
        start: draft.start, moves: draft.moves, headers: draft.headers,
        result: draft.result, source: 'Partie de la base de parties',
      };
      navigate('etude');
    } catch (error) {
      toast('Erreur : ' + error.message);
    }
  }

  function playFromPosition() {
    const position = explorerPosition();
    const board = cellsToAppBoard(Array.from({ length: 51 }, (_, i) => (i === 0 ? 0 : position.pieceAt(i))));
    store.playDraft = {
      board,
      side: position.side === 0 ? 'w' : 'b',
      human: position.side === 0 ? 'w' : 'b',
      label: 'Position de la base de parties',
    };
    navigate('jouer');
  }

  function sendToStructure() {
    const position = explorerPosition();
    const cells = new Uint8Array(51);
    for (let square = 1; square <= 50; square++) cells[square] = position.pieceAt(square);
    editorMarks = cells;
    q('pb-st-name').value = 'Structure de la position';
    paintStructureBoard();
    syncLineFromMarks();
    paintSearchBoard();
    updateSearchSummary();
    setTab('structures');
    toast('Position copiée dans l’éditeur : ajustez les cases libres.');
  }

  /* ------------------------------- onglets ------------------------------- */
  function setTab(name) {
    activeTab = name;
    qa('.pb-tab').forEach(button => button.classList.toggle('is-on', button.dataset.tab === name));
    qa('.pb-view').forEach(view => { view.hidden = view.dataset.view !== name; });
    if (name === 'explorer') refreshExplorer();
    if (name === 'search') { paintSearchBoard(); updateSearchSummary(); }
    if (name === 'base') refreshStats();
  }

  /* ------------------------------- écouteurs ------------------------------- */
  qa('.pb-tab').forEach(button => button.addEventListener('click', () => setTab(button.dataset.tab)));

  q('pb-file').addEventListener('change', event => {
    const files = Array.from(event.target.files || []);
    event.target.value = '';
    if (!files.length) return;
    startImport(files, { resume: resumeMode });
    resumeMode = false;
  });
  q('pb-resume-file').addEventListener('change', event => {
    const files = Array.from(event.target.files || []);
    event.target.value = '';
    if (!files.length) return;
    resumeMode = true;
    startImport(files, { resume: true });
    resumeMode = false;
  });
  q('pb-resume-drop').addEventListener('click', () => { q('pb-resume').hidden = true; });
  q('pb-pause').addEventListener('click', async () => {
    const button = q('pb-pause');
    if (button.dataset.state === 'paused') { await call('resume'); button.dataset.state = ''; button.textContent = 'Pause'; }
    else { await call('pause'); button.dataset.state = 'paused'; button.textContent = 'Reprendre'; }
  });
  q('pb-cancel').addEventListener('click', async () => {
    await call('cancel');
    q('pb-pause').disabled = true;
    q('pb-cancel').disabled = true;
    toast('Import arrêté.');
  });

  q('pb-first').addEventListener('click', () => { explorerHistory = []; gameCursor = 0; explorerSel = 0; refreshExplorer(); });
  q('pb-back').addEventListener('click', () => { if (explorerHistory.length) { explorerHistory.pop(); gameCursor = Math.max(0, gameCursor - 1); explorerSel = 0; refreshExplorer(); } });
  q('pb-fwd').addEventListener('click', () => {
    if (!currentGame || gameCursor >= currentGame.internal.length) { toast('Fin de la partie.'); return; }
    explorerHistory = currentGame.internal.slice(0, gameCursor + 1);
    gameCursor++;
    explorerSel = 0;
    refreshExplorer();
  });
  q('pb-flip').addEventListener('click', () => {
    explorerOrientation = explorerOrientation === 'w' ? 'b' : 'w';
    paintExplorer();
  });
  q('pb-reset').addEventListener('click', () => { explorerHistory = []; currentGame = null; gameCursor = 0; explorerSel = 0; refreshExplorer(); });
  q('pb-print-position').addEventListener('click', printExplorerPosition);
  q('pb-use-struct').addEventListener('click', sendToStructure);
  q('pb-play-position').addEventListener('click', playFromPosition);
  q('pb-analyse').addEventListener('click', () => {
    if (!currentGame) { toast('Ouvrez d’abord une partie de la base.'); return; }
    analyseInApp({ id: currentGame.id, ply: gameCursor });
  });
  q('pb-study').addEventListener('click', () => {
    if (!currentGame) { toast('Ouvrez d’abord une partie de la base.'); return; }
    studyInApp({ id: currentGame.id, ply: gameCursor });
  });
  q('pb-position-games').hidden = false;
  q('pb-f-apply').addEventListener('click', loadPositionGames);
  q('pb-f-clear').addEventListener('click', () => {
    ['pb-f-player', 'pb-f-from', 'pb-f-to', 'pb-f-event'].forEach(id => { q(id).value = ''; });
    q('pb-f-color').value = '';
    loadPositionGames();
  });

  q('pb-st-clear').addEventListener('click', () => {
    editorMarks = new Uint8Array(51);
    paintStructureBoard(); syncLineFromMarks(); paintSearchBoard(); updateSearchSummary();
  });
  q('pb-st-line-apply').addEventListener('click', () => {
    try {
      editorMarks = parseStructure(q('pb-st-line').value).cells.slice();
      paintStructureBoard(); syncLineFromMarks(); paintSearchBoard(); updateSearchSummary();
      toast('Structure importée depuis la chaîne.');
    } catch (error) { toast('Chaîne invalide : ' + error.message); }
  });
  q('pb-st-save').addEventListener('click', () => {
    const name = (q('pb-st-name').value || '').trim() || 'Structure sans nom';
    const line = structureToLine({ cells: editorMarks });
    if (!line.replace(/\./g, '')) { toast('Structure vide : placez au moins une contrainte.'); return; }
    const entry = { nom: name, line, obj: objectFromMarks(editorMarks, name) };
    const existing = savedStructures.findIndex(structure => structure.nom === name);
    if (existing >= 0) savedStructures[existing] = entry; else savedStructures.push(entry);
    persistStructures();
    toast('Structure « ' + name + ' » enregistrée.');
  });
  q('pb-st-export').addEventListener('click', () => {
    if (!savedStructures.length) { toast('Aucune structure à exporter.'); return; }
    download(JSON.stringify(savedStructures.map(structure => structure.obj || objectFromMarks(parseStructure(structure.line).cells, structure.nom)), null, 2),
      'pionicide-structures.json', 'application/json');
  });
  q('pb-st-import').addEventListener('change', async event => {
    const file = event.target.files[0];
    event.target.value = '';
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      const list = Array.isArray(data) ? data : [data];
      let added = 0;
      for (const object of list) {
        try {
          const cells = marksFromObject(object);
          const name = (object.nom || object.name || 'Structure importée').trim();
          savedStructures.push({ nom: name, line: structureToLine({ cells }), obj: objectFromMarks(cells, name) });
          added++;
        } catch { /* structure illisible : on continue */ }
      }
      persistStructures();
      toast(added + ' structure(s) importée(s).');
    } catch (error) { toast('JSON illisible : ' + error.message); }
  });
  q('pb-st-search').addEventListener('click', () => {
    const name = (q('pb-st-name').value || '').trim();
    const line = structureToLine({ cells: editorMarks });
    if (!line.replace(/\./g, '')) { toast('Structure vide.'); return; }
    const index = savedStructures.findIndex(structure => structure.nom === name);
    q('pb-sr-struct').value = index >= 0 ? String(index) : '';
    setTab('search');
    runSearch();
  });
  q('pb-sr-struct').addEventListener('change', () => { paintSearchBoard(); updateSearchSummary(); });
  q('pb-sr-run').addEventListener('click', runSearch);
  q('pb-sr-stop').addEventListener('click', () => {
    searchToken++;
    q('pb-sr-status').textContent = 'Recherche interrompue.';
    q('pb-sr-progress').hidden = true;
    q('pb-sr-run').disabled = false;
    q('pb-sr-stop').disabled = true;
  });

  q('pb-db-refresh').addEventListener('click', refreshStats);
  q('pb-db-persist').addEventListener('click', async () => {
    if (!navigator.storage || !navigator.storage.persist) { toast('API non disponible'); return; }
    const granted = await navigator.storage.persist();
    const badge = q('pb-db-persist-state');
    badge.textContent = granted ? 'persistant accordé' : 'refusé';
    badge.classList.toggle('pb-ok', granted);
  });
  q('pb-db-export').addEventListener('click', async () => {
    q('pb-db-progress').hidden = false;
    q('pb-db-progress').firstElementChild.style.width = '30%';
    q('pb-db-status').textContent = 'Préparation de l’archive…';
    try {
      const result = await call('exportBase');
      q('pb-db-progress').firstElementChild.style.width = '100%';
      q('pb-db-status').textContent = `Archive : ${fmt(result.count)} parties, ${mb(result.size)}.`;
      await download(result.blob, 'pionicide-base-' + new Date().toISOString().slice(0, 10) + '.pbase');
      window.setTimeout(() => { q('pb-db-progress').hidden = true; }, 600);
    } catch (error) {
      q('pb-db-status').textContent = 'Erreur : ' + error.message;
      q('pb-db-progress').hidden = true;
    }
  });
  q('pb-db-import').addEventListener('change', async event => {
    const file = event.target.files[0];
    event.target.value = '';
    if (!file) return;
    q('pb-db-progress').hidden = false;
    q('pb-db-status').textContent = 'Restauration de la base…';
    try {
      const result = await call('importBase', { file });
      q('pb-db-progress').firstElementChild.style.width = '100%';
      q('pb-db-status').textContent = `${fmt(result.added)} parties ajoutées · ${fmt(result.games)} en base · ${fmt(result.players)} joueurs.`;
      await refreshStats();
      await loadPlayersList();
    } catch (error) {
      q('pb-db-status').textContent = 'Erreur : ' + error.message;
      q('pb-db-progress').hidden = true;
    }
  });
  q('pb-idx-rebuild').addEventListener('click', async () => {
    const ply = Math.max(6, Math.min(30, parseInt(q('pb-idx-ply').value, 10) || 30));
    if (!window.confirm(`Reconstruire l’index des ${ply} premiers demi-coups ?`)) return;
    try {
      const result = await call('rebuildIndex', { ply });
      toast('Index reconstruit : ' + fmt(result.records) + ' positions.');
      await refreshStats();
    } catch (error) { toast('Erreur : ' + error.message); }
  });
  q('pb-mt-dupes').addEventListener('click', async () => {
    q('pb-idx-status').textContent = 'Analyse…';
    try {
      const result = await call('scanDuplicates');
      q('pb-idx-status').textContent = `${fmt(result.dupes)} doublon(s) sur ${fmt(result.games)} parties uniques.`;
    } catch (error) { q('pb-idx-status').textContent = 'Erreur : ' + error.message; }
  });
  q('pb-mt-clear').addEventListener('click', async () => {
    if (!window.confirm('Supprimer toutes les parties et l’index de la base ?')) return;
    await call('clearBase');
    q('pb-idx-status').textContent = 'Base vidée.';
    await refreshStats();
  });
  q('pb-al-add').addEventListener('click', async () => {
    const from = q('pb-al-from').value.trim();
    const to = q('pb-al-to').value.trim();
    if (!from || !to) { toast('Renseignez la variante et le nom canonique.'); return; }
    const rows = await call('aliasAdd', { from, to });
    q('pb-al-from').value = '';
    q('pb-al-to').value = '';
    renderAliases(rows);
    toast('Alias ajouté.');
  });
  q('pb-al-apply').addEventListener('click', async () => {
    if (!window.confirm('Réécrire les clés joueurs de toute la base ?')) return;
    toast('Application des alias…');
    try {
      const result = await call('aliasApply');
      toast(`${fmt(result.n)} parties examinées · ${fmt(result.players)} joueurs distincts.`);
      await refreshStats();
      await loadPlayersList();
    } catch (error) { toast('Erreur : ' + error.message); }
  });

  /* ------------------------------- cycle de vie ------------------------------- */
  return {
    el,
    mount() {
      if (mounted) return;
      mounted = true;
      loadStructures();
      paintStructureBoard();
      syncLineFromMarks();
      paintExplorer();
      paintSearchBoard();
      updateSearchSummary();
      setTab('import');
      ensureWorker();
      (async () => {
        await loadAliases();
        await refreshStats();
        await loadPlayersList();
        await refreshExplorer();
      })();
      if (explorerHistory.length || currentGame) refreshExplorer();
    },
    unmount() {
      mounted = false;
      waiting.forEach(pending => pending.reject(new Error('page fermée')));
      waiting.clear();
      if (worker) { worker.terminate(); worker = null; }
    },
    // Point d'entrée pour les autres pages : ouvrir la base sur une partie précise.
    openGame(id, ply) { return openGame(id, ply); },
    analyseInApp,
    playFromPosition,
  };
}
