/* PIONICIDE · Étude d'une partie — calcul des faits.

   Règle absolue de ce module : aucune phrase n'est inventée. Chaque commentaire
   est construit à partir d'un chiffre effectivement présent dans la base de
   parties (nombre de parties, gains, nulles, pertes) ou d'une évaluation du
   moteur PIONICIDE, et chaque ligne porte l'étiquette de sa source.

   Le module est pur : il ne touche ni au DOM, ni au worker, ni au moteur. Les
   données de base et les évaluations arrivent par paramètres, ce qui permet de
   le tester sous Node avec le jeu de parties de `fixtures/`.

   Vocabulaire des sources :
     · « base »   : statistiques de la base de parties de l'utilisateur ;
     · « moteur » : évaluation PIONICIDE à profondeur fixe.
   Quand une source manque, elle est absente du commentaire — jamais remplacée
   par une supposition.
*/

/* ------------------------------------------------------------------ formats */

const NBSP = '\u00a0';
const int = value => Number(value || 0).toLocaleString('fr-FR');
const dec = value => (Math.round(value * 10) / 10).toFixed(1).replace('.', ',');
const sign = value => (value > 0 ? '+' : value < 0 ? '−' : '±') + dec(Math.abs(value));

/** Pluriel simple : `accords(2, 'partie')` → « 2 parties ». */
export function accords(n, mot, pluriel = null) {
  return `${int(n)}${NBSP}${n > 1 ? (pluriel || `${mot}s`) : mot}`;
}

/** Évaluation en pions, vue des Blancs, telle que l'affiche l'application. */
export function formatEval(value) {
  if (!Number.isFinite(value)) return '—';
  if (Math.abs(value) >= 90) return value > 0 ? '+∞' : '−∞';
  return sign(value);
}

/** Nombre de pièces restantes sur un damier (indice = case FMJD). */
export function pieceCount(board) {
  let total = 0;
  for (let square = 1; square <= 50; square += 1) {
    if (board[square] && board[square] !== 'e') total += 1;
  }
  return total;
}

/* ------------------------------------------------------------- étiquettes */

/**
 * Notation d'un coup de la base (`{from,to,caps,path}`) : 34x23, 28-22…
 * Même convention que le module Base de parties.
 */
export function baseMoveLabel(move) {
  if (!move) return '';
  const chain = (move.path && move.path.length) ? move.path : [move.to];
  let out = String(move.from);
  for (const square of chain) out += `${move.caps && move.caps.length ? 'x' : '-'}${square}`;
  return out;
}

/** Deux coups désignent-ils la même chose ? (départ, arrivée, prises) */
export function sameMove(a, b) {
  if (!a || !b) return false;
  if (a.from !== b.from || a.to !== b.to) return false;
  const capsA = (a.caps || a.captured || []).slice().sort((x, y) => x - y);
  const capsB = (b.caps || b.captured || []).slice().sort((x, y) => x - y);
  if (capsA.length !== capsB.length) return false;
  return capsA.every((square, index) => square === capsB[index]);
}

/* ------------------------------------------------------ statistiques de base */

/** Rendement d'un coup dans la base : (gains + ½ nulles) / parties, ou null. */
export function performance(move) {
  if (!move || !move.n) return null;
  return (move.w + move.d / 2) / move.n;
}

/** Rendement en points de pourcentage (0 à 100), ou null. */
export function performancePoints(move) {
  const value = performance(move);
  return value === null ? null : value * 100;
}

/**
 * Qualité de l'échantillon. Sert à interdire les conclusions sur trois parties.
 * @returns {{key: string, label: string, min: number}}
 */
export function sampleClass(n) {
  if (!n) return { key: 'absent', label: 'absent de la base', min: 0 };
  if (n >= 20) return { key: 'etabli', label: 'échantillon établi', min: 20 };
  if (n >= 5) return { key: 'mince', label: 'échantillon mince', min: 5 };
  return { key: 'anecdotique', label: 'échantillon anecdotique', min: 1 };
}

/** Ligne de statistiques d'un coup : « 12 parties · 7 gains, 2 nulles, 3 pertes ». */
export function describeStats(move) {
  if (!move || !move.n) return 'aucune partie';
  return `${accords(move.n, 'partie')}${NBSP}· ${int(move.w)} gain${move.w > 1 ? 's' : ''}, `
    + `${int(move.d)} nulle${move.d > 1 ? 's' : ''}, ${int(move.l)} perte${move.l > 1 ? 's' : ''}`;
}

/** Retrouve les statistiques du coup joué dans la liste des coups de la base. */
export function moveStats(moves, move) {
  if (!Array.isArray(moves) || !move) return null;
  return moves.find(candidate => sameMove(candidate, move)) || null;
}

/**
 * Bascule les compteurs du point de vue de l'index vers celui du joueur.
 *
 * L'index de la base (bumpResult) enregistre les résultats **du point de vue
 * du camp au trait dans la position visée**, c'est-à-dire de l'adversaire de
 * celui qui vient de jouer. Pour commenter un coup, la seule lecture utile est
 * celle du camp qui l'a joué : on échange donc gains et pertes. Les nulles, le
 * total et les résultats inconnus ne changent pas.
 */
export function moverStats(entry) {
  if (!entry) return null;
  return { ...entry, w: entry.l || 0, l: entry.w || 0, d: entry.d || 0, n: entry.n || 0 };
}

/** Applique `moverStats` à une liste de coups de la base. */
export function moverView(moves) {
  return (moves || []).map(moverStats);
}

/**
 * Classe les coups de la base par rendement décroissant.
 * @param {Array}  moves
 * @param {number} minSample  nombre de parties minimal pour être classé
 */
export function rankBaseMoves(moves, minSample = 5) {
  const list = (moves || []).filter(move => move && move.n > 0);
  const ranked = list
    .filter(move => move.n >= minSample)
    .slice()
    .sort((a, b) => (performance(b) - performance(a)) || (b.n - a.n));
  const leader = list.slice().sort((a, b) => (b.n - a.n) || (performance(b) - performance(a)))[0] || null;
  const bestAll = list.slice().sort((a, b) => (performance(b) - performance(a)) || (b.n - a.n))[0] || null;
  return { ranked, best: ranked[0] || null, leader, bestAll, eligible: ranked.length };
}

/* ------------------------------------------------------------- réglages */

export const STUDY_DEFAULTS = Object.freeze({
  minSample: 5,      // parties minimales pour comparer deux coups de la base
  gapPoints: 10,     // écart de rendement (points) qui rend un coup « minoritaire »
  error: 0.5,        // perte en pions → « ? »
  blunder: 1.5,      // perte en pions → « ?? »
  strongEval: 2,     // position déjà tranchée : un « ! » mérite d'être signalé
  maxMoments: 14,    // nombre maximal de moments commentés
  criticalPieces: 12, // seuil de finale
  theoryPlies: 12,   // plies d'ouverture quand la base ne couvre pas le début
});

/* ------------------------------------------------- construction des faits */

/**
 * Construit les faits de chaque demi-coup.
 *
 * @param {object}   input
 * @param {Array}    input.states   positions successives (n + 1 entrées)
 * @param {Array}    input.moves    coups joués (n entrées, format application)
 * @param {string[]} input.labels   notation PDN de ces coups
 * @param {Function} input.baseAt   (index) → {moves:[…]}|null ; null = base indisponible
 * @param {Array}    input.engine   résultats d'annotation : [{loss, scoreBefore, evalBeforeWhite, evalAfterWhite, best}]
 * @param {object}   input.options  seuils (voir STUDY_DEFAULTS)
 */
export function buildPlyFacts({ states = [], moves = [], labels = [], baseAt = () => null, engine = [], options = {} }) {
  const opts = { ...STUDY_DEFAULTS, ...options };
  const indexPly = Number.isFinite(opts.indexPly) ? opts.indexPly : null;
  const total = moves.length;
  const plies = [];

  for (let i = 0; i < total; i += 1) {
    const label = labels[i] || '';
    const move = moves[i];
    const state = states[i];
    const base = typeof baseAt === 'function' ? baseAt(i) : null;
    const enginePly = engine[i] || null;

    // Les statistiques sont ramenées au point de vue du camp qui a joué.
    const baseMoves = base ? moverView(base.moves) : [];
    const coverage = baseMoves.reduce((sum, entry) => sum + (entry.n || 0), 0);
    const mine = base ? moveStats(baseMoves, move) : null;
    const ranking = base ? rankBaseMoves(baseMoves, opts.minSample) : null;

    const played = {
      n: mine?.n || 0,
      w: mine?.w || 0,
      d: mine?.d || 0,
      l: mine?.l || 0,
      perf: performancePoints(mine),
      share: coverage ? (mine?.n || 0) / coverage : null,
      inBase: !!mine,
    };

    const best = ranking?.best || null;
    const gap = (best && played.perf !== null && best !== mine)
      ? performancePoints(best) - played.perf
      : null;

    const loss = Number.isFinite(enginePly?.loss) ? enginePly.loss : null;
    const isBest = !!enginePly?.best && enginePly.best === label;

    const outOfIndex = indexPly !== null && i >= indexPly;
    const flags = {
      outOfIndex,
      novel: !!base && coverage === 0 && !outOfIndex,                       // position inconnue de la base
      unplayed: !!base && coverage > 0 && played.n === 0,    // position connue, coup jamais joué
      minority: !!base && !!best && gap !== null && gap >= opts.gapPoints
        && played.n >= opts.minSample && best.n >= opts.minSample,
      error: loss !== null && !isBest && loss >= opts.error && loss < opts.blunder,
      blunder: loss !== null && !isBest && loss >= opts.blunder,
      strong: isBest && Number.isFinite(enginePly?.evalBeforeWhite)
        && Math.abs(enginePly.evalBeforeWhite) >= opts.strongEval,
      forced: baseMoves.length === 1,
    };

    plies.push({
      index: i,
      label,
      side: state?.side || 'w',
      // Copie du damier : le document imprimé place le diagramme avant le coup.
      position: state ? { board: state.board.slice(), side: state.side } : null,
      moveNumber: Math.floor(i / 2) + 1,
      pieces: state ? pieceCount(state.board) : null,
      baseAvailable: !!base,
      outOfIndex,
      coverage,
      played,
      best: best ? { label: baseMoveLabel(best), n: best.n, perf: performancePoints(best), move: best } : null,
      leader: ranking?.leader ? { label: baseMoveLabel(ranking.leader), n: ranking.leader.n } : null,
      alternatives: ranking ? ranking.ranked.slice(0, 4).map(entry => ({
        label: baseMoveLabel(entry), n: entry.n, perf: performancePoints(entry),
      })) : [],
      gap,
      engine: enginePly ? {
        loss,
        scoreBefore: enginePly.scoreBefore ?? null,
        evalBeforeWhite: enginePly.evalBeforeWhite ?? null,
        evalAfterWhite: enginePly.evalAfterWhite ?? null,
        best: enginePly.best || '',
        isBest,
        depth: enginePly.depth ?? null,
      } : null,
      flags,
    });
  }

  return plies;
}

/* ------------------------------------------------------- sélection des moments */

const WEIGHT = { blunder: 60, error: 40, minority: 30, unplayed: 26, novel: 22, strong: 12, forced: 0 };

/** Poids d'un demi-coup : sert uniquement à choisir les moments les plus parlants. */
export function momentWeight(ply) {
  const flags = ply.flags || {};
  let weight = 0;
  for (const [key, value] of Object.entries(WEIGHT)) if (flags[key]) weight += value;
  weight += Math.min(10, Number(ply.engine?.loss) || 0) * 4;
  weight += Math.min(20, Math.max(0, ply.gap || 0)) / 2;
  if (flags.forced) weight = 0;
  return weight;
}

export function isMoment(ply) {
  const flags = ply.flags || {};
  return !!(flags.blunder || flags.error || flags.minority || flags.unplayed || flags.novel || flags.strong);
}

/**
 * Choisit les moments commentés, puis les remet dans l'ordre de la partie.
 * Le premier écart avec la base et le plus gros écart du moteur sont toujours
 * conservés, quelle que soit la limite.
 */
export function selectMoments(plies, options = {}) {
  const opts = { ...STUDY_DEFAULTS, ...options };
  const candidates = plies.filter(isMoment);
  if (!candidates.length) return [];
  const scored = candidates.map(ply => ({ ply, weight: momentWeight(ply) }))
    .sort((a, b) => (b.weight - a.weight) || (a.ply.index - b.ply.index));
  const keep = new Set();
  const firstNovel = candidates.find(ply => ply.flags.novel || ply.flags.unplayed);
  if (firstNovel) keep.add(firstNovel.index);
  const biggestLoss = candidates.slice().sort((a, b) => (b.engine?.loss || 0) - (a.engine?.loss || 0))[0];
  if (biggestLoss && (biggestLoss.engine?.loss || 0) > 0) keep.add(biggestLoss.index);
  for (const entry of scored) {
    if (keep.size >= opts.maxMoments) break;
    keep.add(entry.ply.index);
  }
  return plies.filter(ply => keep.has(ply.index)).sort((a, b) => a.index - b.index);
}

/* ------------------------------------------------------------- les phrases */

/** Étiquette courte du moment, telle qu'elle apparaîtra en marge. */
export function momentBadge(ply) {
  const flags = ply.flags;
  if (flags.blunder) return 'GAFFE';
  if (flags.error) return 'ERREUR';
  if (flags.minority) return 'MINORITAIRE';
  if (flags.unplayed) return 'COUP NOUVEAU';
  if (flags.novel) return 'POSITION INÉDITE';
  if (flags.strong) return 'MEILLEUR COUP';
  return 'REPÈRE';
}

/** Titre du moment : « 12. 34-29 — position inédite ». */
export function momentTitle(ply, index = 0) {
  const flags = ply.flags;
  const what = flags.blunder || flags.error ? 'écart du moteur'
    : flags.minority ? 'coup minoritaire dans la base'
      : flags.unplayed ? 'coup jamais joué dans cette position'
        : flags.novel ? 'sortie de la base'
          : flags.strong ? 'meilleur coup selon le moteur' : 'repère';
  const number = `${ply.moveNumber}${ply.side === 'w' ? '.' : '…'}`;
  return `${number} ${ply.label} — ${what}`;
}

/**
 * Faits de base pour un demi-coup. Chaque élément est une phrase complète,
 * prête à imprimer, et ne contient que des chiffres de la base.
 */
export function baseSentences(ply) {
  const out = [];
  if (ply.outOfIndex) {
    out.push('L’index de la base ne couvre que les premiers demi-coups de chaque partie : '
      + 'cette position est au-delà, la base ne s’y prononce pas.');
    return out;
  }
  if (!ply.baseAvailable) {
    out.push('Base de parties indisponible pour cette position : index absent ou non interrogé.');
    return out;
  }
  if (!ply.coverage) {
    out.push(`Position absente de la base : aucune partie ne l'a atteinte.`);
    return out;
  }
  out.push(`Sur ${accords(ply.coverage, 'partie')} ayant atteint cette position, `
    + `${ply.label} a été joué ${ply.played.n ? `${int(ply.played.n)} fois (${dec(ply.played.share * 100)}${NBSP}% des parties)` : 'aucune fois'}`
    + `${ply.played.n ? ` : ${describeStats(ply.played).replace(/^\d+[\u00a0]partie[s]?\u00a0· /, '')}` : ''}.`);
  if (ply.best && (!ply.played.inBase || ply.best.label !== ply.label)) {
    out.push(`Meilleur rendement de la base (au moins ${int(STUDY_DEFAULTS.minSample)} parties) : `
      + `${ply.best.label} avec ${accords(ply.best.n, 'partie')} et ${dec(ply.best.perf)}${NBSP}% `
      + '(gains + ½ nulles).');
  }
  if (ply.gap !== null && Number.isFinite(ply.gap)) {
    out.push(`Écart de rendement : ${dec(Math.abs(ply.gap))}${NBSP}points ${ply.gap > 0 ? 'en faveur de' : 'en défaveur de'} `
      + `${ply.gap > 0 ? ply.best.label : ply.label}.`);
  }
  if (ply.leader && ply.leader.label !== ply.label && ply.played.n >= 1) {
    out.push(`Coup le plus fréquent de cette position : ${ply.leader.label} (${accords(ply.leader.n, 'partie')}).`);
  }
  if (ply.flags.unplayed) {
    out.push(`Les ${accords(ply.coverage, 'partie')} de la base ont toutes choisi un autre coup.`);
  }
  return out;
}

/** Faits de moteur pour un demi-coup. */
export function engineSentences(ply, options = {}) {
  const info = ply.engine;
  if (!info) return ['Moteur non interrogé pour cette position.'];
  const out = [];
  const depth = info.depth ? ` à la profondeur ${info.depth}` : '';
  if (Number.isFinite(info.evalBeforeWhite)) {
    const after = Number.isFinite(info.evalAfterWhite) ? ` puis ${formatEval(info.evalAfterWhite)}` : '';
    out.push(`PIONICIDE${depth} évalue la position à ${formatEval(info.evalBeforeWhite)} `
      + `(point de vue des Blancs)${after} après le coup.`);
  }
  if (info.isBest) {
    out.push('C’est le coup retenu par le moteur dans cette position.');
  } else if (info.best) {
    let better;
    if (Number.isFinite(info.loss) && info.loss >= 90) better = ', avec une issue nettement meilleure selon son évaluation (position gagnante annoncée)';
    else if (Number.isFinite(info.loss) && info.loss >= 0.05) better = `, avec ${dec(info.loss)}${NBSP}pion${info.loss > 1 ? 's' : ''} de mieux selon son évaluation`;
    else better = ', à égalité selon son évaluation';
    out.push(`Le moteur préférait ${info.best}${better}.`);
  }
  return out;
}

/**
 * « Lecture » : relie explicitement les deux sources. Chaque phrase dit
 * laquelle parle, et refuse de conclure quand l'échantillon est trop mince.
 */
export function readingSentence(ply, options = {}) {
  const opts = { ...STUDY_DEFAULTS, ...options };
  const flags = ply.flags;
  const enginePart = flags.blunder ? 'le moteur classe ce coup parmi les grosses erreurs'
    : flags.error ? 'le moteur signale une erreur'
      : flags.strong ? 'le moteur ne trouve rien de meilleur dans une position déjà tranchée'
        : ply.engine ? 'le moteur ne voit pas de perte significative' : null;

  let basePart = null;
  if (flags.minority) {
    basePart = `la base le désavoue aussi : ${dec(ply.gap)}${NBSP}points de rendement séparent ${ply.label} `
      + `de ${ply.best.label} sur au moins ${accords(Math.min(ply.played.n, ply.best.n), 'partie')}`;
  } else if (ply.played.n >= opts.minSample && ply.best && ply.best.label === ply.label) {
    basePart = 'la base le confirme : c’est le coup le plus rentable de cette position';
  } else if (ply.leader && ply.leader.label === ply.label && ply.played.n >= opts.minSample) {
    basePart = `la base ne le contredit pas : c’est le coup le plus joué ici (${accords(ply.played.n, 'partie')})`;
  } else if (flags.unplayed) {
    basePart = 'la base ne peut pas le juger : personne ne l’a joué';
  } else if (flags.novel) {
    basePart = 'la base est muette : la position n’a jamais été atteinte';
  } else if (flags.outOfIndex || !ply.baseAvailable) {
    basePart = 'la base ne se prononce pas sur cette position';
  }

  let text = '';
  if (enginePart && basePart) text = `Ici, ${enginePart} et ${basePart}.`;
  else if (enginePart) text = `Ici, ${enginePart}.`;
  else if (basePart) text = `Ici, ${basePart.charAt(0).toUpperCase()}${basePart.slice(1)}.`;
  else text = 'Aucune des deux sources ne signale ce coup.';

  const quality = sampleClass(ply.played.n);
  if (quality.key === 'anecdotique' && ply.played.n > 0) {
    text += ` Réserve : ${accords(ply.played.n, 'partie')} seulement, ce n’est pas un verdict.`;
  }
  if (flags.minority && ply.best && ply.best.n < 20) {
    text += ` Le coup de référence ${ply.best.label} ne repose lui-même que sur ${accords(ply.best.n, 'partie')}.`;
  }
  if (ply.engine && !Number.isFinite(ply.engine.loss)) {
    text += ' Évaluation du moteur incomplète pour ce coup (limite de temps ou position terminale).';
  }
  return text;
}

/* ------------------------------------------------------------ plan de l'étude */

/** Chapitre d'un demi-coup : ouverture (théorie), milieu, finale. */
export function chapterOf(ply, options = {}) {
  const opts = { ...STUDY_DEFAULTS, ...options };
  if (ply.pieces !== null && ply.pieces <= opts.criticalPieces) return 'finale';
  if (ply.baseAvailable && ply.coverage > 0) return 'ouverture';
  return 'milieu';
}

export const CHAPTERS = Object.freeze([
  { key: 'ouverture', numeral: 'I', title: 'Ouverture — la ligne dans la base' },
  { key: 'milieu', numeral: 'II', title: 'Milieu de partie — les coups décisifs' },
  { key: 'finale', numeral: 'III', title: 'Finale — position et résultat' },
]);

/**
 * Résumé chiffré de l'étude. Sert d'encadré d'ouverture et de contrôle :
 * tous les nombres affichés viennent des tableaux `plies`.
 */
export function summarize(plies, options = {}) {
  const opts = { ...STUDY_DEFAULTS, ...options };
  const covered = plies.filter(ply => ply.baseAvailable && ply.coverage > 0).length;
  const lastCovered = plies.filter(ply => ply.baseAvailable && ply.coverage > 0).at(-1);
  const firstGap = plies.find(ply => ply.flags.novel || ply.flags.unplayed);
  const blunders = plies.filter(ply => ply.flags.blunder).length;
  const errors = plies.filter(ply => ply.flags.error).length;
  const minority = plies.filter(ply => ply.flags.minority).length;
  const strong = plies.filter(ply => ply.flags.strong).length;
  const both = plies.filter(ply => (ply.flags.blunder || ply.flags.error) && ply.flags.minority).length;
  const engineOnly = plies.filter(ply => (ply.flags.blunder || ply.flags.error) && !ply.flags.minority).length;
  const baseOnly = plies.filter(ply => ply.flags.minority && !(ply.flags.blunder || ply.flags.error)).length;

  return {
    played: plies.length,
    indexPly: opts.indexPly ?? null,
    covered,
    coverageRate: plies.length ? covered / plies.length : 0,
    lastCovered,
    firstGap,
    blunders,
    errors,
    minority,
    strong,
    both,
    engineOnly,
    baseOnly,
    exactMinSample: opts.minSample,
  };
}

/** Phrases du résumé. */
export function summarySentences(summary, options = {}) {
  const out = [];
  out.push(`${accords(summary.played, 'demi-coup')} étudié${summary.played > 1 ? 's' : ''} ; `
    + `${accords(summary.covered, 'position')} retrouvée${summary.covered > 1 ? 's' : ''} dans la base `
    + `(${dec(summary.coverageRate * 100)}${NBSP}% de la partie).`);
  if (summary.lastCovered) {
    out.push(`Dernière position couverte par la base : demi-coup ${summary.lastCovered.index + 1} `
      + `(${accords(summary.lastCovered.coverage, 'partie')}).`);
  }
  if (summary.firstGap) {
    const ply = summary.firstGap;
    out.push(`${ply.flags.novel ? 'La partie quitte la base' : 'Le coup joué est nouveau pour la base'} `
      + `au demi-coup ${ply.index + 1} (${ply.moveNumber}${ply.side === 'w' ? '.' : '…'} ${ply.label}).`);
  } else if (summary.covered === summary.played) {
    out.push('La partie reste entièrement dans les lignes connues de la base.');
  }
  out.push(`Moteur : ${summary.blunders} grosse${summary.blunders > 1 ? 's' : ''} erreur${summary.blunders > 1 ? 's' : ''} (??), `
    + `${summary.errors} erreur${summary.errors > 1 ? 's' : ''} (?), et ${summary.strong} fois le meilleur coup `
    + 'dans une position déjà tranchée.');
  if (Number.isFinite(summary.indexPly) && summary.indexPly > 0 && summary.played > summary.indexPly) {
    out.push(`L’index de la base couvre les ${summary.indexPly} premiers demi-coups : au-delà, `
      + 'la base ne se prononce pas et le document l’indique.');
  }
  out.push(`Accord des deux sources : ${summary.both} coup${summary.both > 1 ? 's' : ''} désapprouvé${summary.both > 1 ? 's' : ''} `
    + `à la fois par la base et par le moteur ; ${summary.baseOnly} écart${summary.baseOnly > 1 ? 's' : ''} de rendement `
    + `sans faute démontrée ; ${summary.engineOnly} faute${summary.engineOnly > 1 ? 's' : ''} que la base ne départage pas.`);
  void options;
  return out;
}

/**
 * Texte de méthode : explique ce que les deux sources savent et ne savent pas.
 * Statique, mais affiché dans le document pour que le lecteur sache lire.
 */
export function methodNotes(options = {}) {
  const opts = { ...STUDY_DEFAULTS, ...options };
  return [
    'La base de parties ne dit pas qu’un coup est bon : elle dit combien de parties l’ont joué et ce qu’elles ont donné. '
    + `Le rendement affiché est la somme des gains et de la moitié des nulles, divisée par le nombre de parties. `
    + `Aucun classement n’est tiré d’un coup joué moins de ${int(opts.minSample)} fois.`,
    'Le moteur PIONICIDE donne une évaluation en pions, vue des Blancs, à la profondeur indiquée. '
    + `Une perte inférieure à ${dec(opts.error)} pion n’est pas signalée, une perte supérieure à ${dec(opts.blunder)} pions est une grosse erreur. `
    + 'Une recherche plus profonde peut modifier cette évaluation.',
    'Les deux sources sont toujours distinguées : « base » et « moteur ». Quand l’une se taît, le document le dit '
    + 'au lieu de compléter avec une appréciation personnelle. Aucun nom de joueur, aucun tournoi, aucune combinaison '
    + 'n’est cité s’il ne figure pas dans les données chargées.',
    'Les parties citées sous « parties » sont celles de la base qui ont atteint la position qui suit le coup. Elles '
    + 'montrent que la ligne a été jouée et avec quel résultat, mais leur résultat ne prouve pas à lui seul la valeur '
    + 'du coup : le commentaire distingue toujours les deux plans.',
  ];
}

/* ------------------------------------------------------ modèle du document */

/**
 * Ligne suivie pendant les premiers demi-coups, avec le nombre de parties de la
 * base ayant atteint sa dernière position. C'est l'équivalent du titre de
 * système d'une monographie d'ouverture — mais mesuré, pas nommé d'autorité.
 */
export function studyLine(plies, labels, plies_ = 8) {
  const count = Math.min(labels.length, plies_);
  if (!count) return null;
  const tokens = labels.slice(0, count).map((label, index) => (index % 2 === 0
    ? `${index / 2 + 1}. ${label}`
    : label));
  const last = plies[count - 1];
  return {
    text: tokens.join(' '),
    plies: count,
    games: last && last.baseAvailable ? last.coverage : 0,
    inBase: !!(last && last.baseAvailable && last.coverage > 0),
  };
}

/**
 * Assemble le modèle complet du document commenté. Le rendu (document.js) ne
 * fait ensuite que mettre en page : tout ce qui est imprimé est décidé ici.
 *
 * @returns {object} modèle { entête, résumé, méthode, chapitres, tableau, coups }
 */
export function buildStudyModel({
  headers = {}, result = '*', source = 'Partie importée',
  labels = [], plies = [], references = () => [],
  options = {}, engineInfo = null, baseInfo = null,
} = {}) {
  const opts = { ...STUDY_DEFAULTS, ...options };
  const summary = summarize(plies, { ...opts, indexPly: baseInfo?.indexPly ?? engineInfo?.indexPly ?? null });
  const moments = selectMoments(plies, opts);
  const entries = moments.map((ply, order) => ({
    ply,
    badge: momentBadge(ply),
    title: momentTitle(ply, order),
    chapter: chapterOf(ply, opts),
    diagramNumber: order + 1,
    base: baseSentences(ply, opts),
    engine: engineSentences(ply, opts),
    reading: readingSentence(ply, opts),
    references: (references(ply.index) || []).slice(0, 5),
  }));

  const chapters = CHAPTERS.map(chapter => ({
    ...chapter,
    entries: entries.filter(entry => entry.chapter === chapter.key),
  })).filter(chapter => chapter.entries.length);

  const table = plies.map(ply => {
    const covered = ply.baseAvailable && ply.coverage > 0;
    return {
      number: `${ply.moveNumber}${ply.side === 'w' ? '.' : '…'}`,
      label: ply.label,
      n: covered ? ply.played.n : null,
      perf: covered ? ply.played.perf : null,
      share: covered ? ply.played.share : null,
      loss: ply.engine && Number.isFinite(ply.engine.loss) ? ply.engine.loss : null,
      // « ! » n'est porté que lorsqu'il apprend quelque chose : le meilleur coup
      // dans une position déjà tranchée. Les erreurs sont toujours signalées.
      symbol: ply.flags.blunder ? '??' : ply.flags.error ? '?' : ply.flags.strong ? '!' : '',
      covered,
    };
  });

  return {
    title: 'Partie commentée',
    subtitle: `${headers.White || headers.Blancs || 'Blancs'} — ${headers.Black || headers.Noirs || 'Noirs'}`,
    meta: [headers.Event, headers.Site, headers.Date, result ? `résultat ${result}` : null,
      headers.WhiteElo || headers.BlackElo ? `Elo ${headers.WhiteElo || '—'} / ${headers.BlackElo || '—'}` : null]
      .filter(Boolean),
    source,
    sources: [
      baseInfo && baseInfo.games
        ? `Base de parties : ${accords(baseInfo.games, 'partie')}, index sur ${baseInfo.indexPly || 0} demi-coups`
        : 'Base de parties : vide ou non interrogée',
      engineInfo
        ? `Moteur PIONICIDE : profondeur ${engineInfo.depth ?? '—'}, ${accords(plies.length + 1, 'position')} évaluée${plies.length ? 's' : ''}`
        : 'Moteur PIONICIDE : non interrogé',
    ],
    summary,
    summaryLines: summarySentences(summary, opts),
    method: methodNotes(opts),
    line: studyLine(plies, labels),
    chapters,
    table,
    moves: labels.slice(),
    options: opts,
  };
}
