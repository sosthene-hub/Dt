/* PIONICIDE · Étude commentée — mise en page du document imprimable.

   Le document reprend la forme des monographies d'ouverture : titre, sommaire,
   chapitres numérotés, diagrammes numérotés insérés dans le texte, encadrés de
   commentaire et tableau récapitulatif.

   Ce module ne décide de rien : tout le contenu vient du modèle construit par
   `facts.js` (buildStudyModel). Il ne fait que le mettre en page et l'imprimer.
*/
import { boardSvg } from '../analysis/diagram.js';

const el = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
};

const nb = value => (Number.isFinite(value) ? String(Math.round(value * 10) / 10).replace('.', ',') : '—');

function todayFr() {
  return new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
}

/** Bloc « source » : une ligne de faits avec son étiquette. */
function sourceBlock(label, className, lines) {
  const box = el('div', `study-source ${className}`);
  box.append(el('span', 'study-source-tag', label));
  const list = el('div', 'study-source-body');
  for (const line of lines) list.append(el('p', '', line));
  box.append(list);
  return box;
}

/** Diagramme numéroté, flottant à droite du commentaire. */
function diagramFigure(entry) {
  const figure = el('figure', 'study-diagram');
  const caption = `Diagramme ${entry.diagramNumber} · avant ${entry.ply.label}`;
  figure.append(boardSvg({
    board: entry.ply.position.board,
    orientation: 'w',
    numbers: true,
    title: caption,
  }));
  figure.append(el('figcaption', '', caption));
  return figure;
}

function renderEntry(entry) {
  const section = el('section', 'study-entry');
  section.append(el('span', `study-badge study-badge-${entry.badge.toLowerCase().replace(/\s+/g, '-')}`, entry.badge));
  const heading = el('h3', 'study-entry-title', entry.title);
  section.append(heading);
  if (entry.ply.position) section.append(diagramFigure(entry));

  section.append(sourceBlock('BASE', 'study-source-base', entry.base));
  section.append(sourceBlock('MOTEUR', 'study-source-engine', entry.engine));

  if (entry.references.length) {
    const refs = el('div', 'study-source study-source-refs');
    refs.append(el('span', 'study-source-tag', 'PARTIES'));
    const body = el('div', 'study-source-body');
    body.append(el('p', 'study-refs-intro',
      entry.references.length > 1
        ? 'Parties de la base ayant atteint la position qui suit ce coup :'
        : 'Partie de la base ayant atteint la position qui suit ce coup :'));
    const list = el('ul', 'study-refs');
    for (const ref of entry.references) {
      const bits = [ref.w || 'Inconnu', ref.b || 'Inconnu'].join(' — ');
      const tail = [ref.ev, ref.dt, ref.r && `résultat ${ref.r}`].filter(Boolean).join(' · ');
      list.append(el('li', '', tail ? `${bits} · ${tail}` : bits));
    }
    body.append(list);
    refs.append(body);
    section.append(refs);
  }

  const reading = el('p', 'study-reading');
  reading.append(el('span', 'study-reading-tag', 'LECTURE'));
  reading.append(document.createTextNode(' ' + entry.reading));
  section.append(reading);
  return section;
}

/** Tableau récapitulatif de tous les demi-coups. */
function renderTable(model) {
  const wrap = el('div', 'study-table-wrap');
  const table = el('table', 'study-table');
  const thead = el('thead');
  const head = el('tr');
  for (const label of ['Coup', 'Parties', 'Part', '%', 'Perte', 'Sym.']) head.append(el('th', '', label));
  thead.append(head);
  table.append(thead);
  const body = el('tbody');
  for (const row of model.table) {
    const line = el('tr', row.covered ? '' : 'study-row-outside');
    line.append(el('td', 'study-cell-move', `${row.number} ${row.label}`));
    line.append(el('td', 'study-cell-num', row.n ? String(row.n) : '—'));
    line.append(el('td', 'study-cell-num', Number.isFinite(row.share) ? `${nb(row.share * 100)}` : '—'));
    line.append(el('td', 'study-cell-num', Number.isFinite(row.perf) ? nb(row.perf) : '—'));
    line.append(el('td', 'study-cell-num', Number.isFinite(row.loss) ? nb(row.loss) : '—'));
    line.append(el('td', 'study-cell-sym', row.symbol));
    body.append(line);
  }
  table.append(body);
  wrap.append(table);
  return wrap;
}

/** Liste complète des coups, deux colonnes comme dans la feuille de partie. */
function renderMoves(model) {
  const box = el('div', 'study-moves');
  for (let index = 0; index < model.moves.length; index += 2) {
    const line = el('div', 'study-move-line');
    line.append(el('span', 'study-mn', String(index / 2 + 1) + '.'));
    line.append(el('span', 'study-mw', model.moves[index] || ''));
    line.append(el('span', 'study-mb', model.moves[index + 1] || ''));
    box.append(line);
  }
  return box;
}

/**
 * Construit le document complet.
 * @param {object} model modèle de buildStudyModel
 */
export function buildStudySheet(model) {
  const sheet = el('article', 'study-sheet');
  sheet.id = 'study-sheet';

  const toolbar = el('div', 'sheet-toolbar');
  const printButton = el('button', 'primary-button', 'Imprimer / PDF');
  printButton.type = 'button';
  printButton.addEventListener('click', () => window.print());
  const closeButton = el('button', 'secondary-button', 'Fermer');
  closeButton.type = 'button';
  closeButton.addEventListener('click', () => sheet.remove());
  toolbar.append(printButton, closeButton,
    el('span', 'sheet-toolbar-note',
      'Dans la boîte d’impression, choisissez « Enregistrer au format PDF ». Chaque chapitre commence sur une nouvelle page.'));
  sheet.append(toolbar);

  const page = el('div', 'study-page');
  page.append(el('p', 'study-eyebrow', 'PIONICIDE · ÉTUDE D’UNE PARTIE'));
  page.append(el('h1', 'study-title', model.title));
  page.append(el('p', 'study-sub', model.subtitle));
  if (model.meta.length) page.append(el('p', 'study-meta', model.meta.join(' · ')));
  page.append(el('p', 'study-ish', model.source));
  if (model.line) {
    page.append(el('p', 'study-line',
      `Ligne suivie : ${model.line.text}`
      + (model.line.inBase
        ? ` — ${model.line.games} partie${model.line.games > 1 ? 's' : ''} de la base ont atteint cette position.`
        : ' — cette ligne n’est pas dans la base.')));
  }

  const summary = el('section', 'study-summary');
  summary.append(el('h2', 'study-h2', 'Résumé de l’étude'));
  const list = el('ul', 'study-summary-list');
  for (const line of model.summaryLines) list.append(el('li', '', line));
  summary.append(list);
  page.append(summary);

  const method = el('section', 'study-method');
  method.append(el('h2', 'study-h3', 'Comment lire ce document'));
  for (const line of model.method) method.append(el('p', '', line));
  method.append(el('p', 'study-sources', `Sources : ${model.sources.join(' · ')}.`));
  page.append(method);

  if (model.chapters.length) {
    const toc = el('section', 'study-toc');
    toc.append(el('h2', 'study-h2', 'Sommaire'));
    for (const chapter of model.chapters) {
      toc.append(el('p', 'study-toc-chapter', `${chapter.numeral}. ${chapter.title}`));
      for (const entry of chapter.entries) {
        toc.append(el('p', 'study-toc-entry', `${entry.diagramNumber}. ${entry.title}`));
      }
    }
    page.append(toc);
  }

  for (const chapter of model.chapters) {
    const block = el('section', 'study-chapter');
    block.append(el('h2', 'study-chapter-title', `${chapter.numeral}. ${chapter.title}`));
    block.append(el('p', 'study-chapter-count',
      `${chapter.entries.length} moment${chapter.entries.length > 1 ? 's' : ''} commenté${chapter.entries.length > 1 ? 's' : ''}.`));
    for (const entry of chapter.entries) block.append(renderEntry(entry));
    page.append(block);
  }

  if (!model.chapters.length) {
    const empty = el('section', 'study-chapter');
    empty.append(el('h2', 'study-chapter-title', 'Aucun moment à commenter'));
    empty.append(el('p', '',
      'Aucune des deux sources ne signale d’écart dans cette partie aux seuils choisis. '
      + 'Le tableau ci-dessous reste complet : il donne, pour chaque coup, les statistiques de la base et l’évaluation du moteur.'));
    page.append(empty);
  }

  const tableSection = el('section', 'study-chapter study-chapter-table');
  tableSection.append(el('h2', 'study-chapter-title', 'Tableau des coups'));
  tableSection.append(el('p', 'study-chapter-count',
    'Parties : nombre de parties de la base ayant joué ce coup. Part : part de ces parties parmi celles ayant atteint la position. '
    + '% : rendement du camp qui a joué (gains + ½ nulles). Perte : perte en pions selon le moteur. '
    + 'Les lignes estompées sont des positions absentes de la base.'));
  tableSection.append(renderTable(model));
  page.append(tableSection);

  const movesSection = el('section', 'study-chapter');
  movesSection.append(el('h2', 'study-chapter-title', 'Liste des coups'));
  movesSection.append(renderMoves(model));
  page.append(movesSection);

  page.append(el('p', 'study-foot',
    `PIONICIDE · étude générée le ${todayFr()} · aucune donnée envoyée · `
    + 'commentaires produits uniquement à partir de la base de parties locale et du moteur.'));
  sheet.append(page);
  return sheet;
}

export function openStudySheet(model) {
  closeStudySheet();
  const sheet = buildStudySheet(model);
  document.body.append(sheet);
  document.body.classList.add('sheet-open');
  const observer = new MutationObserver(() => {
    if (!document.body.contains(sheet)) {
      document.body.classList.remove('sheet-open');
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true });
  return sheet;
}

export function closeStudySheet() {
  document.querySelector('#study-sheet')?.remove();
  document.body.classList.remove('sheet-open');
}
