/* PIONICIDE · Étude commentée — accès à la base de parties.

   Le module « Base de parties » possède son propre worker (IndexedDB). L'étude
   ouvre une seconde instance du même worker : elle lit l'index et les parties,
   sans jamais toucher au moteur PIONICIDE ni modifier la base.
*/
import { Position, hash32Position } from '../base/core.js';

const CELL = { WMAN: 1, WKING: 2, BMAN: 3, BKING: 4 };

/** Damier de l'application (`'w','W','b','B','e'`) → cases du noyau de la base. */
export function appBoardToCells(board) {
  const cells = new Array(51).fill(0);
  for (let square = 1; square <= 50; square += 1) {
    const piece = board[square];
    if (piece === 'w') cells[square] = CELL.WMAN;
    else if (piece === 'W') cells[square] = CELL.WKING;
    else if (piece === 'b') cells[square] = CELL.BMAN;
    else if (piece === 'B') cells[square] = CELL.BKING;
  }
  return cells;
}

/** Clé Zobrist 32 bits d'une position, telle que l'utilise l'index. */
export function positionKeyOf(board, side) {
  const position = new Position();
  const cells = appBoardToCells(board);
  for (let square = 1; square <= 50; square += 1) {
    if (cells[square]) position.setPiece(square, cells[square]);
  }
  position.side = side === 'b' ? 1 : 0;
  return hash32Position(position);
}

/**
 * Client minimal du worker de la base.
 * @param {object} options `{ onProgress }` pour les messages de progression
 */
export function createBaseClient(options = {}) {
  let worker = null;
  let seq = 0;
  const waiting = new Map();
  let ready = null;
  let failure = null;

  function ensureWorker() {
    if (worker || failure) return worker;
    try {
      worker = new Worker(new URL('../base/worker.js', import.meta.url), { type: 'module' });
    } catch (error) {
      failure = error.message;
      return null;
    }
    worker.onmessage = event => {
      const message = event.data;
      if (!message) return;
      if (message.type === 'importProgress' || message.type === 'searchProgress') {
        options.onProgress?.(message);
        return;
      }
      if (message.id && waiting.has(message.id)) {
        const pending = waiting.get(message.id);
        waiting.delete(message.id);
        if (message.ok) pending.resolve(message.result);
        else pending.reject(new Error(message.error || 'erreur du worker de la base'));
      }
    };
    worker.onerror = () => {
      failure = 'Worker de la base indisponible';
      for (const pending of waiting.values()) pending.reject(new Error(failure));
      waiting.clear();
    };
    return worker;
  }

  /** Envoi brut, avec identifiant de requête. */
  function raw(type, payload = {}) {
    const instance = ensureWorker();
    if (!instance) return Promise.reject(new Error(failure || 'base indisponible'));
    seq += 1;
    const id = seq;
    return new Promise((resolve, reject) => {
      waiting.set(id, { resolve, reject });
      instance.postMessage({ type, payload, id });
    });
  }

  /* Le worker traite les messages de façon concurrente : `init` (ouverture
     IndexedDB + chargement de l'index) doit être attendu avant toute lecture,
     sinon `stats` répond « base vide » alors que l'ouverture est en cours. */
  function ensureReady() {
    if (!ready) {
      ready = raw('init', {}).catch(error => {
        ready = null;
        failure = failure || error.message;
        throw error;
      });
    }
    return ready;
  }

  function call(type, payload = {}) {
    return ensureReady().then(() => raw(type, payload));
  }

  return {
    call,
    /** Statistiques de la base : nombre de parties, portée de l'index. */
    stats: () => ensureReady(),
    /** Coups connus depuis une position : [{from,to,caps,path,n,w,d,l}] */
    explorer: (board, side) => call('explorerMoves', { cells: appBoardToCells(board), side: side === 'b' ? 1 : 0 }),
    /** Parties ayant atteint une position (par clé Zobrist). */
    gamesAt: key => call('positionGames', { key, filters: {}, limit: 8 }),
    /** Partie complète par identifiant. */
    getGame: id => call('getGame', { id }),
    close() {
      worker?.terminate();
      worker = null;
      ready = null;
      for (const pending of waiting.values()) pending.reject(new Error('base fermée'));
      waiting.clear();
    },
    get failure() { return failure; },
  };
}
