/**
 * Coquille mobile du « Damier d'analyse ».
 *
 * Objectif (réorganisation pour le téléphone) : la page principale ne montre plus que
 *   • le damier, en grand et pleine largeur ;
 *   • une seule ligne compacte « Trait : Blancs · −0,06 · prof. 16 · Prêt » ;
 *   • la barre de navigation de la partie (⏮ ◄ ▶ Auto ► ⏭ · Retourner) ;
 *   • une barre fixe de 5 actions essentielles (Coup conseillé · Annuler · Analyse · Outils · Menu).
 *
 * Tout le reste est déplacé, tel quel, dans un tiroir unique (bottom sheet) à onglets :
 * Réglages · Position · Coups · Pièges · Analyse · Outils.
 *
 * Aucun calcul, aucun écouteur et aucune fonction existante n'est modifié : les blocs
 * d'origine sont simplement déplacés dans le DOM (les écouteurs suivent les nœuds) et
 * l'état (position, variante en cours, réglages) est conservé puisqu'aucun élément n'est
 * détruit ni recréé. Sur grand écran, le tiroir redevient un simple empilement de panneaux :
 * toutes les options restent visibles comme avant.
 */
import { store } from '../store.js';

const MOBILE_QUERY = '(max-width: 860px)';

const TABS = [
  { id: 'reglages', label: 'Réglages' },
  { id: 'position', label: 'Position' },
  { id: 'coups', label: 'Coups' },
  { id: 'pieges', label: 'Mauvais coups' },
  { id: 'analyse', label: 'Analyse' },
  { id: 'outils', label: 'Outils' },
];

// Icônes SVG en ligne : indépendantes des polices emoji du téléphone.
const ICONS = {
  idea: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9V16h7v-2.1A6 6 0 0 0 12 3z"/></svg>',
  undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10h9a5 5 0 0 1 0 10H8"/><path d="M8 6l-4 4 4 4"/></svg>',
  pen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20l4-1 9-9-3-3-9 9-1 4z"/><path d="M14 7l3 3"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6"/><path d="M15.6 15.6L20 20"/></svg>',
  menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
};

const LEVELS = [
  ['facile', 'Facile · 12 / 1 s'],
  ['normal', 'Normal · 16 / 4 s'],
  ['fort', 'Fort · 20 / 15 s'],
  ['expert', 'Expert · 22 / 30 s'],
  ['grandmaitre', 'Grand maître · 25 / 90 s'],
];

const PAGE_LINKS = [
  ['base', '▤', 'Base de parties', 'Ouvertures et recherche de parties de maîtres'],
  ['combinaisons', '♛', 'Combinaisons', 'Générateur de rafles par niveau'],
  ['etude', '✎', 'Partie commentée', 'Étudier une partie dans un document imprimable'],
  ['editeur', '▧', 'Éditeur de partie', 'Composer une position sur le damier'],
  ['importer', '⇧', 'Importer une partie', 'Charger une partie au format PDN'],
];

function node(tag, className, html) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (html !== undefined) element.innerHTML = html;
  return element;
}

/**
 * Installe la coquille sur la page d'analyse déjà rendue.
 * @param {{el: HTMLElement, q: (id: string) => HTMLElement|null, navigate: (id: string) => void}} options
 */
export function installAnalysisShell({ el, q, navigate }) {
  // Réorganisation demandée pour le téléphone : sur grand écran, la page reste identique.
  if (!el || el.querySelector('.an-shell') || !window.matchMedia(MOBILE_QUERY).matches) return null;

  const pageRoot = document.querySelector('#page-root') || document.body;

  /* ------------------------------------------------------------------ *
   * 1. Blocs existants que l'on va simplement déplacer
   * ------------------------------------------------------------------ */
  const boardPanel = q('an-board-panel');
  const aside = boardPanel?.querySelector('.analysis-side') || null;
  const playerRow = q('an-side')?.parentElement || null;
  const heading = el.querySelector(':scope > .section-heading');
  const refutationPanel = q('refutation-panel');
  const workshop = q('manual-workshop');
  const exportPanel = el.querySelector('.analysis-export');
  const threatPanel = el.querySelector('.threat-panel');
  const lanes = el.querySelector('.study-lanes');
  const tablesPanel = q('tb-moves')?.closest('section.panel') || null;
  const altBanner = q('man-alt-banner');
  const contextNote = q('an-context');

  /* ------------------------------------------------------------------ *
   * 2. Page principale : damier + ligne compacte + navigation
   * ------------------------------------------------------------------ */
  const shell = node('div', 'an-shell');
  const main = node('div', 'an-main');
  shell.append(main);
  // Le shell est rattaché tout de suite : les nœuds déplacés restent ainsi dans le document
  // (les recherches el.querySelector('#…') continuent de fonctionner pendant la répartition).
  el.prepend(shell);

  // La ligne compacte : « Trait : Blancs · −0,06 · prof. 16 · Prêt »
  const evalMini = node('span', 'an-mini', '—');
  evalMini.id = 'an-eval-mini';
  const depthMini = node('span', 'an-mini', 'prof. 16');
  depthMini.id = 'an-depth-mini';
  const anStatus = q('an-status');
  if (playerRow && anStatus) {
    playerRow.insertBefore(evalMini, anStatus);
    playerRow.insertBefore(depthMini, anStatus);
    playerRow.classList.add('an-status-line');
  }

  // Le panneau du damier reste en place (le moteur y dessine) : on le place en tête.
  if (boardPanel) main.append(boardPanel);
  // La bannière « jouez l'autre coup sur le damier » doit rester visible au-dessus de la barre.
  if (altBanner) main.append(altBanner);

  /* ------------------------------------------------------------------ *
   * 3. Tiroir unique à onglets
   * ------------------------------------------------------------------ */
  const backdrop = node('div', 'an-sheet-backdrop');
  backdrop.id = 'an-sheet-backdrop';

  const sheet = node('section', 'an-sheet');
  sheet.id = 'an-sheet';
  sheet.setAttribute('aria-label', 'Panneaux du damier d’analyse');

  const head = node('header', 'an-sheet-head');
  const title = node('b', '', 'Réglages');
  title.id = 'an-sheet-title';
  const closeBtn = node('button', 'an-sheet-close', '✕');
  closeBtn.type = 'button';
  closeBtn.id = 'an-sheet-close';
  closeBtn.setAttribute('aria-label', 'Fermer le panneau');
  head.append(node('span', 'an-sheet-grip'), title, closeBtn);

  const tabBar = node('div', 'an-tabs');
  tabBar.id = 'an-tabs';
  tabBar.setAttribute('role', 'tablist');
  tabBar.setAttribute('aria-label', 'Panneaux disponibles');
  const tabButtons = new Map();
  for (const tab of TABS) {
    const button = node('button', 'an-tab', tab.label);
    button.type = 'button';
    button.id = `an-tab-${tab.id}`;
    button.dataset.sheet = tab.id;
    button.setAttribute('role', 'tab');
    button.setAttribute('aria-controls', `an-panel-${tab.id}`);
    button.setAttribute('aria-selected', 'false');
    button.addEventListener('click', () => selectTab(tab.id));
    tabBar.append(button);
    tabButtons.set(tab.id, button);
  }

  const sheetBody = node('div', 'an-sheet-body');
  const panels = new Map();
  for (const tab of TABS) {
    const panel = node('section', 'an-sheet-panel');
    panel.id = `an-panel-${tab.id}`;
    panel.dataset.panel = tab.id;
    panel.setAttribute('role', 'tabpanel');
    panel.setAttribute('aria-labelledby', `an-tab-${tab.id}`);
    panels.set(tab.id, panel);
    sheetBody.append(panel);
  }
  sheet.append(head, tabBar, sheetBody);
  shell.append(sheet);

  /* ------------------------------------------------------------------ *
   * 4. Répartition des blocs existants entre les panneaux
   * ------------------------------------------------------------------ */

  // — Réglages : profondeur, évaluation automatique, niveau de difficulté
  {
    const panel = panels.get('reglages');
    panel.append(node('p', 'an-panel-intro', 'Profondeur de calcul, évaluation automatique et niveau de difficulté. Les réglages sont conservés quand vous fermez le panneau.'));

    const evalCard = node('div', 'an-eval-card');
    if (aside) {
      const h3 = aside.querySelector('h3');
      if (h3) evalCard.append(h3);
      for (const id of ['an-score', 'an-meta']) {
        const target = q(id);
        if (target) evalCard.append(target);
      }
    }
    panel.append(evalCard);

    const settings = node('div', 'an-settings');
    if (aside) {
      const depthLabel = aside.querySelector('label');
      if (depthLabel) settings.append(depthLabel);
      const autoLabel = aside.querySelector('label.check-row');
      if (autoLabel) settings.append(autoLabel);
    }
    const levelLabel = node('label', '');
    levelLabel.innerHTML = 'Niveau de difficulté des parties contre PIONICIDE'
      + `<select id="an-level">${LEVELS.map(([value, text]) => `<option value="${value}">${text}</option>`).join('')}</select>`;
    settings.append(levelLabel);
    panel.append(settings);

    const levelSelect = levelLabel.querySelector('#an-level');
    levelSelect.value = LEVELS.some(([value]) => value === store.difficulty) ? store.difficulty : 'normal';
    levelSelect.addEventListener('change', () => { store.difficulty = levelSelect.value; });

    const actions = node('div', 'an-actions');
    for (const id of ['an-evaluate', 'an-hint']) {
      const target = q(id);
      if (target) actions.append(target);
    }
    panel.append(actions);
    panel.append(node('p', 'an-panel-note', 'Astuce : « Coup conseillé » dans la barre du bas évalue la position et affiche la flèche du meilleur coup, sans rien modifier dans votre analyse.'));
  }

  // — Position : éditer, position initiale, imprimer, code + copier
  {
    const panel = panels.get('position');
    panel.append(node('p', 'an-panel-intro', 'Actions sur la position affichée : édition, remise au départ, impression, export du code.'));
    const actions = node('div', 'an-actions');
    for (const id of ['an-edit', 'an-reset', 'an-print-position', 'an-undo']) {
      const target = q(id);
      if (target) actions.append(target);
    }
    panel.append(actions);
    const codeRow = aside?.querySelector('.code-row');
    if (codeRow) {
      panel.append(node('p', 'an-panel-note', 'Code de la position (FMJD) :'));
      panel.append(codeRow);
    }
  }

  // — Coups de la partie : liste des coups joués et variante de PIONICIDE
  {
    const panel = panels.get('coups');
    panel.append(node('p', 'an-panel-intro', 'Coups de la partie jouée et variante proposée par PIONICIDE. Cliquez sur un coup pour vous y placer.'));
    if (contextNote) panel.append(contextNote);
    if (lanes) panel.append(lanes);
  }

  // — Mauvais coups / Pièges
  {
    const panel = panels.get('pieges');
    const actions = node('div', 'an-actions');
    const badMoves = q('an-bad-moves');
    if (badMoves) actions.append(badMoves);
    panel.append(actions);
    if (refutationPanel) panel.append(refutationPanel);
  }

  // — Analyse commentée : partie commentée automatique d'abord, puis feuille manuelle et export
  {
    const panel = panels.get('analyse');
    if (exportPanel) {
      // Le texte commenté automatiquement reste en tête : c'est le résultat que l'on vient lire.
      const preview = exportPanel.querySelector('#an-commentary-preview');
      const status = exportPanel.querySelector('#an-annot-status');
      if (status) panel.append(status);
      if (preview) panel.append(preview);
    }
    if (workshop) panel.append(workshop);
    if (exportPanel) panel.append(exportPanel);
  }

  // — Outils : menaces, tables de finales, guide, bibliothèque
  {
    const panel = panels.get('outils');
    panel.append(node('p', 'an-panel-intro', 'Menaces de la position, tables de finales hors ligne, guide de la page et accès direct aux autres sections.'));
    if (threatPanel) panel.append(threatPanel);
    if (tablesPanel) panel.append(tablesPanel);
    if (heading) panel.append(heading);

    const links = node('div', 'an-links');
    for (const [page, icon, label, desc] of PAGE_LINKS) {
      const button = node('button', 'an-link-row', `<span class="an-link-icon" aria-hidden="true">${icon}</span><span class="an-link-text"><b>${label}</b><small>${desc}</small></span><span class="an-link-arrow" aria-hidden="true">›</span>`);
      button.type = 'button';
      button.addEventListener('click', () => { closeSheet({ restoreFocus: false }); navigate(page); });
      links.append(button);
    }
    panel.append(node('p', 'an-panel-note', 'Bibliothèque / Générateur :'), links);
    panel.append(node('p', 'an-panel-note', 'Les autres sections restent accessibles à tout moment par le bouton « Menu » de la barre du bas.'));
  }

  /* ------------------------------------------------------------------ *
   * 5. Barre fixe des 5 actions essentielles
   * ------------------------------------------------------------------ */
  const bottomBar = node('nav', 'an-bottombar');
  bottomBar.setAttribute('aria-label', 'Actions essentielles');

  function barItem(id, icon, label, onClick, accent) {
    const button = node('button', 'an-bar-item' + (accent ? ' is-accent' : ''), `<span aria-hidden="true">${ICONS[icon] || ''}</span><b>${label}</b>`);
    button.type = 'button';
    button.id = id;
    button.addEventListener('click', onClick);
    bottomBar.append(button);
    return button;
  }

  const barHint = barItem('an-bar-hint', 'idea', 'Coup conseillé', () => q('an-hint')?.click(), true);
  const barUndo = barItem('an-bar-undo', 'undo', 'Annuler', () => { const undo = q('an-undo'); if (undo && !undo.disabled) undo.click(); });
  barItem('an-bar-analyse', 'pen', 'Analyse', () => openSheet('analyse'), true);
  barItem('an-bar-outils', 'search', 'Outils', () => openSheet('outils'));
  barItem('an-bar-menu', 'menu', 'Menu', () => {
    closeSheet({ restoreFocus: false });
    document.querySelector('#menu-toggle')?.click();
  });

  shell.append(bottomBar);
  el.prepend(backdrop);

  // L'ancienne colonne latérale est vide : elle est masquée par la feuille de style.
  aside?.classList.add('an-aside-moved');

  /* ------------------------------------------------------------------ *
   * 6. Miroir de l'évaluation : une seule ligne compacte
   * ------------------------------------------------------------------ */
  const scoreEl = q('an-score');
  const metaEl = q('an-meta');
  const depthSelect = q('an-depth');

  function syncMini() {
    const raw = (scoreEl?.textContent || '').trim();
    const short = raw.replace(/\s*\([^)]*\)\s*$/, '').trim();
    evalMini.textContent = short && short !== '—' ? short.replace(/^-/, '−') : '—';
    const found = /Profondeur\s+(\d+)/i.exec(metaEl?.textContent || '');
    depthMini.textContent = `prof. ${found ? found[1] : depthSelect?.value || '16'}`;
    barHint.disabled = false;
  }

  const observerOptions = { childList: true, characterData: true, subtree: true };
  if (scoreEl) new MutationObserver(syncMini).observe(scoreEl, observerOptions);
  if (metaEl) new MutationObserver(syncMini).observe(metaEl, observerOptions);
  depthSelect?.addEventListener('change', syncMini);
  syncMini();

  if (barUndo) {
    const undoButton = q('an-undo');
    if (undoButton) {
      const syncUndo = () => { barUndo.disabled = Boolean(undoButton.disabled); };
      new MutationObserver(syncUndo).observe(undoButton, { attributes: true, attributeFilter: ['disabled'] });
      syncUndo();
    }
  }

  /* ------------------------------------------------------------------ *
   * 7. Ouverture / fermeture du tiroir (un seul panneau à la fois)
   * ------------------------------------------------------------------ */
  let currentTab = 'reglages';
  let lastFocus = null;
  let locked = false;

  function selectTab(id) {
    if (!panels.has(id)) return;
    currentTab = id;
    for (const [key, panel] of panels) {
      const active = key === id;
      panel.classList.toggle('is-active', active);
      const button = tabButtons.get(key);
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', String(active));
    }
    const meta = TABS.find(tab => tab.id === id);
    title.textContent = meta ? meta.label : 'Panneaux';
    sheetBody.scrollTop = 0;
  }

  function openSheet(id = currentTab) {
    lastFocus = document.activeElement;
    selectTab(id);
    sheet.classList.add('open');
    backdrop.classList.add('visible');
    document.body.classList.add('an-sheet-lock');
    sheet.setAttribute('role', 'dialog');
    sheet.setAttribute('aria-modal', 'true');
    locked = true;
    closeBtn.focus({ preventScroll: true });
  }

  function closeSheet({ restoreFocus = true } = {}) {
    sheet.classList.remove('open');
    backdrop.classList.remove('visible');
    if (locked) {
      document.body.classList.remove('an-sheet-lock');
      locked = false;
    }
    sheet.removeAttribute('aria-modal');
    if (restoreFocus && lastFocus && typeof lastFocus.focus === 'function' && lastFocus.isConnected) {
      lastFocus.focus({ preventScroll: true });
    }
  }

  const isOpen = () => sheet.classList.contains('open');

  closeBtn.addEventListener('click', () => closeSheet());
  backdrop.addEventListener('click', () => closeSheet());
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && isOpen()) { event.stopPropagation(); closeSheet(); }
  }, true);

  /* ------------------------------------------------------------------ *
   * 8. Le damier redevient visible quand une action l'exige
   * ------------------------------------------------------------------ */
  // « Autre coup… » et « Prochain coup en variante » se jouent sur le damier :
  // le tiroir s'efface pour laisser le damier, sans jamais rien perdre de l'état.
  for (const id of ['man-alt-move', 'man-force-var']) {
    q(id)?.addEventListener('click', () => closeSheet({ restoreFocus: false }));
  }

  // Les impressions (PDF, position) s'ouvrent au-dessus du tiroir : on le referme d'abord.
  for (const id of ['man-print', 'an-print-position']) {
    q(id)?.addEventListener('click', () => closeSheet({ restoreFocus: false }));
  }

  /* ------------------------------------------------------------------ *
   * 9. Nettoyage quand on quitte la page
   * ------------------------------------------------------------------ */
  const syncPageState = () => {
    const mounted = el.isConnected;
    document.body.classList.toggle('an-page', mounted);
    if (!mounted) {
      closeSheet({ restoreFocus: false });
      document.body.classList.remove('an-sheet-lock');
      locked = false;
    }
  };
  new MutationObserver(syncPageState).observe(pageRoot, { childList: true });
  syncPageState();

  selectTab(currentTab);

  return {
    open: openSheet,
    close: closeSheet,
    isOpen,
    selectTab,
    shell,
    sheet,
  };
}
