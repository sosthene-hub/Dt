export const EMPTY = 'e';
const directions = [[-1,-1],[-1,1],[1,-1],[1,1]];
const squareAt = new Map();
const coordinates = new Map();
for (let row = 0; row < 10; row++) {
  for (let col = 0; col < 10; col++) {
    if ((row + col) % 2 === 1) {
      const square = squareAt.size + 1;
      squareAt.set(`${row},${col}`, square);
      coordinates.set(square, { row, col });
    }
  }
}

export function coordinate(square) { return coordinates.get(square); }
export function squareAtPosition(row, col) { return squareAt.get(`${row},${col}`); }
export function createInitialBoard() {
  const board = Array(51).fill(EMPTY);
  for (let square = 1; square <= 20; square++) board[square] = 'b';
  for (let square = 31; square <= 50; square++) board[square] = 'w';
  return board;
}
export function opponent(side) { return side === 'w' ? 'b' : 'w'; }
export function sideOf(piece) {
  if (piece === 'w' || piece === 'W') return 'w';
  if (piece === 'b' || piece === 'B') return 'b';
  return null;
}
function isKing(piece) { return piece === 'W' || piece === 'B'; }
function isEnemy(piece, side) { return sideOf(piece) === opponent(side); }
function clone(board) { return board.slice(); }

function captureMovesFrom(board, side, from) {
  const piece = board[from];
  const king = isKing(piece);
  const walk = (position, state, path, captured) => {
    const currentPiece = state[position];
    const capturedSet = new Set(captured);
    const continuations = [];
    const c = coordinates.get(position);
    for (const [dr, dc] of directions) {
      let r = c.row + dr, col = c.col + dc;
      if (!king) {
        const jumped = squareAt.get(`${r},${col}`);
        const landing = squareAt.get(`${r + dr},${col + dc}`);
        if (jumped && landing && isEnemy(state[jumped], side) && !capturedSet.has(jumped) && state[landing] === EMPTY) {
          const next = clone(state);
          next[position] = EMPTY;
          // FMJD: captured pieces remain blockers until the entire sequence ends.
          next[landing] = currentPiece;
          const nextPath = [...path, landing];
          const nextCaptured = [...captured, jumped];
          // A man stays a man during the entire capture sequence, even if it visits the promotion row.
          const descendants = walk(landing, next, nextPath, nextCaptured);
          if (descendants.length) continuations.push(...descendants);
          else continuations.push({ from, to: landing, path: nextPath, captured: nextCaptured });
        }
      } else {
        let enemySquare = null;
        while (r >= 0 && r < 10 && col >= 0 && col < 10) {
          const square = squareAt.get(`${r},${col}`);
          if (!square) break;
          const occupant = state[square];
          if (occupant !== EMPTY) {
            if (sideOf(occupant) === side || enemySquare !== null || capturedSet.has(square)) break;
            enemySquare = square;
          } else if (enemySquare !== null) {
            const next = clone(state);
            next[position] = EMPTY;
            // Do not remove enemySquare yet: it still blocks this capture sequence.
            next[square] = currentPiece;
            const nextPath = [...path, square];
            const nextCaptured = [...captured, enemySquare];
            const descendants = walk(square, next, nextPath, nextCaptured);
            if (descendants.length) continuations.push(...descendants);
            else continuations.push({ from, to: square, path: nextPath, captured: nextCaptured });
          }
          r += dr; col += dc;
        }
      }
    }
    return continuations;
  };
  return walk(from, board, [from], []);
}

function quietMovesFrom(board, side, from) {
  const piece = board[from];
  const c = coordinates.get(from);
  const moves = [];
  if (isKing(piece)) {
    for (const [dr, dc] of directions) {
      let r = c.row + dr, col = c.col + dc;
      while (r >= 0 && r < 10 && col >= 0 && col < 10) {
        const square = squareAt.get(`${r},${col}`);
        if (!square || board[square] !== EMPTY) break;
        moves.push({ from, to: square, path: [from, square], captured: [] });
        r += dr; col += dc;
      }
    }
  } else {
    const dr = side === 'w' ? -1 : 1;
    for (const dc of [-1, 1]) {
      const square = squareAt.get(`${c.row + dr},${c.col + dc}`);
      if (square && board[square] === EMPTY) moves.push({ from, to: square, path: [from, square], captured: [] });
    }
  }
  return moves;
}

export function generateLegalMoves(board, side) {
  const captures = [];
  for (let square = 1; square <= 50; square++) {
    if (sideOf(board[square]) === side) captures.push(...captureMovesFrom(board, side, square));
  }
  if (captures.length) {
    const maxCaptures = Math.max(...captures.map(move => move.captured.length));
    return captures.filter(move => move.captured.length === maxCaptures);
  }
  const quiet = [];
  for (let square = 1; square <= 50; square++) {
    if (sideOf(board[square]) === side) quiet.push(...quietMovesFrom(board, side, square));
  }
  return quiet;
}

export function applyMove(board, move) {
  const next = clone(board);
  const piece = next[move.from];
  next[move.from] = EMPTY;
  for (const captured of move.captured) next[captured] = EMPTY;
  next[move.to] = piece;
  const row = coordinates.get(move.to).row;
  if (piece === 'w' && row === 0) next[move.to] = 'W';
  if (piece === 'b' && row === 9) next[move.to] = 'B';
  return next;
}

export function moveToHub(move) {
  if (!move.captured.length) return `${move.from}-${move.to}`;
  return `${move.from}x${move.to}x${move.captured.join('x')}`;
}
export function moveMatchesEngine(move, notation) {
  const numbers = notation.split(/[x-]/).map(Number);
  if (numbers.length < 2 || numbers[0] !== move.from || numbers[1] !== move.to) return false;
  const engineCaptured = numbers.slice(2).sort((a,b) => a-b);
  const expected = move.captured.slice().sort((a,b) => a-b);
  return engineCaptured.length === expected.length && engineCaptured.every((n,i) => n === expected[i]);
}
export function positionKey(board, side) { return `${side}:${board.slice(1).join('')}`; }
export function boardToHub(board, side) { return (side === 'w' ? 'W' : 'B') + board.slice(1).join(''); }
