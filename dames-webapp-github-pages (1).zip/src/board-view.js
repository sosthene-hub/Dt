import { squareAtPosition, sideOf, coordinate } from './game-rules.js';

let arrowId=0;
export function pathPoints(path,orientation='w'){return path.map(n=>{const c=coordinate(n);if(!c)throw Error('Case de flèche invalide');return `${(orientation==='w'?c.col:9-c.col)*100+50},${(orientation==='w'?c.row:9-c.row)*100+50}`;}).join(' ');}
// Reusable 10×10 draughts board.
// options: board, orientation ('w' = blancs en bas), selected, lastMove (path array),
// targets (Set of legal destination squares), markers (Map square -> css class),
// onSquareClick(square), ariaLabel.
export function renderBoard(container, options = {}) {
  const {
    board,
    orientation = 'w',
    selected = null,
    lastMove = null,
    arrows = [],
    targets = new Set(),
    markers = new Map(),
    onSquareClick = null,
    ariaLabel = 'Damier de dames internationales',
  } = options;
  container.innerHTML = '';
  container.classList.add('board');
  container.setAttribute('role', 'grid');
  container.setAttribute('aria-label', ariaLabel);
  for (let displayRow = 0; displayRow < 10; displayRow++) {
    for (let displayCol = 0; displayCol < 10; displayCol++) {
      const row = orientation === 'w' ? displayRow : 9 - displayRow;
      const col = orientation === 'w' ? displayCol : 9 - displayCol;
      const n = squareAtPosition(row, col);
      const cell = document.createElement('button');
      cell.type = 'button';
      if (!n) {
        cell.className = 'cell light-square';
        cell.disabled = true;
        container.append(cell);
        continue;
      }
      const piece = board[n];
      const color = sideOf(piece);
      cell.className = 'cell playable';
      cell.dataset.square = String(n);
      cell.setAttribute('role', 'gridcell');
      cell.setAttribute('aria-label', `Case ${n}${color ? `, ${color === 'w' ? 'pièce blanche' : 'pièce noire'}${piece === 'W' || piece === 'B' ? ', dame' : ''}` : ''}`);
      if (selected === n) cell.classList.add('selected');
      if (lastMove?.length && (n===lastMove[0]||n===lastMove.at(-1))) cell.classList.add('last-move',n===lastMove[0]?'last-from':'last-to');
      const marker = markers.get(n);
      if (marker) cell.classList.add(marker);
      if (piece !== 'e') {
        const token = document.createElement('span');
        token.className = `piece ${color === 'w' ? 'white-piece' : 'black-piece'}${piece === 'W' || piece === 'B' ? ' king' : ''}`;
        if (piece === 'W' || piece === 'B') token.innerHTML = '<span>♛</span>';
        cell.append(token);
      } else if (targets.has(n)) {
        cell.classList.add('hint-target');
        cell.innerHTML = '<span class="target-dot"></span>';
      }
      if (onSquareClick) cell.addEventListener('click', () => onSquareClick(n));
      container.append(cell);
    }
  }
  // Flèches d'analyse (menaces) : couleur propre, numérotées 1, 2, 3.
  if(Array.isArray(arrows)&&arrows.length){const ns='http://www.w3.org/2000/svg';const svg=document.createElementNS(ns,'svg');svg.classList.add('threat-arrows');svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('aria-hidden','true');const defs=document.createElementNS(ns,'defs');svg.append(defs);
   arrows.forEach((arrow,position)=>{if(!arrow?.path?.length)return;const color=arrow.color||'#2f9e5b';const key='threat-marker-'+(++arrowId);
    const marker=document.createElementNS(ns,'marker');marker.setAttribute('id',key);marker.setAttribute('markerWidth','30');marker.setAttribute('markerHeight','30');marker.setAttribute('refX','30');marker.setAttribute('refY','15');marker.setAttribute('orient','auto');marker.setAttribute('markerUnits','userSpaceOnUse');
    const head=document.createElementNS(ns,'path');head.setAttribute('d','M 0 0 L 30 15 L 0 30 z');head.setAttribute('fill',color);marker.append(head);defs.append(marker);
    const line=document.createElementNS(ns,'polyline');line.setAttribute('points',pathPoints(arrow.path,orientation));line.setAttribute('fill','none');line.setAttribute('stroke',color);line.setAttribute('stroke-width','17');line.setAttribute('stroke-linejoin','round');line.setAttribute('stroke-linecap','round');line.setAttribute('marker-end',`url(#${key})`);if(arrow.dashed)line.setAttribute('stroke-dasharray','28 22');svg.append(line);
    const start=pathPoints([arrow.path[0]],orientation).split(',');
    const badge=document.createElementNS(ns,'circle');badge.setAttribute('cx',start[0]);badge.setAttribute('cy',start[1]);badge.setAttribute('r','33');badge.setAttribute('fill',color);badge.setAttribute('stroke','#0d1720');badge.setAttribute('stroke-width','4');svg.append(badge);
    const label=document.createElementNS(ns,'text');label.setAttribute('x',start[0]);label.setAttribute('y',Number(start[1])+11);label.setAttribute('text-anchor','middle');label.setAttribute('font-size','40');label.setAttribute('font-weight','700');label.setAttribute('font-family','system-ui,sans-serif');label.setAttribute('fill','#ffffff');label.textContent=arrow.label??String(position+1);svg.append(label);});
   container.append(svg);}
  if(lastMove?.length>1){const id='move-arrow-'+(++arrowId);const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('move-arrow');svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('aria-hidden','true');svg.innerHTML=`<defs><marker id="${id}" markerWidth="34" markerHeight="34" refX="34" refY="17" orient="auto" markerUnits="userSpaceOnUse"><path d="M 0 0 L 34 17 L 0 34 z" fill="#ffd43b"/></marker></defs><polyline points="${pathPoints(lastMove,orientation)}" fill="none" stroke="#ffd43b" stroke-width="15" stroke-linejoin="round" stroke-linecap="round" marker-end="url(#${id})"/>`;container.append(svg);}
}

