import { squareAtPosition, sideOf, coordinate } from './game-rules.js';

let arrowId=0;
export function pathPoints(path,orientation='w'){return path.map(n=>{const c=coordinate(n);if(!c)throw Error('Case de flèche invalide');return `${(orientation==='w'?c.col:9-c.col)*100+50},${(orientation==='w'?c.row:9-c.row)*100+50}`;}).join(' ');}
// Reusable 10×10 draughts board.
// options: board, orientation ('w' = blancs en bas), selected, lastMove (path array),
// targets (Set of legal destination squares), markers (Map square -> css class),
// onSquareClick(square), ariaLabel.
export function renderBoard(container, options = {}) {
  const {
    board,
    orientation = 'w',
    selected = null,
    lastMove = null,
    targets = new Set(),
    markers = new Map(),
    onSquareClick = null,
    ariaLabel = 'Damier de dames internationales',
  } = options;
  container.innerHTML = '';
  container.classList.add('board');
  container.setAttribute('role', 'grid');
  container.setAttribute('aria-label', ariaLabel);
  for (let displayRow = 0; displayRow < 10; displayRow++) {
    for (let displayCol = 0; displayCol < 10; displayCol++) {
      const row = orientation === 'w' ? displayRow : 9 - displayRow;
      const col = orientation === 'w' ? displayCol : 9 - displayCol;
      const n = squareAtPosition(row, col);
      const cell = document.createElement('button');
      cell.type = 'button';
      if (!n) {
        cell.className = 'cell light-square';
        cell.disabled = true;
        container.append(cell);
        continue;
      }
      const piece = board[n];
      const color = sideOf(piece);
      cell.className = 'cell playable';
      cell.dataset.square = String(n);
      cell.setAttribute('role', 'gridcell');
      cell.setAttribute('aria-label', `Case ${n}${color ? `, ${color === 'w' ? 'pièce blanche' : 'pièce noire'}${piece === 'W' || piece === 'B' ? ', dame' : ''}` : ''}`);
      if (selected === n) cell.classList.add('selected');
      if (lastMove?.length && (n===lastMove[0]||n===lastMove.at(-1))) cell.classList.add('last-move',n===lastMove[0]?'last-from':'last-to');
      const marker = markers.get(n);
      if (marker) cell.classList.add(marker);
      if (piece !== 'e') {
        const token = document.createElement('span');
        token.className = `piece ${color === 'w' ? 'white-piece' : 'black-piece'}${piece === 'W' || piece === 'B' ? ' king' : ''}`;
        if (piece === 'W' || piece === 'B') token.innerHTML = '<span>♛</span>';
        cell.append(token);
      } else if (targets.has(n)) {
        cell.classList.add('hint-target');
        cell.innerHTML = '<span class="target-dot"></span>';
      }
      if (onSquareClick) cell.addEventListener('click', () => onSquareClick(n));
      container.append(cell);
    }
  }
  if(lastMove?.length>1){const id='move-arrow-'+(++arrowId);const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('move-arrow');svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('aria-hidden','true');svg.innerHTML=`<defs><marker id="${id}" markerWidth="34" markerHeight="34" refX="34" refY="17" orient="auto" markerUnits="userSpaceOnUse"><path d="M 0 0 L 34 17 L 0 34 z" fill="#ffd43b"/></marker></defs><polyline points="${pathPoints(lastMove,orientation)}" fill="none" stroke="#ffd43b" stroke-width="15" stroke-linejoin="round" stroke-linecap="round" marker-end="url(#${id})"/>`;container.append(svg);}
}

