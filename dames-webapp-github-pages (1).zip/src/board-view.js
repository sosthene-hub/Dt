import { squareAtPosition, sideOf } from './game-rules.js';

// Reusable 10×10 draughts board.
// options: board, orientation ('w' = blancs en bas), selected, lastMove (path array),
// targets (Set of legal destination squares), markers (Map square -> css class),
// onSquareClick(square), ariaLabel.
export function renderBoard(container, options = {}) {
  const {
    board,
    orientation = 'w',
    selected = null,
    lastMove = null,
    targets = new Set(),
    markers = new Map(),
    onSquareClick = null,
    ariaLabel = 'Damier de dames internationales',
  } = options;
  container.innerHTML = '';
  container.classList.add('board');
  container.setAttribute('role', 'grid');
  container.setAttribute('aria-label', ariaLabel);
  for (let displayRow = 0; displayRow < 10; displayRow++) {
    for (let displayCol = 0; displayCol < 10; displayCol++) {
      const row = orientation === 'w' ? displayRow : 9 - displayRow;
      const col = orientation === 'w' ? displayCol : 9 - displayCol;
      const n = squareAtPosition(row, col);
      const cell = document.createElement('button');
      cell.type = 'button';
      if (!n) {
        cell.className = 'cell light-square';
        cell.disabled = true;
        container.append(cell);
        continue;
      }
      const piece = board[n];
      const color = sideOf(piece);
      cell.className = 'cell playable';
      cell.dataset.square = String(n);
      cell.setAttribute('role', 'gridcell');
      cell.setAttribute('aria-label', `Case ${n}${color ? `, ${color === 'w' ? 'pièce blanche' : 'pièce noire'}${piece === 'W' || piece === 'B' ? ', dame' : ''}` : ''}`);
      if (selected === n) cell.classList.add('selected');
      if (lastMove && lastMove.includes(n)) cell.classList.add('last-move');
      const marker = markers.get(n);
      if (marker) cell.classList.add(marker);
      if (piece !== 'e') {
        const token = document.createElement('span');
        token.className = `piece ${color === 'w' ? 'white-piece' : 'black-piece'}${piece === 'W' || piece === 'B' ? ' king' : ''}`;
        if (piece === 'W' || piece === 'B') token.innerHTML = '<span>♛</span>';
        cell.append(token);
      } else if (targets.has(n)) {
        cell.classList.add('hint-target');
        cell.innerHTML = '<span class="target-dot"></span>';
      }
      if (onSquareClick) cell.addEventListener('click', () => onSquareClick(n));
      container.append(cell);
    }
  }
}
