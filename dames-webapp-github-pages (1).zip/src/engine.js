import {bitbaseFiles} from './bitbases.js';
// Genuine Scan 3.1b C++ in a dedicated Web Worker. No UI-thread search.
export const LEVELS = Object.freeze({
  facile:{depth:12,maxTimeMs:1000,label:'Facile'},
  normal:{depth:16,maxTimeMs:4000,label:'Normal'},
  fort:{depth:20,maxTimeMs:15000,label:'Fort'},
  expert:{depth:22,maxTimeMs:30000,label:'Expert'},
  grandmaitre:{depth:25,maxTimeMs:90000,label:'Grand maître'},
});
export const DEPTHS=Object.fromEntries(Object.entries(LEVELS).map(([key,v])=>[key,v.depth]));
export function readScanSettings(){try{const s=JSON.parse(localStorage.getItem('scan-settings')||'{}');return {hashMiB:s.hashMiB===128?128:64,runtime:s.runtime==='simd'?'simd':'scalar'};}catch{return {hashMiB:64,runtime:'scalar'};}}
export function defaultMoveTime(depth){return depth<=12?3000:depth<=16?8000:depth<=20?20000:depth<=22?30000:90000;}
export function parseInfoLine(line){
 const info={raw:line};
 for(const key of ['depth','mean-depth','score','nodes','time','nps']){const m=line.match(new RegExp(`(?:^|\\s)${key}=([\\d.+-]+)`));if(m)info[key.replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=Number(m[1]);}
 const match=line.match(/\bpv="([^"]*)"/)||line.match(/\bpv=([^\s]+)/);if(match?.[1])info.pv=match[1].split(/\s+/).filter(Boolean);
 info.completed=/\bcompleted=true\b/.test(line);info.timeLimited=/\blimit=time\b/.test(line);info.book=/\bsource=book\b/.test(line);
 if(info.time>0&&Number.isFinite(info.nodes))info.knps=info.nodes/info.time/1000;
 return info;
}
export class ScanEngine{
 constructor(baseUrl,options={}){this.baseUrl=baseUrl;this.settings={...readScanSettings(),...options};this.worker=null;this.ready=false;this.failed=false;this.initSent=false;this.current=null;this.readyListeners=new Set();this.errorListeners=new Set();this.runtimeInfo=null;this.searchTimeout=95000;this.lastError=null;this.attempt=0;this.reduced=false;}
 onReady(fn){this.readyListeners.add(fn);return()=>this.readyListeners.delete(fn);}
 onError(fn){this.errorListeners.add(fn);return()=>this.errorListeners.delete(fn);}
 start(attempt=0){
  if(this.worker)return;
  this.attempt=attempt;
  this.failed=false;
  try{this.worker=new Worker(`${this.baseUrl}scan-wasm.worker.js`);}catch(e){this.fail('Impossible de créer le Web Worker : '+e.message,attempt);return;}
  this.worker.onmessage=({data})=>{if(data?.type==='runtime'){this.runtimeInfo=data;return;}if(typeof data==='string')this.handleLine(data);};
  this.worker.onerror=()=>this.fail('Le moteur Scan WASM a rencontré une erreur.',this.attempt);
  this.initTimer=setTimeout(()=>this.fail('Initialisation de Scan trop longue.',this.attempt),45000);
  this.worker.postMessage({type:'bitbases',files:bitbaseFiles,hashMiB:this.settings.hashMiB,runtime:`scan-wasm-${this.settings.runtime==='simd'?'simd':'scalar'}.js`});this.worker.postMessage('hub');
 }
 // Taille de table demandée au moteur : 2^n entrées de 16 octets.
 ttExponent(){const mib=Number(this.settings.hashMiB)||64;return Math.max(16,Math.round(Math.log2(mib)+16));}
 // Relance un moteur arrêté (changement de page, mémoire libérée entre-temps).
 ensureStarted(){if(!this.worker){this.failed=false;this.start(0);}}
 // Libère immédiatement le worker et sa mémoire, sans notifier d'erreur.
 release(){
  const context=this.current;this.current=null;
  if(context){clearTimeout(context.timer);context.resolve({move:null,ponder:null,infos:context.infos,stale:true});}
  clearTimeout(this.initTimer);this.worker?.terminate();this.worker=null;
  this.ready=false;this.failed=false;this.initSent=false;this.runtimeInfo=null;
 }
 fail(message,attempt=0){
  const wasReady=this.ready;
  const context=this.current;this.current=null;
  if(context){clearTimeout(context.timer);context.reject(new Error(message));}
  clearTimeout(this.initTimer);this.worker?.terminate();this.worker=null;this.ready=false;this.initSent=false;
  // Un téléphone peut refuser une table de 128 Mio alors que 64 Mio passe.
  // Un seul réessai, en mémoire réduite, avant de déclarer le moteur indisponible.
  if(!wasReady&&attempt===0&&this.settings.hashMiB>32){
    this.settings.hashMiB=32;this.reduced=true;this.start(1);return;
  }
  this.failed=true;this.lastError=message;
  this.errorListeners.forEach(fn=>fn(message));
 }
 handleLine(line){
  if(line==='wait'){if(!this.initSent){this.initSent=true;for(const param of [`tt-size value=${this.ttExponent()}`,'bb-size value=4','book value=true'])this.worker.postMessage('set-param name='+param);this.worker.postMessage('init');}return;}
  if(line==='ready'){clearTimeout(this.initTimer);this.ready=true;this.readyListeners.forEach(fn=>fn());return;}
  if(line.startsWith('error')){this.fail(line);return;}
  const context=this.current;if(!context)return;
  if(line.startsWith('info')){const info=parseInfoLine(line);context.timeLimited ||=info.timeLimited;context.book ||=info.book;if(info.pv||info.completed||Number.isFinite(info.score)){context.infos.push(info);context.onInfo?.(info);}return;}
  if(line.startsWith('done')){this.current=null;clearTimeout(context.timer);context.resolve({move:line.match(/\bmove=([^\s]+)/)?.[1]||null,ponder:line.match(/\bponder=([^\s]+)/)?.[1]||null,infos:context.infos,timeLimited:!!context.timeLimited,timedOut:false,sourceBook:!!context.book,wallMs:performance.now()-context.started,requestedDepth:context.depth,runtime:this.runtimeInfo});}
 }
 waitForReady(){if(this.ready)return Promise.resolve();if(this.failed||!this.worker)return Promise.reject(new Error('Moteur Scan indisponible.'));return new Promise((resolve,reject)=>{const offReady=this.onReady(()=>{offReady();offError();resolve();});const offError=this.onError(message=>{offReady();offError();reject(new Error(message));});});}
 async search({position,depth=16,mode='analyze',maxTimeMs=defaultMoveTime(depth),onInfo}={}){
  this.ensureStarted();
  await this.waitForReady();
  // Never overlap two Hub searches. Terminating a superseded worker also stops
  // an in-progress native iteration immediately, without stale Hub replies.
  if(this.current){this.restart();await this.waitForReady();}
  const ms=Math.max(20,Math.min(90000,Number(maxTimeMs)||defaultMoveTime(depth)));
  const target=Math.max(1,Math.min(30,Math.trunc(Number(depth)||16)));
  return new Promise((resolve,reject)=>{if(!this.worker||this.failed){reject(new Error('Moteur Scan indisponible.'));return;}const context={resolve,reject,infos:[],onInfo,depth:target,started:performance.now()};this.current=context;
   context.timer=setTimeout(()=>{if(this.current!==context)return;this.current=null;const infos=context.infos.filter(i=>i.completed),best=infos.at(-1)||context.infos.at(-1);resolve({move:best?.pv?.[0]||null,ponder:null,infos:best?[best]:[],timedOut:true,timeLimited:true,wallMs:performance.now()-context.started});this.restart();},ms+3000);
   this.worker.postMessage(`pos ${position}`);this.worker.postMessage(`level depth=${target} move-time=${ms/1000}`);this.worker.postMessage(mode==='analyze'?'go analyze':'go think');
  });
 }
 restart(){const current=this.current;this.current=null;if(current){clearTimeout(current.timer);current.resolve({move:null,ponder:null,infos:current.infos,stale:true});}clearTimeout(this.initTimer);this.worker?.terminate();this.worker=null;this.ready=false;this.failed=false;this.initSent=false;this.runtimeInfo=null;this.start();}
 dispose(){const current=this.current;this.current=null;if(current){clearTimeout(current.timer);current.resolve({move:null,ponder:null,infos:current.infos,stale:true});}clearTimeout(this.initTimer);this.worker?.terminate();this.worker=null;const wasReady=this.ready;this.ready=false;this.initSent=false;if(!wasReady)this.errorListeners.forEach(fn=>fn('Calcul annulé.'));}
 configure(settings){this.settings={...this.settings,...settings};try{localStorage.setItem('scan-settings',JSON.stringify(this.settings));}catch{}this.restart();}
 newGame(){if(this.current)this.restart();else this.worker?.postMessage('new-game');}
}
export const engine=new ScanEngine(import.meta.env.BASE_URL);
