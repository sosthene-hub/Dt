// Shared Scan 3.1 wrapper around the local Web Worker (Hub protocol).
// One engine instance serves the game page and the analysis board.

const PARAMS = [
  'set-param name=tt-size value=16',
  'set-param name=bb-size value=0',
];

export const DEPTHS = { facile: 3, normal: 5, fort: 7, expert: 9 };

export function parseInfoLine(line) {
  const info = { raw: line };
  for (const key of ['depth', 'mean-depth', 'score', 'nodes', 'time', 'nps']) {
    const match = line.match(new RegExp(`\\b${key}=([\\d.+-]+)`));
    if (match) info[key.replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = Number(match[1]);
  }
  const quoted = line.match(/\bpv="([^"]*)"/);
  const bare = line.match(/\bpv=([^\s]+)/);
  const pv = quoted ? quoted[1] : bare ? bare[1] : '';
  if (pv) info.pv = pv.split(/\s+/).filter(Boolean);
  return info;
}

export class ScanEngine {
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
    this.worker = null;
    this.ready = false;
    this.failed = false;
    this.initSent = false;
    this.current = null;
    this.readyListeners = new Set();
    this.errorListeners = new Set();
    this.searchTimeout = 20000;
  }

  onReady(listener) { this.readyListeners.add(listener); return () => this.readyListeners.delete(listener); }
  onError(listener) { this.errorListeners.add(listener); return () => this.errorListeners.delete(listener); }

  start() {
    if (this.worker || this.failed) return;
    try {
      this.worker = new Worker(`${this.baseUrl}scan-normal.worker.js`);
    } catch (error) {
      this.failed = true;
      this.onError?.(`Impossible de créer le Web Worker : ${error.message}`);
      return;
    }
    this.worker.onmessage = event => this.handleLine(String(event.data));
    this.worker.onerror = () => {
      this.failed = true;
      this.ready = false;
      if (this.current) {
        const current = this.current;
        this.current = null;
        clearTimeout(current.timer);
        current.reject(new Error('Le moteur Scan a rencontré une erreur.'));
      }
      this.errorListeners.forEach(listener => listener('Le moteur Scan a rencontré une erreur.'));
    };
    this.worker.postMessage('hub');
  }

  handleLine(line) {
    if (line === 'wait') {
      if (!this.initSent) {
        this.initSent = true;
        for (const param of PARAMS) this.worker.postMessage(param);
        this.worker.postMessage('init');
      }
      return;
    }
    if (line === 'ready') {
      this.ready = true;
      this.readyListeners.forEach(listener => listener());
      return;
    }
    if (line === 'pong') return;
    if (line.startsWith('info')) {
      if (this.current) {
        const info = parseInfoLine(line);
        this.current.infos.push(info);
        this.current.onInfo?.(info);
      }
      return;
    }
    if (line.startsWith('done')) {
      const move = line.match(/\bmove=([^\s]+)/);
      const ponder = line.match(/\bponder=([^\s]+)/);
      const result = {
        move: move ? move[1] : null, // null on a terminal position
        ponder: ponder ? ponder[1] : null,
        infos: this.current ? this.current.infos : [],
      };
      const current = this.current;
      this.current = null;
      if (current) {
        clearTimeout(current.timer);
        current.resolve(result);
      }
      return;
    }
    if (line.startsWith('error')) {
      const current = this.current;
      this.current = null;
      if (current) {
        clearTimeout(current.timer);
        current.reject(new Error(line));
      } else {
        this.errorListeners.forEach(listener => listener(line));
      }
      return;
    }
  }

  // Wait until the engine reports ready (or fails).
  waitForReady() {
    if (this.ready) return Promise.resolve();
    if (this.failed || !this.worker) return Promise.reject(new Error('Moteur Scan indisponible.'));
    return new Promise(resolve => {
      const unsubscribeReady = this.onReady(() => { unsubscribeReady(); resolve(); });
      const unsubscribeError = this.onError(() => { unsubscribeError(); unsubscribeReady(); resolve(); });
    });
  }

  // position: full Hub position argument, e.g. 'pos=Weeee…' or 'start moves="32-28"'.
  async search({ position, depth = 5, mode = 'analyze', onInfo } = {}) {
    await this.waitForReady();
    return new Promise((resolve, reject) => {
      if (!this.worker || this.failed) {
        reject(new Error('Moteur Scan indisponible.'));
        return;
      }
      // A previous search may still be pending: close it before overwriting.
      if (this.current) {
        clearTimeout(this.current.timer);
        this.current.resolve({ move: null, ponder: null, infos: this.current.infos, timedOut: true, stale: true });
      }
      const context = { resolve, reject, infos: [], onInfo, timer: null };
      context.timer = setTimeout(() => {
        if (this.current === context) {
          this.current = null;
          context.resolve({ move: null, ponder: null, infos: context.infos, timedOut: true });
        }
      }, this.searchTimeout);
      this.current = context;
      this.worker.postMessage(`pos ${position}`);
      this.worker.postMessage(`level depth=${depth}`);
      this.worker.postMessage(mode === 'analyze' ? 'go analyze' : 'go think');
    });
  }

  newGame() {
    this.worker?.postMessage('new-game');
  }
}

export const engine = new ScanEngine(import.meta.env.BASE_URL);
