import {createInitialBoard,generateLegalMoves,applyMove,sideOf,opponent,coordinate,squareAtPosition,positionKey,moveToHub} from './game-rules.js';
export function counts(b){return ['w','b'].map(s=>b.filter(p=>sideOf(p)===s).length);}
export function validateConfig(c){
 if(!Number.isInteger(c.count)||c.count<1||c.count>20) throw Error('Choisissez de 1 à 20 pions par camp.');
 if(!['w','b'].includes(c.side)||!['w','b'].includes(c.carrier)) throw Error('Camp invalide.');
 if(!c.root||c.root.length!==51||c.root.slice(1).some(p=>!['e','w','b'].includes(p))) throw Error('Racine invalide.');
 if(counts(c.root).some(n=>n>c.count)) throw Error('Le nombre final doit être au moins égal à la racine de chaque camp.');
 if(c.empty.some(n=>c.root[n]!=='e')) throw Error('Une case ne peut être fixe et vide.');
 if(c.root.slice(1,6).includes('w')||c.root.slice(46).includes('b')) throw Error('Un pion ne peut rester sur sa rangée de promotion.');
}
export function isCalm(b){
 for(const s of ['w','b']) if(!generateLegalMoves(b,s).length||generateLegalMoves(b,s).some(m=>m.captured.length)) return false;
 for(let n=1;n<=50;n++) {const s=sideOf(b[n]);if(!s)continue;const {row,col}=coordinate(n);let ally=false,enemy=false;
 for(const dr of [-1,1])for(const dc of [-1,1]){const p=b[squareAtPosition(row+dr,col+dc)];if(sideOf(p)===s)ally=true;if(sideOf(p)===opponent(s))enemy=true;}
 if(enemy&&!ally)return false;
 }return true;
}
export function matches(b,s,c){return s===c.side&&counts(b).every(n=>n===c.count)&&b.every(p=>p!=='W'&&p!=='B')&&c.root.every((p,n)=>n===0||p==='e'||b[n]===p)&&c.empty.every(n=>b[n]==='e')&&isCalm(b);}
export function replay(line){let board=createInitialBoard(),side='w';for(const text of line){const m=generateLegalMoves(board,side).find(m=>moveToHub(m)===text);if(!m)throw Error('Suite illégale : '+text);board=applyMove(board,m);side=opponent(side);}return {board,side};}
export function verify(candidate,c){const r=replay(candidate.line);return positionKey(r.board,r.side)===positionKey(candidate.board,candidate.side)&&matches(r.board,r.side,c);}
export function rng(seed){return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t^=t+Math.imul(t^t>>>7,61|t);return ((t^t>>>14)>>>0)/4294967296;};}
function merit(b,c){let score=0;for(let n=1;n<=50;n++){const p=c.root[n];if(p==='e')continue;if(b[n]===p){score+=5;continue;}const a=coordinate(n);let d=20;for(let k=1;k<=50;k++)if(b[k]===p){const z=coordinate(k);d=Math.min(d,Math.abs(a.row-z.row)+Math.abs(a.col-z.col));}score-=d*.25;}for(const n of c.empty)if(b[n]!=='e')score-=2;return score;}
export function trial(c,random,maxPly=240){let board=createInitialBoard(),side='w',line=[];const seen=new Map();
 for(let ply=0;ply<=maxPly;ply++){
 if(matches(board,side,c))return {board,side,line};
 if(counts(board).some(n=>n<c.count))return null;
 const key=positionKey(board,side);seen.set(key,(seen.get(key)||0)+1);if(seen.get(key)>2)return null;
 const legal=generateLegalMoves(board,side);if(!legal.length)return null;
 const options=legal.map(m=>({m,b:applyMove(board,m)})).filter(o=>counts(o.b).every(n=>n>=c.count));if(!options.length)return null;
 let chosen;if(random()<.35)chosen=options[Math.floor(random()*options.length)];else chosen=options.map(o=>({...o,v:merit(o.b,c)+random()*5})).sort((a,b)=>b.v-a.v)[0];
 line.push(moveToHub(chosen.m));board=chosen.b;side=opponent(side);
 }return null;
}
