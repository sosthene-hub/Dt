import { generateLegalMoves, moveMatchesEngine, boardToHub, opponent } from '../game-rules.js';
import { moveToPdn } from '../pdn.js';
import { pvToMoves } from './annotate.js';

/**
 * Analyse des menaces d'une partie.
 *
 * Principe retenu (brief « ANALYSE DES MENACES ») :
 *  - menace créée  : après le coup joué, le camp qui vient de jouer rejoue
 *    (l'adversaire passe). La ligne principale est la menace ;
 *  - menace évitée : avant le coup joué, on rend le trait à l'adversaire.
 *    Sa ligne principale est la menace adverse ; une seconde analyse, après le
 *    coup joué avec l'adversaire au trait, vérifie que le coup la pare.
 *
 * Toutes les évaluations sont faites sur des copies de positions : la partie
 * enregistrée n'est jamais modifiée. Un cache d'évaluations (clé = position +
 * profondeur) est partagé avec l'analyse annotée pour éviter les recalculs.
 */

export const THREAT_DEFAULTS = Object.freeze({ depth: 16, threshold: 0.5, maxTimeMs: 1500, pvLength: 4 });

const MAX_CACHE_ENTRIES = 6000;

/** Moteur enveloppé d'un cache : même requête = même réponse, sans recalcul. */
export function createMemoSearch(search) {
  const cache = new Map();
  let hits = 0;
  let misses = 0;
  const memo = async options => {
    const { position, depth = THREAT_DEFAULTS.depth, mode = 'analyze', maxTimeMs } = options || {};
    const key = `${mode}|${position}|d${depth}`;
    if (cache.has(key)) {
      hits += 1;
      return cache.get(key);
    }
    const result = await search({ ...options, position, depth, mode, maxTimeMs });
    misses += 1;
    if (cache.size >= MAX_CACHE_ENTRIES) cache.clear();
    cache.set(key, result);
    return result;
  };
  memo.cache = cache;
  memo.size = () => cache.size;
  memo.clear = () => cache.clear();
  memo.stats = () => ({ hits, misses, size: cache.size });
  return memo;
}

function isForcedCapture(legal) {
  return legal.length > 0 && legal.every(move => move.captured.length > 0);
}

/**
 * Une prise n'est pas une menace.
 *
 * Une ligne qui commence par une rafle décrit un gain immédiat déjà disponible,
 * pas une menace à parer : elle est écartée de la détection (et donc des
 * compteurs, des flèches et des annotations exportées).
 */
export function lineStartsWithCapture(line) {
  return !!line && line.length > 0 && (line[0].captured?.length || 0) > 0;
}

/** Évaluation d'une position (copie), du point de vue du camp au trait. */
async function evaluate({ board, side, depth, maxTimeMs, pvLength, search }) {
  const legal = generateLegalMoves(board, side);
  const forcedCapture = isForcedCapture(legal);
  if (!legal.length) {
    return { score: null, best: null, pv: [], terminal: true, forcedCapture, legal };
  }
  const result = await search({ position: `pos=${boardToHub(board, side)}`, depth, mode: 'analyze', maxTimeMs });
  const info = result.infos?.at(-1);
  const score = Number(info?.score);
  const best = result.move ? legal.find(move => moveMatchesEngine(move, result.move)) || null : null;
  const pv = result.stale ? [] : pvToMoves(board, side, info?.pv, pvLength);
  return {
    score: Number.isFinite(score) ? score : null,
    best,
    pv,
    depth: info?.depth ?? null,
    timeLimited: !!result.timeLimited,
    terminal: false,
    forcedCapture,
    legal,
    moveCount: legal.length,
  };
}

function sideName(side) {
  return side === 'w' ? 'les Blancs' : 'les Noirs';
}

function countCaptures(moves) {
  return moves.reduce((total, move) => total + move.captured.length, 0);
}

function lineText(moves, limit = 3) {
  return moves.slice(0, limit).map(moveToPdn).join(' puis ');
}

function pieceWord(count) {
  return `${count} pion${count > 1 ? 's' : ''}`;
}

function pionText(value) {
  // Scan note 95 (ou plus) une position gagnée : on ne parle pas de « 95 pions ».
  if (Math.abs(value) >= 90) return 'gain décisif';
  const text = Math.abs(value).toFixed(1).replace('.', ',');
  return `gain de ${text} pion${Math.abs(value) >= 2 ? 's' : ''}`;
}

export function moveNumberOf(index, startSide = 'w') {
  return Math.floor((index + (startSide === 'b' ? 1 : 0)) / 2) + 1;
}

export function describeCreated(threat) {
  if (!threat) return '';
  const capture = threat.captures > 0;
  return `Menace créée : ${sideName(threat.side)} menacent ${lineText(threat.line)}`
    + `${capture ? `, rafle de ${pieceWord(threat.captures)}` : `, ${pionText(threat.gain)}`}`
    + ' si l’adversaire ne réagit pas.';
}

export function describeAvoided(threat) {
  if (!threat) return '';
  const capture = threat.captures > 0;
  const start = `${sideName(threat.side)} menaçaient ${lineText(threat.line)}`;
  const gain = capture ? `rafle de ${pieceWord(threat.captures)}` : pionText(threat.gap);
  const verdict = threat.parried === false ? 'Le coup joué ne pare pas cette menace.' : 'Le coup joué l’empêche.';
  return `Menace évitée : ${start}, ${gain}. ${verdict}`;
}

/** Portée : toute la partie, un camp, ou une plage de coups (numéros de coups). */
export function scopeAllows(scope, { side, moveNumber }) {
  const kind = scope?.kind || 'all';
  if (kind === 'all') return true;
  if (kind === 'w' || kind === 'b') return side === kind;
  if (kind === 'range') {
    const from = Number(scope.from) || 1;
    const to = Number(scope.to) || Number.MAX_SAFE_INTEGER;
    return moveNumber >= from && moveNumber <= to;
  }
  return true;
}

/**
 * Analyse d'un seul demi-coup.
 *
 * @param {object} options
 * @param {object} options.before   position avant le coup (le camp `side` au trait)
 * @param {object} options.after    position après le coup
 * @param {object} options.move     coup joué (objet local)
 * @param {number} options.index    indice du demi-coup (0 = premier)
 * @param {string} options.mode     'both' | 'created' | 'avoided' (recalcul isolé)
 * @param {Function} options.onWork appelé après chaque évaluation réellement demandée
 */
export async function analyseThreatPly({
  before,
  after,
  move = null,
  index = 0,
  search,
  depth = THREAT_DEFAULTS.depth,
  threshold = THREAT_DEFAULTS.threshold,
  maxTimeMs = THREAT_DEFAULTS.maxTimeMs,
  pvLength = THREAT_DEFAULTS.pvLength,
  startSide = 'w',
  mode = 'both',
  onWork,
} = {}) {
  const mover = before.side;
  const other = opponent(mover);
  const moveNumber = moveNumberOf(index, startSide);
  const entry = {
    index,
    side: mover,
    moveNumber,
    move,
    played: move ? moveToPdn(move) : '',
    created: null,
    avoided: null,
    note: '',
    status: 'none',
    depth,
    diagnostics: {},
  };
  const work = () => onWork?.();

  // 1. Menace créée : après le coup, le camp qui vient de jouer rejoue.
  let valueAfterForMover = null;
  if (mode !== 'avoided') {
    const afterMover = await evaluate({ board: after.board, side: mover, depth, maxTimeMs, pvLength, search });
    work();
    const afterOther = await evaluate({ board: after.board, side: other, depth, maxTimeMs, pvLength, search });
    work();
    valueAfterForMover = afterOther.score === null ? null : -afterOther.score;
    const createdGain = afterMover.score !== null && valueAfterForMover !== null
      ? afterMover.score - valueAfterForMover
      : null;
    entry.diagnostics.created = { moverScore: afterMover.score, otherScore: afterOther.score, gain: createdGain, pv: afterMover.pv.length, depth: afterMover.depth, terminal: afterMover.terminal };
    if (!afterMover.terminal && Number.isFinite(createdGain) && createdGain >= threshold && afterMover.pv.length) {
      if (lineStartsWithCapture(afterMover.pv)) {
        // Ligne écartée : le gain vient d'une prise immédiate, pas d'une menace.
        entry.discarded = 'capture';
        entry.note = 'Menace écartée : la ligne commence par une prise.';
        entry.diagnostics.created.discarded = 'capture';
      } else {
      entry.created = {
        side: mover,
        gain: createdGain,
        value: afterMover.score,
        baseline: valueAfterForMover,
        line: afterMover.pv,
        pdn: afterMover.pv.map(moveToPdn),
        captures: countCaptures([afterMover.pv[0]]),
        totalCaptures: countCaptures(afterMover.pv),
        depth: afterMover.depth,
        score: afterMover.score,
      };
      entry.status = 'created';
      }
    }
  }

  // 2. Menace évitée : avant le coup, le trait revient à l'adversaire.
  if (mode !== 'created') {
    const invertedLegal = generateLegalMoves(before.board, other);
    if (!invertedLegal.length) {
      entry.note = 'Menace évitée non calculable : aucun coup légal pour le camp au trait.';
      if (entry.status === 'none') entry.status = 'terminal';
      return entry;
    }
    if (isForcedCapture(invertedLegal)) {
      // L'inversion du trait fabriquerait une prise obligatoire : mesure artificielle.
      if (entry.status === 'none') entry.status = 'forced';
      entry.note = 'Menace non calculable : prise obligatoire en jeu.';
      entry.diagnostics.avoided = { forced: true };
      return entry;
    }
    const beforeMover = await evaluate({ board: before.board, side: mover, depth, maxTimeMs, pvLength, search });
    work();
    const beforeOther = await evaluate({ board: before.board, side: other, depth, maxTimeMs, pvLength, search });
    work();
    const threatValue = beforeOther.score === null ? null : -beforeOther.score;
    const avoidedGap = beforeMover.score !== null && threatValue !== null ? beforeMover.score - threatValue : null;
    entry.diagnostics.avoided = { moverScore: beforeMover.score, otherScore: beforeOther.score, gap: avoidedGap, pv: beforeOther.pv.length, forced: false };
    if (valueAfterForMover === null) {
      const afterOther = await evaluate({ board: after.board, side: other, depth, maxTimeMs, pvLength, search });
      work();
      valueAfterForMover = afterOther.score === null ? null : -afterOther.score;
    }
    if (Number.isFinite(avoidedGap) && avoidedGap >= threshold && beforeOther.pv.length) {
      if (lineStartsWithCapture(beforeOther.pv)) {
        // Ligne écartée : ce que l'adversaire gagnait était une prise immédiate.
        if (!entry.discarded) entry.discarded = 'capture';
        entry.note = entry.note || 'Menace écartée : la ligne commence par une prise.';
        entry.diagnostics.avoided.discarded = 'capture';
      } else {
      entry.avoided = {
        side: other,
        gap: avoidedGap,
        valueIfOpponentMoves: threatValue,
        valueAfterMove: valueAfterForMover,
        line: beforeOther.pv,
        pdn: beforeOther.pv.map(moveToPdn),
        captures: countCaptures([beforeOther.pv[0]]),
        totalCaptures: countCaptures(beforeOther.pv),
        depth: beforeOther.depth,
        parried: valueAfterForMover === null ? null : valueAfterForMover >= threatValue - threshold,
      };
      if (entry.avoided.parried === false) entry.note = 'Le coup joué ne pare pas cette menace.';
      entry.status = entry.status === 'created' ? 'created+avoided' : 'avoided';
      }
    }
  }

  if (entry.status === 'none') entry.status = entry.note ? 'quiet' : 'none';
  return entry;
}

/** Recalcul isolé d'une menace sur un coup (boutons « Menace créée / évitée »). */
export async function analyseThreatSlice({ mode = 'both', ...options }) {
  return analyseThreatPly({ ...options, mode });
}

/**
 * Analyse les menaces de tous les coups joués.
 *
 * @param {object}   options
 * @param {Array}    options.states      positions successives (n + 1)
 * @param {Array}    options.moves       coups joués (n)
 * @param {Function} options.search      moteur (idéalement createMemoSearch)
 * @param {number}   options.depth       profondeur (10 par défaut)
 * @param {number}   options.threshold   écart minimal en pions (0,5 par défaut)
 * @param {object}   options.scope       {kind: 'all'|'w'|'b'|'range', from, to}
 * @param {Function} options.onProgress(done, total)
 * @param {Function} options.shouldStop()
 */
export async function analyseThreats({
  states,
  moves = [],
  search,
  depth = THREAT_DEFAULTS.depth,
  threshold = THREAT_DEFAULTS.threshold,
  maxTimeMs = THREAT_DEFAULTS.maxTimeMs,
  pvLength = THREAT_DEFAULTS.pvLength,
  scope = { kind: 'all' },
  onProgress,
  shouldStop,
} = {}) {
  const plies = Math.max(0, states.length - 1);
  const startSide = states[0]?.side || 'w';
  const total = Math.max(1, plies * 4);
  let work = 0;
  const results = [];

  for (let index = 0; index < plies; index += 1) {
    if (shouldStop?.()) return { cancelled: true, results: [], summary: null, depth, threshold };
    const before = states[index];
    const after = states[index + 1];
    const move = moves[index] || null;
    const moveNumber = moveNumberOf(index, startSide);
    if (!scopeAllows(scope, { side: before.side, moveNumber })) {
      results.push({
        index,
        side: before.side,
        moveNumber,
        move,
        played: move ? moveToPdn(move) : '',
        created: null,
        avoided: null,
        note: '',
        status: 'skipped',
        depth,
      });
      continue;
    }
    const entry = await analyseThreatPly({
      before,
      after,
      move,
      index,
      search,
      depth,
      threshold,
      maxTimeMs,
      pvLength,
      startSide,
      mode: 'both',
      onWork: () => {
        work += 1;
        onProgress?.(Math.min(total, work), total);
      },
    });
    if (shouldStop?.()) return { cancelled: true, results: [], summary: null, depth, threshold };
    results.push(entry);
  }

  return { cancelled: false, results, summary: summarise(results), depth, threshold, total };
}

/** Récapitulatif : nombre de menaces par camp et les trois coups les plus lourds. */
export function summarise(results = []) {
  const summary = {
    created: { w: 0, b: 0 },
    avoided: { w: 0, b: 0 },
    notParried: 0,
    forced: 0,
    discarded: 0,
    analysed: 0,
    top: [],
  };
  const weightOf = entry => Math.max(entry.created?.gain ?? 0, entry.avoided?.gap ?? 0);
  for (const entry of results) {
    if (entry.status === 'skipped') continue;
    summary.analysed += 1;
    if (entry.created) summary.created[entry.side] += 1;
    if (entry.avoided) {
      summary.avoided[entry.side] += 1;
      if (entry.avoided.parried === false) summary.notParried += 1;
    }
    if (entry.status === 'forced') summary.forced += 1;
    if (entry.discarded === 'capture') summary.discarded += 1;
  }
  summary.top = results
    .filter(entry => entry.created || entry.avoided)
    .sort((a, b) => weightOf(b) - weightOf(a))
    .slice(0, 3)
    .map(entry => ({
      index: entry.index,
      moveNumber: entry.moveNumber,
      side: entry.side,
      played: entry.played,
      weight: weightOf(entry),
      created: !!entry.created,
      avoided: !!entry.avoided,
      stopped: entry.avoided?.parried === false,
    }));
  return summary;
}

/** Texte court affiché sous le damier et dans l'export. */
export function threatSummaryText(entry) {
  if (!entry) return '';
  if (entry.status === 'forced') return entry.note || 'Menace non calculable : prise obligatoire en jeu.';
  if (entry.status === 'skipped') return 'Coup hors de la portée analysée.';
  if (!entry.created && !entry.avoided) {
    if (entry.discarded === 'capture') return 'Aucune menace : le gain immédiat est une prise.';
    return entry.note || 'Aucune menace réelle.';
  }
  const parts = [];
  if (entry.created) parts.push(describeCreated(entry.created));
  if (entry.avoided) parts.push(describeAvoided(entry.avoided));
  if (entry.note && !parts.some(part => part.includes(entry.note))) parts.push(entry.note);
  return parts.join(' ');
}

/** Commentaires ajoutés au PDN / à la feuille imprimable quand l'option est active. */
export function threatAnnotations(results = [], { onlyIndexes = null } = {}) {
  const map = new Map();
  for (const entry of results) {
    if (onlyIndexes && !onlyIndexes.has(entry.index)) continue;
    if (entry.status === 'skipped' || entry.status === 'quiet') continue;
    if (!entry.created && !entry.avoided) continue;
    const text = threatSummaryText(entry);
    if (text) map.set(entry.index, text);
  }
  return map;
}
