import { boardSvg } from './diagram.js';
import { formatEval, moveNumberOf } from './annotate.js';
import { moveToPdn } from '../pdn.js';

const MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

function todayPdn() {
  return new Date().toISOString().slice(0, 10).replaceAll('-', '.');
}

function cleanHeader(value, fallback) {
  return String(value ?? '').replace(/["\\]/g, "'").trim() || fallback;
}

export function normaliseHeaders(headers = {}, fallback = {}) {
  return {
    Event: cleanHeader(headers.Event, fallback.Event || 'Analyse Scan'),
    Site: cleanHeader(headers.Site, 'Dames — entraînement local'),
    Date: cleanHeader(headers.Date, todayPdn()),
    Round: cleanHeader(headers.Round, '-'),
    White: cleanHeader(headers.White, fallback.White || 'Blancs'),
    Black: cleanHeader(headers.Black, fallback.Black || 'Noirs'),
  };
}

/** « 13. 17-21 34-30 14. 23-29 » à partir d'une suite de coups. */
export function formatVariation(moves, startIndex) {
  const parts = [];
  moves.forEach((move, offset) => {
    const index = startIndex + offset;
    if (index % 2 === 0) parts.push(`${moveNumberOf(index)}.`);
    parts.push(moveToPdn(move));
  });
  return parts.join(' ');
}

/**
 * PDN annoté : en-tête, tous les coups, symbole et commentaire par coup analysé,
 * variante de Scan pour les erreurs. Les commentaires et variantes sont ignorés
 * par le lecteur PDN de l'application : le fichier se rouvre donc à l'identique.
 */
export function buildAnnotatedPdn({ headers, moves, plies, result = '*', depth = 12, detail = 'errors', thresholds }) {
  const head = normaliseHeaders(headers);
  const lines = [
    `[Event "${head.Event}"]`,
    `[Site "${head.Site}"]`,
    `[Date "${head.Date}"]`,
    `[Round "${head.Round}"]`,
    `[White "${head.White}"]`,
    `[Black "${head.Black}"]`,
    `[Result "${result}"]`,
    `[Annotator "Scan 3.1b · profondeur ${depth}"]`,
    '[EvalPerspective "Blancs"]',
    `[ErrorThreshold "${thresholds?.error ?? 0.5}"]`,
    `[BlunderThreshold "${thresholds?.blunder ?? 1.5}"]`,
    `[ExportDetail "${detail}"]`,
  ];
  const tokens = ['\n'];
  moves.forEach((move, index) => {
    const ply = plies[index] || {};
    const isError = ply.symbol === '?' || ply.symbol === '??';
    const annotate = detail === 'all' || isError;
    if (index % 2 === 0) tokens.push(`${moveNumberOf(index)}.`);
    tokens.push(moveToPdn(move) + (annotate ? ply.symbol || '' : ''));
    if (annotate && Number.isFinite(ply.evalAfterWhite)) {
      tokens.push(`{ ${formatEval(ply.evalAfterWhite)}, prof. ${ply.depth ?? depth} }`);
    }
    if (isError && ply.pv?.length) {
      tokens.push(`( ${formatVariation(ply.pv, index)} )`);
    }
    if (index % 12 === 11) tokens.push('\n');
  });
  tokens.push(result);
  return `${lines.join('\n')}\n\n${tokens.join(' ').replace(/ \n/g, '\n').replace(/\n /g, '\n').trim()}\n`;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function moveLabel(ply) {
  return `${ply.played}${ply.symbol || ''}`;
}

/**
 * Feuille imprimable : en-tête, liste numérotée sur deux colonnes, bloc d'erreur
 * (coup joué, meilleur coup, évaluations, variante) et diagrammes SVG.
 */
export function buildPrintSheet({ headers, plies, states, positions = [], marks = new Set(), options = {}, depth = 12, result = '*', title = '' }) {
  const detail = options.detail || 'errors';
  const thresholds = options.thresholds || { error: 0.5, blunder: 1.5 };
  const head = normaliseHeaders(headers);
  const pliesByIndex = new Map(plies.map(ply => [ply.index, ply]));
  const errorIndexes = plies.filter(ply => ply.symbol === '?' || ply.symbol === '??').map(ply => ply.index);
  const diagramIndexes = new Set([...marks]);
  if (options.autoBlunder) {
    for (const ply of plies) if (ply.symbol === '??') diagramIndexes.add(ply.index + 1);
  }
  const diagramAfterMove = new Map();
  for (const positionIndex of diagramIndexes) {
    // La position marquée est celle qui suit le coup d'indice positionIndex-1.
    const moveIndex = positionIndex - 1;
    if (moveIndex < 0) continue;
    if (!diagramAfterMove.has(moveIndex)) diagramAfterMove.set(moveIndex, positionIndex);
  }

  const sheet = el('article', 'print-sheet');
  sheet.id = 'print-sheet';
  const page = el('div', 'sheet-page');

  const toolbar = el('div', 'sheet-toolbar');
  const printButton = el('button', 'primary-button', 'Imprimer / PDF');
  printButton.type = 'button';
  printButton.addEventListener('click', () => window.print());
  const closeButton = el('button', 'secondary-button', 'Fermer');
  closeButton.type = 'button';
  closeButton.addEventListener('click', () => sheet.remove());
  toolbar.append(printButton, closeButton, el('span', 'sheet-toolbar-note', 'Dans la boîte d’impression, choisissez « Enregistrer au format PDF ».'));
  sheet.append(toolbar);

  const header = el('header', 'sheet-head');
  header.append(el('h1', 'sheet-title', title || 'Analyse de la partie'));
  header.append(el('p', 'sheet-sub', `${head.White} — ${head.Black}`));
  const metaParts = [
    head.Event !== 'Analyse Scan' ? head.Event : '',
    head.Date,
    `Résultat ${result}`,
    `Scan 3.1b, profondeur ${depth}`,
    detail === 'errors' ? 'Erreurs et grosses erreurs seulement' : 'Partie complète',
  ].filter(Boolean);
  header.append(el('p', 'sheet-meta', metaParts.join(' · ')));
  header.append(el('p', 'sheet-legend',
    `! meilleur coup de Scan · ? perte d’au moins ${String(thresholds.error).replace('.', ',')} pion · `
    + `?? perte d’au moins ${String(thresholds.blunder).replace('.', ',')} pion · évaluations vues des Blancs`));
  page.append(header);

  const table = el('div', 'sheet-moves');
  const rowHeader = el('div', 'move-line move-line-head');
  rowHeader.append(el('span', 'mn', 'N°'), el('span', 'mw', 'Blancs'), el('span', 'mb', 'Noirs'));
  table.append(rowHeader);

  const rows = Math.ceil(plies.length / 2);
  let printedErrors = 0;
  for (let row = 0; row < rows; row += 1) {
    const whiteIndex = row * 2;
    const blackIndex = whiteIndex + 1;
    const whitePly = pliesByIndex.get(whiteIndex);
    const blackPly = blackIndex < plies.length ? pliesByIndex.get(blackIndex) : null;
    const rowHasError = [whitePly, blackPly].some(ply => ply && (ply.symbol === '?' || ply.symbol === '??'));
    // Un diagramme choisi à la main s'imprime même si le coup n'est pas une erreur.
    const rowHasDiagram = [whitePly, blackPly].some(ply => ply && diagramAfterMove.has(ply.index));
    if (detail === 'errors' && !rowHasError && !rowHasDiagram) continue;

    const line = el('div', 'move-line');
    line.append(el('span', 'mn', String(row + 1)));
    const markClass = ply => (ply?.symbol === '??' ? ' mark-blunder' : ply?.symbol === '?' ? ' mark-error' : '');
    const whiteCell = el('span', `mw${markClass(whitePly)}`, whitePly ? moveLabel(whitePly) : '');
    const blackCell = el('span', `mb${markClass(blackPly)}`, blackPly ? moveLabel(blackPly) : '');
    line.append(whiteCell, blackCell);
    table.append(line);

    for (const ply of [whitePly, blackPly]) {
      if (!ply || (ply.symbol !== '?' && ply.symbol !== '??')) continue;
      printedErrors += 1;
      const note = el('div', 'note');
      const noteHeader = el('p', 'note-head',
        `Coup ${ply.moveNumber} · ${ply.side === 'w' ? 'Blancs' : 'Noirs'} · ${ply.played} ${ply.symbol}`);
      note.append(noteHeader);
      const list = el('dl', 'note-body');
      const add = (term, value) => {
        list.append(el('dt', '', term));
        list.append(el('dd', '', value));
      };
      add('Mon coup', ply.played);
      add('Meilleur coup de Scan', ply.best || '—');
      add('Évaluation avant', formatEval(ply.evalBeforeWhite));
      add('Évaluation après', formatEval(ply.evalAfterWhite));
      add('Perte', Number.isFinite(ply.loss) ? `${ply.loss.toFixed(2).replace('.', ',')} pion` : '—');
      add('Variante conseillée', ply.pv?.length
        ? formatVariation(ply.pv, ply.index)
        : '—');
      note.append(list);
      table.append(note);
    }

    for (const ply of [whitePly, blackPly]) {
      if (!ply) continue;
      const positionIndex = diagramAfterMove.get(ply.index);
      if (positionIndex === undefined) continue;
      const state = states[positionIndex];
      if (!state) continue;
      const figure = el('figure', 'diagram');
      const bestHere = positions[positionIndex]?.best;
      figure.append(boardSvg({
        board: state.board,
        orientation: 'w',
        arrow: options.arrow && bestHere ? [bestHere.from, bestHere.to] : null,
        numbers: !!options.numbers,
        title: `Position après le coup ${ply.moveNumber} (${ply.played})`,
      }));
      figure.append(el('figcaption', '',
        `Coup ${ply.moveNumber} · ${ply.played} · ${state.side === 'w' ? 'aux Blancs' : 'aux Noirs'} de jouer`));
      table.append(figure);
    }
  }
  if (!printedErrors && detail === 'errors') {
    table.append(el('p', 'sheet-empty', 'Aucune erreur au-dessus des seuils choisis. Utilisez « Toute la partie » pour la liste complète.'));
  }
  page.append(table);
  page.append(el('p', 'sheet-foot', `Analyse produite localement par Scan 3.1b · ${todayPdn()} · aucune donnée envoyée.`));
  sheet.append(page);
  return sheet;
}

export function openPrintSheet(payload) {
  document.querySelector('#print-sheet')?.remove();
  const sheet = buildPrintSheet(payload);
  document.body.append(sheet);
  document.body.classList.add('sheet-open');
  const observer = new MutationObserver(() => {
    if (!document.body.contains(sheet)) {
      document.body.classList.remove('sheet-open');
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true });
  return sheet;
}
