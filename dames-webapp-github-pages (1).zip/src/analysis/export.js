import { boardSvg } from './diagram.js';
import { formatEval, moveNumberOf } from './annotate.js';
import { moveToPdn } from '../pdn.js';
import { threatSummaryText } from './threats.js';

const MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

function todayPdn() {
  return new Date().toISOString().slice(0, 10).replaceAll('-', '.');
}

function cleanHeader(value, fallback) {
  return String(value ?? '').replace(/["\\]/g, "'").trim() || fallback;
}

export function normaliseHeaders(headers = {}, fallback = {}) {
  return {
    Event: cleanHeader(headers.Event, fallback.Event || 'Analyse PIONICIDE'),
    Site: cleanHeader(headers.Site, 'Dames — entraînement local'),
    Date: cleanHeader(headers.Date, todayPdn()),
    Round: cleanHeader(headers.Round, '-'),
    White: cleanHeader(headers.White, fallback.White || 'Blancs'),
    Black: cleanHeader(headers.Black, fallback.Black || 'Noirs'),
  };
}

/** « 13. 17-21 34-30 14. 23-29 » à partir d'une suite de coups. */
export function formatVariation(moves, startIndex, startSide = null) {
  const parts = [];
  moves.forEach((move, offset) => {
    const index = startIndex + offset;
    const side = startSide ? (offset % 2 === 0 ? startSide : startSide === 'w' ? 'b' : 'w') : (index % 2 === 0 ? 'w' : 'b');
    if (side === 'w') parts.push(`${moveNumberOf(index)}.`);
    parts.push(moveToPdn(move));
  });
  return parts.join(' ');
}

/**
 * PDN annoté : en-tête, tous les coups, symbole et commentaire par coup analysé,
 * variante de PIONICIDE pour les erreurs. Les commentaires et variantes sont ignorés
 * par le lecteur PDN de l'application : le fichier se rouvre donc à l'identique.
 */
export function buildAnnotatedPdn({
  headers, moves, plies, result = '*', depth = 12, detail = 'errors', thresholds,
  threats = null, threatDepth = 10, threatThreshold = 0.5,
}) {
  const head = normaliseHeaders(headers);
  const threatByIndex = new Map();
  for (const entry of threats || []) {
    if (!entry || (!entry.created && !entry.avoided)) continue;
    const text = threatSummaryText(entry);
    if (text) threatByIndex.set(entry.index, text);
  }
  const lines = [
    `[Event "${head.Event}"]`,
    `[Site "${head.Site}"]`,
    `[Date "${head.Date}"]`,
    `[Round "${head.Round}"]`,
    `[White "${head.White}"]`,
    `[Black "${head.Black}"]`,
    `[Result "${result}"]`,
    `[Annotator "PIONICIDE · profondeur ${depth}"]`,
    '[EvalPerspective "Blancs"]',
    `[ErrorThreshold "${thresholds?.error ?? 0.5}"]`,
    `[BlunderThreshold "${thresholds?.blunder ?? 1.5}"]`,
    `[ExportDetail "${detail}"]`,
    ...(threatByIndex.size
      ? ['[ThreatAnalysis "PIONICIDE"]', `[ThreatDepth "${threatDepth}"]`, `[ThreatThreshold "${threatThreshold}"]`]
      : []),
  ];
  const tokens = ['\n'];
  moves.forEach((move, index) => {
    const ply = plies[index] || {};
    const isError = ply.symbol === '?' || ply.symbol === '??';
    const annotate = detail === 'all' || isError;
    if (index % 2 === 0) tokens.push(`${moveNumberOf(index)}.`);
    tokens.push(moveToPdn(move) + (annotate ? ply.symbol || '' : ''));
    if (annotate && Number.isFinite(ply.evalAfterWhite)) {
      tokens.push(`{ ${formatEval(ply.evalAfterWhite)}, prof. ${ply.depth ?? depth} }`);
    }
    if (isError && ply.pv?.length) {
      tokens.push(`( ${formatVariation(ply.pv, index)} )`);
    }
    const threatNote = threatByIndex.get(index);
    if (threatNote) tokens.push(`{ ${threatNote} }`);
    if (index % 12 === 11) tokens.push('\n');
  });
  tokens.push(result);
  return `${lines.join('\n')}\n\n${tokens.join(' ').replace(/ \n/g, '\n').replace(/\n /g, '\n').trim()}\n`;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function moveLabel(ply) {
  return `${ply.played}${ply.symbol || ''}`;
}

/**
 * Feuille imprimable : en-tête, liste numérotée sur deux colonnes, bloc d'erreur
 * (coup joué, meilleur coup, évaluations, variante) et diagrammes SVG.
 */
/**
 * Texte commenté continu, dans la présentation des captures de référence :
 *
 *   25. 34-30 12-17 26. 30-25 4-9 27. 39-34 ?! Inaccuracy. Best move was 42-37.
 *   ⌐ 27... 42-37 18-23 28. 28x19 14x34 29. 39x30 10-14 […]
 *   27... 14-19 28. 34-30 9-14 29. 50-45 26-31 30. 27-22 18x27
 *   31. 44-39 ?! Inaccuracy. Best move was 45-40.
 *   ⌐ 31... 45-40 8-12 32. 40-35 12-18 33. 24-20 15x24 […]
 *
 * Le coup joué reste en gras noir, le coup annoté prend la couleur de son
 * symbole, et la variante conseillée est accrochée juste après avec une barre.
 */
export function buildAnnotatedCommentary({ plies, moves = [], numbers = true }) {
  const byIndex = new Map(plies.map(ply => [ply.index, ply]));
  const total = Math.max(plies.length, moves.length);
  const blocks = [];
  let buffer = [];
  const flush = () => { if (buffer.length) { blocks.push({ type: 'text', parts: buffer }); buffer = []; } };

  const firstSide = plies[0]?.side || 'w';
  for (let index = 0; index < total; index += 1) {
    const ply = byIndex.get(index);
    const move = moves[index];
    const pdn = ply?.played || (move ? moveToPdn(move) : '');
    if (!pdn) continue;
    const side = ply?.side || (index % 2 === 0 ? firstSide : firstSide === 'w' ? 'b' : 'w');
    const moveNumber = ply?.moveNumber || Math.floor(index / 2) + 1;

    // Numéro de coup : au début de chaque coup blanc, et toujours en tête de ligne
    // (après un commentaire ou une variante, le coup noir reprend son numéro « 6... »).
    const atLineStart = buffer.filter(part => part.t !== 'sp').length === 0;
    if (numbers && (side === 'w' || atLineStart)) {
      buffer.push({ t: 'num', text: side === 'w' ? `${moveNumber}.` : `${moveNumber}...` });
    }
    // Comme dans la référence, seules les fautes sont signalées.
    const fault = ply && ['??', '?', '?!'].includes(ply.symbol) ? ply.symbol : '';
    buffer.push({
      t: 'move',
      text: pdn + fault,
      mark: fault === '??' ? 'blunder' : fault === '?' ? 'error' : fault === '?!' ? 'inaccuracy' : '',
    });
    buffer.push({ t: 'sp' });

    if (!fault) continue;
    const verdict = fault === '??' ? 'Blunder' : 'Inaccuracy';
    buffer.push({ t: 'note', text: `${verdict}. Best move was ${ply.best || '—'}.` });
    flush();
    if (ply.pv?.length) {
      // La variante reprend après le coup fautif : demi-coup suivant seulement
      // (le numéro du coup vient du premier coup de la variante, jamais doublé).
      const startSide = side === 'w' ? 'b' : 'w';
      const line = el('div', 'an-commentary-var');
      line.append(el('span', 'acv-bar', '⌐'));
      const variationText = formatVariation(ply.pv, index + 1, startSide).replace(/^(\d+)\.\s+/, '');
      line.append(el('span', 'acv-line', variationText));
      blocks.push({ type: 'variation', node: line });
    }
    buffer.push({ t: 'sp' });
  }
  flush();
  return blocks;
}

export function buildPrintSheet({
  headers, plies, states, positions = [], marks = new Set(), options = {}, depth = 12, result = '*', title = '',
  threats = null, threatDepth = 10,
}) {
  const detail = options.detail || 'errors';
  const thresholds = options.thresholds || { error: 0.5, blunder: 1.5 };
  const head = normaliseHeaders(headers);
  const pliesByIndex = new Map(plies.map(ply => [ply.index, ply]));
  const errorIndexes = plies.filter(ply => ply.symbol === '?' || ply.symbol === '??').map(ply => ply.index);
  const diagramIndexes = new Set([...marks]);
  if (options.autoBlunder) {
    for (const ply of plies) if (ply.symbol === '??') diagramIndexes.add(ply.index + 1);
  }
  const diagramAfterMove = new Map();
  for (const positionIndex of diagramIndexes) {
    // La position marquée est celle qui suit le coup d'indice positionIndex-1.
    const moveIndex = positionIndex - 1;
    if (moveIndex < 0) continue;
    if (!diagramAfterMove.has(moveIndex)) diagramAfterMove.set(moveIndex, positionIndex);
  }

  const sheet = el('article', 'print-sheet');
  sheet.id = 'print-sheet';
  const page = el('div', 'sheet-page');

  const toolbar = el('div', 'sheet-toolbar');
  const printButton = el('button', 'primary-button', 'Imprimer / PDF');
  printButton.type = 'button';
  printButton.addEventListener('click', () => window.print());
  const closeButton = el('button', 'secondary-button', 'Fermer');
  closeButton.type = 'button';
  closeButton.addEventListener('click', () => sheet.remove());
  toolbar.append(printButton, closeButton, el('span', 'sheet-toolbar-note', 'Dans la boîte d’impression, choisissez « Enregistrer au format PDF ».'));
  sheet.append(toolbar);

  const header = el('header', 'sheet-head');
  header.append(el('h1', 'sheet-title', title || 'Analyse de la partie'));
  header.append(el('p', 'sheet-sub', `${head.White} — ${head.Black}`));
  const metaParts = [
    head.Event !== 'Analyse PIONICIDE' ? head.Event : '',
    head.Date,
    `Résultat ${result}`,
    `PIONICIDE, profondeur ${depth}`,
    detail === 'errors' ? 'Erreurs et grosses erreurs seulement' : 'Partie complète',
    threats?.length ? `Menaces analysées à la profondeur ${threatDepth}` : '',
  ].filter(Boolean);
  header.append(el('p', 'sheet-meta', metaParts.join(' · ')));
  header.append(el('p', 'sheet-legend',
    `! meilleur coup de PIONICIDE · ? perte d’au moins ${String(thresholds.error).replace('.', ',')} pion · `
    + `?? perte d’au moins ${String(thresholds.blunder).replace('.', ',')} pion · évaluations vues des Blancs`));
  page.append(header);

  // Texte commenté continu (présentation des captures de référence), en tête de feuille.
  const commentaryBlocks = buildAnnotatedCommentary({ plies, moves: options.moves || [], numbers: options.commentaryNumbers !== false });
  if (commentaryBlocks.length) {
    const section = el('section', 'sheet-commentary');
    section.id = 'sheet-commentary';
    section.append(el('h2', 'sheet-section', 'Partie commentée automatiquement'));
    const body = el('div', 'an-commentary');
    for (const block of commentaryBlocks) {
      if (block.type === 'variation') { body.append(block.node); continue; }
      const paragraph = el('p', 'an-commentary-line');
      for (const part of block.parts) {
        if (part.t === 'sp') continue;
        if (part.t === 'num') { paragraph.append(el('span', 'ac-num', part.text)); paragraph.append(document.createTextNode(' ')); continue; }
        paragraph.append(el('span', `ac-move${part.mark ? ' ac-' + part.mark : ''}`, part.text));
        paragraph.append(document.createTextNode(' '));
      }
      body.append(paragraph);
    }
    section.append(body);
    page.append(section);
  }

  const table = el('div', 'sheet-moves');
  const rowHeader = el('div', 'move-line move-line-head');
  rowHeader.append(el('span', 'mn', 'N°'), el('span', 'mw', 'Blancs'), el('span', 'mb', 'Noirs'));
  table.append(rowHeader);

  const rows = Math.ceil(plies.length / 2);
  let printedErrors = 0;
  for (let row = 0; row < rows; row += 1) {
    const whiteIndex = row * 2;
    const blackIndex = whiteIndex + 1;
    const whitePly = pliesByIndex.get(whiteIndex);
    const blackPly = blackIndex < plies.length ? pliesByIndex.get(blackIndex) : null;
    const rowHasError = [whitePly, blackPly].some(ply => ply && (ply.symbol === '?' || ply.symbol === '??'));
    // Un diagramme choisi à la main s'imprime même si le coup n'est pas une erreur.
    const rowHasDiagram = [whitePly, blackPly].some(ply => ply && diagramAfterMove.has(ply.index));
    if (detail === 'errors' && !rowHasError && !rowHasDiagram) continue;

    const line = el('div', 'move-line');
    line.append(el('span', 'mn', String(row + 1)));
    const markClass = ply => (ply?.symbol === '??' ? ' mark-blunder' : ply?.symbol === '?' ? ' mark-error' : '');
    const whiteCell = el('span', `mw${markClass(whitePly)}`, whitePly ? moveLabel(whitePly) : '');
    const blackCell = el('span', `mb${markClass(blackPly)}`, blackPly ? moveLabel(blackPly) : '');
    line.append(whiteCell, blackCell);
    table.append(line);

    for (const ply of [whitePly, blackPly]) {
      if (!ply || (ply.symbol !== '?' && ply.symbol !== '??')) continue;
      printedErrors += 1;
      const note = el('div', 'note');
      const noteHeader = el('p', 'note-head',
        `Coup ${ply.moveNumber} · ${ply.side === 'w' ? 'Blancs' : 'Noirs'} · ${ply.played} ${ply.symbol}`);
      note.append(noteHeader);
      const list = el('dl', 'note-body');
      const add = (term, value) => {
        list.append(el('dt', '', term));
        list.append(el('dd', '', value));
      };
      add('Mon coup', ply.played);
      add('Meilleur coup de PIONICIDE', ply.best || '—');
      add('Évaluation avant', formatEval(ply.evalBeforeWhite));
      add('Évaluation après', formatEval(ply.evalAfterWhite));
      add('Perte', Number.isFinite(ply.loss) ? `${ply.loss.toFixed(2).replace('.', ',')} pion` : '—');
      add('Variante conseillée', ply.pv?.length
        ? formatVariation(ply.pv, ply.index)
        : '—');
      note.append(list);
      table.append(note);
    }

    for (const ply of [whitePly, blackPly]) {
      if (!ply) continue;
      const positionIndex = diagramAfterMove.get(ply.index);
      if (positionIndex === undefined) continue;
      const state = states[positionIndex];
      if (!state) continue;
      const figure = el('figure', 'diagram');
      const bestHere = positions[positionIndex]?.best;
      figure.append(boardSvg({
        board: state.board,
        orientation: 'w',
        arrow: options.arrow && bestHere ? [bestHere.from, bestHere.to] : null,
        numbers: !!options.numbers,
        title: `Position après le coup ${ply.moveNumber} (${ply.played})`,
      }));
      figure.append(el('figcaption', '',
        `Coup ${ply.moveNumber} · ${ply.played} · ${state.side === 'w' ? 'aux Blancs' : 'aux Noirs'} de jouer`));
      table.append(figure);
    }
  }
  if (!printedErrors && detail === 'errors') {
    table.append(el('p', 'sheet-empty', 'Aucune erreur au-dessus des seuils choisis. Utilisez « Toute la partie » pour la liste complète.'));
  }
  page.append(table);
  if (threats?.length) {
    const notes = threats
      .filter(entry => entry && (entry.created || entry.avoided))
      .map(entry => ({ entry, text: threatSummaryText(entry) }))
      .filter(item => item.text);
    if (notes.length) {
      const section = el('section', 'sheet-threats');
      section.append(el('h2', 'sheet-section', 'Menaces de la partie'));
      section.append(el('p', 'sheet-legend',
        'Menace créée : le camp qui vient de jouer rejoue (l’adversaire passe). '
        + 'Menace évitée : l’adversaire jouait à la place de ce coup ; la parade est vérifiée après le coup.'));
      for (const { entry, text } of notes) {
        const block = el('div', 'note note-threat');
        block.append(el('p', 'note-head',
          `Coup ${entry.moveNumber} · ${entry.side === 'w' ? 'Blancs' : 'Noirs'} · ${entry.played}`));
        block.append(el('p', 'note-threat-text', text));
        section.append(block);
      }
      table.append(section);
    }
  }
  page.append(el('p', 'sheet-foot', `Partie analysée par PIONICIDE · ${todayPdn()} · aucune donnée envoyée.`));
  sheet.append(page);
  return sheet;
}

export function openPrintSheet(payload) {
  document.querySelector('#print-sheet')?.remove();
  const sheet = buildPrintSheet(payload);
  document.body.append(sheet);
  document.body.classList.add('sheet-open');
  const observer = new MutationObserver(() => {
    if (!document.body.contains(sheet)) {
      document.body.classList.remove('sheet-open');
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true });
  return sheet;
}
