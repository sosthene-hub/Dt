/* PIONICIDE · Arbre d'analyse manuelle (variantes imbriquées, commentaires,
   symboles d'appréciation et diagrammes à n'importe quelle position).

   Ce module est 100 % pur (aucune dépendance au DOM) afin d'être intégralement
   testable sous Node :
   - arbre à profondeur illimitée : ligne principale (profondeur 0), variantes
     de niveau 1 [ … ] (vertes), sous-variantes de niveau 2 ( … ) (italique bleu),
     et niveaux suivants ;
   - commentaires avant le coup (preComment, utile au début d'une variante :
     « Mieux vaut 27...9-14 ») et après le coup (comment) ;
   - diagramme attachable à N'IMPORTE QUELLE position (position initiale, coup
     de la partie, variante ou sous-variante) ;
   - sérialisation JSON (sauvegarde locale automatique) et aller-retour PDN
     complet (variantes imbriquées, commentaires, NAG/symboles et [%diagram]). */

import { createInitialBoard, generateLegalMoves, moveToHub } from '../game-rules.js';
import { initialState, appendState } from '../game-history.js';
import { moveToPdn, parseHeaders, resolvePdnMove } from '../pdn.js';
import { parsePdnPosition, positionToPdn } from '../position.js';
import { normaliseHeaders } from './export.js';

export const ALLOWED_SYMBOLS = ['', '!', '!!', '?', '??', '!?', '?!'];

const NAG_TO_SYMBOL = {
  '$1': '!',
  '$2': '?',
  '$3': '!!',
  '$4': '??',
  '$5': '!?',
  '$6': '?!',
};

const INITIAL_PDN_POS = positionToPdn(createInitialBoard(), 'w');

function makeNode({
  id, parentId = null, ply = 0, move = null, san = '', state,
  symbol = '', preComment = '', comment = '', diagram = false, diagramCaption = '',
  originMain = false,
}) {
  return {
    id,
    parentId,
    ply,
    move,
    san,
    symbol,
    preComment,
    comment,
    diagram: Boolean(diagram),
    diagramCaption: String(diagramCaption || ''),
    originMain: Boolean(originMain),
    state,
    main: null,
    variations: [],
  };
}

/** Crée un arbre d'analyse à partir d'une position initiale et d'une suite de coups. */
export function createManualTree({ start, moves = [] } = {}) {
  const startBoard = start?.board ? start.board.slice() : createInitialBoard();
  const startSide = start?.side === 'b' ? 'b' : 'w';
  const rootState = initialState(startBoard, startSide);
  const nodes = new Map();
  let seq = 0;
  const nextId = () => `n${seq++}`;

  const root = makeNode({
    id: nextId(),
    parentId: null,
    ply: 0,
    move: null,
    san: '',
    state: rootState,
    originMain: true,
  });
  nodes.set(root.id, root);

  const tree = {
    root,
    nodes,
    rootSide: startSide,
    allocId: nextId,
  };

  let cur = root;
  for (const rawMove of moves) {
    const legal = generateLegalMoves(cur.state.board, cur.state.side)
      .find(candidate => moveToHub(candidate) === moveToHub(rawMove));
    if (!legal) break;
    const childState = appendState([cur.state], legal).at(-1);
    const child = makeNode({
      id: tree.allocId(),
      parentId: cur.id,
      ply: cur.ply + 1,
      move: legal,
      san: moveToPdn(legal),
      state: childState,
      originMain: true,
    });
    tree.nodes.set(child.id, child);
    cur.main = child;
    cur = child;
  }

  return tree;
}

export function getNode(tree, nodeId) {
  return tree?.nodes?.get(nodeId) || null;
}

export function getParent(tree, nodeId) {
  const node = getNode(tree, nodeId);
  return node && node.parentId ? getNode(tree, node.parentId) : null;
}

/**
 * Profondeur logique d'un nœud :
 * - 0 : ligne principale (racine et chaîne .main depuis la racine)
 * - 1 : variante de premier niveau [ … ]
 * - 2 : sous-variante ( … )
 * - 3+ : sous-variantes plus profondes
 */
export function nodeDepth(tree, nodeId) {
  let depth = 0;
  let cur = getNode(tree, nodeId);
  while (cur && cur.parentId) {
    const parent = getNode(tree, cur.parentId);
    if (!parent) break;
    if (parent.variations.includes(cur)) depth += 1;
    cur = parent;
  }
  return depth;
}

/** Renvoie la racine de la variante courante ({ parent, varRoot, index }) ou null si ligne principale. */
export function variationRootOf(tree, nodeId) {
  let cur = getNode(tree, nodeId);
  while (cur && cur.parentId) {
    const parent = getNode(tree, cur.parentId);
    if (!parent) return null;
    const idx = parent.variations.indexOf(cur);
    if (idx !== -1) return { parent, varRoot: cur, index: idx };
    cur = parent;
  }
  return null;
}

/** Tous les nœuds de la ligne principale [root, ply1, ply2, ...]. */
export function mainLineNodes(tree) {
  const list = [];
  let cur = tree?.root || null;
  while (cur) {
    list.push(cur);
    cur = cur.main;
  }
  return list;
}

/** Numéro du coup et camp ayant joué ce demi-coup (ply >= 1). */
export function moveNumberAt(ply, rootSide = 'w') {
  const offset = (ply - 1) + (rootSide === 'b' ? 1 : 0);
  return {
    num: Math.floor(offset / 2) + 1,
    side: offset % 2 === 0 ? 'w' : 'b',
  };
}

/** « 19.31-27 », « 12-18 » ou « 19...7-11 » selon que le numéro est requis. */
export function formatMoveToken(node, rootSide = 'w', forceNumber = false) {
  if (!node || !node.move) return 'Position initiale';
  const { num, side } = moveNumberAt(node.ply, rootSide);
  const prefix = side === 'w' ? `${num}.` : (forceNumber ? `${num}...` : '');
  return `${prefix}${node.san}${node.symbol || ''}`;
}

/** Étiquette courte toujours numérotée : « 19.31-27 » ou « 19...12-18 ». */
export function describeMoveNode(node, rootSide = 'w') {
  if (!node || !node.move) return 'Position initiale';
  return formatMoveToken(node, rootSide, true);
}

/**
 * Joue un coup légal depuis `fromNodeId`.
 * - Si le coup existe déjà comme .main (et !asVariation) ou dans .variations, y avance sans doublon.
 * - Si fromNode n'a pas encore de .main et !asVariation, prolonge la ligne courante (.main).
 * - Sinon, crée une nouvelle branche dans fromNode.variations.
 */
export function playMoveOnTree(tree, fromNodeId, move, { asVariation = false } = {}) {
  const parent = getNode(tree, fromNodeId);
  if (!parent) throw new Error('Position parente introuvable dans l’arbre.');
  const legal = generateLegalMoves(parent.state.board, parent.state.side)
    .find(candidate => moveToHub(candidate) === moveToHub(move));
  if (!legal) throw new Error('Coup illégal dans cette position.');

  const hub = moveToHub(legal);
  if (!asVariation && parent.main && moveToHub(parent.main.move) === hub) {
    return { node: parent.main, created: false };
  }
  const existingVar = parent.variations.find(v => moveToHub(v.move) === hub);
  if (existingVar) {
    return { node: existingVar, created: false };
  }

  const nextState = appendState([parent.state], legal).at(-1);
  const child = makeNode({
    id: tree.allocId(),
    parentId: parent.id,
    ply: parent.ply + 1,
    move: legal,
    san: moveToPdn(legal),
    state: nextState,
    originMain: false,
  });
  tree.nodes.set(child.id, child);

  if (!parent.main && !asVariation) {
    parent.main = child;
  } else {
    parent.variations.push(child);
  }
  return { node: child, created: true };
}

/** Insère une séquence de coups (ex. variante proposée par PIONICIDE) à partir d'un nœud. */
export function addLineToTree(tree, fromNodeId, moves = [], { asVariation = true, preComment = '', comment = '' } = {}) {
  let curId = fromNodeId;
  let firstNode = null;
  let lastNode = null;
  moves.forEach((move, idx) => {
    const res = playMoveOnTree(tree, curId, move, { asVariation: idx === 0 ? asVariation : false });
    if (idx === 0) {
      firstNode = res.node;
      if (preComment && !firstNode.preComment) firstNode.preComment = preComment;
    }
    lastNode = res.node;
    curId = res.node.id;
  });
  if (lastNode && comment && !lastNode.comment) lastNode.comment = comment;
  return { firstNode, lastNode };
}

/** Met à jour les annotations (commentaires, symbole, diagramme) d'un nœud. */
export function updateNodeAnnotation(tree, nodeId, patch = {}) {
  const node = getNode(tree, nodeId);
  if (!node) return null;
  if ('comment' in patch) node.comment = String(patch.comment ?? '');
  if ('preComment' in patch) node.preComment = String(patch.preComment ?? '');
  if ('symbol' in patch && ALLOWED_SYMBOLS.includes(patch.symbol)) {
    node.symbol = node.move ? patch.symbol : '';
  }
  if ('diagram' in patch) node.diagram = Boolean(patch.diagram);
  if ('diagramCaption' in patch) node.diagramCaption = String(patch.diagramCaption ?? '');
  return node;
}

function collectSubtreeIds(node, acc = []) {
  if (!node) return acc;
  acc.push(node.id);
  if (node.main) collectSubtreeIds(node.main, acc);
  for (const v of node.variations) collectSubtreeIds(v, acc);
  return acc;
}

/**
 * Supprime un nœud et toute sa descendance.
 * Renvoie le nœud parent vers lequel replacer le curseur (ou null si refusé).
 */
export function deleteSubtree(tree, nodeId, { allowOriginMain = false } = {}) {
  const node = getNode(tree, nodeId);
  if (!node || !node.parentId) return null;
  if (node.originMain && !allowOriginMain) return null;
  const parent = getNode(tree, node.parentId);
  if (!parent) return null;

  if (parent.main === node) {
    parent.main = null;
  } else {
    const idx = parent.variations.indexOf(node);
    if (idx !== -1) parent.variations.splice(idx, 1);
  }
  for (const id of collectSubtreeIds(node)) {
    tree.nodes.delete(id);
  }
  return parent;
}

/**
 * Promeut la variante contenant `nodeId` :
 * - si elle n'est pas en tête de `parent.variations`, la remonte d'un cran ;
 * - si elle est déjà en tête et que `swapWithMain` est vrai (et que .main n'est pas verrouillé),
 *   l'échange avec `parent.main`.
 */
export function promoteVariation(tree, nodeId, { swapWithMain = true } = {}) {
  const info = variationRootOf(tree, nodeId);
  if (!info) return false;
  const { parent, varRoot, index } = info;
  if (index > 0) {
    parent.variations.splice(index, 1);
    parent.variations.splice(index - 1, 0, varRoot);
    return true;
  }
  if (swapWithMain && parent.main && !parent.main.originMain) {
    const oldMain = parent.main;
    parent.main = varRoot;
    parent.variations.splice(0, 1, oldMain);
    return true;
  }
  if (swapWithMain && !parent.main) {
    parent.variations.splice(0, 1);
    parent.main = varRoot;
    return true;
  }
  return false;
}

/** Détache un coup .main non verrouillé pour le placer en variante [ … ]. */
export function convertMainToVariation(tree, nodeId) {
  const node = getNode(tree, nodeId);
  if (!node || !node.parentId || node.originMain) return false;
  const parent = getNode(tree, node.parentId);
  if (!parent || parent.main !== node) return false;
  parent.main = null;
  parent.variations.unshift(node);
  return true;
}

/** Statistiques rapides sur l'arbre pour l'interface et l'export. */
export function countTreeStats(tree) {
  let mainMoves = 0;
  let variationCount = 0;
  let variationMoves = 0;
  let commentCount = 0;
  let diagramCount = 0;

  function walk(node, depth) {
    if (!node) return;
    if (node.move) {
      if (depth === 0) mainMoves += 1;
      else variationMoves += 1;
    }
    if ((node.comment && node.comment.trim()) || (node.preComment && node.preComment.trim())) {
      commentCount += 1;
    }
    if (node.diagram) diagramCount += 1;
    for (const v of node.variations) {
      variationCount += 1;
      walk(v, depth + 1);
    }
    if (node.main) walk(node.main, depth);
  }
  walk(tree.root, 0);
  return {
    mainMoves,
    variationCount,
    variationMoves,
    commentCount,
    diagramCount,
    hasManualEnrichment: variationCount > 0 || commentCount > 0 || diagramCount > 0,
  };
}

/* ============================================================================
 *  Modèle structuré de rendu (style livre / Turbo Dambase 5.0)
 * ============================================================================
 *
 * Produit une liste ordonnée de blocs :
 * - { type: 'intro', nodeId, text }
 * - { type: 'main-line', items: [ { kind: 'preComment'|'move'|'comment', nodeId, depth: 0, text } ] }
 * - { type: 'variation-block', varRootId, depth: 1, segments: [ ... ] }
 * - { type: 'diagram', diagramNumber, nodeId, depth, state, label, caption }
 */

function diagramAutoLabel(node, rootSide, depth) {
  if (!node.move) {
    return `Position initiale · Trait aux ${node.state.side === 'w' ? 'Blancs' : 'Noirs'}`;
  }
  const moveText = describeMoveNode(node, rootSide);
  const trait = `Trait aux ${node.state.side === 'w' ? 'Blancs' : 'Noirs'}`;
  const prefix = depth === 0 ? 'Après' : 'Variante, après';
  return `${prefix} ${moveText} · ${trait}`;
}

export function buildAnalysisBlocks(tree) {
  const blocks = [];
  const root = tree.root;
  const rootSide = tree.rootSide || root.state.side || 'w';
  let diagramSeq = 0;

  const makeDiagramObj = (node, depth) => {
    diagramSeq += 1;
    return {
      kind: 'diagram',
      type: 'diagram',
      diagramNumber: diagramSeq,
      nodeId: node.id,
      depth,
      state: node.state,
      lastMove: node.move ? [node.move.from, node.move.to] : null,
      label: diagramAutoLabel(node, rootSide, depth),
      caption: (node.diagramCaption || '').trim(),
    };
  };

  // Introduction et/ou diagramme sur la position de départ
  const rootText = [root.preComment?.trim(), root.comment?.trim()].filter(Boolean).join(' ');
  if (rootText) {
    blocks.push({ type: 'intro', nodeId: root.id, text: rootText });
  }
  if (root.diagram) {
    blocks.push(makeDiagramObj(root, 0));
  }

  /**
   * Parcourt une variante de niveau `depth >= 1` à partir de `varRoot` et pousse
   * ses segments (tokens en ligne et éventuels diagrammes) dans `segments`.
   */
  function emitVariationLine(varRoot, depth, segments) {
    let needNumber = true;

    const emitSingleNode = node => {
      const pre = (node.preComment || '').trim();
      if (pre) {
        segments.push({ kind: 'preComment', depth, nodeId: node.id, text: pre });
        needNumber = true;
      }
      segments.push({
        kind: 'move',
        depth,
        nodeId: node.id,
        ply: node.ply,
        text: formatMoveToken(node, rootSide, needNumber),
      });
      needNumber = false;

      const post = (node.comment || '').trim();
      if (post) {
        segments.push({ kind: 'comment', depth, nodeId: node.id, text: post });
        needNumber = true;
      }
      if (node.diagram) {
        segments.push(makeDiagramObj(node, depth));
        needNumber = true;
      }
    };

    const emitSiblingSubVariations = subVars => {
      if (!subVars.length) return;
      const subDepth = depth + 1;
      const useBrackets = subDepth % 2 === 1;
      segments.push({
        kind: useBrackets ? 'open-bracket' : 'open-paren',
        depth: subDepth,
        text: useBrackets ? '[ ' : '( ',
      });
      subVars.forEach((subRoot, idx) => {
        if (idx > 0) {
          segments.push({ kind: 'semicolon', depth: subDepth, text: '; ' });
        }
        emitVariationLine(subRoot, subDepth, segments);
      });
      segments.push({
        kind: useBrackets ? 'close-bracket' : 'close-paren',
        depth: subDepth,
        text: useBrackets ? ' ]' : ')',
      });
      needNumber = true;
    };

    // 1er coup de cette variante
    emitSingleNode(varRoot);

    // Suite (.main) de cette variante
    let parent = varRoot;
    let cur = parent.main;
    while (cur) {
      emitSingleNode(cur);
      if (parent.variations.length > 0) {
        emitSiblingSubVariations(parent.variations);
      }
      parent = cur;
      cur = parent.main;
    }
    // Sous-variantes de continuation à la toute fin de cette variante (si parent.main === null)
    if (parent.variations.length > 0) {
      emitSiblingSubVariations(parent.variations);
    }
  }

  const buildTopVariationBlock = varRoot => {
    const segments = [{ kind: 'open-bracket', depth: 1, text: '[ ' }];
    emitVariationLine(varRoot, 1, segments);
    segments.push({ kind: 'close-bracket', depth: 1, text: ' ]' });
    return {
      type: 'variation-block',
      varRootId: varRoot.id,
      depth: 1,
      segments,
    };
  };

  // Parcours de la ligne principale (depth = 0)
  let currentMainItems = [];
  const flushMain = () => {
    if (currentMainItems.length) {
      blocks.push({ type: 'main-line', items: currentMainItems });
      currentMainItems = [];
    }
  };

  let needNumber = true;
  let parent = root;
  let cur = root.main;

  while (cur) {
    const pre = (cur.preComment || '').trim();
    if (pre) {
      currentMainItems.push({ kind: 'preComment', depth: 0, nodeId: cur.id, text: pre });
      needNumber = true;
    }
    currentMainItems.push({
      kind: 'move',
      depth: 0,
      nodeId: cur.id,
      ply: cur.ply,
      text: formatMoveToken(cur, rootSide, needNumber),
    });
    needNumber = false;

    const post = (cur.comment || '').trim();
    if (post) {
      currentMainItems.push({ kind: 'comment', depth: 0, nodeId: cur.id, text: post });
      needNumber = true;
    }

    if (cur.diagram) {
      flushMain();
      blocks.push(makeDiagramObj(cur, 0));
      needNumber = true;
    }

    // Variantes alternatives à `cur` (stockées dans `parent.variations`)
    if (parent.variations.length > 0) {
      flushMain();
      for (const varRoot of parent.variations) {
        blocks.push(buildTopVariationBlock(varRoot));
      }
      needNumber = true;
    }

    parent = cur;
    cur = parent.main;
  }

  flushMain();

  // Variantes attachées après le dernier coup (ou directement sur root si aucun coup principal)
  if (parent.variations.length > 0) {
    for (const varRoot of parent.variations) {
      blocks.push(buildTopVariationBlock(varRoot));
    }
  }

  return blocks;
}

/** Rendu texte fidèle (utile pour les tests et l'aperçu texte). */
export function blocksToPlainText(blocks) {
  const lines = [];
  const joinInline = tokens => {
    let out = '';
    for (const tok of tokens) {
      if (tok.kind === 'diagram') {
        out = out.trimEnd();
        out += `\n[${tok.label}${tok.caption ? ' — ' + tok.caption : ''}]\n`;
        continue;
      }
      if (tok.kind === 'open-bracket' || tok.kind === 'open-paren') {
        if (out && !out.endsWith(' ') && !out.endsWith('\n')) out += ' ';
        out += tok.text;
      } else if (tok.kind === 'close-bracket' || tok.kind === 'close-paren' || tok.kind === 'semicolon') {
        out = out.trimEnd();
        if (tok.kind === 'close-bracket') out += ' ]';
        else out += tok.text;
      } else {
        if (out && !out.endsWith(' ') && !out.endsWith('\n') && !out.endsWith('( ') && !out.endsWith('[ ')) {
          out += ' ';
        }
        out += tok.text;
      }
    }
    return out.trim();
  };

  for (const block of blocks) {
    if (block.type === 'intro') lines.push(block.text);
    else if (block.type === 'main-line') lines.push(joinInline(block.items));
    else if (block.type === 'variation-block') lines.push(joinInline(block.segments));
    else if (block.type === 'diagram') lines.push(`[${block.label}${block.caption ? ' — ' + block.caption : ''}]`);
  }
  return lines.join('\n');
}

/* ============================================================================
 *  Sérialisation JSON (localStorage) et PDN complet (export / import)
 * ============================================================================ */

export function serializeManualTree(tree) {
  function encodeNode(node) {
    return {
      move: node.move
        ? { from: node.move.from, to: node.move.to, path: [...node.move.path], captured: [...(node.move.captured || [])] }
        : null,
      symbol: node.symbol || '',
      preComment: node.preComment || '',
      comment: node.comment || '',
      diagram: Boolean(node.diagram),
      diagramCaption: node.diagramCaption || '',
      originMain: Boolean(node.originMain),
      main: node.main ? encodeNode(node.main) : null,
      variations: node.variations.map(encodeNode),
    };
  }
  return {
    version: 1,
    startPos: positionToPdn(tree.root.state.board, tree.root.state.side),
    root: encodeNode(tree.root),
  };
}

export function deserializeManualTree(data) {
  if (!data || data.version !== 1 || !data.root) return null;
  const start = parsePdnPosition(data.startPos) || { board: createInitialBoard(), side: 'w' };
  const tree = createManualTree({ start, moves: [] });
  const applyMeta = (target, src) => {
    target.symbol = ALLOWED_SYMBOLS.includes(src.symbol) && target.move ? src.symbol : '';
    target.preComment = String(src.preComment || '');
    target.comment = String(src.comment || '');
    target.diagram = Boolean(src.diagram);
    target.diagramCaption = String(src.diagramCaption || '');
    target.originMain = Boolean(src.originMain);
  };
  applyMeta(tree.root, data.root);

  function restoreChildren(parentNode, srcNode) {
    if (srcNode.main && srcNode.main.move) {
      try {
        const { node } = playMoveOnTree(tree, parentNode.id, srcNode.main.move, { asVariation: false });
        applyMeta(node, srcNode.main);
        restoreChildren(node, srcNode.main);
      } catch {
        // Coup invalide ignoré proprement
      }
    }
    for (const vSrc of srcNode.variations || []) {
      if (!vSrc?.move) continue;
      try {
        const { node } = playMoveOnTree(tree, parentNode.id, vSrc.move, { asVariation: true });
        applyMeta(node, vSrc);
        restoreChildren(node, vSrc);
      } catch {
        // Variante invalide ignorée proprement
      }
    }
  }
  restoreChildren(tree.root, data.root);
  return tree;
}

function cleanPdnCommentText(text) {
  return String(text || '').replace(/[{}]/g, ch => (ch === '{' ? '(' : ')')).trim();
}

function formatCommentWithDiagram(commentText, diagram, diagramCaption) {
  const parts = [];
  if (diagram) {
    const cap = cleanPdnCommentText(diagramCaption).replace(/\]/g, ')');
    parts.push(cap ? `[%diagram:${cap}]` : '[%diagram]');
  }
  const clean = cleanPdnCommentText(commentText);
  if (clean) parts.push(clean);
  return parts.length ? `{ ${parts.join(' ')} }` : '';
}

/** Exporte l'arbre complet (variantes imbriquées, commentaires, symboles, diagrammes) en PDN valide. */
export function treeToPdn(tree, { headers = {}, result = '*' } = {}) {
  const head = normaliseHeaders(headers, { Event: 'Analyse manuelle PIONICIDE' });
  const startFen = positionToPdn(tree.root.state.board, tree.root.state.side);
  const headerLines = [
    `[Event "${head.Event}"]`,
    `[Site "${head.Site}"]`,
    `[Date "${head.Date}"]`,
    `[Round "${head.Round}"]`,
    `[White "${head.White}"]`,
    `[Black "${head.Black}"]`,
    `[Result "${result || '*'}"]`,
    '[Annotator "Analyse manuelle · PIONICIDE"]',
  ];
  if (startFen !== INITIAL_PDN_POS) {
    headerLines.push('[SetUp "1"]');
    headerLines.push(`[FEN "${startFen}"]`);
  }

  const rootSide = tree.rootSide || tree.root.state.side || 'w';
  const tokens = [];

  const rootPre = cleanPdnCommentText([tree.root.preComment, tree.root.comment].filter(Boolean).join(' '));
  const rootComment = formatCommentWithDiagram(rootPre, tree.root.diagram, tree.root.diagramCaption);
  if (rootComment) tokens.push(rootComment);

  function serializeLine(firstNode, parentOfFirst, isVariation) {
    let needNumber = true;
    let parent = parentOfFirst;
    let cur = firstNode;

    while (cur) {
      const pre = cleanPdnCommentText(cur.preComment);
      if (pre) {
        tokens.push(`{ ${pre} }`);
        needNumber = true;
      }
      const { num, side } = moveNumberAt(cur.ply, rootSide);
      if (side === 'w') tokens.push(`${num}.`);
      else if (needNumber) tokens.push(`${num}...`);
      tokens.push(`${cur.san}${cur.symbol || ''}`);
      needNumber = false;

      const postToken = formatCommentWithDiagram(cur.comment, cur.diagram, cur.diagramCaption);
      if (postToken) {
        tokens.push(postToken);
        needNumber = true;
      }

      // Les alternatives à `cur` se trouvent dans `parent.variations`, sauf pour le 1er coup d'une variante
      if (!(isVariation && cur === firstNode) && parent && parent.variations.length > 0) {
        for (const v of parent.variations) {
          tokens.push('(');
          serializeLine(v, parent, true);
          tokens.push(')');
        }
        needNumber = true;
      }

      parent = cur;
      cur = parent.main;
    }

    if (parent && parent.variations.length > 0) {
      for (const v of parent.variations) {
        tokens.push('(');
        serializeLine(v, parent, true);
        tokens.push(')');
      }
    }
  }

  if (tree.root.main) {
    serializeLine(tree.root.main, tree.root, false);
  } else if (tree.root.variations.length > 0) {
    for (const v of tree.root.variations) {
      tokens.push('(');
      serializeLine(v, tree.root, true);
      tokens.push(')');
    }
  }

  tokens.push(result || '*');

  // Mise en forme lisible ~80 caractères par ligne
  const wrapped = [];
  let line = '';
  for (const tok of tokens) {
    const next = line ? `${line} ${tok}` : tok;
    if (line && next.length > 82) {
      wrapped.push(line);
      line = tok;
    } else {
      line = next;
    }
  }
  if (line) wrapped.push(line);

  return `${headerLines.join('\n')}\n\n${wrapped.join('\n')}\n`;
}

function extractDiagramTag(rawComment) {
  let diagram = false;
  let diagramCaption = '';
  const cleaned = String(rawComment || '').replace(/\[%diagram(?::([^\]]*))?\]/gi, (_, cap) => {
    diagram = true;
    if (cap) diagramCaption = cap.trim();
    return '';
  }).trim();
  return { text: cleaned, diagram, diagramCaption };
}

function tokenizeMovetext(movetext) {
  const out = [];
  const src = String(movetext || '');
  let i = 0;

  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) { i += 1; continue; }

    // Commentaire { ... } — texte intégralement préservé (deux-points, ponctuation, etc.)
    if (ch === '{') {
      const end = src.indexOf('}', i + 1);
      if (end === -1) {
        out.push({ type: 'comment', raw: src.slice(i + 1) });
        break;
      }
      out.push({ type: 'comment', raw: src.slice(i + 1, end) });
      i = end + 1;
      continue;
    }

    // Commentaire de fin de ligne PDN (% en début de ligne)
    if (ch === '%' && (i === 0 || src[i - 1] === '\n')) {
      const nl = src.indexOf('\n', i + 1);
      i = nl === -1 ? src.length : nl + 1;
      continue;
    }

    if (ch === '(' || ch === '[') {
      out.push({ type: 'var-open', ch });
      i += 1;
      continue;
    }
    if (ch === ')' || ch === ']') {
      out.push({ type: 'var-close', ch });
      i += 1;
      continue;
    }
    if (ch === ';') {
      out.push({ type: 'semicolon' });
      i += 1;
      continue;
    }

    // Lecture d'un mot jusqu'au prochain délimiteur
    let j = i;
    while (j < src.length && !/[\s{}()[\];]/.test(src[j])) j += 1;
    const word = src.slice(i, j).replace(/[×:]/g, 'x');
    i = j;

    if (word === '*' || /^(?:1-0|0-1|2-0|0-2|1-1|1\/2-1\/2)$/.test(word)) {
      out.push({ type: 'result', value: word });
      continue;
    }
    if (/^\$\d+$/.test(word)) {
      if (NAG_TO_SYMBOL[word]) out.push({ type: 'symbol', value: NAG_TO_SYMBOL[word] });
      continue;
    }
    if (/^[!?]{1,2}$/.test(word) && ALLOWED_SYMBOLS.includes(word)) {
      out.push({ type: 'symbol', value: word });
      continue;
    }
    if (/^\d+\.+$/.test(word) || word === '...') {
      continue; // Numéro de coup isolé : 1. ou 19...
    }

    // Coup potentiellement préfixé par son numéro (ex. 19...7-11 ou 20.50-45!)
    const stripped = word.replace(/^\d+\.+/, '');
    const symMatch = stripped.match(/([!?]{1,2})$/);
    const symbol = symMatch && ALLOWED_SYMBOLS.includes(symMatch[1]) ? symMatch[1] : '';
    const core = symMatch ? stripped.slice(0, -symMatch[1].length) : stripped;
    if (/^\d+(?:[-x]\d+)+$/.test(core)) {
      out.push({ type: 'move', token: core, symbol });
    }
  }
  return out;
}

/**
 * Lit un texte PDN (avec variantes imbriquées, commentaires, NAG/symboles et [%diagram])
 * et reconstruit l'arbre complet `tree`, les `headers` et le `result`.
 */
export function parsePdnToTree(text) {
  const raw = String(text || '').trim();
  const headerMatch = raw.match(/^((?:\s*\[[^\n]*\]\s*)+)/);
  const headerBlock = headerMatch ? headerMatch[0] : '';
  const headers = parseHeaders(headerBlock);
  const movetext = raw.slice(headerBlock.length);

  const start = headers.FEN ? parsePdnPosition(headers.FEN) : { board: createInitialBoard(), side: 'w' };
  if (!start) throw new Error('Position de départ FEN invalide.');

  const tree = createManualTree({ start, moves: [] });
  const tokens = tokenizeMovetext(movetext);

  let currentNode = tree.root;
  let awaitingFirstVarMove = false;
  let branchParent = null;
  let savedTipBeforeVar = null;
  let pendingPreComment = '';
  let result = headers.Result || '*';
  const stack = [];

  for (const tok of tokens) {
    if (tok.type === 'result') {
      if (!stack.length && tok.value) result = tok.value;
      continue;
    }
    if (tok.type === 'symbol') {
      if (currentNode && currentNode.move) currentNode.symbol = tok.value;
      continue;
    }
    if (tok.type === 'comment') {
      const parsed = extractDiagramTag(tok.raw);
      if (awaitingFirstVarMove) {
        if (parsed.text) {
          pendingPreComment = pendingPreComment ? `${pendingPreComment} ${parsed.text}` : parsed.text;
        }
      } else {
        if (parsed.text) {
          currentNode.comment = currentNode.comment ? `${currentNode.comment} ${parsed.text}` : parsed.text;
        }
        if (parsed.diagram) {
          currentNode.diagram = true;
          if (parsed.diagramCaption) currentNode.diagramCaption = parsed.diagramCaption;
        }
      }
      continue;
    }
    if (tok.type === 'var-open') {
      stack.push({
        savedCurrent: currentNode,
        savedAwaiting: awaitingFirstVarMove,
        savedBranchParent: branchParent,
        savedTip: savedTipBeforeVar,
        savedPre: pendingPreComment,
      });
      savedTipBeforeVar = currentNode;
      branchParent = getParent(tree, currentNode.id) || currentNode;
      awaitingFirstVarMove = true;
      pendingPreComment = '';
      continue;
    }
    if (tok.type === 'semicolon') {
      if (stack.length > 0 && branchParent) {
        awaitingFirstVarMove = true;
        pendingPreComment = '';
      }
      continue;
    }
    if (tok.type === 'var-close') {
      const frame = stack.pop();
      if (frame) {
        currentNode = frame.savedCurrent;
        awaitingFirstVarMove = frame.savedAwaiting;
        branchParent = frame.savedBranchParent;
        savedTipBeforeVar = frame.savedTip;
        pendingPreComment = frame.savedPre;
      }
      continue;
    }
    if (tok.type === 'move') {
      if (awaitingFirstVarMove) {
        // Variante alternative au dernier coup joué (cas standard PDN) ou suite après le dernier coup
        let anchor = branchParent || currentNode;
        let resolved = resolvePdnMove(anchor.state.board, anchor.state.side, tok.token);
        if (!resolved.move && savedTipBeforeVar && savedTipBeforeVar !== anchor) {
          const alt = resolvePdnMove(savedTipBeforeVar.state.board, savedTipBeforeVar.state.side, tok.token);
          if (alt.move) {
            anchor = savedTipBeforeVar;
            resolved = alt;
            branchParent = anchor;
          }
        }
        if (!resolved.move) continue;
        const { node } = playMoveOnTree(tree, anchor.id, resolved.move, { asVariation: true });
        if (tok.symbol) node.symbol = tok.symbol;
        if (pendingPreComment) node.preComment = pendingPreComment;
        pendingPreComment = '';
        awaitingFirstVarMove = false;
        currentNode = node;
      } else {
        const resolved = resolvePdnMove(currentNode.state.board, currentNode.state.side, tok.token);
        if (!resolved.move) continue;
        const isMain = stack.length === 0;
        const { node } = playMoveOnTree(tree, currentNode.id, resolved.move, { asVariation: false });
        if (isMain) node.originMain = true;
        if (tok.symbol) node.symbol = tok.symbol;
        currentNode = node;
      }
    }
  }

  return { tree, headers, result };
}
