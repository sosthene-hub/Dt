/* PIONICIDE · Feuille imprimable — une position ou une partie entière.
   Volontairement indépendante de l'analyse : on peut imprimer ce que l'on voit,
   sans lancer le moteur. Utilisée par l'explorateur, la recherche de la base et
   le damier d'analyse.

   Le modèle de données (sheetModel) est pur et testable sous Node ; la
   construction du DOM est isolée dans buildGameSheet/openGameSheet. */
import { boardSvg } from './diagram.js';

const SVG_LABEL = 'Damier de la position imprimée';

/**
 * Répartit les coups en lignes « Blancs / Noirs » pour l'impression.
 * @param {string[]} moves  coups en notation PDN
 * @param {number} cursor   nombre de coups joués avant la position représentée
 * @returns {{rows: Array, marked: object|null, at: number, count: number, last: string}}
 */
export function sheetModel(moves = [], cursor = 0) {
  const list = Array.isArray(moves) ? moves : [];
  const rows = [];
  for (let index = 0; index < list.length; index += 2) {
    rows.push({ n: index / 2 + 1, white: list[index] || '', black: list[index + 1] || '' });
  }
  const at = Math.max(0, Math.min(Number(cursor) || 0, list.length));
  const marked = at > 0 ? { n: Math.ceil(at / 2), side: at % 2 === 1 ? 'white' : 'black' } : null;
  return { rows, marked, at, count: list.length, last: at > 0 ? list[at - 1] : '' };
}

/** Phrase de légende sous le damier. */
export function positionCaption(at, total, side = 'w') {
  const trait = side === 'b' ? 'aux Noirs' : 'aux Blancs';
  if (!at) return `Position initiale · ${trait} de jouer`;
  return `Position après le coup ${Math.ceil(at / 2)} (${at % 2 === 1 ? 'Blancs' : 'Noirs'}) · ${trait} de jouer`
    + (total > at ? ` · ${total - at} coup(s) encore à jouer` : ' · fin de la partie');
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}

function todayFr() {
  return new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
}

/**
 * Construit la feuille imprimable.
 *
 * @param {object} options
 * @param {string}  options.title      titre (ex. « Partie de la base »)
 * @param {string}  options.subtitle   ligne secondaire (ex. « Blancs — Noirs »)
 * @param {string}  options.meta       ligne d'informations (événement, date, résultat)
 * @param {Array}   options.board      damier (indice = case FMJD)
 * @param {string}  options.orientation 'w' = Blancs en bas
 * @param {boolean} options.numbers    numéroter les cases
 * @param {string[]} options.moves     coups en notation PDN
 * @param {number}  options.cursor     position représentée (nombre de coups joués)
 * @param {string}  options.side       camp au trait sur la position imprimée
 * @param {string}  options.note       remarque libre imprimée sous le damier
 * @param {Array}   options.boards     diagrammes imposés : [{board, orientation, caption}]
 */
export function buildGameSheet({
  title = 'Position', subtitle = '', meta = '', board, orientation = 'w',
  numbers = true, moves = [], cursor = 0, side = 'w', note = '', boards = null,
} = {}) {
  const sheet = el('article', 'print-sheet');
  sheet.id = 'print-sheet';

  const toolbar = el('div', 'sheet-toolbar');
  const printButton = el('button', 'primary-button', 'Imprimer / PDF');
  printButton.type = 'button';
  printButton.addEventListener('click', () => window.print());
  const closeButton = el('button', 'secondary-button', 'Fermer');
  closeButton.type = 'button';
  closeButton.addEventListener('click', () => sheet.remove());
  toolbar.append(printButton, closeButton,
    el('span', 'sheet-toolbar-note', 'Dans la boîte d’impression, choisissez « Enregistrer au format PDF » pour garder une copie.'));
  sheet.append(toolbar);

  const page = el('div', 'sheet-page');

  const head = el('header', 'sheet-head');
  head.append(el('h1', 'sheet-title', title));
  if (subtitle) head.append(el('p', 'sheet-sub', subtitle));
  if (meta) head.append(el('p', 'sheet-meta', meta));
  page.append(head);

  const model = sheetModel(moves, cursor);
  // Un ou deux diagrammes : la position demandée, ou le départ et la fin d'une partie.
  const figures = Array.isArray(boards) && boards.length
    ? boards
    : (board ? [{ board, orientation, caption: positionCaption(model.at, model.count, side) }] : []);
  for (const entry of figures) {
    if (!entry || !entry.board) continue;
    const figure = el('figure', `diagram sheet-position${figures.length > 1 ? ' sheet-position-half' : ''}`);
    figure.append(boardSvg({
      board: entry.board,
      orientation: entry.orientation || orientation,
      numbers,
      title: SVG_LABEL,
    }));
    if (entry.caption) figure.append(el('figcaption', '', entry.caption));
    page.append(figure);
  }

  if (model.rows.length) {
    const table = el('div', 'sheet-moves');
    const head_ = el('div', 'move-line move-line-head');
    head_.append(el('span', 'mn', 'N°'), el('span', 'mw', 'Blancs'), el('span', 'mb', 'Noirs'));
    table.append(head_);
    for (const row of model.rows) {
      const line = el('div', 'move-line');
      line.append(el('span', 'mn', String(row.n)));
      const whiteMark = model.marked && model.marked.n === row.n && model.marked.side === 'white';
      const blackMark = model.marked && model.marked.n === row.n && model.marked.side === 'black';
      line.append(el('span', `mw${whiteMark ? ' mark-position' : ''}`, row.white));
      line.append(el('span', `mb${blackMark ? ' mark-position' : ''}`, row.black));
      table.append(line);
    }
    page.append(table);
  } else {
    page.append(el('p', 'sheet-empty', 'Aucun coup : la feuille ne représente que la position.'));
  }

  if (note) page.append(el('p', 'sheet-note', note));
  page.append(el('p', 'sheet-foot', `PIONICIDE · ${todayFr()} · aucune donnée envoyée.`));
  sheet.append(page);
  return sheet;
}

/** Affiche la feuille par-dessus l'application, prête à imprimer. */
export function openGameSheet(options) {
  closeGameSheet();
  const sheet = buildGameSheet(options);
  document.body.append(sheet);
  document.body.classList.add('sheet-open');
  const observer = new MutationObserver(() => {
    if (!document.body.contains(sheet)) {
      document.body.classList.remove('sheet-open');
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true });
  return sheet;
}

export function closeGameSheet() {
  const existing = document.querySelector('#print-sheet');
  if (existing) existing.remove();
  document.body.classList.remove('sheet-open');
}
