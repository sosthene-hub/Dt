/* PIONICIDE · Rendu visuel et feuille d'impression de l'analyse manuelle
   (style classique Turbo Dambase / revue de dames :
   - ligne principale en gras noir ;
   - commentaires en romain noir dans le fil du texte ;
   - variantes de niveau 1 entre crochets [ … ] avec coups en vert ;
   - sous-variantes de niveau 2 entre parenthèses ( … ) avec coups en italique bleu foncé ;
   - diagrammes vectoriels SVG insérés à n'importe quelle position marquée). */

import { boardSvg } from './diagram.js';
import { normaliseHeaders } from './export.js';
import { closeGameSheet } from './print-sheet.js';
import { buildAnalysisBlocks } from './manual-tree.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}

function todayFr() {
  return new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
}

function appendSpaceIfNeeded(parent) {
  const last = parent.lastChild;
  if (!last) return;
  const txt = last.textContent || '';
  if (txt && !txt.endsWith(' ') && !txt.endsWith('[ ') && !txt.endsWith('( ')) {
    parent.append(document.createTextNode(' '));
  }
}

function moveDepthClass(depth) {
  if (depth <= 0) return 'td-move td-d0';
  if (depth === 1) return 'td-move td-d1';
  if (depth === 2) return 'td-move td-d2';
  return 'td-move td-d3';
}

function renderDiagramFigure(diagItem, {
  orientation = 'w',
  numbers = false,
  arrow = false,
  interactive = false,
  activeNodeId = null,
  onSelectNode = null,
} = {}) {
  const fig = el('figure', `td-diagram${diagItem.depth > 0 ? ' td-diagram-var' : ''}${activeNodeId === diagItem.nodeId ? ' is-active' : ''}`);
  const svg = boardSvg({
    board: diagItem.state.board,
    orientation,
    numbers,
    arrow: arrow && diagItem.lastMove ? diagItem.lastMove : null,
    title: `Diagramme ${diagItem.diagramNumber} — ${diagItem.label}`,
  });
  fig.append(svg);
  const captionText = diagItem.caption
    ? `Diagramme ${diagItem.diagramNumber} — ${diagItem.caption} (${diagItem.label})`
    : `Diagramme ${diagItem.diagramNumber} — ${diagItem.label}`;
  fig.append(el('figcaption', 'td-diagram-cap', captionText));
  if (interactive && onSelectNode) {
    fig.tabIndex = 0;
    fig.role = 'button';
    fig.title = 'Cliquer pour afficher cette position sur le damier';
    fig.addEventListener('click', () => onSelectNode(diagItem.nodeId));
    fig.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onSelectNode(diagItem.nodeId);
      }
    });
  }
  return fig;
}

/**
 * Construit le contenu typographique complet (commun à l'aperçu interactif et à
 * la feuille d'impression A4) à partir des blocs de `buildAnalysisBlocks(tree)`.
 */
export function renderNotationDom(tree, {
  interactive = false,
  showFullDiagramsInPreview = false,
  activeNodeId = null,
  onSelectNode = null,
  orientation = 'w',
  numbers = false,
  arrow = false,
  result = '*',
} = {}) {
  const blocks = buildAnalysisBlocks(tree);
  const root = el('div', `td-prose${interactive ? ' td-interactive' : ''}`);

  if (!blocks.length) {
    const empty = el('p', 'td-empty',
      'Aucun coup ni commentaire pour l’instant. Jouez des coups sur le damier ou importez une partie pour commencer votre analyse.');
    root.append(empty);
    return root;
  }

  const createMoveNode = seg => {
    const cls = moveDepthClass(seg.depth) + (interactive && activeNodeId === seg.nodeId ? ' is-active' : '');
    if (interactive && onSelectNode) {
      const btn = el('button', cls, seg.text);
      btn.type = 'button';
      btn.dataset.nodeId = seg.nodeId;
      btn.addEventListener('click', () => onSelectNode(seg.nodeId));
      return btn;
    }
    return el('span', cls, seg.text);
  };

  const createCommentNode = seg => {
    const span = el('span', 'td-comment' + (interactive && activeNodeId === seg.nodeId ? ' is-active-comment' : ''), seg.text);
    if (interactive && onSelectNode && seg.nodeId) {
      span.addEventListener('click', () => onSelectNode(seg.nodeId));
    }
    return span;
  };

  const createDiagramBadgeOrFigure = diag => {
    if (!interactive || showFullDiagramsInPreview) {
      return renderDiagramFigure(diag, { orientation, numbers, arrow, interactive, activeNodeId, onSelectNode });
    }
    const badge = el('button', 'td-diag-badge' + (activeNodeId === diag.nodeId ? ' is-active' : ''),
      `▦ Diagramme ${diag.diagramNumber}${diag.caption ? ' · ' + diag.caption : ''}`);
    badge.type = 'button';
    badge.title = `${diag.label} — sera imprimé à cet emplacement exact`;
    if (onSelectNode) badge.addEventListener('click', () => onSelectNode(diag.nodeId));
    return badge;
  };

  for (const block of blocks) {
    if (block.type === 'intro') {
      const p = el('div', 'td-intro');
      p.append(createCommentNode({ nodeId: block.nodeId, text: block.text }));
      root.append(p);
      continue;
    }

    if (block.type === 'diagram') {
      root.append(createDiagramBadgeOrFigure(block));
      continue;
    }

    if (block.type === 'main-line') {
      const div = el('div', 'td-main-block');
      for (const item of block.items) {
        appendSpaceIfNeeded(div);
        if (item.kind === 'move') div.append(createMoveNode(item));
        else div.append(createCommentNode(item));
      }
      root.append(div);
      continue;
    }

    if (block.type === 'variation-block') {
      const varContainer = el('div', 'td-var-block');
      let inlineBox = el('span', 'td-var-inline');
      varContainer.append(inlineBox);

      // Évite un « ) » ou « ] » orphelin sur une ligne seule après un diagramme de fin de variante
      const segs = [];
      for (const seg of block.segments) {
        if ((seg.kind === 'close-bracket' || seg.kind === 'close-paren') && segs.length && segs.at(-1).kind === 'diagram') {
          const trailingDiags = [];
          while (segs.length && segs.at(-1).kind === 'diagram') trailingDiags.unshift(segs.pop());
          segs.push(seg, ...trailingDiags);
        } else {
          segs.push(seg);
        }
      }

      for (const seg of segs) {
        if (seg.kind === 'diagram') {
          varContainer.append(createDiagramBadgeOrFigure(seg));
          inlineBox = el('span', 'td-var-inline');
          varContainer.append(inlineBox);
          continue;
        }
        if (seg.kind === 'open-bracket' || seg.kind === 'open-paren') {
          appendSpaceIfNeeded(inlineBox);
          inlineBox.append(el('span', seg.depth >= 2 ? 'td-delim td-delim-sub' : 'td-delim', seg.text));
        } else if (seg.kind === 'close-bracket' || seg.kind === 'close-paren' || seg.kind === 'semicolon') {
          inlineBox.append(el('span', seg.depth >= 2 ? 'td-delim td-delim-sub' : 'td-delim', seg.text));
        } else if (seg.kind === 'move') {
          appendSpaceIfNeeded(inlineBox);
          inlineBox.append(createMoveNode(seg));
        } else {
          appendSpaceIfNeeded(inlineBox);
          inlineBox.append(createCommentNode(seg));
        }
      }
      root.append(varContainer);
    }
  }

  if (result && result !== '*') {
    const resBlock = el('div', 'td-result', result);
    root.append(resBlock);
  }

  return root;
}

/**
 * Construit la feuille imprimable A4 complète (avec barre d'options en direct :
 * 1 ou 2 colonnes, taille des diagrammes, numérotation 1–50, flèche, couleurs).
 */
export function buildManualPrintSheet({
  tree,
  headers = {},
  result = '*',
  title = '',
  orientation = 'w',
  options = {},
} = {}) {
  const state = {
    columns: options.columns === 2 ? 2 : 1,
    diagramSize: options.diagramSize || 'medium', // 'small' | 'medium' | 'large'
    numbers: Boolean(options.numbers),
    arrow: Boolean(options.arrow),
    colorScheme: options.colorScheme || 'classic', // 'classic' (vert/bleu Turbo Dambase) | 'mono'
    diagramOrientation: options.diagramOrientation || 'w', // 'w' | 'board'
  };

  const head = normaliseHeaders(headers, { Event: '' });
  const sheet = el('article', 'print-sheet manual-print-sheet');
  sheet.id = 'print-sheet';

  /* ---- Barre d'outils d'aperçu (masquée à l'impression papier/PDF) ---- */
  const toolbar = el('div', 'sheet-toolbar manual-sheet-toolbar');

  const printBtn = el('button', 'primary-button', 'Imprimer / Enregistrer en PDF');
  printBtn.type = 'button';
  printBtn.addEventListener('click', () => window.print());

  const closeBtn = el('button', 'secondary-button', 'Fermer');
  closeBtn.type = 'button';
  closeBtn.addEventListener('click', () => sheet.remove());

  const makeSelect = (labelText, items, initial, onChange) => {
    const wrap = el('label', 'manual-tb-ctrl');
    wrap.append(el('span', '', labelText));
    const sel = document.createElement('select');
    for (const [val, txt] of items) {
      const opt = document.createElement('option');
      opt.value = String(val);
      opt.textContent = txt;
      if (String(val) === String(initial)) opt.selected = true;
      sel.append(opt);
    }
    sel.addEventListener('change', () => onChange(sel.value));
    wrap.append(sel);
    return wrap;
  };

  const makeCheck = (labelText, initial, onChange) => {
    const wrap = el('label', 'manual-tb-check');
    const inp = document.createElement('input');
    inp.type = 'checkbox';
    inp.checked = Boolean(initial);
    inp.addEventListener('change', () => onChange(inp.checked));
    wrap.append(inp, el('span', '', labelText));
    return wrap;
  };

  const page = el('div', 'sheet-page manual-sheet-page');
  const bodyHost = el('div', 'manual-sheet-body');

  function refreshBody() {
    page.dataset.columns = String(state.columns);
    page.dataset.diagSize = state.diagramSize;
    page.dataset.scheme = state.colorScheme;
    const effOrientation = state.diagramOrientation === 'board' ? orientation : 'w';
    bodyHost.replaceChildren(renderNotationDom(tree, {
      interactive: false,
      orientation: effOrientation,
      numbers: state.numbers,
      arrow: state.arrow,
      result,
    }));
  }

  toolbar.append(
    printBtn,
    makeSelect('Colonnes', [['1', '1 colonne'], ['2', '2 colonnes (revue)']], state.columns, val => {
      state.columns = Number(val) === 2 ? 2 : 1;
      refreshBody();
    }),
    makeSelect('Diagrammes', [['small', 'Compacts (44 mm)'], ['medium', 'Normaux (55 mm)'], ['large', 'Grands (68 mm)']], state.diagramSize, val => {
      state.diagramSize = val;
      refreshBody();
    }),
    makeSelect('Style', [['classic', 'Couleurs (vert / bleu)'], ['mono', 'Noir et blanc']], state.colorScheme, val => {
      state.colorScheme = val;
      refreshBody();
    }),
    makeCheck('Cases 1–50', state.numbers, checked => {
      state.numbers = checked;
      refreshBody();
    }),
    makeCheck('Flèche du coup', state.arrow, checked => {
      state.arrow = checked;
      refreshBody();
    }),
    closeBtn,
  );
  sheet.append(toolbar);

  /* ---- En-tête sobre de la feuille ---- */
  const headerEl = el('header', 'sheet-head manual-sheet-head');
  const playersLine = `${head.White} — ${head.Black}`;
  const mainHeading = (title && title !== 'Position libre' && title !== 'Position chargée') ? title : playersLine;
  headerEl.append(el('h1', 'sheet-title', mainHeading));
  if (mainHeading !== playersLine) {
    headerEl.append(el('p', 'sheet-sub', playersLine));
  }
  const rawEvent = String(headers.Event || '').trim();
  const rawSite = String(headers.Site || '').trim();
  const rawRound = String(headers.Round || '').trim();
  const rawDate = String(headers.Date || '').trim();
  const metaBits = [
    rawEvent,
    rawSite,
    rawRound && rawRound !== '-' ? `Ronde ${rawRound}` : '',
    rawDate || head.Date,
    result && result !== '*' ? `Résultat : ${result}` : '',
  ].filter(Boolean);
  if (metaBits.length) {
    headerEl.append(el('p', 'sheet-meta', metaBits.join(' · ')));
  }
  page.append(headerEl);

  refreshBody();
  page.append(bodyHost);
  page.append(el('p', 'sheet-foot', `PIONICIDE · Analyse et commentaires · ${todayFr()}`));
  sheet.append(page);
  return sheet;
}

/** Ouvre l'aperçu imprimable par-dessus l'application. */
export function openManualPrintSheet(options) {
  closeGameSheet();
  const sheet = buildManualPrintSheet(options);
  document.body.append(sheet);
  document.body.classList.add('sheet-open');
  const observer = new MutationObserver(() => {
    if (!document.body.contains(sheet)) {
      document.body.classList.remove('sheet-open');
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true });
  return sheet;
}
