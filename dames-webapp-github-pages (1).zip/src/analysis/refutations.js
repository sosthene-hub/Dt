/* PIONICIDE · Détection à la demande des mauvais coups (imprécisions ?!,
   erreurs ?, grosses erreurs ??) dans une position donnée, avec la variante de
   réfutation permettant d'exploiter chaque erreur pour prendre l'avantage ou
   mener au gain.

   100 % pur (aucune dépendance au DOM) et intégralement testable sous Node. */

import { generateLegalMoves, moveMatchesEngine, boardToHub, opponent, sideOf } from '../game-rules.js';
import { appendState } from '../game-history.js';
import { adjudicate } from '../draw-rules.js';
import { probeTable } from '../bitbases.js';
import { moveToPdn } from '../pdn.js';
import { pvToMoves, formatEval } from './annotate.js';

export const REFUTATION_DEFAULTS = Object.freeze({
  depth: 14,
  maxTimeMs: 1200,
  pvLength: 10,
  minPvLength: 6,
  inaccuracy: 0.25,
  error: 0.60,
  blunder: 1.50,
  winScore: 1.40,
});

function materialFor(board, side) {
  let men = 0;
  let kings = 0;
  for (let sq = 1; sq <= 50; sq += 1) {
    const p = board[sq];
    if (sideOf(p) !== side) continue;
    if (p === 'W' || p === 'B') kings += 1;
    else men += 1;
  }
  return { men, kings, weighted: men + kings * 3 };
}

/** Décrit factuellement le motif tactique ou positionnel observé dans la réfutation. */
export function describeRefutationMotif(afterState, refutationMoves, refutationStates) {
  if (!refutationMoves?.length) return '';
  const punisher = afterState.side;
  const defender = opponent(punisher);
  const startPun = materialFor(afterState.board, punisher);
  const startDef = materialFor(afterState.board, defender);
  const endBoard = refutationStates.at(-1).board;
  const endPun = materialFor(endBoard, punisher);
  const endDef = materialFor(endBoard, defender);

  const netWeighted = (endPun.weighted - endDef.weighted) - (startPun.weighted - startDef.weighted);
  const netPieces = (endPun.men + endPun.kings - endDef.men - endDef.kings)
    - (startPun.men + startPun.kings - startDef.men - startDef.kings);
  const gainedKing = endPun.kings > startPun.kings;

  let maxPunisherRafle = 0;
  let totalPunisherCaptures = 0;
  refutationMoves.forEach((m, idx) => {
    if (idx % 2 === 0 && m.captured?.length) {
      totalPunisherCaptures += m.captured.length;
      if (m.captured.length > maxPunisherRafle) maxPunisherRafle = m.captured.length;
    }
  });

  const parts = [];
  if (maxPunisherRafle >= 2 && (netWeighted > 0 || gainedKing)) {
    parts.push(`Combinaison (rafle de ${maxPunisherRafle} pièces)`);
  } else if (totalPunisherCaptures >= 2 && netPieces > 0) {
    parts.push(' Enchaînement tactique'.trim());
  }
  if (gainedKing) {
    parts.push('Promotion en dame');
  } else if (netPieces >= 1) {
    parts.push(`Gain matériel (+${netPieces} pion${netPieces > 1 ? 's' : ''})`);
  }
  if (!parts.length && netWeighted <= 0) {
    parts.push('Exploitation positionnelle');
  }
  return parts.join(' · ');
}

/** Classe la gravité d'un coup selon la perte par rapport au meilleur coup. */
export function classifyCandidateLoss(loss, isBest, thresholds = REFUTATION_DEFAULTS) {
  if (isBest || !Number.isFinite(loss) || loss < thresholds.inaccuracy) {
    return { severity: 'good', symbol: isBest ? '!' : '', label: isBest ? 'Meilleur coup' : 'Coup sain' };
  }
  if (loss >= thresholds.blunder) {
    return { severity: 'blunder', symbol: '??', label: 'Grosse erreur' };
  }
  if (loss >= thresholds.error) {
    return { severity: 'error', symbol: '?', label: 'Erreur' };
  }
  return { severity: 'inaccuracy', symbol: '?!', label: 'Imprécision' };
}

/** Qualifie l'aboutissement de la réfutation du point de vue du camp qui l'exploite. */
export function classifyExploitationVerdict(punisherScore, tbAfter, winScore = REFUTATION_DEFAULTS.winScore) {
  const tbWin = Boolean(tbAfter?.available && tbAfter.value > 0);
  if (tbWin || (Number.isFinite(punisherScore) && punisherScore >= 80)) {
    return { code: 'gain-force', badge: 'Gain forcé', leadsToWin: true };
  }
  if (Number.isFinite(punisherScore) && punisherScore >= winScore) {
    return { code: 'gain-decisif', badge: 'Suite gagnante', leadsToWin: true };
  }
  if (Number.isFinite(punisherScore) && punisherScore >= 0.65) {
    return { code: 'avantage-net', badge: 'Avantage net', leadsToWin: false };
  }
  if (Number.isFinite(punisherScore) && punisherScore >= 0.20) {
    return { code: 'initiative', badge: 'Pression / initiative', leadsToWin: false };
  }
  return { code: 'avantage-lache', badge: 'Lâche l’avantage', leadsToWin: false };
}

function buildStatesFromMoves(startState, moves) {
  let states = [startState];
  for (const m of moves) {
    states = appendState(states, m);
  }
  return states;
}

/**
 * Si la table de transposition a tronqué la PV du moteur à 1–3 demi-coups alors
 * que la position reste active, prolonge la ligne de réfutation jusqu'à `minPvLength`.
 */
async function ensureCompletePv(afterState, initialMoves, { search, depth, maxTimeMs, minPvLength, maxPvLength, shouldStop }) {
  const moves = [...initialMoves];
  let states = buildStatesFromMoves(afterState, moves);
  let guard = 0;

  while (moves.length < minPvLength && guard < 3) {
    if (shouldStop?.()) break;
    const tail = states.at(-1);
    if (adjudicate(tail.board, tail.side, tail.drawState)) break;
    const legal = generateLegalMoves(tail.board, tail.side);
    if (!legal.length) break;
    if (legal.length === 1) {
      moves.push(legal[0]);
      states = appendState(states, legal[0]);
      continue;
    }
    guard += 1;
    const subDepth = Math.max(6, depth - moves.length);
    const res = await search({
      position: `pos=${boardToHub(tail.board, tail.side)}`,
      depth: subDepth,
      mode: 'analyze',
      maxTimeMs: Math.min(maxTimeMs, 700),
    });
    if (shouldStop?.() || res.stale) break;
    const info = res.infos?.at(-1);
    const extra = pvToMoves(tail.board, tail.side, info?.pv?.length ? info.pv : res.move ? [res.move] : [], maxPvLength - moves.length);
    if (!extra.length) break;
    for (const m of extra) {
      moves.push(m);
      states = appendState(states, m);
      if (moves.length >= maxPvLength) break;
    }
  }

  return { moves: moves.slice(0, maxPvLength), states: states.slice(0, maxPvLength + 1) };
}

/**
 * Analyse tous les coups légaux d'une position pour isoler les imprécisions (?!),
 * erreurs (?) et grosses erreurs (??), ainsi que la variante qui les réfute.
 */
export async function analyzeBadMoves(state, {
  search,
  depth = REFUTATION_DEFAULTS.depth,
  maxTimeMs = REFUTATION_DEFAULTS.maxTimeMs,
  pvLength = REFUTATION_DEFAULTS.pvLength,
  minPvLength = REFUTATION_DEFAULTS.minPvLength,
  thresholds = REFUTATION_DEFAULTS,
  onProgress = null,
  shouldStop = null,
} = {}) {
  const side = state.side;
  const punisherSide = opponent(side);
  const legal = generateLegalMoves(state.board, side);

  if (!legal.length) {
    return {
      cancelled: false,
      forced: false,
      terminal: true,
      side,
      punisherSide,
      depth,
      bestMove: null,
      bestScore: -99,
      candidates: [],
      badMoves: [],
      goodMoves: [],
    };
  }

  if (legal.length === 1) {
    const afterOnly = appendState([state], legal[0]).at(-1);
    return {
      cancelled: false,
      forced: true,
      terminal: false,
      side,
      punisherSide,
      depth,
      bestMove: legal[0],
      bestPdn: moveToPdn(legal[0]),
      bestScore: null,
      candidates: [{
        move: legal[0],
        pdn: moveToPdn(legal[0]),
        afterState: afterOnly,
        loss: 0,
        isBest: true,
        isBad: false,
        severity: 'good',
        symbol: '',
        label: 'Coup unique obligatoire',
        refutationMoves: [],
        refutationStates: [afterOnly],
      }],
      badMoves: [],
      goodMoves: [],
    };
  }

  const totalSteps = legal.length + 1;
  let doneSteps = 0;
  onProgress?.(doneSteps, totalSteps, 'Évaluation de la position de référence…');

  // 1. Évaluation de la position racine pour connaître le meilleur coup de référence
  const rootRes = await search({
    position: `pos=${boardToHub(state.board, side)}`,
    depth,
    mode: 'analyze',
    maxTimeMs,
  });
  if (shouldStop?.() || rootRes.stale) {
    return { cancelled: true, candidates: [], badMoves: [], goodMoves: [] };
  }
  const rootInfo = rootRes.infos?.at(-1);
  const rootBestMove = rootRes.move ? legal.find(m => moveMatchesEngine(m, rootRes.move)) || null : null;
  const rootBestPdn = rootBestMove ? moveToPdn(rootBestMove) : '';
  const rootBestPv = pvToMoves(state.board, side, rootInfo?.pv, pvLength);
  doneSteps += 1;
  onProgress?.(doneSteps, totalSteps, rootBestPdn ? `Meilleur coup : ${rootBestPdn}` : 'Analyse des coups…');

  // 2. Évaluation de chaque coup légal et extraction de sa réfutation optimale
  const rawEntries = [];
  for (const move of legal) {
    if (shouldStop?.()) {
      return { cancelled: true, candidates: [], badMoves: [], goodMoves: [] };
    }
    const pdn = moveToPdn(move);
    const afterState = appendState([state], move).at(-1);
    const drawDecision = adjudicate(afterState.board, afterState.side, afterState.drawState);
    const nextLegal = generateLegalMoves(afterState.board, afterState.side);
    const tbAfter = probeTable(afterState.board, afterState.side);

    let punisherScore = null;
    let initialPv = [];
    let reachedDepth = depth;

    if (!nextLegal.length) {
      // L'adversaire n'a plus de coup : ce coup gagne immédiatement !
      punisherScore = -99.99;
      reachedDepth = 0;
    } else if (drawDecision) {
      punisherScore = 0;
      reachedDepth = 0;
    } else {
      const childRes = await search({
        position: `pos=${boardToHub(afterState.board, afterState.side)}`,
        depth,
        mode: 'analyze',
        maxTimeMs,
      });
      if (shouldStop?.() || childRes.stale) {
        return { cancelled: true, candidates: [], badMoves: [], goodMoves: [] };
      }
      const cInfo = childRes.infos?.at(-1);
      const rawScore = Number(cInfo?.score);
      punisherScore = Number.isFinite(rawScore) ? rawScore : 0;
      reachedDepth = cInfo?.depth ?? depth;
      const pvTokens = cInfo?.pv?.length ? cInfo.pv : childRes.move ? [childRes.move] : [];
      initialPv = pvToMoves(afterState.board, afterState.side, pvTokens, pvLength);
    }

    const valueForMover = Number.isFinite(punisherScore) ? -punisherScore : null;
    rawEntries.push({
      move,
      pdn,
      afterState,
      tbAfter,
      punisherScore,
      valueForMover,
      initialPv,
      reachedDepth,
    });

    doneSteps += 1;
    onProgress?.(doneSteps, totalSteps, `Coup examiné : ${pdn} (${doneSteps - 1}/${legal.length})`);
  }

  // Valeur de référence = meilleure valeur obtenue parmi tous les coups à profondeur homogène
  let bestValue = -Infinity;
  for (const entry of rawEntries) {
    if (Number.isFinite(entry.valueForMover) && entry.valueForMover > bestValue) {
      bestValue = entry.valueForMover;
    }
  }
  if (!Number.isFinite(bestValue)) bestValue = Number(rootInfo?.score) || 0;

  // Identification du meilleur coup (celui de la racine s'il est ex-aequo à <= 0.05, sinon le max exact)
  let bestEntry = rawEntries.find(e => e.pdn === rootBestPdn && bestValue - e.valueForMover <= 0.08)
    || rawEntries.reduce((acc, cur) => (!acc || cur.valueForMover > acc.valueForMover ? cur : acc), null);

  // 3. Classification et prolongement éventuel des PV tronquées pour les mauvais coups
  const candidates = [];
  for (const entry of rawEntries) {
    const isBest = bestEntry ? entry.move === bestEntry.move : false;
    const loss = isBest ? 0 : Math.max(0, bestValue - entry.valueForMover);
    const cls = classifyCandidateLoss(loss, isBest, thresholds);
    const isBad = cls.severity !== 'good';

    let refMoves = entry.initialPv;
    let refStates = buildStatesFromMoves(entry.afterState, refMoves);

    if (isBad && refMoves.length > 0 && refMoves.length < minPvLength) {
      const extended = await ensureCompletePv(entry.afterState, refMoves, {
        search,
        depth,
        maxTimeMs,
        minPvLength,
        maxPvLength: pvLength,
        shouldStop,
      });
      refMoves = extended.moves;
      refStates = extended.states;
    }

    const verdict = classifyExploitationVerdict(entry.punisherScore, entry.tbAfter, thresholds.winScore ?? REFUTATION_DEFAULTS.winScore);
    const motif = isBad ? describeRefutationMotif(entry.afterState, refMoves, refStates) : '';
    const evalWhite = Number.isFinite(entry.valueForMover)
      ? (side === 'w' ? entry.valueForMover : -entry.valueForMover)
      : null;

    candidates.push({
      move: entry.move,
      pdn: entry.pdn,
      afterState: entry.afterState,
      valueForMover: entry.valueForMover,
      punisherScore: entry.punisherScore,
      evalWhite,
      evalText: formatEval(evalWhite),
      punisherScoreText: formatEval(entry.punisherScore),
      loss,
      lossText: loss.toFixed(2).replace('.', ','),
      isBest,
      isBad,
      severity: cls.severity,
      symbol: cls.symbol,
      label: cls.label,
      verdict,
      motif,
      depth: entry.reachedDepth,
      refutationMoves: refMoves,
      refutationStates: refStates,
    });
  }

  // Tri : du pire coup (plus grosse perte / gain adverse le plus net) au meilleur coup
  const badMoves = candidates
    .filter(c => c.isBad)
    .sort((a, b) => b.loss - a.loss || b.punisherScore - a.punisherScore);

  const goodMoves = candidates
    .filter(c => !c.isBad)
    .sort((a, b) => b.valueForMover - a.valueForMover);

  const bestEvalWhite = Number.isFinite(bestValue) ? (side === 'w' ? bestValue : -bestValue) : null;

  return {
    cancelled: false,
    forced: false,
    terminal: false,
    side,
    punisherSide,
    depth,
    bestMove: bestEntry?.move || rootBestMove,
    bestPdn: bestEntry?.pdn || rootBestPdn,
    bestValue,
    bestEvalWhite,
    bestEvalText: formatEval(bestEvalWhite),
    bestPv: rootBestPv,
    candidates,
    badMoves,
    goodMoves,
  };
}

/** Construit un commentaire synthétique pour l'insertion dans l'arbre d'analyse manuelle. */
export function formatBadMoveStudyComment(badItem, punisherSide) {
  const camp = punisherSide === 'w' ? 'les Blancs' : 'les Noirs';
  const parts = [`${badItem.label} (−${badItem.lossText} pion)`];
  if (badItem.verdict?.leadsToWin) {
    parts.push(`${badItem.verdict.badge.toLowerCase()} pour ${camp} (${badItem.punisherScoreText})`);
  } else if (Number.isFinite(badItem.punisherScore) && badItem.punisherScore >= 0.20) {
    parts.push(`${badItem.verdict.badge.toLowerCase()} pour ${camp} (${badItem.punisherScoreText})`);
  } else {
    parts.push(`lâche l’avantage — réplique optimale pour ${camp} (${badItem.punisherScoreText})`);
  }
  if (badItem.motif) parts.push(badItem.motif.toLowerCase());
  return parts.join(' — ');
}
