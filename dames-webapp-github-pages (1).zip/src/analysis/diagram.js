import { coordinate, squareAtPosition, sideOf } from '../game-rules.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

function svgEl(name, attrs = {}) {
  const node = document.createElementNS(SVG_NS, name);
  for (const [key, value] of Object.entries(attrs)) {
    if (value !== null && value !== undefined) node.setAttribute(key, String(value));
  }
  return node;
}

function centerOf(square, orientation) {
  const c = coordinate(square);
  if (!c) return null;
  const displayCol = orientation === 'w' ? c.col : 9 - c.col;
  const displayRow = orientation === 'w' ? c.row : 9 - c.row;
  return { x: displayCol * 100 + 50, y: displayRow * 100 + 50 };
}

/**
 * Damier 10×10 en SVG pur : net à l'impression, lisible en noir et blanc.
 *
 * @param {object} options
 * @param {Array}  options.board      pièces (indice = case FMJD)
 * @param {string} options.orientation 'w' = blancs en bas
 * @param {Array}  options.arrow      [from, to] du meilleur coup, facultatif
 * @param {boolean} options.numbers   numérotation des cases 1 à 50
 * @param {string} options.title      étiquette lue par les lecteurs d'écran
 */
export function boardSvg({ board, orientation = 'w', arrow = null, numbers = false, title = 'Diagramme' }) {
  const svg = svgEl('svg', {
    viewBox: '0 0 1000 1000',
    class: 'diagram-board',
    role: 'img',
    'aria-label': title,
    preserveAspectRatio: 'xMidYMid meet',
  });
  const titleNode = svgEl('title', {});
  titleNode.textContent = title;
  svg.append(titleNode);

  const background = svgEl('rect', { x: 0, y: 0, width: 1000, height: 1000, fill: '#ffffff' });
  svg.append(background);

  for (let displayRow = 0; displayRow < 10; displayRow += 1) {
    for (let displayCol = 0; displayCol < 10; displayCol += 1) {
      const row = orientation === 'w' ? displayRow : 9 - displayRow;
      const col = orientation === 'w' ? displayCol : 9 - displayCol;
      const square = squareAtPosition(row, col);
      // Cases claires = non jouables (le damier international se joue sur les cases sombres).
      svg.append(svgEl('rect', {
        x: displayCol * 100,
        y: displayRow * 100,
        width: 100,
        height: 100,
        fill: square ? '#9a9a9a' : '#ffffff',
        stroke: '#111111',
        'stroke-width': 1,
      }));
    }
  }

  if (numbers) {
    for (let square = 1; square <= 50; square += 1) {
      const c = coordinate(square);
      const point = centerOf(square, orientation);
      const displayCol = orientation === 'w' ? c.col : 9 - c.col;
      const displayRow = orientation === 'w' ? c.row : 9 - c.row;
      const label = svgEl('text', {
        x: displayCol * 100 + 4,
        y: displayRow * 100 + 26,
        'font-size': 29,
        'font-family': 'system-ui, sans-serif',
        'font-weight': 700,
        fill: '#1a1a1a',
        stroke: '#ffffff',
        'stroke-width': 5,
        'paint-order': 'stroke',
        'stroke-linejoin': 'round',
        opacity: 0.95,
      });
      label.textContent = String(square);
      svg.append(label);
      void point;
    }
  }

  for (let square = 1; square <= 50; square += 1) {
    const piece = board[square];
    const color = sideOf(piece);
    if (!color) continue;
    const point = centerOf(square, orientation);
    const king = piece === 'W' || piece === 'B';
    const disc = svgEl('circle', {
      cx: point.x,
      cy: point.y,
      r: 34,
      fill: color === 'w' ? '#ffffff' : '#111111',
      stroke: '#111111',
      'stroke-width': 6,
    });
    svg.append(disc);
    if (king) {
      // Couronne schématique : anneau intérieur contrasté, lisible en noir et blanc.
      svg.append(svgEl('circle', {
        cx: point.x,
        cy: point.y,
        r: 18,
        fill: 'none',
        stroke: color === 'w' ? '#111111' : '#ffffff',
        'stroke-width': 6,
      }));
    }
  }

  if (arrow && arrow.length === 2) {
    const from = centerOf(arrow[0], orientation);
    const to = centerOf(arrow[1], orientation);
    if (from && to && (from.x !== to.x || from.y !== to.y)) {
      const dx = to.x - from.x;
      const dy = to.y - from.y;
      const length = Math.hypot(dx, dy) || 1;
      const ux = dx / length;
      const uy = dy / length;
      const start = { x: from.x + ux * 38, y: from.y + uy * 38 };
      const end = { x: to.x - ux * 42, y: to.y - uy * 42 };
      const markerId = `diagram-arrow-${Math.random().toString(36).slice(2, 9)}`;
      const defs = svgEl('defs', {});
      const marker = svgEl('marker', {
        id: markerId,
        markerWidth: 6,
        markerHeight: 6,
        refX: 5,
        refY: 3,
        orient: 'auto',
        markerUnits: 'strokeWidth',
      });
      marker.append(svgEl('path', { d: 'M 0 0 L 6 3 L 0 6 z', fill: '#111111' }));
      defs.append(marker);
      svg.append(defs);
      // Halo blanc : l'arrow reste visible sur une case sombre comme sur une pièce.
      svg.append(svgEl('line', {
        x1: start.x, y1: start.y, x2: end.x, y2: end.y,
        stroke: '#ffffff', 'stroke-width': 18, 'stroke-linecap': 'round',
      }));
      svg.append(svgEl('line', {
        x1: start.x, y1: start.y, x2: end.x, y2: end.y,
        stroke: '#111111', 'stroke-width': 8, 'stroke-linecap': 'round',
        'marker-end': `url(#${markerId})`,
      }));
    }
  }

  svg.append(svgEl('rect', {
    x: 3, y: 3, width: 994, height: 994, fill: 'none', stroke: '#111111', 'stroke-width': 6,
  }));
  return svg;
}
