import { generateLegalMoves, moveMatchesEngine, boardToHub, opponent } from '../game-rules.js';
import { initialState, appendState } from '../game-history.js';
import { moveToPdn } from '../pdn.js';

/** Seuils de perte en pions (vue des Blancs), réglables dans l'interface. */
export const DEFAULT_THRESHOLDS = Object.freeze({ error: 0.5, blunder: 1.5 });

export function classifyLoss(loss, isBest, thresholds = DEFAULT_THRESHOLDS) {
  if (!Number.isFinite(loss)) return '';
  if (loss >= thresholds.blunder) return '??';
  if (loss >= thresholds.error) return '?';
  return isBest ? '!' : '';
}

/** Signe et formatage d'une évaluation, vue des Blancs. */
export function formatEval(value) {
  if (!Number.isFinite(value)) return '—';
  if (Math.abs(value) >= 90) return value > 0 ? '+∞' : '−∞';
  const text = Math.abs(value).toFixed(2).replace('.', ',');
  return `${value > 0 ? '+' : value < 0 ? '−' : '±'}${text}`;
}

export function moveNumberOf(index, startSide = 'w') {
  return Math.floor((index + (startSide === 'b' ? 1 : 0)) / 2) + 1;
}

export function pvToMoves(board, side, rawTokens, limit = 6) {
  const moves = [];
  let state = initialState(board, side);
  for (const token of rawTokens || []) {
    const legal = generateLegalMoves(state.board, state.side);
    const move = legal.find(candidate => moveMatchesEngine(candidate, token));
    if (!move) break;
    moves.push(move);
    state = appendState([state], move).at(-1);
    if (moves.length >= limit) break;
  }
  return moves;
}

/**
 * Analyse chaque position d'une partie avec PIONICIDE.
 *
 * Une seule recherche par position. La valeur du coup joué se déduit de la
 * position suivante : valeur du coup = −(valeur de la position d'après, vue de
 * l'adversaire). La perte est donc `score(i) + score(i+1)`, sans seconde
 * recherche : c'est exact à condition que l'adversaire joue le meilleur coup,
 * ce qui est précisément la convention d'une analyse.
 *
 * @param {object}   options
 * @param {Array}    options.states    positions successives (n+1 entrées)
 * @param {Function} options.search    moteur PIONICIDE (search de ScanEngine)
 * @param {number}   options.depth     profondeur demandée
 * @param {number}   options.maxTimeMs plafond de temps par position
 * @param {Function} options.onProgress(done, total)
 * @param {Function} options.shouldStop() → true pour interrompre
 */
export async function annotateGame({ states, search, depth = 16, maxTimeMs = 1500, pvLength = 6, onProgress, shouldStop }) {
  const total = states.length;
  const positions = [];
  for (let i = 0; i < total; i += 1) {
    if (shouldStop?.()) return { cancelled: true, positions, plies: [] };
    const state = states[i];
    const legal = generateLegalMoves(state.board, state.side);
    if (!legal.length) {
      // Position terminale : le camp au trait est battu.
      positions.push({ score: -99, best: null, bestPdn: '', pv: [], depth: 0, terminal: true });
      onProgress?.(i + 1, total);
      continue;
    }
    const result = await search({
      position: `pos=${boardToHub(state.board, state.side)}`,
      depth,
      mode: 'analyze',
      maxTimeMs,
    });
    if (shouldStop?.()) return { cancelled: true, positions, plies: [] };
    const info = result.infos?.at(-1);
    const score = Number(info?.score);
    const best = result.move ? legal.find(candidate => moveMatchesEngine(candidate, result.move)) : null;
    positions.push({
      score: Number.isFinite(score) ? score : null,
      best,
      bestPdn: best ? moveToPdn(best) : '',
      pv: result.stale ? [] : pvToMoves(state.board, state.side, info?.pv, pvLength),
      depth: info?.depth ?? null,
      timeLimited: !!result.timeLimited,
      terminal: false,
    });
    onProgress?.(i + 1, total);
  }

  const plies = [];
  for (let i = 0; i < states.length - 1; i += 1) {
    const before = positions[i];
    const after = positions[i + 1];
    const side = states[i].side;
    const move = states[i + 1].lastMove
      ? null
      : null; // les coups ne sont pas portés par les états : fournis séparément
    void move;
    const scoreBefore = before?.score;
    const scoreAfter = after?.score;
    const valueForMover = Number.isFinite(scoreAfter) ? -scoreAfter : null;
    const loss = Number.isFinite(scoreBefore) && Number.isFinite(valueForMover)
      ? Math.max(0, scoreBefore - valueForMover)
      : null;
    const bestPdn = before?.bestPdn || '';
    plies.push({
      index: i,
      side,
      moveNumber: moveNumberOf(i),
      scoreBefore,
      scoreAfter,
      valueForMover,
      loss,
      best: bestPdn,
      pv: before?.pv || [],
      depth: before?.depth ?? null,
      evalBeforeWhite: Number.isFinite(scoreBefore) ? (side === 'w' ? scoreBefore : -scoreBefore) : null,
      evalAfterWhite: Number.isFinite(valueForMover) ? (side === 'w' ? valueForMover : -valueForMover) : null,
      timeLimited: !!before?.timeLimited,
    });
  }
  return { cancelled: false, positions, plies, depth };
}

/** Ajoute les coups joués et les symboles aux résultats d'annotation. */
export function withPlayedMoves(annotation, moves, thresholds = DEFAULT_THRESHOLDS) {
  return annotation.plies.map((ply, index) => {
    const move = moves[index];
    const played = move ? moveToPdn(move) : '';
    const isBest = !!ply.best && played === ply.best;
    // Le meilleur coup du moteur ne peut pas être une erreur : l'écart résiduel
    // éventuel vient de la recherche enfant (profondeur ou plafond de temps).
    const loss = isBest ? 0 : ply.loss;
    return {
      ...ply,
      played,
      isBest,
      loss,
      symbol: classifyLoss(loss, isBest, thresholds),
    };
  });
}

/** Coups de la variante conseillée, à partir de la position du coup joué. */
export function variationAfter(states, index, ply) {
  return ply.pv || [];
}

export { opponent };
