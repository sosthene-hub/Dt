import {retroSearch} from './retro-core.js';
self.onmessage=({data:c})=>{try{const result=retroSearch(c.board,c.side,c.options,report=>self.postMessage({type:'progress',report}));self.postMessage({type:'done',result});}catch(e){self.postMessage({type:'error',message:e.message});}};
