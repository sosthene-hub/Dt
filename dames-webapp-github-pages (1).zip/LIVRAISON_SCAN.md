# Livraison — Scan WebAssembly amélioré

**À téléverser dans le dépôt Dt : `dames-webapp-github-pages (1).zip`**, sans le renommer. Remplacer le ZIP du même nom à la racine du dépôt ; le workflow existant l’extrait et construit l’application. Cette livraison n’a pas été publiée sur votre compte.

## Inclus

- `Dames-autonome.html` : application complète hors ligne, moteur WASM et données embarquées. Ouvrir dans Chrome, pas dans le visualiseur Arena qui restreint les Workers.
- `RAPPORT_PERF_SCAN.md` : diagnostic, mêmes positions avant/après, mesures, limites Android, taille des bases 5/6 et décisions.
- `RAPPORT-TESTS.md` et traces brutes : contrôles techniques exécutés.
- Sources de l’application, du moteur actif et commande de compilation ; licence GPL-3.0.

## Réglages conseillés sur téléphone

Commencer par **WASM portable / 64 Mio**. Pour approfondir, choisir **Fort**, **Expert** ou **Grand maître**. Les objectifs sont 20/22/25 avec plafonds 15/30/90 secondes ; le moteur rend le meilleur résultat terminé s’il atteint le plafond. Les coups du livre d’ouvertures et les coups forcés peuvent rester rapides.

128 Mio et SIMD sont accessibles dans « Réglages Scan » ; ils ne sont pas toujours plus rapides et peuvent consommer davantage de mémoire. Les changements redémarrent le moteur. Les performances Linux du rapport ne constituent pas une garantie de débit Android.

Les tables 2–4 restent automatiques. Pas de tables 5/6 ni de multi-thread en fichier local dans cette livraison. Jeu, analyse, générateur, PDN, règles, flèches et recherche rétrograde bornée sont conservés.
