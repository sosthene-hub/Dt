# Livraison — Scan optimisé + module Combinaisons

**ZIP à téléverser : `dames-webapp-github-pages (1).zip`** — 19,0 Mo, sous la limite GitHub de 25 Mo par fichier.

## Pourquoi 19 Mo et pas 27 Mo

GitHub refuse tout fichier de plus de **25 Mo** en téléversement web. Le ZIP a été allégé sans rien perdre :

- le moteur Scan est maintenant embarqué **compressé** dans le HTML autonome (décompression à l’ouverture) : −3,2 Mo ;
- les **deux tomes PDF (5,6 Mo chacun)** sont fournis à part, car à eux deux ils faisaient dépasser la limite. Ils s’ajoutent en deux fichiers séparés, chacun accepté par GitHub.

## Contenu du ZIP

- `Dames-autonome.html` (16,0 Mo) : application hors ligne complète, **base des 2880 combinaisons embarquée**, Scan WASM inclus.
- `public/combinations-app.json` : base servie par l’application et précachée hors ligne.
- `data/combinaisons/` : base complète (rejeu, écarts d’en-tête, rejets), extraction brute, bilans, mesures.
- Sources, scripts d’extraction/validation, tests, licence GPL-3.0.
- `data/livres/` : **vide** ; y déposer les deux PDF (voir ci-dessous).

## Les deux PDF, à ajouter ensuite

1. Ouvrir `data/livres/` dans le dépôt.
2. « Add file » → « Upload files ».
3. Déposer `tome-1.pdf` et `tome-2.pdf` (5,6 Mo chacun), puis « Commit changes ».

Ils servent uniquement de provenance et à régénérer la base ; le site fonctionne sans eux.

## Vérifications de cette livraison

- `npm test` complet : réussi.
- HTML livré, `file://`, réseau bloqué : base reconnue, Scan fonctionne (décompression gzip), exercice joué et résolu, zéro requête externe.
- Navigation, niveaux 1–4, import de secours, persistance, rétrograde, service worker v12 : passés.

## Rappels

- Source citée dans l’application et les données (Gerrit Boom, *PC Blues deel 66*) ; vérifier les droits avant republication.
- Niveaux 3 et 4 : acceptation plus faible ; échec possible après 45 s, annoncé.
- La vérification Scan n’est pas une preuve d’unicité.
- Performances Android non garanties (mesures Chromium/Linux).
