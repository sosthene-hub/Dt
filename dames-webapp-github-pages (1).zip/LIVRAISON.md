# Livraison — export annoté (PDN + PDF) et solution de combinaison pas à pas

**Ajout du 20 octobre 2026 (cette livraison) : voir la section « Nouveautés — export annoté » ci-dessous.** Les sections suivantes décrivent la livraison Scan contre Scan, toujours valable.

**ZIP à téléverser : `dames-webapp-github-pages (1).zip`** — environ 19 Mo, sous la limite GitHub de 25 Mo par fichier.

## Nouveautés — export annoté (20 octobre 2026)

- **Analyse → Partie annotée par Scan.** Un bouton évalue toutes les positions de la partie chargée (profondeur 9, 12, 16 ou 20 ; 12 par défaut) et marque chaque coup : `!` meilleur coup, `?` erreur, `??` grosse erreur. Seuils réglables, 0,5 et 1,5 pion par défaut.
- **Export PDN annoté** : en-tête (joueurs, tournoi, date, résultat), tous les coups, commentaire `{ −0,45, prof. 12 }` et variante Scan entre parenthèses pour chaque erreur. Le fichier se rouvre dans « Importer » : même partie, mêmes coups. Fichier typique : 2 Ko.
- **Imprimer / PDF** : feuille A4 dédiée, liste des coups sur **deux colonnes**, bloc par erreur (mon coup, meilleur coup de Scan, évaluation avant / après, perte, variante), **sans aucune courbe ni graphique**. Le bouton ouvre l'impression du navigateur ; « Enregistrer au format PDF » produit un PDF de 3 pages pour la partie d'exemple.
- **Diagrammes SVG** de 5,5 cm ajoutés à la demande depuis la position affichée, ou automatiquement après chaque `??`. Flèche du meilleur coup et cases numérotées 1 à 50 en option. Noir et blanc lisible, net à l'impression.
- **Combinaisons** : la solution n'occupe plus qu'une ligne, avec `⏮` / `◀` / `▶` / `⏭` pour suivre les demi-coups un par un.
- Réglages d'export : niveau de détail « erreurs seulement » (défaut) ou « toute la partie », profondeur d'annotation, seuils `?` et `??`.

Détails techniques et mesures : **RAPPORT-EXPORT-ANNOTE.md**. Résultats des tests : section « Export annoté » de **RAPPORT-TESTS.md**.

## Livraison précédente — Scan contre Scan (20 octobre 2026)


- **Scan contre Scan** : deux moteurs Scan, un Web Worker chacun, profondeur et temps réglables séparément (jusqu’à 20), **mémoire de 60 Mo (64 Mio) ou 120 Mo (128 Mio) par moteur**, Démarrer / Pause / Reprendre / Arrêter, vitesse d’affichage, série de 1 à 6 parties avec alternance des couleurs et score cumulé, coups en notation FMJD, évaluation, détection de victoire et de nulle (répétition, 25 coups, finales), export PDN.
- **Un seul moteur partagé** pour l’accueil, l’analyse et les combinaisons : il est libéré en quittant ces écrans et relancé automatiquement, avec un réessai en 32 Mio si l’appareil refuse la mémoire demandée. C’est la correction du « Scan indisponible » constaté après un match Scan contre Scan.
- **Écran « Créer une partie » retiré** : il faisait doublon avec l’accueil, qui propose déjà le choix du niveau. Le menu compte six écrans.
- **Jouer une position contre Scan** : depuis l’éditeur (bouton dédié) et depuis une combinaison. Choix de ma couleur, du camp au trait et du niveau ; refus motivé si un pion est sur une ligne de promotion, si un camp dépasse 20 pièces ou n’a aucun coup légal ; bouton « Recommencer cette position ».
- **Validateur de cohérence** des positions de combinaison : lignes de promotion, 20 pièces maximum, écart de matériel réglable (3 par défaut), avancée des leurres réglable, pions isolés ajoutés refusés, prise parasite au trait refusée. Les positions générées qui échouent sont remplacées, jamais affichées.
- **Retrait** de la recherche rétrograde et de la recherche avancée ; l’accueil « Jouer » et « Créer une partie » sont conservés. Le dépôt n’avait qu’un seul workflow (publication GitHub Pages), rien d’accessoire à supprimer.

## Pourquoi 19 Mo et pas 27 Mo

GitHub refuse tout fichier de plus de **25 Mo** en téléversement web. Le ZIP a été allégé sans rien perdre :

- le moteur Scan est embarqué **compressé** dans le HTML autonome (décompression à l’ouverture) ;
- les **deux tomes PDF (5,6 Mo chacun)** sont fournis à part, car à eux deux ils faisaient dépasser la limite.

## Contenu du ZIP

- `Dames-autonome.html` (16,0 Mo) : application hors ligne complète, base des 2880 combinaisons embarquée, Scan WASM inclus.
- `public/combinations-app.json` : base servie par l’application et précachée hors ligne.
- `data/combinaisons/` : base complète, extraction brute, bilans, mesures, **validation-coherence.json**.
- `perf/` : résultats des tests, dont `scan-vs-scan.json`, les parties PDN et les captures.
- Sources, scripts de test, licences GPL-3.0.
- `data/livres/` : **vide** ; y déposer les deux PDF (voir ci-dessous).

## Les deux PDF, à ajouter ensuite

1. Ouvrir `data/livres/` dans le dépôt.
2. « Add file » → « Upload files ».
3. Déposer `tome-1.pdf` et `tome-2.pdf` (5,6 Mo chacun), puis « Commit changes ».

Ils servent à la provenance et à régénérer la base ; le site fonctionne sans eux.

## Vérifications de cette livraison (export annoté)

- `node scripts/test-export.mjs` : 8/8 (seuils, formatage, PDN annoté relisible, 131/131 coups identiques).
- `node scripts/browser-annotate.mjs` sur la production `/Dt/` : annotation réelle de Verpoest–Berte 1980 (131 demi-coups, 11 commentaires, 11 variantes), feuille avec 11 blocs d'erreur et 3 diagrammes, PDF de 3 pages, **PDN réimporté dans l'application : 131/131 demi-coups légaux**. Même test réussi sur `Dames-autonome.html` en `file://`.
- `node scripts/browser-annotate-offline.mjs` sur `Dames-autonome.html` (réseau coupé) : annotation 1,7 s, 11 blocs d'erreur, 3 diagrammes, solution pas à pas de « 1/9 » à « 9/9 », 0 requête externe, 0 erreur.
- Mobile 412×915 : aucun débordement, 3 diagrammes (1 manuel + 2 automatiques), 0 erreur JS.
- Non-régression complète : `npm test` (code 0) et dix suites navigateur (`browser-check`, `browser-study`, `browser-combinaisons`, `-import`, `-offline`, `browser-editor-game`, `browser-scan-disponible`, `browser-finales`, `browser-offline-finales`, `browser-annotate`) : toutes réussies.

## Vérifications de la livraison précédente

- `npm test` complet : réussi (code 0), y compris le nouveau `test:validator`.
- HTML extrait du ZIP, `file://`, réseau coupé : base reconnue, Scan opérationnel, partie depuis l’éditeur et Scan contre Scan joués.
- Partie Scan contre Scan complète à deux niveaux : profondeur 6 contre 3, 177 demi-coups, nulle par triple répétition, PDN exporté ; seconde passe : profondeur 3 contre 2, victoire 1-0 en 109 demi-coups.
- Enchaînement complet sans rechargement : Analyse → Scan contre Scan → Analyse → Combinaisons vérifiées par Scan → partie contre Scan, toutes avec le même moteur partagé.
- Série de deux parties avec alternance des couleurs et score cumulé : réussie.
- Aucune erreur JavaScript, aucun débordement mobile 412×915.

## Rappels

- Source citée dans l’application et les données (Gerrit Boom, *PC Blues deel 66*) ; vérifier les droits avant republication.
- Deux moteurs = deux workers et deux tables de 64 Mio ; sur téléphone, fermer l’onglet libère la mémoire.
- La pause laisse finir le calcul en cours.
- Performances Android non garanties (mesures Chromium/Linux).
