# Livraison — Scan contre Scan, parties depuis une position, validateur de combinaisons

**ZIP à téléverser : `dames-webapp-github-pages (1).zip`** — environ 19 Mo, sous la limite GitHub de 25 Mo par fichier.

## Nouveautés de cette version (20 octobre 2026)

- **Scan contre Scan** : deux moteurs Scan, un Web Worker chacun, profondeur et temps réglables séparément (jusqu’à 20), Démarrer / Pause / Reprendre / Arrêter, vitesse d’affichage, série de 1 à 6 parties avec alternance des couleurs et score cumulé, coups en notation FMJD, évaluation, détection de victoire et de nulle (répétition, 25 coups, finales), export PDN.
- **Jouer une position contre Scan** : depuis l’éditeur (bouton dédié) et depuis une combinaison. Choix de ma couleur, du camp au trait et du niveau ; refus motivé si un pion est sur une ligne de promotion, si un camp dépasse 20 pièces ou n’a aucun coup légal ; bouton « Recommencer cette position ».
- **Validateur de cohérence** des positions de combinaison : lignes de promotion, 20 pièces maximum, écart de matériel réglable (3 par défaut), avancée des leurres réglable, pions isolés ajoutés refusés, prise parasite au trait refusée. Les positions générées qui échouent sont remplacées, jamais affichées.
- **Retrait** de la recherche rétrograde et de la recherche avancée ; l’accueil « Jouer » et « Créer une partie » sont conservés. Le dépôt n’avait qu’un seul workflow (publication GitHub Pages), rien d’accessoire à supprimer.

## Pourquoi 19 Mo et pas 27 Mo

GitHub refuse tout fichier de plus de **25 Mo** en téléversement web. Le ZIP a été allégé sans rien perdre :

- le moteur Scan est embarqué **compressé** dans le HTML autonome (décompression à l’ouverture) ;
- les **deux tomes PDF (5,6 Mo chacun)** sont fournis à part, car à eux deux ils faisaient dépasser la limite.

## Contenu du ZIP

- `Dames-autonome.html` (16,0 Mo) : application hors ligne complète, base des 2880 combinaisons embarquée, Scan WASM inclus.
- `public/combinations-app.json` : base servie par l’application et précachée hors ligne.
- `data/combinaisons/` : base complète, extraction brute, bilans, mesures, **validation-coherence.json**.
- `perf/` : résultats des tests, dont `scan-vs-scan.json`, les parties PDN et les captures.
- Sources, scripts de test, licences GPL-3.0.
- `data/livres/` : **vide** ; y déposer les deux PDF (voir ci-dessous).

## Les deux PDF, à ajouter ensuite

1. Ouvrir `data/livres/` dans le dépôt.
2. « Add file » → « Upload files ».
3. Déposer `tome-1.pdf` et `tome-2.pdf` (5,6 Mo chacun), puis « Commit changes ».

Ils servent à la provenance et à régénérer la base ; le site fonctionne sans eux.

## Vérifications de cette livraison

- `npm test` complet : réussi (code 0), y compris le nouveau `test:validator`.
- HTML extrait du ZIP, `file://`, réseau coupé : base reconnue, Scan opérationnel, partie depuis l’éditeur et Scan contre Scan joués.
- Partie Scan contre Scan complète à deux niveaux : profondeur 6 contre 3, 177 demi-coups, nulle par triple répétition, PDN exporté.
- Série de deux parties avec alternance des couleurs et score cumulé : réussie.
- Aucune erreur JavaScript, aucun débordement mobile 412×915.

## Rappels

- Source citée dans l’application et les données (Gerrit Boom, *PC Blues deel 66*) ; vérifier les droits avant republication.
- Deux moteurs = deux workers et deux tables de 64 Mio ; sur téléphone, fermer l’onglet libère la mémoire.
- La pause laisse finir le calcul en cours.
- Performances Android non garanties (mesures Chromium/Linux).
