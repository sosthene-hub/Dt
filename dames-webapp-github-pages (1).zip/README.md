# Dames — nouveau générateur sur dessin

## Publication sur le dépôt Dt existant

1. Télécharger l’archive livrée **dames-webapp-github-pages (1).zip**.
2. Dans le dépôt `sosthene-hub/Dt`, remplacer le fichier ZIP qui porte exactement ce nom, à la racine. Ne pas renommer le fichier : le workflow actuel utilise ce nom.
3. Valider sur la branche `main`. Le workflow déjà présent dans le dépôt extrait cette archive, lance `npm ci` puis `npm test` et publie `app/dist`.
4. Attendre la réussite de l’onglet Actions, puis recharger https://sosthene-hub.github.io/Dt/ . En cas d’ancien écran, vider les données du site / recharger.

Cette livraison n’a pas été téléversée sur votre compte. Le workflow de votre dépôt reste inchangé.

## Fichier autonome

`Dames-autonome.html` contient l’application, Scan, ses données et le worker du générateur. Ouvrir dans Chrome, hors du visualiseur de fichiers Arena qui restreint les workers. Testé réellement en `file://` avec Chromium et sans serveur. Android/Chrome physique reste à contrôler : certains gestionnaires Android ouvrent le HTML dans un visualiseur limité plutôt que dans Chrome. Privilégier GitHub Pages dans ce cas. Le dernier dessin utilise localStorage ; sa conservation dépend des permissions du navigateur.

## Utilisation

Menu → Générateur de positions. Placer les pions du porteur, les pions adverses et les vides obligatoires. Le porteur définit la couleur de l’outil ; changer le porteur ne recolore pas les pions déjà dessinés. Une case sans dessin est libre, ce n’est pas une case vide imposée. Le dessin doit se retrouver exactement sur les cases indiquées dans la position finale ; des pions supplémentaires complètent les effectifs choisis. Les pièces ne sont pas immobilisées pendant la partie preuve.

Saisir les effectifs égaux, trait, avantage ou équilibre, seuil Scan, profondeur (1–20), budget et graine. Lancer le tirage. Recherche de parties légales guidée par le dessin, puis filtrage et analyse Scan en série ; maximum 100 candidats uniques par lot, 10 damiers témoins. Cliquer un témoin pour rejouer la preuve depuis le départ, demi-coup par demi-coup. Le JSON conserve tous les résultats retenus et le rapport. Scan peut modifier la structure dans sa meilleure variante.

## Limites explicites

- Recherche heuristique, pas un solveur exhaustif d’atteignabilité : une racine spécifique peut ne donner aucun résultat, même si elle est réalisable.
- Scan fourni est la compilation JavaScript/asm.js 3.1, **pas WASM**. Aucune migration WASM n’est revendiquée.
- Une analyse sans score à la profondeur demandée est rejetée. Délai Scan : 20 secondes par candidat ; dépassement interrompt le lot sans valider les recherches incomplètes. Profondeur 20 n’est pas garantie, notamment sur téléphone.
- Pions seuls dans les résultats. La définition opérationnelle du contact isolé est : voisin adverse sur une diagonale immédiate et aucun voisin allié sur ces quatre diagonales.
- Les scores sont ceux de Scan, ramenés au point de vue blanc ; le seuil n’est pas une probabilité de victoire. Tables de finales désactivées.
- Retrait des rubriques Apprendre/Puzzles et Problèmes ainsi que du moteur de positions aléatoires ancien. Jeu, analyse, éditeur et import PDN conservés.

## Développement

`npm ci`, `npm test`, `npm run dev`. `npm run standalone` reconstruit le HTML autonome. Pour la publication : `VITE_BASE_PATH=/Dt/ npm run build`.

Tests navigateur optionnels : installer Playwright et Chromium, puis adapter le chemin file:// dans `scripts/browser-check.mjs`. Le contrôle utilise un seuil très large pour vérifier la chaîne technique, pas la force des positions.

## Licence et provenance

Scan 3.1 : Fabien Letouzey ; port JavaScript distribué par TheYoBots, paquet `scan3.1.js@1.1.0`. Sources et licence GPL-3.0 du paquet inclus dans `third-party/scan3.1`. Les notices amont sont conservées. Code applicatif fourni sous GPL-3.0 pour cette redistribution ; voir `LICENSE`. Dépôt de base : commit `0c47952f04fd05f8639c811d5a225e4e8d399d6f`, archive applicative incluse dans ce dépôt.
