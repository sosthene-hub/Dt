# Dames — Scan WebAssembly amélioré, étude et recherche rétrograde


> **Version actuelle : Scan optimisé + module Combinaisons, 19 octobre 2026.** L’onglet « Générateur de positions » est remplacé par « Combinaisons » (PC Blues deel 66, base incluse : 2880 combinaisons) ; la recherche rétrograde a son propre onglet. Voir [RAPPORT-COMBINAISONS.md](RAPPORT-COMBINAISONS.md).

> **Optimisation Scan du 19 octobre 2026.** Lire [RAPPORT_PERF_SCAN.md](RAPPORT_PERF_SCAN.md) et [RAPPORT-TESTS.md](RAPPORT-TESTS.md). Vrai Scan 3.1b C++/WASM, 64 Mio par défaut, 128 Mio et SIMD optionnels ; niveaux 12/16/20/22/25. Les quatre phases précédentes sont conservées.

> **Fonctions de la livraison précédente :** Lire d’abord [LIVRAISON-QUATRE-PHASES.md](LIVRAISON-QUATRE-PHASES.md) : PDN corrigé, lignes partie/Scan indépendantes, nouvelle interface de jeu, flèches SVG et recherche rétrograde depuis un **damier final complet**. Le mode par défaut du générateur est désormais ce dessin complet. Les paragraphes sur les racines partielles ci-dessous concernent l’ancien mode, conservé dans le sélecteur.

## Publication sur le dépôt Dt existant

1. Télécharger l’archive livrée **dames-webapp-github-pages (1).zip**.
2. Dans le dépôt `sosthene-hub/Dt`, remplacer le fichier ZIP qui porte exactement ce nom, à la racine. Ne pas renommer le fichier : le workflow actuel utilise ce nom.
3. Valider sur la branche `main`. Le workflow déjà présent dans le dépôt extrait cette archive, lance `npm ci` puis `npm test` et publie `app/dist`.
4. Attendre la réussite de l’onglet Actions, puis recharger https://sosthene-hub.github.io/Dt/ . En cas d’ancien écran, vider les données du site / recharger.

Cette livraison n’a pas été téléversée sur votre compte. Le workflow de votre dépôt reste inchangé.

## Fichier autonome

`Dames-autonome.html` contient l’application, Scan, ses données et le worker du générateur. Ouvrir dans Chrome, hors du visualiseur de fichiers Arena qui restreint les workers. Testé réellement en `file://` avec Chromium et sans serveur. Android/Chrome physique reste à contrôler : certains gestionnaires Android ouvrent le HTML dans un visualiseur limité plutôt que dans Chrome. Privilégier GitHub Pages dans ce cas. Le dernier dessin utilise localStorage ; sa conservation dépend des permissions du navigateur.

## Utilisation

Menu → Générateur de positions. Placer les pions du porteur, les pions adverses et les vides obligatoires. Le porteur définit la couleur de l’outil ; changer le porteur ne recolore pas les pions déjà dessinés. Une case sans dessin est libre, ce n’est pas une case vide imposée. Le dessin doit se retrouver exactement sur les cases indiquées dans la position finale ; des pions supplémentaires complètent les effectifs choisis. Les pièces ne sont pas immobilisées pendant la partie preuve.

Saisir les effectifs égaux, trait, avantage ou équilibre, seuil Scan, profondeur (1–20), budget et graine. Lancer le tirage. Recherche de parties légales guidée par le dessin, puis filtrage et analyse Scan en série ; maximum 100 candidats uniques par lot, 10 damiers témoins. Cliquer un témoin pour rejouer la preuve depuis le départ, demi-coup par demi-coup. Le JSON conserve tous les résultats retenus et le rapport. Scan peut modifier la structure dans sa meilleure variante.

## Limites explicites

- Recherche heuristique, pas un solveur exhaustif d’atteignabilité : une racine spécifique peut ne donner aucun résultat, même si elle est réalisable.
- Le moteur actif est désormais Scan 3.1b compilé en **WebAssembly O3/LTO**. L’ancien asm.js est conservé uniquement comme référence de mesure.
- Le générateur ne valide que les itérations terminées à la profondeur demandée. Un arrêt temporel conserve une PV légale pour l’analyse et le jeu, mais ne valide pas une profondeur incomplète. Les budgets dépendent de la profondeur ; voir le rapport. Aucune profondeur n’est garantie sur téléphone.
- Pions seuls dans les résultats. La définition opérationnelle du contact isolé est : voisin adverse sur une diagonale immédiate et aucun voisin allié sur ces quatre diagonales.
- Les scores du générateur sont ceux de Scan, ramenés au point de vue blanc ; le seuil n’est pas une probabilité de victoire. Tables locales activées jusqu’à 4 pièces au total.
- Retrait des rubriques Apprendre/Puzzles et Problèmes ainsi que du moteur de positions aléatoires ancien. Jeu, analyse, éditeur et import PDN conservés.

## Développement

`npm ci`, `npm test`, `npm run dev`. `npm run standalone` reconstruit le HTML autonome. Pour la publication : `VITE_BASE_PATH=/Dt/ npm run build`.

Tests navigateur optionnels : installer Playwright et Chromium, puis adapter le chemin file:// dans `scripts/browser-check.mjs`. Le contrôle utilise un seuil très large pour vérifier la chaîne technique, pas la force des positions.

## Licence et provenance

Scan 3.1 : Fabien Letouzey ; port JavaScript distribué par TheYoBots, paquet `scan3.1.js@1.1.0`. Sources et licence GPL-3.0 du paquet inclus dans `third-party/scan3.1`. Les notices amont sont conservées. Code applicatif fourni sous GPL-3.0 pour cette redistribution ; voir `LICENSE`. Dépôt de base : commit `0c47952f04fd05f8639c811d5a225e4e8d399d6f`, archive applicative incluse dans ce dépôt.


## Nouvelle livraison : recherche avancée

Menu → Recherche avancée. Bibliothèque locale, sans serveur ni compte, limitée à 3 000 positions et aux capacités du stockage du navigateur. Dessin de pions/dames et vides imposés ; motif partiel ou position exacte ; trait ; nombre minimum/maximum de pièces de chaque camp ; nombre exact de dames de chaque couleur ; texte nom/étiquettes. Résultats paginés par 20, damiers, analyse et suppression avec confirmation.

Enregistrer depuis l’éditeur ou l’analyse. Les nouveaux résultats du générateur sont ajoutés automatiquement. Import/export JSON (format bibliothèque ou ancien export de tirage) avec dédoublonnage. Exporter régulièrement : effacer les données du site efface la bibliothèque. La recherche ne parcourt pas des bases de parties en ligne ni les joueurs PDN : vous avez choisi la recherche de positions.

## Tables de finales hors ligne : 2 à 4 pièces au total

**41 fichiers réels** de bitbases Scan sont intégrés. Aucune requête à une API de finales. Pions, dames, promotions et prises obligatoires pris en charge. Dans le damier d’analyse, le panneau « Tables de finales hors ligne » affiche gain/nulle/perte pour le trait et le résultat de chaque coup légal. Cliquer un coup pour le jouer. Scan charge lui-même ces fichiers dans son système de fichiers virtuel avec `bb-size=4`, en partie et en analyse.

**Couverture explicite : 4 pièces maximum au total, pas 4 par camp. Les tables 5–6 pièces ne sont pas incluses.** Au-delà : affichage « hors couverture », analyse Scan classique, jamais un faux résultat exact. Les tables décrivent un WDL théorique sans historique, sans distance au gain et sans garantir de gagner avant une limite de nulle. Le résultat réglementaire dépend aussi de l’historique. Le score numérique Scan n’est pas le WDL : Scan peut filtrer les coups avec les tables tout en affichant une évaluation non nulle sur une position théoriquement nulle. L’interface les sépare.

Provenance : https://hjetten.home.xs4all.nl/scan/bb.zip ; sélection 2–4 pièces extraite par requêtes HTTP partielles, CRC ZIP vérifié pour chaque fichier. Tailles et SHA-256 : `bitbases-provenance.json`. Script de reconstruction optionnel : `python scripts/download-bitbases.py`. Les fichiers 5–6, volumineux, n’ont pas été téléchargés. Aucun fichier externe n’est nécessaire à l’utilisation normale.

## Nulles FMJD

Module commun au jeu et à l’analyse : répétition triple avec même trait ; 25 coups de chaque camp uniquement de dames, sans capture ni mouvement de pion ; limites de finales 16 et 5 coups par camp. Version de référence : FMJD Annexes 2024, annexe 1, articles 6.1–6.4, https://www.fmjd.org/downloads/FMJD_Annexes_2024_8-sig.pdf .

La disposition à trois pièces dont au moins une dame contre une dame seule déclenche 16 ; si la dame seule est seule à occuper la grande diagonale, un délai de 5 est aussi activé (ajout du texte 2024). Deux dames, dame+pion ou dame seule contre dame seule déclenchent 5. La capture ne remet pas à zéro une échéance de finale déjà engagée ; une nouvelle échéance plus courte peut s’ajouter. Une victoire par immobilisation ou disparition des pièces a priorité au dernier coup. Compteurs affichés, sauvegardés/restaurés à l’annulation, remis à zéro à la nouvelle partie. La première apparition du matériel déclenche le compte des coups suivants.

L’analyse d’un code chargé commence un nouvel historique : on ne peut pas déduire les anciennes répétitions ni compteurs d’un seul damier. Cette limite est affichée. Le fichier autonome contient également la bibliothèque et les tables ; pas de manifeste installable ajouté ici (finalisation PWA distincte). Sur le site publié, le service worker est maintenant enregistré automatiquement et précache aussi le worker du générateur.
