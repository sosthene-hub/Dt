# PIONICIDE — dames internationales 10×10

> **Version 1.0.0 — projet bouclé (1er novembre 2026).** Les six phases sont terminées : la Phase 6 apporte l'**application installable** (manifeste, icônes, invite d'installation, liens directs, cache hors ligne complet) et la reprise de toute la documentation. Voir [PHASE6.md](PHASE6.md) pour l'état final, les vérifications et la procédure de publication.

> **Sept écrans** : **Accueil / Jouer**, **PIONICIDE contre PIONICIDE**, **Damier d'analyse**, **Éditeur de partie**, **Importer une partie**, **Combinaisons**, **Base de parties** (import massif de PDN, explorateur d'ouvertures, recherche par structure, export de la base, passerelles vers l'analyse et le jeu). Ce dernier module est décrit dans [INTEGRATION-BASE.md](INTEGRATION-BASE.md).

> **Série 2 (rappel) : 21 octobre 2026.** L’application s’appelle **PIONICIDE** : « Scan » a disparu de toute l’interface, le moteur reste identique. Deux nouveautés : l’**analyse des menaces de la partie** (menaces créées et menaces évitées, repères dans la liste des coups, flèches numérotées, export PDN et PDF) et le **bouton PDN du match moteur contre moteur** désormais opérationnel pendant et après chaque partie, avec archive des parties et bouton « Étudier ». Détails et résultats : [RAPPORT-MENACES-PIONICIDE.md](RAPPORT-MENACES-PIONICIDE.md), [LIVRAISON-SUITE2.md](LIVRAISON-SUITE2.md), [RAPPORT-TESTS.md](RAPPORT-TESTS.md).

> **Combinaisons** : base du livre PC Blues deel 66 — 2880 combinaisons incluses.

> **Moteur Scan 3.1b C++/WASM** (nom technique inchangé, GPL-3.0), 64 Mio de table de transposition par défaut (128 Mio et SIMD en option), profondeurs 12 à 25. Mesures et limites : [RAPPORT_PERF_SCAN.md](RAPPORT_PERF_SCAN.md).

> **Combinaisons** : base du livre, option « Demander une rafle » par préfixe de route, niveaux 1 à 4, validateur de cohérence des positions. Détails et chiffres : [RAPPORT-COMBINAISONS.md](RAPPORT-COMBINAISONS.md).

## Publication sur le dépôt Dt existant

1. Télécharger l’archive livrée **dames-webapp-github-pages (1).zip** (moins de 25 Mo, acceptée par l’interface web de GitHub).
2. Dans le dépôt `sosthene-hub/Dt`, remplacer le fichier ZIP qui porte exactement ce nom, à la racine. Ne pas renommer le fichier : le workflow actuel utilise ce nom.
3. **Deuxième téléversement** : ouvrir `data/livres/` et déposer `tome-1.pdf` et `tome-2.pdf` (5,6 Mo chacun), fournis à côté du ZIP. Réunis dans l’archive, ils dépassaient la limite GitHub de 25 Mo par fichier. Le site fonctionne sans eux.
4. Valider sur la branche `main`. Le workflow déjà présent dans le dépôt extrait cette archive, lance `npm ci` puis `npm test` et publie `app/dist`.
5. Attendre la réussite de l’onglet Actions, puis recharger https://sosthene-hub.github.io/Dt/ . En cas d’ancien écran, vider les données du site / recharger.

Cette livraison n’a pas été téléversée sur votre compte. Le workflow de votre dépôt reste inchangé : c’est le seul workflow du dépôt, il n’y avait rien d’accessoire à supprimer.

## Fichier autonome

`Dames-autonome.html` contient l’application, Scan, ses données (évaluation compressée en gzip) et la base des 2880 combinaisons. Ouvrir dans Chrome, hors du visualiseur de fichiers Arena qui restreint les workers. Testé réellement en `file://` avec Chromium et sans serveur. Android/Chrome physique reste à contrôler : certains gestionnaires Android ouvrent le HTML dans un visualiseur limité plutôt que dans Chrome. Privilégier GitHub Pages dans ce cas. Le dernier dessin utilise localStorage ; sa conservation dépend des permissions du navigateur.

## Utilisation

- **Jouer** : partie contre Scan, choix du camp et du niveau, annulation, relecture, analyse, export PDN.
- **PIONICIDE contre PIONICIDE** : deux moteurs avec profondeur et temps séparés, **mémoire de 60 ou 120 Mo par moteur**, Démarrer / Pause / Reprendre / Arrêter, vitesse d'affichage, séries de 1 à 6 parties avec alternance des couleurs et score, export PDN. **PDN opérationnel** : `⤓ PDN de la partie en cours` à tout moment (résultat `*`), `⤓ PDN` pour toutes les parties de la session, archive « Parties et PDN » avec une ligne par partie (résultat, raison de la fin, profondeurs, demi-coups) et un bouton **Étudier** qui ouvre la partie dans le damier d’analyse ; une partie arrêtée est conservée ; secours « Afficher / copier le PDN » pour les navigateurs qui bloquent les téléchargements. La position de départ peut être la position initiale ou une position préparée dans l'éditeur ou une combinaison. Un seul moteur partagé pour les autres écrans, libéré pendant le match pour laisser la place aux deux joueurs.
- **Analyse** : deux lignes distinctes (partie jouée et variante Scan), tables de finales 2–4 pièces, export PDN.
- **Partie annotée (Analyse)** : « Analyser et annoter la partie » évalue chaque position avec Scan une seule fois, marque les coups `!`, `?`, `??` selon les seuils réglables (0,5 et 1,5 pion par défaut), puis deux exports : **PDN annoté** (en-tête complet, commentaire `{ −0,45, prof. 12 }`, variante Scan pour chaque erreur) et **feuille imprimable / PDF** (liste des coups sur deux colonnes, bloc par erreur avec mon coup, meilleur coup, évaluations et variante, **sans courbe ni graphique**). Niveau de détail « erreurs seulement » par défaut ou « toute la partie ». Diagrammes **SVG** de 5 à 6 cm ajoutés à la demande (« Ajouter un diagramme à l’export »), automatiquement après chaque `??` si on le souhaite, avec flèche du meilleur coup et cases numérotées de 1 à 50 en option.
- **Menaces de la partie** (Damier d’analyse) : « Analyser les menaces de la partie » examine chaque coup — la menace qu’il crée (le camp qui vient de jouer rejoue, l’adversaire passe) et la menace adverse qu’il évite (le trait revient à l’adversaire avant le coup, puis la parade est vérifiée après le coup). Profondeur 6 à 20 (10 par défaut), seuil 0,5 pion, portée toute la partie / un camp / une plage de coups, repères `▲` `▼` dans la liste, flèches numérotées 1-2-3 (vert créée, orange évitée, rouge rafle), récapitulatif par camp et trois coups les plus importants, recalcul isolé d’un coup. Lancée avec l’analyse annotée, elle partage ses évaluations : **un seul passage**. Option d’export dans le PDN et le PDF, décochée par défaut.
- **Éditeur** : placement des pièces, code de position, « Analyser cette position » et « **Jouer contre Scan à partir de cette position** » (choix de ma couleur, du camp au trait et du niveau ; contrôles de position avant lancement).
- **Importer** : PDN, relecture complète.
- **Combinaisons** : rafle demandée, niveau 1 à 4, filtres, réglages du validateur (écart de matériel, avancée des leurres, pions isolés), bouton « Jouer cette position contre Scan ». La solution s’affiche désormais **pas à pas** : boutons `⏮`, `◀`, `▶`, `⏭` et une seule ligne « 7/11 · 4. 34x23 », au lieu de la liste complète des demi-coups.

## Limites explicites

- Recherche heuristique, pas un solveur exhaustif d’atteignabilité : une racine spécifique peut ne donner aucun résultat, même si elle est réalisable.
- Le moteur actif est désormais Scan 3.1b compilé en **WebAssembly O3/LTO**. L’ancien asm.js est conservé uniquement comme référence de mesure.
- Le générateur ne valide que les itérations terminées à la profondeur demandée. Un arrêt temporel conserve une PV légale pour l’analyse et le jeu, mais ne valide pas une profondeur incomplète. Les budgets dépendent de la profondeur ; voir le rapport. Aucune profondeur n’est garantie sur téléphone.
- Pions seuls dans les résultats. La définition opérationnelle du contact isolé est : voisin adverse sur une diagonale immédiate et aucun voisin allié sur ces quatre diagonales.
- Les scores du générateur sont ceux de Scan, ramenés au point de vue blanc ; le seuil n’est pas une probabilité de victoire. Tables locales activées jusqu’à 4 pièces au total.
- Retrait des rubriques Apprendre/Puzzles et Problèmes ainsi que du moteur de positions aléatoires ancien. Jeu, analyse, éditeur et import PDN conservés.

## Développement

`npm ci`, `npm test`, `npm run dev`. `npm run standalone` reconstruit le HTML autonome. Pour la publication : `VITE_BASE_PATH=/Dt/ npm run build`.

Tests navigateur optionnels : installer Playwright et Chromium, puis adapter le chemin file:// dans `scripts/browser-check.mjs`. Le contrôle utilise un seuil très large pour vérifier la chaîne technique, pas la force des positions.

Contrôles de clôture : `npm run test:browser-pwa` (manifeste, icônes, service worker, invite d'installation, liens directs, rechargement hors ligne) et `npm run test:browser-base` (parcours complet de la base de parties, `PDN=chemin.pdn` pour utiliser un autre corpus).

Contrôles propres à l’export annoté : `npm run test:export` (seuils, PDN annoté, relecture) `npm run test:browser-annotate` (annotation réelle, téléchargement du PDN, feuille imprimable, PDF, réimport du PDN dans l’application ; serveur de production ou `BASE_URL=file://…/Dames-autonome.html`) et `npm run test:browser-annotate-offline` (HTML autonome, réseau coupé).

## Licence et provenance

Scan 3.1 : Fabien Letouzey ; port JavaScript distribué par TheYoBots, paquet `scan3.1.js@1.1.0`. Sources et licence GPL-3.0 du paquet inclus dans `third-party/scan3.1`. Les notices amont sont conservées. Code applicatif fourni sous GPL-3.0 pour cette redistribution ; voir `LICENSE`. Dépôt de base : commit `0c47952f04fd05f8639c811d5a225e4e8d399d6f`, archive applicative incluse dans ce dépôt.


## Base de parties (module ajouté puis bouclé)

Menu → **Base de parties**, cinq onglets :

- **Importer** : un ou plusieurs fichiers PDN, traitement par lots dans un worker dédié (4 Mo à la fois), barre de progression, pause, reprise au même octet après une coupure, rapport final (importées / doublons / ignorées **avec motif** / tronquées / joueurs distincts) et mesures de l'appareil.
- **Explorateur** : index Zobrist sur 30 demi-coups, neuf coups légaux au départ, pourcentages gain / nulle / perte par coup, position courante jouable au clic, liste des parties de la position avec filtres joueur, couleur, période et événement.
- **Structures** : éditeur à six états par appui répété (pion blanc, dame blanche, pion noir, dame noire, case vide obligatoire, libre), chaîne de 50 caractères, JSON, enregistrement / renommage / suppression / export.
- **Recherche** : structure dessinée ou enregistrée, symétrie de couleur, filtre joueur, rejeu **par opérations binaires** (sans générateur de coups), progression, ouverture au coup trouvé.
- **Base** : compteurs, stockage persistant, export / import du fichier de base `.pbase`, reconstruction de l'index, table d'alias des joueurs, analyse des doublons.

Trois passerelles relient ce module au reste de l'application : **Analyser cette partie** (→ damier d'analyse, avec `store.analysisDraft`), **Jouer cette position** (→ partie contre PIONICIDE, avec `store.playDraft`) et **Vers l'éditeur de structure**.

**Recherche par nom tolérante** : accents et casse, ordre prénom/nom, nom seul, prénom seul, initiales, abréviation, lettres sautées ou doublées, mots de liaison (`van der`, `jr`). Le champ indique le nom retenu (« Nom corrigé : Taeke Kooistra ») ou l'absence de nom proche.

**Mesures réelles** sur le fichier de 1 000 parties : 977 importées, 11 doublons, 12 ignorées avec motif, 360 joueurs, ≈ 0,5 ms par partie, index 21 036 positions / 0,6 Mo, stockage 20 Mo sur 10 Go de quota, recherche par structure en 27 à 46 ms.

## Installation sur l'appareil (Phase 6)

PIONICIDE est une **PWA installable** : `manifest.webmanifest` (nom, icônes 192/512 et maskable, mode `standalone`, trois raccourcis), invite d'installation dans l'application, et service worker qui précache le shell, les assets, les données du moteur, le manifeste et les icônes. Sur Android : Chrome → **⋮ → Installer l'application** ; sur ordinateur, l'icône d'installation de la barre d'adresse. Une fois installée, l'application s'ouvre en plein écran et fonctionne hors ligne. Les liens directs `#jouer`, `#analyse`, `#base`… ouvrent l'écran voulu.

## Réglages transversaux

- **Une seule profondeur** (sélecteur du damier d'analyse, 16 par défaut, 3 à 25) pour l'évaluation, l'annotation et l'analyse des menaces.
- **Une prise immédiate n'est pas une menace** : toute ligne de menace qui commence par une rafle est écartée et signalée comme telle.
- **Un seul worker pour la base de parties**, séparé du moteur ; le moteur Scan reste intact.
