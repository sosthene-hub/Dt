# Dames — Scan WebAssembly, combinaisons et Scan contre Scan

> **Version actuelle : 20 octobre 2026.** Sept écrans : **Accueil / Jouer**, **Créer une partie**, **Scan contre Scan**, **Damier d'analyse**, **Éditeur de partie**, **Importer une partie**, **Combinaisons** (PC Blues deel 66, 2880 combinaisons incluses). Les onglets « Recherche rétrograde » et « Recherche avancée » sont retirés. Voir [RAPPORT-SCAN-VS-SCAN.md](RAPPORT-SCAN-VS-SCAN.md) pour les nouveautés et [RAPPORT-TESTS.md](RAPPORT-TESTS.md) pour les résultats.

> **Scan 3.1b C++/WASM**, 64 Mio de table de transposition par défaut (128 Mio et SIMD en option), profondeurs 12 à 25. Mesures et limites : [RAPPORT_PERF_SCAN.md](RAPPORT_PERF_SCAN.md).

> **Combinaisons** : base du livre, option « Demander une rafle » par préfixe de route, niveaux 1 à 4, validateur de cohérence des positions. Détails et chiffres : [RAPPORT-COMBINAISONS.md](RAPPORT-COMBINAISONS.md).

## Publication sur le dépôt Dt existant

1. Télécharger l’archive livrée **dames-webapp-github-pages (1).zip** (moins de 25 Mo, acceptée par l’interface web de GitHub).
2. Dans le dépôt `sosthene-hub/Dt`, remplacer le fichier ZIP qui porte exactement ce nom, à la racine. Ne pas renommer le fichier : le workflow actuel utilise ce nom.
3. **Deuxième téléversement** : ouvrir `data/livres/` et déposer `tome-1.pdf` et `tome-2.pdf` (5,6 Mo chacun), fournis à côté du ZIP. Réunis dans l’archive, ils dépassaient la limite GitHub de 25 Mo par fichier. Le site fonctionne sans eux.
4. Valider sur la branche `main`. Le workflow déjà présent dans le dépôt extrait cette archive, lance `npm ci` puis `npm test` et publie `app/dist`.
5. Attendre la réussite de l’onglet Actions, puis recharger https://sosthene-hub.github.io/Dt/ . En cas d’ancien écran, vider les données du site / recharger.

Cette livraison n’a pas été téléversée sur votre compte. Le workflow de votre dépôt reste inchangé : c’est le seul workflow du dépôt, il n’y avait rien d’accessoire à supprimer.

## Fichier autonome

`Dames-autonome.html` contient l’application, Scan, ses données (évaluation compressée en gzip) et la base des 2880 combinaisons. Ouvrir dans Chrome, hors du visualiseur de fichiers Arena qui restreint les workers. Testé réellement en `file://` avec Chromium et sans serveur. Android/Chrome physique reste à contrôler : certains gestionnaires Android ouvrent le HTML dans un visualiseur limité plutôt que dans Chrome. Privilégier GitHub Pages dans ce cas. Le dernier dessin utilise localStorage ; sa conservation dépend des permissions du navigateur.

## Utilisation

- **Jouer** : partie contre Scan, choix du camp et du niveau, annulation, relecture, analyse, export PDN.
- **Créer une partie** : réglage du niveau puis lancement.
- **Scan contre Scan** : deux moteurs avec profondeur et temps séparés, Démarrer / Pause / Reprendre / Arrêter, vitesse d'affichage, séries de 1 à 6 parties avec alternance des couleurs et score, export PDN. La position de départ peut être la position initiale ou une position préparée dans l'éditeur ou une combinaison.
- **Analyse** : deux lignes distinctes (partie jouée et variante Scan), tables de finales 2–4 pièces, export PDN.
- **Éditeur** : placement des pièces, code de position, « Analyser cette position » et « **Jouer contre Scan à partir de cette position** » (choix de ma couleur, du camp au trait et du niveau ; contrôles de position avant lancement).
- **Importer** : PDN, relecture complète.
- **Combinaisons** : rafle demandée, niveau 1 à 4, filtres, réglages du validateur (écart de matériel, avancée des leurres, pions isolés), bouton « Jouer cette position contre Scan ».

## Limites explicites

- Recherche heuristique, pas un solveur exhaustif d’atteignabilité : une racine spécifique peut ne donner aucun résultat, même si elle est réalisable.
- Le moteur actif est désormais Scan 3.1b compilé en **WebAssembly O3/LTO**. L’ancien asm.js est conservé uniquement comme référence de mesure.
- Le générateur ne valide que les itérations terminées à la profondeur demandée. Un arrêt temporel conserve une PV légale pour l’analyse et le jeu, mais ne valide pas une profondeur incomplète. Les budgets dépendent de la profondeur ; voir le rapport. Aucune profondeur n’est garantie sur téléphone.
- Pions seuls dans les résultats. La définition opérationnelle du contact isolé est : voisin adverse sur une diagonale immédiate et aucun voisin allié sur ces quatre diagonales.
- Les scores du générateur sont ceux de Scan, ramenés au point de vue blanc ; le seuil n’est pas une probabilité de victoire. Tables locales activées jusqu’à 4 pièces au total.
- Retrait des rubriques Apprendre/Puzzles et Problèmes ainsi que du moteur de positions aléatoires ancien. Jeu, analyse, éditeur et import PDN conservés.

## Développement

`npm ci`, `npm test`, `npm run dev`. `npm run standalone` reconstruit le HTML autonome. Pour la publication : `VITE_BASE_PATH=/Dt/ npm run build`.

Tests navigateur optionnels : installer Playwright et Chromium, puis adapter le chemin file:// dans `scripts/browser-check.mjs`. Le contrôle utilise un seuil très large pour vérifier la chaîne technique, pas la force des positions.

## Licence et provenance

Scan 3.1 : Fabien Letouzey ; port JavaScript distribué par TheYoBots, paquet `scan3.1.js@1.1.0`. Sources et licence GPL-3.0 du paquet inclus dans `third-party/scan3.1`. Les notices amont sont conservées. Code applicatif fourni sous GPL-3.0 pour cette redistribution ; voir `LICENSE`. Dépôt de base : commit `0c47952f04fd05f8639c811d5a225e4e8d399d6f`, archive applicative incluse dans ce dépôt.


## Nouvelle livraison : recherche avancée

Menu → Recherche avancée. Bibliothèque locale, sans serveur ni compte, limitée à 3 000 positions et aux capacités du stockage du navigateur. Dessin de pions/dames et vides imposés ; motif partiel ou position exacte ; trait ; nombre minimum/maximum de pièces de chaque camp ; nombre exact de dames de chaque couleur ; texte nom/étiquettes. Résultats paginés par 20, damiers, analyse et suppression avec confirmation.

Enregistrer depuis l’éditeur ou l’analyse. Les nouveaux résultats du générateur sont ajoutés automatiquement. Import/export JSON (format bibliothèque ou ancien export de tirage) avec dédoublonnage. Exporter régulièrement : effacer les données du site efface la bibliothèque. La recherche ne parcourt pas des bases de parties en ligne ni les joueurs PDN : vous avez choisi la recherche de positions.

## Tables de finales hors ligne : 2 à 4 pièces au total

**41 fichiers réels** de bitbases Scan sont intégrés. Aucune requête à une API de finales. Pions, dames, promotions et prises obligatoires pris en charge. Dans le damier d’analyse, le panneau « Tables de finales hors ligne » affiche gain/nulle/perte pour le trait et le résultat de chaque coup légal. Cliquer un coup pour le jouer. Scan charge lui-même ces fichiers dans son système de fichiers virtuel avec `bb-size=4`, en partie et en analyse.

**Couverture explicite : 4 pièces maximum au total, pas 4 par camp. Les tables 5–6 pièces ne sont pas incluses.** Au-delà : affichage « hors couverture », analyse Scan classique, jamais un faux résultat exact. Les tables décrivent un WDL théorique sans historique, sans distance au gain et sans garantir de gagner avant une limite de nulle. Le résultat réglementaire dépend aussi de l’historique. Le score numérique Scan n’est pas le WDL : Scan peut filtrer les coups avec les tables tout en affichant une évaluation non nulle sur une position théoriquement nulle. L’interface les sépare.

Provenance : https://hjetten.home.xs4all.nl/scan/bb.zip ; sélection 2–4 pièces extraite par requêtes HTTP partielles, CRC ZIP vérifié pour chaque fichier. Tailles et SHA-256 : `bitbases-provenance.json`. Script de reconstruction optionnel : `python scripts/download-bitbases.py`. Les fichiers 5–6, volumineux, n’ont pas été téléchargés. Aucun fichier externe n’est nécessaire à l’utilisation normale.

## Nulles FMJD

Module commun au jeu et à l’analyse : répétition triple avec même trait ; 25 coups de chaque camp uniquement de dames, sans capture ni mouvement de pion ; limites de finales 16 et 5 coups par camp. Version de référence : FMJD Annexes 2024, annexe 1, articles 6.1–6.4, https://www.fmjd.org/downloads/FMJD_Annexes_2024_8-sig.pdf .

La disposition à trois pièces dont au moins une dame contre une dame seule déclenche 16 ; si la dame seule est seule à occuper la grande diagonale, un délai de 5 est aussi activé (ajout du texte 2024). Deux dames, dame+pion ou dame seule contre dame seule déclenchent 5. La capture ne remet pas à zéro une échéance de finale déjà engagée ; une nouvelle échéance plus courte peut s’ajouter. Une victoire par immobilisation ou disparition des pièces a priorité au dernier coup. Compteurs affichés, sauvegardés/restaurés à l’annulation, remis à zéro à la nouvelle partie. La première apparition du matériel déclenche le compte des coups suivants.

L’analyse d’un code chargé commence un nouvel historique : on ne peut pas déduire les anciennes répétitions ni compteurs d’un seul damier. Cette limite est affichée. Le fichier autonome contient également la bibliothèque et les tables ; pas de manifeste installable ajouté ici (finalisation PWA distincte). Sur le site publié, le service worker est maintenant enregistré automatiquement et précache aussi le worker du générateur.
