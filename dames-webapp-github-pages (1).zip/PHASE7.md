# PHASE 7 — PIONICIDE joue sur Lidraughts

Objectif : faire jouer PIONICIDE contre de vrais joueurs, sur lidraughts.org,
pour mesurer sa force réelle. Livrable : le dossier `bridge/`, autonome, qui
utilise **le moteur de l'application sans le modifier**.

## Ce qui a été construit

| Fichier | Rôle |
| --- | --- |
| `bridge/engine.cjs` | charge `public/scan-wasm-scalar.js` dans Node, écrit `/data/eval`, `/data/book` et les tables de finales, puis pilote le protocole Hub (`hub`, `init`, `pos`, `level`, `go think`) |
| `bridge/positions.mjs` | conversions : coups Lidraughts (`3429`, `233228`) → coups du noyau `src/base/core.js` ; position du noyau → chaîne Hub ; coup du moteur → paires de cases de l'API |
| `bridge/lidraughts.mjs` | client de l'API Bot : `/api/account`, `/api/stream/event`, `/api/bot/game/stream/{id}`, `/api/bot/game/{id}/move/{…}`, `/api/challenge/{user}`, acceptation, refus, abandon, clavardage |
| `bridge/bot.mjs` | boucle de jeu : écoute, accepte, suit les parties, calcule le budget de temps, joue, journalise ; modes `--check`, `--selftest`, `--challenge` |
| `bridge/test-mock.mjs` | faux serveur Lidraughts : vérifie de bout en bout l'acceptation, le suivi et la légalité du coup envoyé, sans réseau |
| `bridge/config.example.json` | modèle de configuration |
| `bridge/README.md` | procédure complète : compte BOT, jeton, lancement, mesure de force, dépannage |

## Trois découvertes décisives (protocole du moteur)

1. **La position se donne en forme « dense »** : une lettre de trait suivie des
   50 cases (`Wbbbb…wwww`), exactement ce que produit `boardToHub()`.
   `pos pos=W:W31-50:B1-20` (FEN PDN) est **silencieusement ignoré** : le moteur
   reste sur sa position courante, sans erreur. D'où des coups absurdes
   (« 34-30 » pour les Noirs) tant qu'on ne l'a pas vu.
2. **`pos pos=…` est la bonne syntaxe**, pas `pos pos=… ` sans le nom de couple,
   ni `pos W:…` : `main.cpp` n'accepte que des couples `nom=valeur` et retombe
   sinon sur la position par défaut.
3. **Les rafles sont abrégées** : Scan écrit `26x17` et non `26x17x21` quand la
   prise est la seule possible entre ces deux cases. La reconnaissance d'un coup
   du moteur doit donc se faire par *départ + arrivée*, puis par les prises
   citées en cas d'ambiguïté — et non par comparaison de chaînes.

## Mesures

- Démarrage du moteur dans Node : ~0,7 s (évaluation 8,5 Mo + 41 tables de
  finales + `init`), table de transposition 64 Mio (exposant 22).
- Recherche réelle vérifiée : profondeur 18 en 0,3 s, profondeur 22 en 3,1 s,
  positions de milieu de partie, coups toujours légaux et rejouables par le noyau.
- Ouverture : le livre de Scan répond instantanément sur les premiers coups.
- 20 demi-coups d'auto-jeu enchaînés sans erreur, puis 10 demi-coups à 1,2 s de
  budget : coups légaux à chaque fois.

## Essais automatisés

```
node bridge/bot.mjs --selftest 10     → 10 demi-coups, coups légaux, journal complet
node bridge/test-mock.mjs             → défi accepté, partie suivie, coup légal
                                        envoyé, présentation postée → OK
```

Le second script remplace Lidraughts par un serveur local qui **rejoue chaque
coup reçu avec les règles FMJD du noyau** : un coup illégal serait refusé en 400.

## Ce qu'il reste à faire, côté compte

1. Créer un **compte neuf** (jamais utilisé) pour le bot : la bascule BOT est
   irréversible et impossible sur `Sosthene`.
2. Générer un jeton avec `bot:play` + `challenge:write`, puis
   `POST /api/bot/account/upgrade`.
3. Faire tourner `node bridge/bot.mjs` en continu (PC allumé, ou petit serveur).
4. Défier des joueurs en 5+2 ou plus long pour une mesure honnête.

## Session privée pour un ami

Le pont sait maintenant réserver les défis à des comptes nommés :
`node bridge/bot.mjs --allow Sosthene,MonAmi`. Les autres défis sont déclinés,
la limite de parties simultanées est réglable (`maxGames`, défaut 2, le moteur
traitant les recherches une par une dans une file d'attente), et chaque partie
terminée est archivée en PDN dans `bridge/games/` avec un bilan
`session.jsonl`. Mode d'emploi : `bridge/JOUER-AVEC-UN-AMI.md`.

Point de blocage à connaître : la bascule BOT est impossible sur `Sosthene`
(compte ayant déjà joué) et, de toute façon, elle priverait son propriétaire du
jeu à la main. La rencontre ami ↔ PIONICIDE se fait donc sur un compte bot
séparé, par défi. Les parties classées contre des humains sont autorisées sur
Lidraughts (contrairement à Lichess) : vérifié sur les bots du site, qui jouent
des classées en bullet, blitz et rapide contre des comptes humains.

## Contrôle de fair-play

`bridge/fairplay.mjs` analyse des parties réelles avec le moteur de l'application
et produit, camp par camp : accord avec le meilleur coup, perte moyenne
d'évaluation, temps médian et régularité du temps de réflexion (horloges de
l'export PDN), temps passé sur des coups forcés. Testé sur une partie réelle
bot-test – Nityananda : perte moyenne 0,013 pour le moteur contre 0,101 pour le
joueur — l'indicateur qui sépare vraiment, l'accord brut étant trompeur (68 %
pour un maître qui suit la théorie). Détail et limites dans
`bridge/TRICHERIE-ET-DETECTION.md`.

## Limites assumées

- WebAssembly mono-thread : nettement plus lent que Scan natif ; sous 5 minutes
  de cadence, la force mesurée serait tronquée.
- Variantes non standard refusées.
- Le jeu de dames produit beaucoup de nulles : la force se lit sur une série,
  pas sur une partie.
