# Rapport — Partie commentée (étude d'une partie, à la manière des monographies d'ouverture)

**8 novembre 2026.** Demande traitée : ajouter à PIONICIDE une **partie commentée** qui reproduit la forme du document fourni — le système hollandais 1. 32-28 18-22, 39 pages, 48 diagrammes, Diag. 272 à 319 — mais pour **la partie que l'utilisateur veut étudier**, et non pour les seules ouvertures de l'explorateur.

Contrainte posée dès le départ et tenue dans tout le module : **les commentaires ne sont pas inventés**. Chaque phrase porte une source explicite, calculée à partir des parties réellement présentes dans la base locale ou d'une évaluation réelle du moteur PIONICIDE.

---

## 1. Ce que fait le document produit

Le document reprend la structure du PDF de référence :

| Élément du PDF fourni | Ce que produit PIONICIDE |
|---|---|
| Titre du système, « SYSTÈME HOLLANDAIS : 1.32-28 18-22 » | En-tête de la partie + ligne « Ligne suivie : 1. 32-28 18-23 2. 33-29… », avec le nombre de parties de la base ayant atteint cette position |
| Chapitres `VARIANTE I`, `Développement 3. 31-26`, `1ère continuation`, `Ramification A` | Chapitres **I Ouverture / II Milieu / III Finale**, chacun avec ses moments numérotés |
| Diagrammes numérotés (Diag. 272…) | Diagrammes **SVG numérotés** (1, 2, 3…), légende « Diagramme n · avant 47-42 », placés avant le coup commenté |
| Parties de référence nommées et datées | Bloc **PARTIES** : les parties de la base qui ont atteint la position qui suit le coup, avec joueurs, événement, date et résultat — uniquement si elles existent dans la base |
| Verdicts (« Un coup faible », « Gain blanc ») | Bloc **BASE** (statistiques), bloc **MOTEUR** (évaluation et meilleur coup), puis **LECTURE** qui confronte les deux |
| Texte continu en colonnes | Texte justifié avec diagrammes flottants, sommaire, encadré de méthode, tableau des coups, liste complète des coups sur deux colonnes |

Trois sorties : l'écran de résultats (moments cliquables), le **document imprimable** (A4, prêt pour « Imprimer / PDF »), et le même document dans le **fichier autonome** hors ligne.

## 2. Les deux sources, et ce qu'elles disent

**Base de parties.** Pour chaque position, l'index Zobrist renvoie les coups joués et leurs résultats. Le module en tire, pour le coup joué : nombre de parties, gains / nulles / pertes, part de la position, et le **rendement** (gains + ½ nulles ÷ parties). Il désigne aussi le coup de meilleur rendement parmi ceux joués au moins *N* fois (5 par défaut) et l'écart de rendement avec le coup joué.

Point technique vérifié et corrigé : `bumpResult` enregistre les résultats **du point de vue du camp au trait dans la position visée**, donc de l'adversaire de celui qui vient de jouer. Le module (`moverStats`) échange explicitement gains et pertes pour parler du point de vue du joueur.

**Moteur PIONICIDE.** Évaluation en pions vue des Blancs, profondeur et plafond de temps réglables, meilleur coup et perte associée au coup joué. Le module réutilise `annotateGame` avec mémoïsation : **une seule recherche par position**, la valeur du coup joué se déduisant de la position suivante.

**Ce que le module refuse de faire**, et qui est écrit noir sur blanc dans le document :

- classer deux coups quand l'un d'eux a moins de *N* parties (`minSample`) ;
- conclure sur un échantillon anecdotique (moins de 5 parties) sans le signaler ;
- présenter un coup de référence mince comme une autorité : « le coup de référence 19-24 ne repose lui-même que sur 6 parties » ;
- parler de la base au-delà de la portée de l'index (30 demi-coups) : le document indique alors que la base ne se prononce pas ;
- citer un joueur, un tournoi ou une combinaison absents des données.

## 3. Choix des moments commentés

Tous les demi-coups ne méritent pas un paragraphe. Un demi-coup devient un « moment » s'il porte un fait vérifiable :

| Étiquette | Condition |
|---|---|
| `GAFFE` | perte ≥ 1,5 pion selon le moteur |
| `ERREUR` | perte ≥ 0,5 pion |
| `MINORITAIRE` | écart ≥ 10 points de rendement avec le meilleur coup de la base, les deux coups ayant au moins 5 parties |
| `COUP NOUVEAU` | position connue de la base, mais coup jamais joué |
| `POSITION INÉDITE` | position absente de la base |
| `MEILLEUR COUP` | meilleur coup du moteur dans une position déjà tranchée (|éval| ≥ 2 pions) |

Le nombre de moments est plafonné (8, 14 par défaut, ou 24), avec conservation garantie du premier écart avec la base et de la plus grosse perte du moteur. Le recalcul de la liste est instantané : les réglages de seuils ne relancent pas le moteur.

## 4. Entrées dans l'écran

- Menu → **Partie commentée** (nouvel écran, `#etude`).
- **Jouer** → bouton « Étudier et commenter » (partie en cours, avec la date et le résultat).
- **Base de parties** → bouton « Étudier et commenter » à côté de « Analyser cette partie » (la partie ouverte depuis la base).
- Chargement direct : fichier PDN, ou PDN collé.
- Le damier d'analyse alimente aussi l'écran par `store.analysisDraft` si l'on arrive sans partie.

## 5. Fichiers ajoutés ou modifiés

| Fichier | Rôle |
|---|---|
| `src/study/facts.js` (nouveau) | Cœur pur et testable : statistiques, classements, faits, phrases, sélection des moments, modèle du document |
| `src/study/base-client.js` (nouveau) | Client du worker de la base : ouverture attendue avant lecture, `explorerMoves`, `positionGames` |
| `src/study/document.js` (nouveau) | Mise en page du document imprimable (sommaire, chapitres, diagrammes, encadrés, tableau, liste des coups) |
| `src/study/study.css` (nouveau) | Écran sombre + page A4 blanche + `@media print` |
| `src/pages/etude.js` (nouveau) | Écran de réglages, progression, exécution base + moteur, résultats |
| `src/main.js` | Page `etude`, route `#etude` |
| `src/store.js` | `studyDraft` |
| `src/base/page.js` | Bouton « Étudier et commenter », `gameDraft()` factorisé avec l'analyse |
| `src/pages/game.js` | Bouton « Étudier et commenter » |
| `scripts/test-etude.mjs` (nouveau) | Tests des faits, sans navigateur |
| `scripts/browser-etude.mjs` (nouveau) | Parcours navigateur complet + PDF |
| `scripts/browser-etude-standalone.mjs` (nouveau) | Même parcours dans `Dames-autonome.html`, réseau coupé |
| `package.json` | `test:etude` ajouté à `npm test` ; `test:browser-etude`, `test:browser-etude-standalone` |

## 6. Vérifications exécutées

`npm test` passe en entier (build, règles, position, PDN, export, menaces, moteur, WASM, hors ligne, finales, validateur, base, **étude**).

**Exactitude des statistiques** (`scripts/test-etude.mjs`) : les coups et résultats sont recomptés indépendamment, partie par partie, sur 192 parties réelles, puis comparés au module. 2 positions comparées à l'identique (aucune transposition), 1 position contrôlée en inclusion (transposition), 0 écart. Les seuils, la sélection des moments, les cas « base vide » et « base indisponible » sont également testés.

**Parcours navigateur** (`scripts/browser-etude.mjs`, build de production) :

```
· OK  liste des parties de la position disponible
· OK  partie ouverte dans l'explorateur
· OK  l'écran Partie commentée est ouvert
· OK  partie reçue depuis la base — Benedictus Springer — Alfred Molimard · Wereldkampioenschap Amsterdam KNDB 1928
· OK  étude terminée en 3,5 s (126 demi-coups, profondeur 10)
· OK  résumé chiffré présent (5 lignes)
· OK  moments commentés — 8 moments, chacun avec ses deux sources
· OK  document : 5 chapitres, 8 moments, 8 diagrammes, 10 parties de référence, 127 lignes de tableau
· OK  document : sommaire aligné, légendes « Diagramme n », aucun artefact
· OK  PDF produit — 377 Ko, en-tête %PDF- valide
· OK  PDN collé chargé et étudié (131 demi-coups)
· OK  hors base : le document le dit
· OK  bouton « Étudier et commenter » présent dans la partie
· OK  aucune erreur JavaScript
```

**Fichier autonome hors ligne** (`scripts/browser-etude-standalone.mjs`, `file://`, réseau coupé via `page.route`) : étude terminée, 8 moments, 8 diagrammes, aucune requête réseau, et le cas « base demandée mais IndexedDB vide en `file://` » se dégrade proprement (« Base de parties : vide ou non interrogée », étude poursuivie avec le moteur seul).

Extrait réel produit sur la partie Springer — Molimard (Amsterdam 1928) :

> **MINORITAIRE — 1. 32-28 — coup minoritaire dans la base**
> **BASE** Sur 192 parties ayant atteint cette position, 32-28 a été joué 40 fois (20,8 % des parties) : 9 gains, 19 nulles, 12 pertes. Meilleur rendement de la base (au moins 5 parties) : 35-30 avec 5 parties et 80,0 % (gains + ½ nulles). Écart de rendement : 33,8 points en faveur de 35-30.
> **MOTEUR** PIONICIDE à la profondeur 10 évalue la position à ±0,0 (point de vue des Blancs) puis ±0,0 après le coup. Le moteur préférait 34-30, à égalité selon son évaluation.
> **PARTIES** 5 parties de la base ayant atteint la position qui suit ce coup, dont Benedictus Springer — Willem Rustenburg, Wereldkampioenschap Amsterdam 1928, résultat 2-1.
> **LECTURE** Le moteur ne voit pas de perte significative ; la base le désavoue aussi : 33,8 points de rendement séparent 32-28 de 35-30 sur au moins 5 parties. Le coup de référence 35-30 ne repose lui-même que sur 5 parties.

## 7. Limites explicites

- La profondeur et le temps décident de la qualité des commentaires du moteur : à profondeur 10 et 0,6 s par position, l'étude est rapide mais grossière ; les chiffres affichés disent toujours la profondeur employée.
- La base ne couvre que ses 30 premiers demi-coups et seulement les parties importées : une partie hors base n'aura que des commentaires « POSITION INÉDITE » et moteur.
- Le rendement de la base n'est pas une probabilité de victoire : c'est un rapport gains/nulles/pertes sur les parties présentes. Les parties de référence ne prouvent pas à elles seules la valeur d'un coup, et la méthode du document le dit.
- Aucune génération de « nom d'ouverture » : le document décrit la ligne par ses coups et son nombre de parties, il n'invente pas de terminologie.
- Les seuils et le plafond de moments sont des réglages, pas des vérités : changer un seuil change la sélection, jamais les chiffres.

## 8. Publication

Le dépôt `sosthene-hub/Dt` ne compile pas les sources : son workflow extrait `dames-webapp-github-pages (1).zip` à la racine, lance `npm ci` puis `npm test`, et publie `app/dist`. Il faut donc **remplacer ce ZIP** par celui livré ici (même nom exact), sans toucher au workflow. `Dames-autonome.html` a été régénéré pour inclure le nouvel écran.
