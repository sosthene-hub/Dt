# Compléments aux phases 2, 3 et 5 — recherche et finales

Livraison du 18 octobre 2026. Les fichiers PHASE0 à PHASE5 décrivent les étapes historiques, pas l’état intégral de cette version.

- Recherche avancée : désormais fonctionnelle pour les positions locales (choix utilisateur), pas pour une base de parties distante.
- Tables : désormais activées dans Scan et consultables dans l’analyse, couverture complète des matériels de 2 à 4 pièces au total. 5–6 pièces non fournies.
- Nulles : module partagé FMJD 2024, appliqué au jeu et à l’analyse, avec annulation des compteurs.
- Générateur sur racine de la livraison précédente conservé. Puzzles et problèmes restent retirés.
- Manifeste PWA, icônes d’installation et validation sur Android physique : toujours hors de cette livraison.

Voir README.md et RAPPORT-TESTS.md pour utilisation, limites et résultats exacts des tests.
