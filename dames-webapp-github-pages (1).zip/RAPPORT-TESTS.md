# Rapport de tests — livraison Scan + Combinaisons + Scan contre Scan

20 octobre 2026. Résultats finaux exécutés, pas seulement une liste de tests proposés. Cette livraison ajoute Scan contre Scan, la partie depuis une position éditée ou une combinaison, et le validateur de cohérence ; la recherche rétrograde et la recherche avancée sont retirées.

## Résultat

- `VITE_BASE_PATH=/Dt/ npm test` : **réussi**, code de sortie 0. Le générateur de motifs et la recherche rétrograde ont été retirés avec leurs workers ; le service worker passe en cache **v13**.
- Vrai moteur WASM portable **et SIMD** : **120 cas de finales chacun**, modes analyse/jeu, coups optimaux contrôlés ; livre réellement utilisé ; deadline interne ; reprise après délai ; position terminale sans blocage.
- `node scripts/browser-study.mjs` : **réussi**, HTML autonome réellement hors ligne ; PDN 131/131 ; deux lignes indépendantes ; rafles, flèches, retournement, annulation, relecture, choix des Noirs.
- `node scripts/browser-finales.mjs` : **réussi**, tables de finales, compteurs FMJD, nulle des 5 coups, annulation.
- `node scripts/browser-check.mjs` : **réussi**, 100 candidats analysés et retenus dans le contrôle technique permissif, 10 témoins, pas d’erreur JS ou de débordement mobile. Ce seuil de test ne prouve pas la force des positions.
- `node scripts/browser-perf-scan.mjs` : **réussi**, autonome `file://`, réseau désactivé ; WASM SIMD + 128 Mio ; coup de livre réel ; deadline 1,2 s ; 72 frames / écart maximum observé 16,8 ms ; menu utilisable ; arrêt effectif du Worker lors de la sortie d’analyse puis nouvelle analyse profondeur 3.
- `node scripts/browser-offline-finales.mjs` : **réussi**, production `/Dt/`, service worker **v13**, précache des builds WASM, du livre et de la base, rechargement hors ligne réel, combinaisons et **Scan contre Scan hors ligne**.
- `node scripts/browser-scan-vs-scan.mjs` : **réussi** — partie complète à deux niveaux (profondeur 6 contre 3, 177 demi-coups, nulle par triple répétition) et série de deux parties avec alternance des couleurs et score cumulé. Détails dans `RAPPORT-SCAN-VS-SCAN.md`.
- `node scripts/browser-editor-game.mjs` : **réussi** — partie depuis une position éditée (coup humain, réponse Scan, annulation, reprise du point de départ), position illégale refusée, combinaison jouée contre Scan.
- `node scripts/test-validator.mjs` : **réussi** — six règles contrôlées une par une ; 40 générations par niveau (2 et 3 : 40/40, 4 : 39/40) ; aucune pièce ajoutée sur une rangée interdite ; base du livre contrôlée (0 pion sur une ligne de promotion).

Traces : `tests-execution.log`, `perf/wasm-regression.json`, `perf/wasm-regression-simd.json`, `perf/browser-perf.json`, `browser-study-results.json`, `browser-finales-results.json`, `browser-offline-results.json`, `browser-test-results.json`.

## Combinaisons

- `node scripts/test-combinaisons.mjs` : **réussi** — 2880 combinaisons rejouées intégralement, index par case complet, 120 positions de niveau 1, 160 positions générées contrôlées, quatre rafles demandées respectées, route impossible refusée. Détails : `perf/combinaisons-tests.json`.
- `node scripts/browser-combinaisons.mjs` : **réussi** — niveaux 1 à 4 dans le navigateur, coup joué par l’interface, réponses forcées enchaînées, solution complète, aucun débordement.
- `node scripts/browser-combinaisons-offline.mjs` : **réussi** — autonome privé en `file://` avec réseau bloqué, base embarquée, niveau 1 et niveau 2 vérifié par Scan, zéro requête externe.
- `node scripts/browser-combinaisons-import.mjs` : **réussi** — version publique sans base, import du fichier privé, persistance après rechargement.
- `node scripts/browser-check.mjs` : **réussi** — cinq exercices de niveau 1, rafle affichée, réglages mémorisés, aucun débordement.
- Mesures d’extraction, de validation, de calibrage Scan et de génération : `RAPPORT-COMBINAISONS.md`.

## Performances et limites

Les mesures avant/après, position exacte, tailles de TT et de tables, répétitions, matériel, échecs OOM et choix SIMD sont détaillés dans **RAPPORT_PERF_SCAN.md** ; les résultats bruts sont dans `perf/`. Le détail des nouvelles fonctions et des règles de cohérence est dans **RAPPORT-SCAN-VS-SCAN.md**.

Le test Android est une mise en page mobile sous Chromium Linux, **pas un téléphone Android physique**. Aucun Elo ni débit Android garanti. La profondeur est un objectif soumis à une limite de temps. L’interface reste isolée du calcul natif ; la mémoire totale dépasse la seule TT affichée.

Tables automatiques **2–4 pièces**, pas 5/6. Un fil de recherche, pas de faux pthreads en fichier local. La recherche rétrograde a été retirée à la demande du propriétaire ; l’analyse et les tables restent disponibles.

## Intégrité

Le wrapper moteur est intentionnellement modifié dans cette livraison autorisant l’optimisation. Les règles applicatives FMJD, le module de nulles et le lecteur de tables demeurent identiques à leurs versions précédentes ; empreintes dans `core-integrity.json`. L’ancien Worker asm.js est gardé comme témoin, pas utilisé comme moteur actif.

`RAPPORT-QUATRE-PHASES-ANTERIEUR.md` conserve le précédent rapport. Les anciennes affirmations « moteur inchangé » ou « pas WASM » ne concernent pas cette nouvelle livraison.
