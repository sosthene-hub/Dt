# Rapport de tests — PIONICIDE (série 2 : menaces, renommage, PDN moteur contre moteur)

21 octobre 2026. Section ajoutée en tête ; les sections suivantes décrivent la livraison du 20 octobre, toujours valable.

## Analyse des menaces — `npm run test:threats`

`node scripts/test-threats.mjs` exécute le vrai moteur WASM dans Node (aucun moteur simulé) :

- **unités** : textes « Menace créée / évitée / non calculable / aucune menace réelle », portée `all` / `w` / `b` / `range`, seuils, rase de description (gain, rafle, « ne pare pas cette menace ») ;
- **annotation réelle** de 19 positions de la partie Verpoest–Berte 1980 à la profondeur 9 : une évaluation par position, cache alimenté ;
- **analyse des menaces réelle** sur 18 demi-coups : **6 menaces créées, 3 menaces évitées, 3 coups « prise obligatoire »** ; **chaque ligne de menace est rejouée coup par coup sur les règles FMJD** (légalité vérifiée) ; `captures` et `gain`/`gap` finis ;
- **cache** : 47 évaluations réutilisées, 19 nouvelles ; **second passage : 0 nouvelle évaluation et récapitulatif identique** ;
- **portée** « coups des Blancs » : les coups des Noirs sont marqués hors portée ;
- **seuil 5 pions** : 0 menace conservée sur 9 ;
- **recalcul isolé** d'un coup : identique au passage complet ;
- **export** : 9 commentaires `{ Menace … }` ;
- **interruption** : `cancelled`, aucun résultat partiel.

Trace : `perf/threats-tests.json`.

## Menaces dans le navigateur — `npm run test:browser-threats` (production `/Dt/`)

`node scripts/browser-threats.mjs` : **16 étapes, 0 erreur JavaScript**.

- marque PIONICIDE (en-tête, `<title>`) ; **aucune occurrence de « Scan »** dans le texte affiché ;
- passage unique annonce + menaces à la profondeur 9 sur 131 coups : **3,4 s**, message « Passage unique · 131 coups annotés et 131 coups examinés » ;
- récapitulatif : Blancs 17 / Noirs 27 menaces créées, Blancs 21 / Noirs 13 évitées ; trois coups les plus importants ;
- **78 repères** `▲`/`▼` dans la liste des coups ;
- clic sur un coup : **3 flèches numérotées 1-2-3**, couleurs de la palette (vert/orange/rouge), texte de menace visible sous le damier ;
- **recalcul isolé** des deux boutons (même profondeur) ; **« Revenir à la partie »** retire les flèches ;
- **PDN exporté** (`[Annotator "PIONICIDE · profondeur 9"]`, `[ThreatAnalysis "PIONICIDE"]`, 60 commentaires de menace) et **réimporté 131/131 demi-coups légaux** ;
- **mémoire** : retour sur la partie analysée → « Résultats mémorisés · aucun recalcul » en 1,1 s ;
- **feuille imprimable** : 61 blocs « Menaces de la partie », pied « Partie analysée par PIONICIDE » ;
- **portée** « Blancs » (66 coups examinés) et plage de coups n°2 à n°4 (6 demi-coups) ;
- **mobile 412 × 915** : aucun débordement, panneau 372 px.

## PDN du match moteur contre moteur — `npm run test:browser-svs-pdn`

`node scripts/browser-svs-pdn.mjs` : **10 étapes, 0 erreur**, deux parties complètes ou interrompues :

- `⤓ PDN de la partie en cours` téléchargé au 30e demi-coup → **relu par le parseur de l'application, 100 % de coups légaux**, `Result "*"`, en-têtes `PIONICIDE A/B · profondeur 2 · 0.2 s/coup` ;
- archive « Parties et PDN » : ligne « Partie 1 en cours », boutons `⤓ PDN` et `Étudier` ;
- **arrêt en cours de partie** : la partie rejoint l'archive, son PDN reste exportable ;
- **Étudier** : la partie (46 demi-coups) s'ouvre dans le damier d'analyse ;
- partie terminée (nulle FMJD, 136 demi-coups) : archive à jour, `⤓ PDN` produit un fichier de 2 parties, **chaque partie relue jusqu'au dernier coup sans coup illégal** ;
- « Afficher / copier le PDN » : texte complet affiché (2 028 octets) et actions disponibles ;
- mobile 412 × 915 : aucun débordement.

## Non-régression (série 2)

| Suite | Résultat |
|---|---|
| `npm test` (build, règles, position, PDN, export, **menaces**, moteur, WASM portable + SIMD, hors ligne, finales, validateur) | **code 0** |
| `browser-annotate.mjs` (annotation, PDN, feuille, PDF, réimport) | réussi |
| `browser-scan-disponible.mjs` (moteur partagé : analyse → match → analyse → combinaisons → partie) | réussi |
| `browser-scan-vs-scan.mjs` (parties complètes, série, en-têtes PIONICIDE) | réussi |
| `browser-study.mjs` (HTML autonome hors ligne, 131/131, deux lignes, rafles) | réussi |
| `browser-editor-game.mjs`, `browser-finales.mjs`, `browser-check.mjs` | réussis |
| `browser-combinaisons.mjs`, `browser-combinaisons-offline.mjs`, `browser-annotate-offline.mjs` | réussis |

Le cache du service worker passe en **v14** (`…-pionicide-v14`) : les visiteurs déjà venus reçoivent la nouvelle interface au lieu de l'ancienne.

---

# Rapport de tests — livraison Scan + Combinaisons + Scan contre Scan

20 octobre 2026. Résultats finaux exécutés, pas seulement une liste de tests proposés. Cette livraison ajoute l’export PDN annoté, la feuille imprimable / PDF avec diagrammes SVG et la solution de combinaison pas à pas (voir `RAPPORT-EXPORT-ANNOTE.md`), en plus de Scan contre Scan, de la partie depuis une position éditée ou une combinaison et du validateur de cohérence ; la recherche rétrograde et la recherche avancée sont retirées.

## Export annoté (20 octobre 2026)

- `node scripts/test-export.mjs` : **8/8** — seuils par défaut et réglés, formatage des évaluations (`±0,00`, `−0,45`, `+∞`), numérotation des variantes depuis un coup blanc ou noir, neutralisation de la perte du meilleur coup, en-têtes normalisés, PDN annoté intégral puis relu par le parseur de l’application (**131/131 demi-coups, coups et en-têtes identiques**), mode « toute la partie ».
- `node scripts/browser-annotate.mjs` (production `/Dt/`, Chromium 1180×900) : **réussi** — import de Verpoest–Berte 1980 (131 demi-coups), annotation réelle à la profondeur 9, PDN téléchargé (11 commentaires, 11 variantes), feuille imprimable (11 blocs d’erreur, 3 diagrammes, 150 numéros de cases, flèches, application et barre d’outils masquées en média impression), **PDF de 3 pages**, puis **réimport du PDN produit : 131/131 demi-coups légaux**. Même test réussi en `file://` sur `Dames-autonome.html`, réseau non utilisé.
- Durées d’annotation mesurées sur 131 positions : profondeur 9 → 1,7 s ; 12 → 4,1 s ; 16 → 12,2 s (Chromium Linux, desktop ; Android non mesuré).
- `node scripts/browser-annotate-offline.mjs` (`Dames-autonome.html`, `file://`, réseau coupé) : **réussi** — annotation réelle en 1,7 s, 11 blocs d’erreur, 3 diagrammes, solution de combinaison pas à pas (« 1/9 · 1. 34-29 » → « 9/9 · 5. 25x12 » → retour « 8/9 »), 0 requête externe, 0 erreur JS.
- Mobile 412×915 : panneau d’export 372 px sans débordement, feuille 392 px, 3 diagrammes (1 manuel + 2 automatiques), 11 blocs d’erreur, 0 erreur JS.
- Non-régression : `npm test` code 0 ; `browser-check`, `browser-study`, `browser-combinaisons`, `browser-combinaisons-import`, `browser-combinaisons-offline`, `browser-editor-game`, `browser-scan-disponible`, `browser-finales`, `browser-offline-finales` : toutes réussies.
- Traces : `perf/annotate/` (`rapport.json`, `partie-annotee.pdn`, `partie-annotee.pdf`, captures écran et impression), `perf/combinaisons/page-solution-pas-a-pas.png`.

## Résultat

- `VITE_BASE_PATH=/Dt/ npm test` : **réussi**, code de sortie 0. Le générateur de motifs et la recherche rétrograde ont été retirés avec leurs workers ; le service worker passe en cache **v13**.
- Vrai moteur WASM portable **et SIMD** : **120 cas de finales chacun**, modes analyse/jeu, coups optimaux contrôlés ; livre réellement utilisé ; deadline interne ; reprise après délai ; position terminale sans blocage.
- `node scripts/browser-study.mjs` : **réussi**, HTML autonome réellement hors ligne ; PDN 131/131 ; deux lignes indépendantes ; rafles, flèches, retournement, annulation, relecture, choix des Noirs.
- `node scripts/browser-finales.mjs` : **réussi**, tables de finales, compteurs FMJD, nulle des 5 coups, annulation.
- `node scripts/browser-check.mjs` : **réussi**, 100 candidats analysés et retenus dans le contrôle technique permissif, 10 témoins, pas d’erreur JS ou de débordement mobile. Ce seuil de test ne prouve pas la force des positions.
- `node scripts/browser-perf-scan.mjs` : **réussi**, autonome `file://`, réseau désactivé ; WASM SIMD + 128 Mio ; coup de livre réel ; deadline 1,2 s ; 72 frames / écart maximum observé 16,8 ms ; menu utilisable ; arrêt effectif du Worker lors de la sortie d’analyse puis nouvelle analyse profondeur 3.
- `node scripts/browser-offline-finales.mjs` : **réussi**, production `/Dt/`, service worker **v13**, précache des builds WASM, du livre et de la base, rechargement hors ligne réel, combinaisons et **Scan contre Scan hors ligne**.
- `node scripts/browser-scan-vs-scan.mjs` : **réussi** — partie complète à deux niveaux (profondeur 6 contre 3, 177 demi-coups, nulle par triple répétition) et série de deux parties avec alternance des couleurs et score cumulé. Détails dans `RAPPORT-SCAN-VS-SCAN.md`.
- `node scripts/browser-editor-game.mjs` : **réussi** — partie depuis une position éditée (coup humain, réponse Scan, annulation, reprise du point de départ), position illégale refusée, combinaison jouée contre Scan.
- `node scripts/browser-scan-disponible.mjs` : **réussi** — un seul aller-retour couvre Analyse, Scan contre Scan, retour à l’analyse, Combinaisons vérifiées par Scan et partie contre Scan : le moteur partagé revient à chaque fois.
- `node scripts/test-validator.mjs` : **réussi** — six règles contrôlées une par une ; 40 générations par niveau (2 et 3 : 40/40, 4 : 39/40) ; aucune pièce ajoutée sur une rangée interdite ; base du livre contrôlée (0 pion sur une ligne de promotion).

Traces : `tests-execution.log`, `perf/wasm-regression.json`, `perf/wasm-regression-simd.json`, `perf/browser-perf.json`, `browser-study-results.json`, `browser-finales-results.json`, `browser-offline-results.json`, `browser-test-results.json`.

## Combinaisons

- `node scripts/test-combinaisons.mjs` : **réussi** — 2880 combinaisons rejouées intégralement, index par case complet, 120 positions de niveau 1, 160 positions générées contrôlées, quatre rafles demandées respectées, route impossible refusée. Détails : `perf/combinaisons-tests.json`.
- `node scripts/browser-combinaisons.mjs` : **réussi** — niveaux 1 à 4 dans le navigateur, coup joué par l’interface, réponses forcées enchaînées, solution complète, aucun débordement.
- `node scripts/browser-combinaisons-offline.mjs` : **réussi** — autonome privé en `file://` avec réseau bloqué, base embarquée, niveau 1 et niveau 2 vérifié par Scan, zéro requête externe.
- `node scripts/browser-combinaisons-import.mjs` : **réussi** — version publique sans base, import du fichier privé, persistance après rechargement.
- `node scripts/browser-check.mjs` : **réussi** — cinq exercices de niveau 1, rafle affichée, réglages mémorisés, aucun débordement.
- Mesures d’extraction, de validation, de calibrage Scan et de génération : `RAPPORT-COMBINAISONS.md`.

## Performances et limites

Les mesures avant/après, position exacte, tailles de TT et de tables, répétitions, matériel, échecs OOM et choix SIMD sont détaillés dans **RAPPORT_PERF_SCAN.md** ; les résultats bruts sont dans `perf/`. Le détail des nouvelles fonctions, des correctifs mémoire et des règles de cohérence est dans **RAPPORT-SCAN-VS-SCAN.md**.

Le test Android est une mise en page mobile sous Chromium Linux, **pas un téléphone Android physique**. Aucun Elo ni débit Android garanti. La profondeur est un objectif soumis à une limite de temps. L’interface reste isolée du calcul natif ; la mémoire totale dépasse la seule TT affichée.

Tables automatiques **2–4 pièces**, pas 5/6. Un fil de recherche, pas de faux pthreads en fichier local. La recherche rétrograde a été retirée à la demande du propriétaire ; l’analyse et les tables restent disponibles.

## Intégrité

Le wrapper moteur est intentionnellement modifié dans cette livraison autorisant l’optimisation. Les règles applicatives FMJD, le module de nulles et le lecteur de tables demeurent identiques à leurs versions précédentes ; empreintes dans `core-integrity.json`. L’ancien Worker asm.js est gardé comme témoin, pas utilisé comme moteur actif.

`RAPPORT-QUATRE-PHASES-ANTERIEUR.md` conserve le précédent rapport. Les anciennes affirmations « moteur inchangé » ou « pas WASM » ne concernent pas cette nouvelle livraison.
