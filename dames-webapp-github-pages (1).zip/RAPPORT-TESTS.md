# Rapport de tests — livraison Scan + Combinaisons

19 octobre 2026. Résultats finaux exécutés, pas seulement une liste de tests proposés. Cette livraison remplace le générateur de positions par le module Combinaisons ; la recherche rétrograde garde son onglet.

## Résultat

- `VITE_BASE_PATH=/Dt/ npm test` : **réussi**, code de sortie 0. Le générateur de motifs a été retiré avec son worker ; le service worker passe en cache v11.
- Vrai moteur WASM portable **et SIMD** : **120 cas de finales chacun**, modes analyse/jeu, coups optimaux contrôlés ; livre réellement utilisé ; deadline interne ; reprise après délai ; position terminale sans blocage.
- `node scripts/browser-study.mjs` : **réussi**, HTML autonome réellement hors ligne ; PDN 131/131 ; deux lignes indépendantes ; rafles, flèches, retournement, annulation, relecture, choix des Noirs ; preuve rétrograde réelle et attribution des historiques connus.
- `node scripts/browser-finales.mjs` : **réussi**, recherche/bibliothèque persistante, tables, compteurs FMJD, annulation.
- `node scripts/browser-check.mjs` : **réussi**, 100 candidats analysés et retenus dans le contrôle technique permissif, 10 témoins, pas d’erreur JS ou de débordement mobile. Ce seuil de test ne prouve pas la force des positions.
- `node scripts/browser-perf-scan.mjs` : **réussi**, autonome `file://`, réseau désactivé ; WASM SIMD + 128 Mio ; coup de livre réel ; deadline 1,2 s ; 72 frames / écart maximum observé 16,8 ms ; menu utilisable ; arrêt effectif du Worker lors de la sortie d’analyse puis nouvelle analyse profondeur 3.
- `node scripts/browser-offline-finales.mjs` : **réussi**, production `/Dt/`, service worker **v11**, précache des builds WASM, du livre et du worker rétrograde, rechargement hors ligne réel, combinaisons et rétrograde.

Traces : `tests-execution.log`, `perf/wasm-regression.json`, `perf/wasm-regression-simd.json`, `perf/browser-perf.json`, `browser-study-results.json`, `browser-finales-results.json`, `browser-offline-results.json`, `browser-test-results.json`.

## Combinaisons

- `node scripts/test-combinaisons.mjs` : **réussi** — 2880 combinaisons rejouées intégralement, index par case complet, 120 positions de niveau 1, 160 positions générées contrôlées, quatre rafles demandées respectées, route impossible refusée. Détails : `perf/combinaisons-tests.json`.
- `node scripts/browser-combinaisons.mjs` : **réussi** — niveaux 1 à 4 dans le navigateur, coup joué par l’interface, réponses forcées enchaînées, solution complète, aucun débordement.
- `node scripts/browser-combinaisons-offline.mjs` : **réussi** — autonome privé en `file://` avec réseau bloqué, base embarquée, niveau 1 et niveau 2 vérifié par Scan, zéro requête externe.
- `node scripts/browser-combinaisons-import.mjs` : **réussi** — version publique sans base, import du fichier privé, persistance après rechargement.
- `node scripts/browser-check.mjs` : **réussi** — cinq exercices de niveau 1, rafle affichée, réglages mémorisés, aucun débordement.
- Mesures d’extraction, de validation, de calibrage Scan et de génération : `RAPPORT-COMBINAISONS.md`.

## Performances et limites

Les mesures avant/après, position exacte, tailles de TT et de tables, répétitions, matériel, échecs OOM et choix SIMD sont détaillés dans **RAPPORT_PERF_SCAN.md** ; les résultats bruts sont dans `perf/`.

Le test Android est une mise en page mobile sous Chromium Linux, **pas un téléphone Android physique**. Aucun Elo ni débit Android garanti. La profondeur est un objectif soumis à une limite de temps. L’interface reste isolée du calcul natif ; la mémoire totale dépasse la seule TT affichée.

Tables automatiques **2–4 pièces**, pas 5/6. Un fil de recherche, pas de faux pthreads en fichier local. La recherche rétrograde demeure heuristique et bornée : un échec n’est pas une preuve d’impossibilité.

## Intégrité

Le wrapper moteur est intentionnellement modifié dans cette livraison autorisant l’optimisation. Les règles applicatives FMJD, le module de nulles et le lecteur de tables demeurent identiques à leurs versions précédentes ; empreintes dans `core-integrity.json`. L’ancien Worker asm.js est gardé comme témoin, pas utilisé comme moteur actif.

`RAPPORT-QUATRE-PHASES-ANTERIEUR.md` conserve le précédent rapport. Les anciennes affirmations « moteur inchangé » ou « pas WASM » ne concernent pas cette nouvelle livraison.
