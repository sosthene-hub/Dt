/**
 * Tests du module Combinaisons. Sans base privée, le script s'arrête proprement
 * (code 0) en indiquant que les contrôles dépendant du livre sont sautés.
 *
 *   COMB_DB=/chemin/combinations-app.json node scripts/test-combinaisons.mjs
 */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { generateLegalMoves, applyMove, sideOf } from '../src/game-rules.js';
import { replayHubs, parseRouteInput, entryRoute, routeMatches } from '../src/combinations/model.js';
import { buildCandidate, findModels, generateVerified, mulberry32 } from '../src/combinations/generate.js';

const dbPath = process.env.COMB_DB || 'public/combinations-app.json';
if (!fs.existsSync(dbPath)) {
  console.log('Base privée absente : contrôles du livre sautés. Les tests publics restent couverts par npm test.');
  process.exit(0);
}
const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
const checks = {};

// 1. Intégrité et rejeu de toute la base.
let replayed = 0;
for (const entry of db.entries) {
  const result = replayHubs(entry.board, entry.trait, entry.solution);
  assert(result.ok, `${entry.id}: ${result.error}`);
  assert(entry.trait === 'w', `${entry.id}: trait inattendu`);
  replayed += 1;
}
checks.baseReplayed = replayed;
checks.baseTotal = db.entries.length;

// 2. Index par pion de départ complet et cohérent.
let indexed = 0;
for (let square = 1; square <= 50; square += 1) {
  for (const id of db.index[square] || []) {
    const entry = db.entries.find(e => e.id === id);
    assert(entry && entry.rafle_depart === square, `index incohérent ${square}/${id}`);
    indexed += 1;
  }
}
assert.equal(indexed, db.entries.length);
checks.indexed = indexed;

// 3. Niveau 1 : la position du livre se rejoue et conserve sa rafle.
let level1 = 0;
for (const entry of db.entries.slice(0, 120)) {
  const built = buildCandidate(entry, { level: 1 });
  assert(built.ok, `${entry.id}: ${built.reason}`);
  assert.deepEqual(built.candidate.rafle_complete, entryRoute(entry));
  level1 += 1;
}
checks.level1 = level1;

// 4. Niveaux 2 à 4 : légalité, matériel, rafle, prise obligatoire au départ.
const samples = { 2: 60, 3: 60, 4: 40 };
const stats = {};
for (const [level, count] of Object.entries(samples)) {
  const rng = mulberry32(20261019 + Number(level));
  let accepted = 0;
  let attempts = 0;
  const rejects = {};
  while (accepted < count && attempts < count * 40) {
    attempts += 1;
    const entry = db.entries[Math.floor(rng() * db.entries.length)];
    const built = buildCandidate(entry, { level: Number(level), rng });
    if (!built.ok) { rejects[built.reason] = (rejects[built.reason] || 0) + 1; continue; }
    const candidate = built.candidate;
    const replay = replayHubs(candidate.board, candidate.trait, candidate.solution);
    assert(replay.ok, `${entry.id}/n${level}: solution cassée`);
    assert(Math.abs(candidate.nb_pieces_blanc - candidate.nb_pieces_noir) <= 1, 'matériel');
    assert(candidate.nb_pieces_blanc + candidate.nb_pieces_noir <= 40, '40 pièces maximum');
    const lastWhite = [...replay.moves].reverse().find(m => m.side === 'w' && m.captured.length);
    assert(lastWhite, 'prise blanche');
    for (let i = 0; i < candidate.rafle_complete.length; i += 1) {
      assert.equal([lastWhite.from, ...lastWhite.path.slice(1)][i], candidate.rafle_complete[i]);
    }
    const root = generateLegalMoves(candidate.board, candidate.trait);
    if (root.some(m => m.captured.length)) {
      assert(replay.moves[0].captured.length, 'prise obligatoire ignorée');
      assert(root.every(m => m.from === replay.moves[0].from && m.to === replay.moves[0].to), 'prise concurrente');
    }
    accepted += 1;
  }
  assert.equal(accepted, count, `niveau ${level}: ${count} positions attendues`);
  stats[level] = { accepted, attempts, acceptance: +(accepted / attempts).toFixed(3), rejects };
}
checks.generation = stats;

// 5. Une rafle demandée est respectée, en direct ou par translation.
for (const request of ['25x', '38x27', '40x29x20', '31x22x11']) {
  const parsed = parseRouteInput(request);
  assert(parsed, `route invalide ${request}`);
  const models = findModels(db.entries, parsed);
  const pool = models.direct.concat(models.translated);
  assert(pool.length > 0, `aucun modèle pour ${request}`);
  let produced = 0;
  for (let i = 0; i < 12; i += 1) {
    const built = buildCandidate(pool[i % pool.length], { level: 2, request: parsed, rng: mulberry32(i + 1) });
    if (!built.ok) continue;
    assert(routeMatches(built.candidate.rafle_complete, parsed), `${request}: rafle ${built.candidate.rafle_complete}`);
    produced += 1;
  }
  assert(produced > 0, `${request}: aucune position`);
  checks.routes = { ...(checks.routes || {}), [request]: { models: pool.length, produced } };
}

// 6. Route impossible : refus explicite, aucune invention.
assert.equal(findModels(db.entries, parseRouteInput('2x9')).direct.length, 0);
const refused = buildCandidate(db.entries[0], { level: 2, request: parseRouteInput('2x9') });
assert.equal(refused.ok, false);
checks.impossibleRouteRefused = true;

// 7. Génération sans Scan : budget et statistiques cohérentes.
const start = Date.now();
const fakeSearch = async () => ({ infos: [{ score: 3, depth: 12, pv: ['x'] }], move: 'x' });
const generated = await generateVerified(db.entries, { level: 2, attempts: 5, search: fakeSearch, depth: 12, seed: 5 });
assert(generated.candidate || generated.reason);
checks.scanPipeline = { accepted: !!generated.candidate, stats: generated.stats, ms: Date.now() - start };

// 8. Filtres de l'interface : nombre de pièces et longueur de solution.
const filtered = db.entries.filter(e => e.nb_pieces_blanc + e.nb_pieces_noir <= 20 && e.solution.length >= 10);
checks.filters = { shortPositionsLongSolutions: filtered.length };

fs.writeFileSync('perf/combinaisons-tests.json', JSON.stringify({ date: new Date().toISOString(), checks, passed: true }, null, 2));
console.log(JSON.stringify(checks, null, 2));
console.log('Combinaisons : tous les contrôles locaux passent.');
