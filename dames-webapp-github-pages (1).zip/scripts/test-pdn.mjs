import assert from 'node:assert/strict';
import { extractMoveTokens, gameToPdn, moveMatchesPdn, moveToPdn, parseHeaders, parsePdnGames } from '../src/pdn.js';
import { createInitialBoard, generateLegalMoves, squareAtPosition } from '../src/game-rules.js';

// --- tokenizer: numbers, comments, variations, NAGs, annotations, results ---
const tokens = extractMoveTokens(`1. 32-28 {un commentaire} 17-22 2. 37-32 (!) 18-23
3. 33-28 $1 23x32x28 (2. ... 27-23 3. 28x19x28) 37x28 4. 12-18 *`);
assert.deepEqual(tokens, [
  '32-28', '17-22', '37-32', '18-23', '33-28', '23x32x28', '37x28', '12-18',
], `unexpected tokens: ${JSON.stringify(tokens)}`);

// result tokens are not moves
assert.deepEqual(extractMoveTokens('1. 32-28 17-22 1-0'), ['32-28', '17-22']);
assert.deepEqual(extractMoveTokens('1. 32-28 17-22 1/2-1/2'), ['32-28', '17-22']);

// --- headers ---
const headers = parseHeaders('[Event "Match"]\n[Site "Lyon"]\n[Result "1-0"]');
assert.deepEqual(headers, { Event: 'Match', Site: 'Lyon', Result: '1-0' });

// --- full document, several games ---
const games = parsePdnGames(`[Event "A"]
[White "B"]
[Black "N"]

1. 32-28 17-22 *

[Event "B"]
[White "X"]
[Black "Y"]
[Result "0-1"]

1. 32-28 17-22 2. 37-32 18-23 0-1
`);
assert.equal(games.length, 2);
assert.equal(games[0].headers.Event, 'A');
assert.equal(games[1].headers.Result, '0-1');
assert.equal(games[1].tokens.length, 4);

// --- matching against legal moves ---
const initial = createInitialBoard();
const opening = generateLegalMoves(initial, 'w');
assert.ok(opening.some(move => moveMatchesPdn(move, '32-28')));
const quiet = opening.find(move => moveMatchesPdn(move, '32-28'));
assert.equal(moveToPdn(quiet), '32-28');

// double capture: PDN lists every landing square
const captureBoard = Array(51).fill('e');
captureBoard[squareAtPosition(5, 2)] = 'w';
captureBoard[squareAtPosition(4, 3)] = 'b';
captureBoard[squareAtPosition(2, 5)] = 'b';
captureBoard[squareAtPosition(5, 6)] = 'w';
captureBoard[squareAtPosition(4, 7)] = 'b';
const captures = generateLegalMoves(captureBoard, 'w');
assert.ok(captures.length > 0 && captures.every(move => move.captured.length === 2));
const double = captures[0];
assert.equal(double.path.length, 3);
assert.equal(moveToPdn(double).split('x').length, 3, 'PDN capture lists every landing square');
assert.ok(moveMatchesPdn(double, moveToPdn(double)));

// --- serialization round trip ---
const pdnText = gameToPdn({
  headers: { Event: 'Test', White: 'A', Black: 'B', Result: '1-0' },
  moves: [
    { from: 32, to: 28, path: [32, 28], captured: [] },
    { from: 17, to: 22, path: [17, 22], captured: [] },
  ],
  result: '1-0',
});
assert.ok(pdnText.includes('[Event "Test"]'));
assert.ok(pdnText.includes('[Result "1-0"]'));
assert.ok(pdnText.includes('1. 32-28 17-22 1-0'));
const reparsed = parsePdnGames(pdnText);
assert.equal(reparsed.length, 1);
assert.deepEqual(reparsed[0].tokens, ['32-28', '17-22']);

console.log('PDN tests passed: tokenizer, headers, multi-game, matching and serialization.');
