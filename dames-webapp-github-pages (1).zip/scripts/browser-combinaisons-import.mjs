import fs from 'node:fs';
import { chromium } from 'playwright';

const BASE = process.env.COMB_BASE || 'http://localhost:4173/Dt/';
const DB = process.env.COMB_DB || 'public/combinations-app.json';
const browser = await chromium.launch();
// Service workers bloqués : sans cela, le cache hors ligne peut servir la base
// avant que la requête réseau simulée en échec n'arrive, et le repli n'est pas testé.
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, serviceWorkers: 'block' });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(String(error)));
// Simule un déploiement où le fichier JSON n'est pas accessible : repli IndexedDB + import.
await page.route('**/combinations-app.json', route => route.abort());
await page.goto(BASE, { waitUntil: 'domcontentloaded' });
await page.click('#menu-toggle');
await page.click('[data-page="combinaisons"]');
await page.waitForSelector('#cb-import:not([hidden])', { timeout: 30000 });
const report = {
  fallbackMessage: (await page.textContent('#cb-db')).trim(),
  errors,
};
await page.setInputFiles('#cb-file', DB);
await page.waitForFunction(() => /^Base importée/.test(document.querySelector('#cb-db')?.textContent || ''), { timeout: 60000 });
report.afterImport = (await page.textContent('#cb-db')).trim();
await page.unroute('**/combinations-app.json');
await page.selectOption('#cb-level', '1');
await page.selectOption('#cb-scan-depth', '0');
await page.fill('#cb-route', '27x');
await page.click('#cb-generate');
await page.waitForFunction(() => {
  const panel = document.querySelector('#cb-exercise');
  return panel && !panel.hidden && document.querySelector('#cb-exercise')?.dataset.solution;
}, { timeout: 30000 });
report.exercise = {
  meta: (await page.textContent('#cb-meta')).trim(),
  moves: (await page.evaluate(() => document.querySelector('#cb-exercise')?.dataset.solution || '')).split(' ').filter(Boolean),
};
// Persistance : rechargement, la base importée doit être retrouvée.
await page.reload({ waitUntil: 'domcontentloaded' });
await page.click('#menu-toggle');
await page.click('[data-page="combinaisons"]');
await page.waitForFunction(() => /^Base (importée|embarquée)/.test(document.querySelector('#cb-db')?.textContent || ''), { timeout: 30000 });
report.afterReload = (await page.textContent('#cb-db')).trim();
report.overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
fs.writeFileSync('perf/combinaisons/browser-import.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
await browser.close();
