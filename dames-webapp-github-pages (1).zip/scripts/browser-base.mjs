import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/* Parcours navigateur du module « Base de parties » dans l'application réelle :
   import PDN, explorateur, ouverture d'une partie, structures, recherche,
   export de la base et passerelles vers l'analyse et le jeu.
   Prérequis : `npm run build`, Playwright + Chromium, et un fichier PDN
   (variable PDN, sinon fixtures/base-echantillon-200.pdn). */
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = process.env.APP_DIST || path.join(root, 'dist');
const MIME = { '.html':'text/html; charset=utf-8', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.bin':'application/octet-stream', '.data':'application/octet-stream', '.wasm':'application/wasm' };
const CORPUS = process.env.PDN || path.join(root, 'fixtures/base-echantillon-200.pdn');
const SHOTS = process.env.SHOTS || '';
const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  let file = path.join(ROOT, url === '/' ? 'index.html' : url);
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('nope'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});
const PORT = Number(process.env.PORT) || 8799;
await new Promise(r => server.listen(PORT, '0.0.0.0', r));

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2 });
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
// test d'intégration : build de production de l'app + corpus PDN réel
await page.goto(`http://127.0.0.1:${PORT}/`);
await page.waitForTimeout(2500);
console.log('titre:', await page.title());

// ouvrir le tiroir puis la Base
await page.click('#menu-toggle');
await page.waitForTimeout(400);
const navItems = await page.$$eval('.nav-item', els => els.map(e => e.textContent.trim()));
console.log('menu:', navItems.join(' | '));
await page.click('.nav-item[data-page="base"]');
await page.waitForTimeout(1200);
console.log('onglets:', await page.$$eval('.pb-tab', els => els.map(e => e.textContent.trim()).join(' | ')));
await page.screenshot({ path: '/home/user/pionicide-app/dist/../shots-01-base.png' });

// import du PDN réel
await page.setInputFiles('#pb-file', CORPUS);
await page.waitForFunction(() => !document.querySelector('#pb-report').hidden, null, { timeout: 180000 });
await page.waitForTimeout(800);
const report = (await page.textContent('#pb-report')).replace(/\s+/g, ' ').trim();
console.log('RAPPORT:', report.slice(0, 220));
console.log('MESURES:', await page.textContent('#pb-m-games'), 'parties ·', await page.textContent('#pb-m-ms'), 'ms/partie ·', await page.textContent('#pb-m-rate'), 'parties/s ·', await page.textContent('#pb-m-index'), 'index ·', await page.textContent('#pb-m-store'), 'stockage');
if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-02-import.png` });

// explorateur
await page.click('.pb-tab[data-tab="explorer"]');
await page.waitForTimeout(1500);
const moves = await page.$$eval('#pb-explorer-moves .pb-row', els => els.map(e => e.textContent.replace(/\s+/g, ' ').trim()));
console.log('explorateur:', moves.length, 'coups:', moves.slice(0, 3).join(' / '));
await page.click('#pb-explorer-moves .pb-row');
await page.waitForTimeout(1200);
console.log('après coup:', await page.textContent('#pb-explorer-state'));
await page.waitForTimeout(1200);
const games = await page.$$eval('#pb-position-list .pb-row', els => els.length);
console.log('parties de la position:', games);
if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-03-explorateur.png` });

// ouvrir une partie
if (games) {
  await page.click('#pb-position-list .pb-open');
  await page.waitForTimeout(1500);
  console.log('contexte partie:', (await page.textContent('#pb-game-context')).replace(/\s+/g,' ').slice(0, 100));
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-04-partie.png` });
}

// structures : dessiner 3 cases puis rechercher
await page.click('.pb-tab[data-tab="structures"]');
await page.waitForTimeout(400);
for (const sq of [28, 29, 30]) await page.click(`#pb-board-structures .cell[data-square="${sq}"]`);
await page.waitForTimeout(300);
console.log('chaîne:', (await page.inputValue('#pb-st-line')).length, (await page.inputValue('#pb-st-line')).slice(24, 34));
await page.fill('#pb-st-name', 'Blocage 28-29-30');
await page.click('#pb-st-save');
await page.waitForTimeout(400);
console.log('structures enregistrées:', await page.$$eval('#pb-st-list .pb-row', e => e.length));
if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-05-structures.png` });

await page.click('#pb-st-search');
await page.waitForTimeout(3000);
console.log('recherche:', (await page.textContent('#pb-sr-status')).replace(/\s+/g,' '));
console.log('résultats:', await page.$$eval('#pb-sr-results .pb-row', e => e.length));
if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-06-recherche.png` });

// base
await page.click('.pb-tab[data-tab="base"]');
await page.waitForTimeout(1200);
console.log('BASE:', (await page.textContent('[data-view="base"] .pb-kv')).replace(/\s+/g,' ').slice(0, 200));
if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-07-base.png` });

// interop : jouer la position contre PIONICIDE
await page.click('.pb-tab[data-tab="explorer"]');
await page.waitForTimeout(1200);
await page.click('#pb-play-position');
await page.waitForTimeout(2000);
console.log('INTEROP jouer:', await page.title(), '| page visible:', await page.$eval('.game-options, .board-wrap', e => e.className).catch(() => 'n/a'));
if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-08-jouer.png` });

// retour à la base puis analyse d'une partie
await page.click('#menu-toggle');
await page.waitForTimeout(400);
await page.click('.nav-item[data-page="base"]');
await page.waitForTimeout(1500);
await page.click('.pb-tab[data-tab="explorer"]');
await page.waitForTimeout(1200);
const rows = await page.$$eval('#pb-position-list .pb-open', els => els.length);
if (rows) { await page.click('#pb-position-list .pb-open'); await page.waitForTimeout(1200); }
await page.click('#pb-analyse');
await page.waitForTimeout(2500);
console.log('INTEROP analyser:', await page.title());
if (SHOTS) await page.screenshot({ path: `${SHOTS}/base-09-analyser.png` });

console.log('ERREURS JS:', errors.length ? errors.join(' | ') : 'aucune');
await browser.close();
server.close();
