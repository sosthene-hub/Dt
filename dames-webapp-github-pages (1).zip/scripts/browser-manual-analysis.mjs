import assert from 'node:assert/strict';
import fs from 'node:fs';
import { chromium } from 'playwright';

const baseUrl = process.env.BASE_URL || 'http://127.0.0.1:5173/';

const GAME_PDN = `[Event "Championnat classique"]
[Site "Amsterdam"]
[Date "2026.11.08"]
[White "Blancs"]
[Black "Noirs"]
[Result "*"]

1. 33-28 18-23 2. 31-27 12-18 3. 39-33 7-12 4. 44-39 1-7
5. 49-44 20-24 6. 37-31 14-20 7. 41-37 10-14 8. 34-29 23x34
9. 40x29 20-25 10. 29x20 15x24 11. 27-22 18x27 12. 31x22 5-10
13. 44-40 10-15 14. 40-34 14-20 15. 45-40 16-21 16. 46-41 21-26
17. 36-31 17-21 18. 41-36 11-16 19. 31-27 12-18 20. 50-45 7-11
21. 37-31 26x37 22. 42x31 21-26 *`;

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 } });
const page = await context.newPage();
const errors = [];
page.on('pageerror', err => errors.push(err.message));
page.on('console', msg => { if (msg.type() === 'error') errors.push('console: ' + msg.text()); });

await page.goto(baseUrl);
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });

// Ouvrir Damier d'analyse
await page.click('#menu-toggle');
await page.click('[data-page="analyse"]');
await page.uncheck('#an-auto');
await page.waitForFunction(() => !document.querySelector('#an-status').textContent.includes('analyse'), null, { timeout: 20000 });

// Charger la partie PDN directement dans l'atelier d'analyse manuelle
await page.click('#man-import-toggle');
await page.fill('#man-import-text', GAME_PDN);
await page.click('#man-import-apply');

// Aller sur 19...12-18 dans l'aperçu interactif
await page.locator('#man-preview-card button.td-d0', { hasText: '12-18' }).nth(1).click();
assert.match(await page.locator('#man-node-label').textContent(), /19\.\.\.12-18/);

// Ajouter un symbole ? et un commentaire sur 19...12-18, plus un diagramme sur la ligne principale
await page.click('#man-symbols [data-sym="?"]');
await page.fill('#man-comment', 'Malheureusement les Noirs connaissaient l’idée mais pas les détails. C’est une grave erreur. Il fallait jouer :');
await page.click('#man-diagram-toggle');

// Cliquer sur « Autre coup à la place de 19...12-18? » et jouer 7-11 manuellement sur le damier !
await page.click('#man-alt-move');
await page.click('#analysis-board [data-square="7"]');
await page.click('#analysis-board [data-square="11"]');
assert.equal(await page.locator('#man-depth-badge').textContent(), 'Variante [ … ]');
assert.equal(await page.locator('#man-node-label').textContent(), '19...7-11');
await page.fill('#man-comment', 'Après');

// Continuer la variante sur le damier : 20.50-45 puis commentaire « peut suivre »
await page.click('#analysis-board [data-square="50"]');
await page.click('#analysis-board [data-square="45"]');
await page.fill('#man-comment', 'peut suivre');

// Suite de la variante : 20...24-30 21.35x24 19x30
await page.click('#analysis-board [data-square="24"]');
await page.click('#analysis-board [data-square="30"]');
await page.click('#analysis-board [data-square="35"]');
await page.click('#analysis-board [data-square="24"]');
await page.click('#analysis-board [data-square="19"]');
await page.click('#analysis-board [data-square="30"]');
await page.fill('#man-comment', 'et les Blancs sont très mal. Par exemple');
// Insérer aussi un diagramme DANS la variante !
await page.click('#man-diagram-toggle');
await page.fill('#man-diag-caption', 'Position critique de la variante 19...7-11');

// Revenir sur 20.50-45 dans la variante et créer une sous-variante ( … ) avec 20.34-29 12-18 !
await page.locator('#man-preview-card button.td-d1', { hasText: '20.50-45' }).click();
await page.click('#man-alt-move');
await page.click('#analysis-board [data-square="34"]');
await page.click('#analysis-board [data-square="29"]');
assert.equal(await page.locator('#man-depth-badge').textContent(), 'Sous-variante ( … )');
await page.fill('#man-pre-comment', 'La variante principale continue par');
await page.click('#analysis-board [data-square="12"]');
await page.click('#analysis-board [data-square="18"]');
await page.fill('#man-comment', 'et les Noirs ont le dernier mot');

// Commenter 20.50-45 de la ligne principale et ajouter une variante avec introduction avant le 1er coup
await page.locator('#man-preview-card button.td-d0', { hasText: '20.50-45' }).click();
await page.fill('#man-comment', 'Naturellement');
await page.click('#man-alt-move');
await page.click('#analysis-board [data-square="37"]');
await page.click('#analysis-board [data-square="31"]');
await page.fill('#man-pre-comment', 'Pendant la partie, Thomas s’est trompé avec');
await page.click('#analysis-board [data-square="26"]');
await page.click('#analysis-board [data-square="37"]');
await page.click('#analysis-board [data-square="42"]');
await page.click('#analysis-board [data-square="31"]');
await page.click('#analysis-board [data-square="18"]');
await page.click('#analysis-board [data-square="23"]');
await page.fill('#man-comment', 'et les Noirs ont repris l’initiative.');

// Vérifier zéro débordement horizontal sur mobile 412×915
const overflowMobile = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
assert.equal(overflowMobile, false, 'Aucun débordement horizontal sur mobile 412px');

await page.locator('#manual-workshop').scrollIntoViewIfNeeded();
await page.screenshot({ path: '/tmp/shot-workshop-mobile.png', fullPage: true });

// Ouvrir la feuille d'impression / PDF et contrôler les couleurs, la typographie et les 2 diagrammes SVG
await page.click('#man-print');
await page.waitForSelector('#print-sheet .manual-sheet-page');

const sheetCheck = await page.evaluate(() => {
  const d0 = document.querySelector('#print-sheet .td-d0');
  const d1 = document.querySelector('#print-sheet .td-d1');
  const d2 = document.querySelector('#print-sheet .td-d2');
  const svgs = document.querySelectorAll('#print-sheet svg.diagram-board');
  const cs0 = getComputedStyle(d0);
  const cs1 = getComputedStyle(d1);
  const cs2 = getComputedStyle(d2);
  return {
    d0Weight: cs0.fontWeight,
    d0Color: cs0.color,
    d1Color: cs1.color,
    d2Style: cs2.fontStyle,
    d2Color: cs2.color,
    svgCount: svgs.length,
    text: document.querySelector('#print-sheet .manual-sheet-body').innerText,
  };
});

assert.equal(sheetCheck.d0Weight, '700', 'Ligne principale en gras');
assert.equal(sheetCheck.d0Color, 'rgb(0, 0, 0)', 'Ligne principale en noir');
assert.equal(sheetCheck.d1Color, 'rgb(21, 120, 36)', 'Variante niveau 1 en vert');
assert.equal(sheetCheck.d2Style, 'italic', 'Sous-variante niveau 2 en italique');
assert.equal(sheetCheck.d2Color, 'rgb(16, 42, 131)', 'Sous-variante niveau 2 en bleu foncé');
assert.equal(sheetCheck.svgCount, 2, 'Les 2 diagrammes (ligne principale + variante) sont rendus en SVG');
assert.match(sheetCheck.text, /\[ 19\.\.\.7-11 Après 20\.50-45 peut suivre \( La variante principale continue par 20\.34-29 12-18 et les Noirs ont le dernier mot\) 20\.\.\.24-30 21\.35x24 19x30/);

await page.locator('#print-sheet .manual-sheet-page').screenshot({ path: '/tmp/shot-print-mobile.png' });

// Vue bureau 1000×1200 + mode 2 colonnes
await page.setViewportSize({ width: 1000, height: 1200 });
const selects = page.locator('#print-sheet .manual-sheet-toolbar select');
await selects.nth(0).selectOption('2');
await page.locator('#print-sheet .manual-sheet-page').screenshot({ path: '/tmp/shot-print-2col.png' });

assert.deepEqual(errors, [], `Erreurs console/page: ${JSON.stringify(errors)}`);
await browser.close();
console.log('OK — Parcours navigateur complet (variantes, sous-variantes, commentaires, diagrammes et impression PDF) validé.');
