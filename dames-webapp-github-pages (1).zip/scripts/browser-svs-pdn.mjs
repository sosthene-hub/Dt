// Bouton PDN du match moteur contre moteur : export pendant la partie, après
// l'arrêt, après une partie terminée, relecture du fichier produit, passage
// direct à l'étude et secours « Afficher / copier ».
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { parsePdnGames, replayPdnGame } from '../src/pdn.js';

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080/';
const OUT = 'perf/svs-pdn';
fs.mkdirSync(OUT, { recursive: true });

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1180, height: 950 }, acceptDownloads: true, serviceWorkers: 'block' });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });
const report = { base: BASE, steps: [], errors };
const step = (name, detail = {}) => { report.steps.push({ name, ...detail }); console.log('·', name, JSON.stringify(detail)); };

await page.goto(BASE, { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 90000 });
await page.evaluate(() => document.querySelector('#menu-toggle').click());
await page.click('[data-page="scan-vs-scan"]');
await page.waitForTimeout(150);

const heading = (await page.textContent('.section-heading h1')).trim();
assert.equal(heading, 'PIONICIDE contre PIONICIDE');
assert.equal(await page.evaluate(() => document.body.innerText.includes('Scan')), false);
step('écran renommé', { titre: heading });

// Profondeurs minimales pour un match rapide.
await page.selectOption('#svs-a-depth', '2');
await page.selectOption('#svs-b-depth', '2');
await page.selectOption('#svs-a-time', '200');
await page.selectOption('#svs-b-time', '200');
await page.selectOption('#svs-games', '1');
await page.fill('#svs-speed', '0');
await page.dispatchEvent('#svs-speed', 'input');

assert.equal(await page.isDisabled('#svs-pdn'), true, 'aucun PDN avant le premier coup');
assert.equal(await page.isDisabled('#svs-pdn-current'), true);

await page.click('#svs-start-btn');
await page.waitForFunction(() => document.querySelectorAll('#svs-moves button').length >= 6, null, { timeout: 120000 });
const pliesMid = await page.$$eval('#svs-moves button', nodes => nodes.length);
step('partie lancée', { demiCoups: pliesMid });

// 1. PDN de la partie en cours, sans attendre la fin.
assert.equal(await page.isEnabled('#svs-pdn-current'), true);
assert.equal(await page.isEnabled('#svs-pdn'), true);
const [currentDownload] = await Promise.all([page.waitForEvent('download'), page.click('#svs-pdn-current')]);
const currentPath = path.resolve(OUT, 'partie-en-cours.pdn');
await currentDownload.saveAs(currentPath);
const currentText = fs.readFileSync(currentPath, 'utf8');
const currentGames = parsePdnGames(currentText);
assert.equal(currentGames.length, 1);
const currentReplay = replayPdnGame(currentGames[0]);
assert.equal(currentReplay.problem, null, 'le PDN de la partie en cours doit être entièrement légal');
assert.ok(currentReplay.moves.length >= 6);
assert.equal(currentGames[0].result, '*');
assert.match(currentGames[0].headers.Event, /PIONICIDE contre PIONICIDE/);
assert.match(currentGames[0].headers.White, /PIONICIDE A · profondeur 2/);
assert.match(currentGames[0].headers.Black, /PIONICIDE B · profondeur 2/);
step('PDN de la partie en cours', {
  demiCoups: currentReplay.moves.length,
  resultat: currentGames[0].result,
  blancs: currentGames[0].headers.White,
  noirs: currentGames[0].headers.Black,
});

// 2. Archive : une ligne « en cours » avec ses boutons.
const archive = await page.$$eval('.svs-archive-row', rows => rows.map(row => ({
  label: row.querySelector('b')?.textContent?.trim(),
  detail: row.querySelector('span')?.textContent?.trim(),
  buttons: [...row.querySelectorAll('button')].map(button => button.textContent.trim()),
})));
assert.ok(archive.length >= 1);
assert.match(archive[0].label, /en cours/);
assert.deepEqual(archive[0].buttons, ['⤓ PDN', 'Étudier']);
step('archive pendant la partie', archive[0]);

// 3. Arrêt en cours de partie : le PDN reste disponible.
await page.click('#svs-stop');
await page.waitForTimeout(300);
const afterStop = await page.evaluate(() => ({
  status: document.querySelector('#svs-status').textContent.trim(),
  current: !document.querySelector('#svs-pdn-current').disabled,
  all: !document.querySelector('#svs-pdn').disabled,
  rows: document.querySelectorAll('.svs-archive-row').length,
}));
// La partie arrêtée est archivée : c'est l’archive qui porte désormais son PDN.
assert.equal(afterStop.current, false);
assert.equal(afterStop.all, true);
assert.match(afterStop.status, /rejoint l’archive/);
assert.equal(afterStop.rows, 1, 'la partie arrêtée n’est plus affichée comme « en cours »');
step('arrêt en cours de partie', afterStop);

// 4. Étudier : la partie s'ouvre dans le damier d'analyse.
await page.click('.svs-archive-row .replay-toolbar button:nth-child(2)');
await page.waitForFunction(() => document.querySelectorAll('#played-moves button').length > 3, null, { timeout: 30000 });
const study = await page.evaluate(() => ({
  title: document.querySelector('#played-title')?.textContent?.trim(),
  plies: document.querySelectorAll('#played-moves button').length - 1,
  screen: document.querySelector('.section-heading h1')?.textContent?.trim(),
}));
assert.equal(study.screen, 'Damier d’analyse');
assert.ok(study.plies >= 5);
assert.match(study.title, /PIONICIDE|Étudier/);
step('passage à l’étude', study);

// 5. Retour au match : on relance une partie et on la laisse finir.
await page.evaluate(() => document.querySelector('#menu-toggle').click());
await page.click('[data-page="scan-vs-scan"]');
await page.waitForTimeout(200);
await page.click('#svs-start-btn');
await page.waitForFunction(() => /Terminé/.test(document.querySelector('#svs-turn')?.textContent || ''), null, { timeout: 300000 });
const finished = await page.evaluate(() => ({
  turn: document.querySelector('#svs-turn').textContent.trim(),
  status: document.querySelector('#svs-status').textContent.trim(),
  rows: [...document.querySelectorAll('.svs-archive-row')].map(row => row.querySelector('b')?.textContent?.trim()),
}));
step('partie terminée', finished);
assert.ok(finished.rows.some(label => /Partie \d+ · /.test(label)), 'une partie terminée doit apparaître dans l’archive');
assert.ok(finished.rows.some(label => /Partie \d+ · \*/.test(label)), 'la partie arrêtée doit rester archivée');

// 6. PDN de toutes les parties : chaque partie doit être relisible.
const [allDownload] = await Promise.all([page.waitForEvent('download'), page.click('#svs-pdn')]);
const allPath = path.resolve(OUT, 'toutes-les-parties.pdn');
await allDownload.saveAs(allPath);
const allText = fs.readFileSync(allPath, 'utf8');
assert.ok(allText.length > 200);
const games = parsePdnGames(allText);
assert.ok(games.length >= 2, `parties attendues : au moins 2, trouvées ${games.length}`);
const details = games.map(game => {
  const replay = replayPdnGame(game);
  assert.equal(replay.problem, null, `PDN illégal dans « ${game.headers.Event} » : ${JSON.stringify(replay.problem)}`);
  assert.match(game.headers.Event, /PIONICIDE contre PIONICIDE/);
  return { resultat: game.headers.Result, demiCoups: replay.moves.length, terminaison: game.headers.Termination };
});
step('PDN de toutes les parties', { parties: games.length, details });
assert.ok(details.every(item => ['1-0', '0-1', '1/2-1/2', '*'].includes(item.resultat)));
assert.ok(details.filter(item => item.resultat !== '*').length >= 1, 'au moins une partie terminée attendue');
assert.ok(details.some(item => item.resultat === '*'), 'la partie arrêtée est conservée avec le résultat « * »');

// 7. Secours : texte affichable et copiable (Android, aperçus intégrés).
await page.click('#svs-pdn-show');
await page.waitForSelector('#svs-pdn-text:not([hidden])', { timeout: 5000 });
const shown = await page.evaluate(() => ({
  value: document.querySelector('#svs-pdn-text').value,
  actions: !document.querySelector('#svs-pdn-actions').hidden,
}));
assert.equal(shown.value, allText);
assert.equal(shown.actions, true);
step('affichage du PDN', { octets: shown.value.length });

// 8. Mobile.
await page.setViewportSize({ width: 412, height: 915 });
await page.waitForTimeout(250);
const mobile = await page.evaluate(() => ({
  scroll: document.documentElement.scrollWidth,
  client: document.documentElement.clientWidth,
  panel: document.querySelector('.svs-pdn-panel')?.getBoundingClientRect().width,
}));
step('mobile 412×915', mobile);
assert.ok(mobile.scroll <= mobile.client + 1);

fs.writeFileSync(path.resolve(OUT, 'rapport.json'), JSON.stringify(report, null, 2));
assert.deepEqual(errors, [], `erreurs JavaScript : ${errors.join(' | ')}`);
await browser.close();
console.log('PDN moteur contre moteur :', report.steps.length, 'étapes, aucune erreur JavaScript.');
