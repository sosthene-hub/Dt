import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/* Parcours navigateur de l'écran « Partie commentée » dans l'application réelle :
   import d'une base de parties, ouverture d'une partie depuis la base, étude
   (base + moteur), vérification du document et impression en PDF.
   Prérequis : `npm run build`, Playwright + Chromium.
   Variables : PDN (corpus, sinon fixtures/base-echantillon-200.pdn), DEPTH, MS,
   SHOTS (dossier de captures), PORT. */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = process.env.APP_DIST || path.join(root, 'dist');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.bin': 'application/octet-stream', '.data': 'application/octet-stream', '.wasm': 'application/wasm' };
const CORPUS = process.env.PDN || path.join(root, 'fixtures/base-echantillon-200.pdn');
const SHOTS = process.env.SHOTS || '';
const DEPTH = process.env.DEPTH || '10';
const MS = process.env.MS || '600';

const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  const file = path.join(ROOT, url === '/' ? 'index.html' : url);
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('nope'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});
const PORT = Number(process.env.PORT) || 8801;
await new Promise(resolve => server.listen(PORT, '0.0.0.0', resolve));

let failures = 0;
const check = (label, condition, detail = '') => {
  if (!condition) failures += 1;
  console.log((condition ? '· OK   ' : '· ÉCHEC') + ' ' + label + (detail ? ' — ' + detail : ''));
};

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 1000 }, acceptDownloads: true });
const page = await context.newPage();
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });

await page.goto(`http://127.0.0.1:${PORT}/`);
await page.waitForTimeout(2000);

/* ---- 1. importer une base de parties ---- */
await page.click('#menu-toggle');
await page.waitForTimeout(300);
await page.click('.nav-item[data-page="base"]');
await page.waitForTimeout(1000);
await page.setInputFiles('#pb-file', CORPUS);
await page.waitForFunction(() => !document.querySelector('#pb-report').hidden, null, { timeout: 240000 });
await page.waitForTimeout(800);
console.log('base importée :', (await page.textContent('#pb-report')).replace(/\s+/g, ' ').slice(0, 140));

/* ---- 2. ouvrir une partie de la base et l'envoyer à l'étude ---- */
await page.click('.pb-tab[data-tab="explorer"]');
await page.waitForTimeout(1500);
await page.waitForSelector('#pb-position-list .pb-open', { timeout: 30000 });
check('liste des parties de la position disponible', true);
await page.click('#pb-position-list .pb-open');
await page.waitForTimeout(1500);
check('partie ouverte dans l’explorateur', !(await page.isDisabled('#pb-analyse')));
await page.click('#pb-study');
await page.waitForTimeout(1500);
check('l’écran Partie commentée est ouvert', await page.isVisible('#st-run'));
const source = (await page.textContent('#st-source')).replace(/\s+/g, ' ').trim();
check('partie reçue depuis la base', /partie|demi-coups/i.test(source), source.slice(0, 90));

/* ---- 3. lancer l'étude ---- */
await page.selectOption('#st-depth', DEPTH);
await page.selectOption('#st-time', MS);
await page.selectOption('#st-max', '8');
await page.click('#st-run');
check('progression visible', await page.isVisible('#st-progress'));
const started = Date.now();
await page.waitForFunction(() => !document.querySelector('#st-doc').disabled, null, { timeout: 600000 });
console.log('étude terminée en', ((Date.now() - started) / 1000).toFixed(1), 's');
const status = (await page.textContent('#st-status')).replace(/\s+/g, ' ').trim();
console.log('statut :', status);
check('statut final cohérent', /terminée/i.test(status), status.slice(0, 120));

/* ---- 4. contenu des résultats ---- */
await page.waitForTimeout(600);
const summaryLines = await page.$$eval('#st-summary li', els => els.map(e => e.textContent.trim()));
check('résumé chiffré présent', summaryLines.length >= 3, summaryLines.length + ' lignes');
const moments = await page.$$eval('.study-moment', els => els.map(e => e.textContent.replace(/\s+/g, ' ').trim()));
check('moments commentés', moments.length > 0, moments.length + ' moments');
check('chaque moment porte ses deux sources',
  moments.every(text => /BASE/.test(text) && /MOTEUR/.test(text)));
check('aucune valeur technique dans le texte',
  !moments.some(text => /undefined|NaN|\[object/.test(text)));
if (moments.length) console.log('exemple :', moments[0].slice(0, 240));
if (SHOTS) await page.screenshot({ path: `${SHOTS}/etude-01-resultats.png`, fullPage: true });

/* ---- 5. document imprimable ---- */
await page.click('#st-doc');
await page.waitForSelector('#study-sheet', { timeout: 15000 });
await page.waitForTimeout(1200);
const doc = await page.evaluate(() => {
  const sheet = document.querySelector('#study-sheet');
  const text = sheet ? sheet.innerText : '';
  return {
    text: text.replace(/\s+/g, ' ').trim(),
    chapters: sheet.querySelectorAll('.study-chapter').length,
    entries: sheet.querySelectorAll('.study-entry').length,
    diagrams: sheet.querySelectorAll('.study-diagram svg').length,
    captions: [...sheet.querySelectorAll('.study-diagram figcaption')].map(e => e.textContent.trim()),
    refs: sheet.querySelectorAll('.study-refs li').length,
    rows: sheet.querySelectorAll('.study-table tr').length,
    toc: sheet.querySelectorAll('.study-toc-entry').length,
    sources: sheet.querySelectorAll('.study-source-tag').length,
  };
});
check('document : chapitres', doc.chapters >= 2, doc.chapters + ' chapitres');
check('document : diagrammes numérotés', doc.diagrams === doc.entries, `${doc.diagrams} diagrammes / ${doc.entries} entrées`);
check('document : légendes « Diagramme n »', doc.captions.every(c => /^Diagramme \d+/.test(c)),
  doc.captions.slice(0, 2).join(' | '));
check('document : sommaire aligné sur les entrées', doc.toc === doc.entries, `${doc.toc} entrées au sommaire`);
check('document : blocs de sources', doc.sources >= doc.entries * 2, doc.sources + ' étiquettes');
check('document : tableau complet', doc.rows > 5, doc.rows + ' lignes');
check('document : aucun artefact', !/undefined|NaN|\[object/.test(doc.text));
check('document : méthode présente', /comment lire ce document/i.test(doc.text));
check('document : sources citées', /Base de parties/.test(doc.text) && /Moteur PIONICIDE/.test(doc.text));
console.log('document :', doc.chapters, 'chapitres ·', doc.entries, 'moments ·', doc.diagrams, 'diagrammes ·',
  doc.refs, 'parties de référence ·', doc.rows, 'lignes de tableau');
if (SHOTS) await page.screenshot({ path: `${SHOTS}/etude-02-document.png` });

/* ---- 6. impression PDF ---- */
await page.emulateMedia({ media: 'print' });
await page.waitForTimeout(400);
const pdfPath = path.join(root, 'dist', 'etude-test.pdf');
await page.pdf({ path: pdfPath, format: 'A4', printBackground: true, margin: { top: '12mm', bottom: '12mm', left: '12mm', right: '12mm' } });
const pdfSize = fs.statSync(pdfPath).size;
check('PDF produit', pdfSize > 20000, Math.round(pdfSize / 1024) + ' Ko');
const pdfHead = fs.readFileSync(pdfPath).subarray(0, 5).toString();
check('en-tête PDF valide', pdfHead === '%PDF-');
await page.emulateMedia({ media: 'screen' });

/* ---- 7. second parcours : PDN collé ---- */
await page.click('#study-sheet .secondary-button');
await page.waitForTimeout(400);
await page.click('#st-clear');
await page.waitForTimeout(300);
await page.click('#st-paste-toggle');
const pdn = fs.readFileSync(path.join(root, 'fixtures/Verpoest-Berte-1980.pdn'), 'utf8');
await page.fill('#st-text', pdn);
await page.click('#st-load-text');
await page.waitForTimeout(1200);
const source2 = (await page.textContent('#st-source')).replace(/\s+/g, ' ').trim();
check('PDN collé chargé', /Verpoest/i.test(source2), source2.slice(0, 90));
await page.click('#st-run');
await page.waitForFunction(() => !document.querySelector('#st-doc').disabled, null, { timeout: 900000 });
const status2 = (await page.textContent('#st-status')).replace(/\s+/g, ' ').trim();
check('étude d’un PDN extérieur terminée', /terminée/i.test(status2), status2.slice(0, 120));
await page.click('#st-doc');
await page.waitForSelector('#study-sheet', { timeout: 15000 });
await page.waitForTimeout(800);
const outside = await page.evaluate(() => document.querySelector('#study-sheet').innerText.replace(/\s+/g, ' '));
check('hors base : le document le dit', /absente de la base|indisponible|muette|quitte la base|ne se prononce pas|jamais été atteinte/i.test(outside),
  outside.match(/Résumé de l’étude[^]{0,200}/)?.[0] || outside.slice(0, 200));
check('hors base : aucun artefact', !/undefined|NaN/.test(outside));
if (SHOTS) await page.screenshot({ path: `${SHOTS}/etude-03-hors-base.png` });

/* ---- 8. le bouton d'entrée existe sur le jeu et le damier ---- */
await page.click('#study-sheet .secondary-button');
await page.waitForTimeout(300);
await page.goto(`http://127.0.0.1:${PORT}/#jouer`);
await page.waitForTimeout(1500);
check('bouton « Étudier et commenter » dans la partie', await page.isVisible('#game-study'));

const fatal = errors.filter(text => !/favicon|manifest|ServiceWorker|sw\.js/i.test(text));
check('aucune erreur JavaScript', fatal.length === 0, fatal.slice(0, 2).join(' | '));

await browser.close();
server.close();
console.log(failures ? `\nPartie commentée (navigateur) : ${failures} échec(s).` : '\nPartie commentée (navigateur) : tous les tests passent.');
process.exit(failures ? 1 : 0);
