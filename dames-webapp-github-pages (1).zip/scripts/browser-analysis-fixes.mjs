/**
 * Vérifie les trois corrections demandées sur le téléphone :
 *   1. « Coup conseillé » affiche réellement une flèche sur le damier et un bandeau durable ;
 *   2. l'analyse automatique se lance seule et produit le texte commenté de référence
 *      (« 6. 30-24? Inaccuracy. Best move was 46-41. » + variante « ⌐ … ») et s'imprime ;
 *   3. les six panneaux (Réglages, Position, Coups, Mauvais coups, Analyse, Outils) sont
 *      tous visibles et leur contenu s'affiche entièrement, quelle que soit sa longueur.
 *
 * L'analyse manuelle n'est pas concernée : aucun de ces contrôles ne la modifie.
 */
import assert from 'node:assert/strict';
import { chromium } from 'playwright';

const BASE = process.env.BASE_URL || 'http://127.0.0.1:5173/';
const SHOTS = process.env.SHOTS || '/tmp/qa2';

// Partie courte contenant deux fautes réelles (produit ?! / ? selon l'évaluation).
const GAME_WITH_FAULTS = `[Event "Contrôle des trois corrections"]
[White "Blancs"]
[Black "Noirs"]
[Result "*"]

1. 32-28 19-23 2. 28x19 14x23 3. 37-32 10-14 4. 41-37 14-19
5. 34-30 20-25 6. 30-24 19x30 7. 35x24 17-21 *`;

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2 });
const page = await context.newPage();
const errors = [];
page.on('pageerror', err => errors.push('pageerror: ' + err.message));
page.on('console', msg => { if (msg.type() === 'error') errors.push('console: ' + msg.text()); });

await page.goto(BASE, { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });
await page.click('#menu-toggle');
await page.click('[data-page="analyse"]');
await page.waitForTimeout(900);

/* ---------- 1. Coup conseillé : flèche visible + bandeau durable ---------- */
await page.click('#an-bar-hint');
await page.waitForFunction(() => (document.querySelector('#an-board-status')?.textContent || '').includes('Coup conseillé :') && !document.querySelector('#an-board-status')?.textContent.includes('réfléchit'), null, { timeout: 90000 });
const hint = await page.evaluate(() => {
  const arrows = document.querySelectorAll('#analysis-board svg.threat-arrows polyline');
  const banner = document.querySelector('#an-board-status');
  const rect = banner.getBoundingClientRect();
  const bar = document.querySelector('.an-bottombar').getBoundingClientRect();
  return {
    arrows: arrows.length,
    stroke: arrows[0]?.getAttribute('stroke'),
    text: banner.textContent.trim(),
    visible: !banner.hidden && rect.height > 0,
    aboveBottomBar: rect.bottom <= bar.top + 1,
  };
});
assert.ok(hint.arrows >= 1, 'Le coup conseillé trace une flèche sur le damier');
assert.equal(hint.text.includes('réfléchit'), false, 'Le bandeau affiche le résultat, pas l’attente');
assert.match(hint.text, /Coup conseillé : \d{1,2}(x|-)\d{1,2}/, 'Le bandeau nomme le coup conseillé');
assert.equal(hint.visible, true, 'Le bandeau reste affiché après le calcul');
assert.equal(hint.aboveBottomBar, true, 'Le bandeau ne passe pas sous la barre du bas');
await page.screenshot({ path: `${SHOTS}/fix1-coup-conseille.png` });
// La flèche disparaît quand on change de position.
await page.click('#analysis-board [data-square="34"]');
await page.click('#analysis-board [data-square="30"]');
await page.waitForTimeout(400);
assert.equal(await page.locator('#analysis-board svg.threat-arrows polyline').count(), 0, 'La flèche de conseil est retirée après un coup');

/* ---------- 3. Les six panneaux sont tous accessibles et lisibles ---------- */
await page.click('#an-bar-analyse');
await page.waitForTimeout(500);
const tabs = await page.evaluate(() => [...document.querySelectorAll('.an-tab')].map(tab => {
  const rect = tab.getBoundingClientRect();
  const strip = document.querySelector('#an-tabs').getBoundingClientRect();
  return {
    label: tab.textContent.trim(),
    height: Math.round(rect.height),
    insideStrip: rect.top >= strip.top - 1 && rect.bottom <= strip.bottom + 1,
    visible: getComputedStyle(tab).visibility === 'visible' && getComputedStyle(tab).display !== 'none',
  };
}));
assert.deepEqual(tabs.map(tab => tab.label), ['Réglages', 'Position', 'Coups', 'Mauvais coups', 'Analyse', 'Outils']);
for (const tab of tabs) {
  assert.equal(tab.visible, true, `Onglet « ${tab.label} » visible`);
  assert.equal(tab.insideStrip, true, `Onglet « ${tab.label} » entièrement dans la barre d’onglets (non coupé)`);
  assert.ok(tab.height >= 44, `Onglet « ${tab.label} » ≥ 44 px`);
}

const geometry = [];
for (const id of ['reglages', 'position', 'coups', 'pieges', 'analyse', 'outils']) {
  await page.click(`#an-tab-${id}`);
  await page.waitForTimeout(350);
  const state = await page.evaluate(() => {
    const sheet = document.querySelector('#an-sheet').getBoundingClientRect();
    const strip = document.querySelector('#an-tabs').getBoundingClientRect();
    const body = document.querySelector('.an-sheet-body');
    const bodyRect = body.getBoundingClientRect();
    const panel = document.querySelector('.an-sheet-panel.is-active');
    const first = panel?.firstElementChild;
    const firstRect = first?.getBoundingClientRect();
    return {
      sheetHeight: Math.round(sheet.height),
      panel: panel?.dataset.panel,
      contentBelowTabs: firstRect ? firstRect.top >= strip.bottom - 1 : false,
      contentTop: firstRect ? Math.round(firstRect.top) : null,
      bodyTop: Math.round(bodyRect.top),
      bodyHeight: Math.round(bodyRect.height),
      scrollable: body.scrollHeight >= body.clientHeight,
      hasContent: (panel?.textContent || '').trim().length > 20,
    };
  });
  geometry.push({ id, ...state });
  assert.equal(state.panel, id, `Panneau « ${id} » actif`);
  assert.equal(state.hasContent, true, `Panneau « ${id} » contient bien ses options`);
  assert.equal(state.contentBelowTabs, true, `Le contenu de « ${id} » commence sous les onglets`);
  assert.ok(state.bodyHeight >= 500, `Le panneau « ${id} » dispose d’une hauteur utile (${state.bodyHeight} px)`);
  await page.screenshot({ path: `${SHOTS}/fix3-panneau-${id}.png` });
}
// Hauteur constante : plus de tiroir qui se ratatine d'un onglet à l'autre.
const heights = new Set(geometry.map(item => item.sheetHeight));
assert.equal(heights.size, 1, `Hauteur du tiroir constante entre les panneaux (${[...heights].join(', ')})`);

/* ---------- 2. Analyse automatique + texte commenté de référence + impression ---------- */
await page.click('#an-tab-analyse');
await page.waitForTimeout(300);
await page.click('#man-import-toggle');
await page.fill('#man-import-text', GAME_WITH_FAULTS);
await page.click('#man-import-apply');

// Aucun clic sur « Analyser et annoter » : l'analyse doit partir seule.
await page.waitForFunction(() => /coups évalués|Passage unique/.test(document.querySelector('#an-annot-status')?.textContent || ''), null, { timeout: 240000 });
const annotated = await page.textContent('#an-annot-status');
assert.match(annotated, /\d+ coups évalués|Passage unique/, 'L’analyse automatique a bien tourné sans clic');

const commentary = await page.evaluate(() => {
  const host = document.querySelector('#an-commentary-preview');
  return {
    hidden: host.hidden,
    text: host.innerText,
    variations: host.querySelectorAll('.an-commentary-var').length,
    faults: host.querySelectorAll('.ac-error, .ac-inaccuracy, .ac-blunder').length,
  };
});
assert.equal(commentary.hidden, false, 'Le texte commenté est affiché dans le panneau Analyse');
assert.match(commentary.text, /Inaccuracy\. Best move was \d{1,2}(x|-)\d{1,2}\.?/, 'Phrase de verdict conforme à la référence');
assert.match(commentary.text, /⌐/, 'La variante conseillée est accrochée sous le coup fautif');
assert.ok(commentary.faults >= 1, 'Les coups fautifs sont colorés');
assert.ok(commentary.variations >= 1, 'Au moins une variante est proposée');
await page.screenshot({ path: `${SHOTS}/fix2-texte-commente.png` });

// Impression / PDF de l'analyse AUTOMATIQUE (bouton « Imprimer / PDF » de l'export).
await page.click('#an-print');
await page.waitForSelector('#print-sheet', { timeout: 20000 });
const sheetText = await page.evaluate(() => document.querySelector('#sheet-commentary')?.innerText || '');
assert.match(sheetText, /PARTIE COMMENTÉE AUTOMATIQUEMENT/);
assert.match(sheetText, /Inaccuracy\. Best move was/);
assert.ok(await page.locator('#print-sheet .an-commentary-var').count() >= 1, 'La feuille imprimée reprend les variantes');
assert.ok(await page.locator('#print-sheet .note-body').count() >= 1, 'Les fiches détaillées par erreur restent présentes (rien n’a été retiré)');
await page.locator('#print-sheet .sheet-page').screenshot({ path: `${SHOTS}/fix2-impression.png` });
assert.equal(await page.locator('#an-export-pdn').isEnabled(), true, 'L’export PDN annoté est disponible sans clic préalable');
await page.locator('#print-sheet').getByRole('button', { name: /Fermer/ }).first().click();

/* ---------- L'analyse manuelle reste intacte ---------- */
await page.waitForTimeout(300);
assert.equal(await page.locator('#manual-workshop').count(), 1, 'L’atelier d’analyse manuelle est toujours présent');
assert.equal(await page.locator('#man-print').isVisible(), true, 'Le bouton d’impression de l’analyse manuelle reste accessible');

assert.deepEqual(errors, [], `Erreurs console/page : ${JSON.stringify(errors.slice(0, 5))}`);
await browser.close();
console.log('OK — Coup conseillé visible, analyse automatique au format de référence avec impression, six panneaux lisibles, analyse manuelle intacte.');
