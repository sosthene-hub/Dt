import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';const autonomeUrl=process.env.BASE_URL||pathToFileURL(new URL('../Dames-autonome.html',import.meta.url).pathname).href;

const FILE = process.env.FILE || '/home/user/project/Dames-autonome.html';
const HAS_DB = true;
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 412, height: 915 } });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
await page.goto('file://' + path.resolve(FILE));
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), { timeout: 45000 });
await page.click('#menu-toggle');
await page.click('[data-page="combinaisons"]');
const report = { file: path.basename(FILE), errors, exercises: [], overflow: false, persistence: false };
if (HAS_DB) {
  await page.waitForFunction(() => /^Base embarquée/.test(document.querySelector('#cb-db')?.textContent || ''), { timeout: 30000 });
  let count = 0;
  for (const route of ['25x', '31x', '38x', '40x', '31x22x11']) {
    await page.selectOption('#cb-level', '1');
    await page.selectOption('#cb-scan-depth', '0');
    await page.fill('#cb-route', route);
    const before = await page.evaluate(() => document.querySelector('#cb-exercise')?.dataset.exid || '0');
    await page.click('#cb-generate');
    await page.waitForFunction(prev => {
      const panel = document.querySelector('#cb-exercise');
      return panel && !panel.hidden && panel.dataset.exid !== prev;
    }, before, { timeout: 30000 });
    const meta = (await page.textContent('#cb-meta')).trim();
    const moves = (await page.evaluate(() => document.querySelector('#cb-exercise')?.dataset.solution || '')).split(' ').filter(Boolean);
    if (!moves.length) throw Error('solution vide');
    if (!/rafle/.test(meta)) throw Error('rafle absente du panneau');
    const pieces = await page.$$eval('#cb-board .piece', nodes => nodes.length);
    report.exercises.push({ route, meta: meta.slice(0, 120), moves: moves.length, pieces });
    count += 1;
  }
  if (count !== 5) throw Error('cinq exercices attendus');
  // Persistance des réglages après rechargement.
  await page.fill('#cb-route', '38x27');
  await page.reload();
  await page.click('#menu-toggle');
  await page.click('[data-page="combinaisons"]');
  await page.waitForFunction(() => /^Base embarquée/.test(document.querySelector('#cb-db')?.textContent || ''), { timeout: 30000 });
  report.persistence = (await page.inputValue('#cb-route')) === '38x27';
  if (!report.persistence) throw Error('réglage de rafle non mémorisé');
} else {
  report.publicNotice = (await page.textContent('#cb-db')).trim();
}
report.overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
await page.screenshot({ path: '/home/user/browser-check-combinaisons.png', fullPage: false });
if (errors.length) throw Error(errors.join('\n'));
fs.writeFileSync('browser-test-results.json', JSON.stringify({ ...report, mode: 'file:// autonome, Chromium, 412×915' }, null, 2));
console.log(JSON.stringify(report, null, 2));
await browser.close();
