import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/* Contrôle navigateur de l'installation (Phase 6) : manifeste, icônes, service
   worker, invitation à installer, liens directs #page et rechargement hors ligne.
   Prérequis : `npm run build` puis Playwright + Chromium (voir README). */
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = process.env.APP_DIST || path.join(root, 'dist');
const SHOTS = process.env.SHOTS || '';
const MIME = { '.html':'text/html; charset=utf-8', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.webmanifest':'application/manifest+json', '.png':'image/png', '.bin':'application/octet-stream', '.data':'application/octet-stream', '.wasm':'application/wasm' };
const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  const file = path.join(ROOT, url === '/' ? 'index.html' : url);
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('absent'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});
const PORT = Number(process.env.PORT) || 8803;
await new Promise(r => server.listen(PORT, '0.0.0.0', r));

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2 });
const page = await context.newPage();
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
await page.goto(`http://127.0.0.1:${PORT}/`);
await page.waitForTimeout(3000);

// 1. manifeste lisible et complet
const manifestInfo = await page.evaluate(async () => {
  const href = document.querySelector('link[rel=manifest]')?.href;
  const data = await (await fetch(href)).json();
  const icons = [];
  for (const icon of data.icons) {
    const response = await fetch(new URL(icon.src, href));
    icons.push({ src: icon.src, status: response.status, type: response.headers.get('content-type'), size: (await response.arrayBuffer()).byteLength });
  }
  return { href, name: data.name, short: data.short_name, display: data.display, lang: data.lang, start: data.start_url, icons, shortcuts: (data.shortcuts || []).length };
});
console.log('manifeste :', JSON.stringify({ ...manifestInfo, href: 'servi' }));

// 2. icônes affichées dans le navigateur (décodage réel)
const iconOk = await page.evaluate(async () => {
  const src = document.querySelector('link[rel=apple-touch-icon]').href;
  const image = new Image();
  image.src = src;
  await image.decode();
  return image.naturalWidth + 'x' + image.naturalHeight;
});
console.log('icône décodée :', iconOk);

// 3. service worker actif, cache v15 avec icônes
const sw = await page.evaluate(async () => {
  const registration = await navigator.serviceWorker.getRegistration();
  await navigator.serviceWorker.ready;
  const keys = await caches.keys();
  const cache = await caches.open(keys.find(key => key.includes('shell-pionicide')));
  const entries = (await cache.keys()).map(request => new URL(request.url).pathname);
  return { scope: registration.scope, controller: !!navigator.serviceWorker.controller, keys, cached: entries.filter(path => path.includes('manifest') || path.includes('icon')).sort() };
});
console.log('service worker :', JSON.stringify(sw));

// 4. invitation à l'installation (événement simulé)
await page.evaluate(() => {
  const event = new Event('beforeinstallprompt');
  event.prompt = async () => { window.__promptShown = true; };
  window.dispatchEvent(event);
});
await page.waitForTimeout(400);
const bannerVisible = await page.isVisible('.install-banner');
await page.click('.install-banner [data-install]');
await page.waitForTimeout(300);
console.log('bandeau install :', bannerVisible, '| prompt appelé :', await page.evaluate(() => !!window.__promptShown));
if (SHOTS) await page.screenshot({ path: `${SHOTS}/pwa-installation.png` });

// 5. raccourcis : ouverture directe #base
await page.goto(`http://127.0.0.1:${PORT}/#base`);
await page.waitForTimeout(2500);
const titreBase = await page.title();
const pageHashBase = new URL(page.url()).hash;
console.log('lien direct #base :', titreBase, '|', await page.$eval('.nav-item.active', el => el.textContent.trim()));
console.log('URL après navigation :', new URL(page.url()).hash);
await page.click('#menu-toggle'); await page.waitForTimeout(300);
await page.click('.nav-item[data-page="analyse"]'); await page.waitForTimeout(800);
console.log('hash après clic menu :', new URL(page.url()).hash, '|', await page.title());

// 6. hors ligne complet : coupure réseau puis rechargement
await context.setOffline(true);
await page.reload();
await page.waitForTimeout(2500);
const offlineTitle = await page.title();
const offlineBody = await page.evaluate(() => document.querySelector('#app')?.textContent?.length || 0);
console.log('hors ligne :', offlineTitle, '| contenu rendu :', offlineBody > 200);
if (SHOTS) await page.screenshot({ path: `${SHOTS}/pwa-hors-ligne.png` });
await context.setOffline(false);

await browser.close();
server.close();
const failures = [];
if (manifestInfo.short !== 'PIONICIDE' || manifestInfo.display !== 'standalone') failures.push('manifeste incomplet');
if (manifestInfo.icons.some(icon => icon.status !== 200 || icon.type !== 'image/png' || icon.size < 1000)) failures.push('icône manquante ou invalide');
if (iconOk !== '180x180') failures.push('icône iOS non décodable');
if (!sw.controller) failures.push('service worker inactif');
if (sw.cached.length < 6) failures.push('manifeste ou icônes absents du cache');
if (!bannerVisible) failures.push('invitation à installer invisible');
if (!offlineTitle.includes('PIONICIDE') || !offlineBody) failures.push('rechargement hors ligne en échec');
if (pageHashBase !== '#base' || !titreBase.startsWith('Base de parties')) failures.push('lien direct #base inopérant');
if (errors.length) failures.push('erreurs JavaScript : ' + errors.join(' | '));
if (failures.length) { console.error('ÉCHEC — ' + failures.join(' ; ')); process.exit(1); }
console.log('OK — manifeste, icônes, service worker, invitation à installer, liens directs et rechargement hors ligne vérifiés.');
