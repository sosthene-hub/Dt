import fs from 'node:fs';
const dir='dist';let html=fs.readFileSync(dir+'/index.html','utf8');
const js=fs.readdirSync(dir+'/assets').find(n=>n.startsWith('index-')&&n.endsWith('.js'));
const css=fs.readdirSync(dir+'/assets').find(n=>n.endsWith('.css'));
const gen=fs.readdirSync(dir+'/assets').find(n=>n.startsWith('generator.worker-'));
const encode=s=>Buffer.from(s).toString('base64');
const prefix=`self.XMLHttpRequest=class {open(){} send(){const raw=atob(DATA);const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);this.status=200;this.readyState=4;this.response=bytes.buffer;setTimeout(()=>{this.onload?.({target:this});this.onreadystatechange?.({target:this});},0);} setRequestHeader(){} };`;
const bootstrap=`<script>
const nativeWorker=window.Worker;
const scanSource=atob('${encode(fs.readFileSync('public/scan-normal.worker.js'))}');
const generatorSource=atob('${encode(fs.readFileSync(dir+'/assets/'+gen))}');
const scanData='${fs.readFileSync('public/scan_normal.data').toString('base64')}';
window.Worker=class extends nativeWorker{constructor(url,options){const text=String(url);let source;if(text.includes('scan-normal.worker.js'))source='const DATA='+JSON.stringify(scanData)+';'+${JSON.stringify(prefix)}+scanSource;else if(text.includes('generator.worker-'))source=generatorSource;else {super(url,options);return;}const blob=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));super(blob);setTimeout(()=>URL.revokeObjectURL(blob),1000);}};
</script>`;
html=html.replace(/<script type="module"[^>]*src="[^"]+"[^>]*><\/script>/,'').replace(/<link rel="stylesheet"[^>]+>/,'');
html=html.replace('</head>',`<style>${fs.readFileSync(dir+'/assets/'+css,'utf8')}</style></head>`);
html=html.replace('</body>',bootstrap+'<script type="module">'+fs.readFileSync(dir+'/assets/'+js,'utf8').replace(/<\/script/gi,'<\\/script')+'</script></body>');
fs.writeFileSync('Dames-autonome.html',html);
console.log('Fichier autonome : '+html.length+' caractères');
