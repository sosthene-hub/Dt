import fs from 'node:fs';
import zlib from 'node:zlib';
const dir='dist';let html=fs.readFileSync(dir+'/index.html','utf8');
const js=fs.readdirSync(dir+'/assets').find(n=>n.startsWith('index-')&&n.endsWith('.js'));
const css=fs.readdirSync(dir+'/assets').find(n=>n.endsWith('.css'));
const workers=Object.fromEntries(fs.readdirSync(dir+'/assets').filter(n=>n.endsWith('.js')&&(n.includes('.worker-')||/^worker-[\w-]+\.js$/.test(n))).map(n=>[n,fs.readFileSync(dir+'/assets/'+n).toString('base64')]));
const encode=s=>Buffer.from(s).toString('base64');
const runtimes=Object.fromEntries(['scan-wasm-scalar.js','scan-wasm-simd.js'].map(n=>[n,encode(fs.readFileSync('public/'+n))]));
const bootstrap=`<script>
const nativeWorker=window.Worker;
const scanSource=atob('${encode(fs.readFileSync('public/scan-wasm.worker.js'))}');
const workerSources=${JSON.stringify(workers)};
const scanRuntimes=${JSON.stringify(runtimes)};
const scanDataGz='${zlib.gzipSync(fs.readFileSync('public/scan_normal.data').subarray(0,8503280),{level:9}).toString('base64')}';
const scanBook='${fs.readFileSync('public/scan-book.bin').toString('base64')}';
window.Worker=class extends nativeWorker{constructor(url,options){const text=String(url);let source;if(text.includes('scan-wasm.worker.js'))source='self.SCAN_EMBEDDED_DATA_GZ='+JSON.stringify(scanDataGz)+';self.SCAN_EMBEDDED_BOOK='+JSON.stringify(scanBook)+';self.SCAN_EMBEDDED_RUNTIMES='+JSON.stringify(scanRuntimes)+';'+scanSource;else {const file=Object.keys(workerSources).find(n=>text.includes(n));if(file)source=new TextDecoder().decode(Uint8Array.from(atob(workerSources[file]),c=>c.charCodeAt(0)));else {super(url,options);return;}}const blob=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));super(blob);setTimeout(()=>URL.revokeObjectURL(blob),1000);}};
</script>`;
html=html.replace(/<script type="module"[^>]*src="[^"]+"[^>]*><\/script>/,'').replace(/<link rel="stylesheet"[^>]+>/,'');
// Remplacement par fonction : le code minifié contient des séquences $& et $'
// que String.replace interpréterait comme des motifs, en injectant du HTML.
const cssText=fs.readFileSync(dir+'/assets/'+css,'utf8');
const jsText=fs.readFileSync(dir+'/assets/'+js,'utf8').replace(/<\/script/gi,'<\\/script');
html=html.replace('</head>',()=>`<style>${cssText}</style></head>`);
html=html.replace('</body>',()=>bootstrap+'<script type="module">'+jsText+'</script></body>');
try{new Function(jsText.split('import.meta').join('({url:""})'));}catch(error){throw Error('Le paquet JavaScript ne se parse pas : '+error.message);}
if(!html.includes(jsText))throw Error('Le JavaScript embarqué diffère du paquet construit.');
fs.writeFileSync('Dames-autonome.html',html);console.log('Fichier autonome : '+html.length+' caractères');
const combPath=process.env.EMBED_COMBINATIONS||'public/combinations-app.json';
if(fs.existsSync(combPath)){
 const db=fs.readFileSync(combPath,'utf8');
 html=html.replace('</head>',()=>'<script>window.__COMBINATIONS__='+db.replace(/<\//g,'<\\/')+';</script></head>');
 fs.writeFileSync('Dames-autonome.html',html);
 console.log('Base de combinaisons embarquée : '+JSON.parse(db).entries.length+' entrées, '+html.length+' caractères');
}
