/* Tests du module « Base de parties » — sans navigateur, sans IndexedDB.
   Vérifie : lecture PDN, encodage compact, index d'ouvertures, recherche par
   structure (masques binaires) comparée à l'implémentation de référence de
   l'application (src/game-rules.js + resolvePdnMove), structures et noms. */
import fs from 'node:fs';
import path from 'node:path';
import * as Core from '../src/base/core.js';
const moveToPdn = Core.moveToPdn; // notation PDN des coups encodés par la base
import { makeLib } from '../src/base/index-lib.js';
import { createInitialBoard } from '../src/game-rules.js';


const Lib = makeLib(Core);
let failures = 0;
const check = (label, condition, detail = '') => {
  if (!condition) failures++;
  console.log((condition ? '· OK   ' : '· ÉCHEC') + ' ' + label + (detail ? ' — ' + detail : ''));
};

/* ---------- jeu de données : 200 parties réelles, ou le fichier complet s'il est présent ---------- */
const complet = 'fixtures/base-1000-parties.pdn';
const fichier = fs.existsSync(complet) ? complet : 'fixtures/base-echantillon-200.pdn';
const pdn = fs.readFileSync(fichier, 'utf8');
console.log('Jeu de test : ' + fichier + ' (' + Math.round(pdn.length / 1024) + ' Ko)');

/* ---------- 1. lecture PDN et encodage ---------- */
const games = [];
const seen = new Set();
let lues = 0;
for (const raw of Core.pdnGames(pdn)) {
  lues++;
  const rec = Lib.prepareRecord(raw, null);
  if (!rec.pl || seen.has(rec.dv)) continue;
  seen.add(rec.dv);
  rec.id = games.length + 1;
  games.push(rec);
}
check('lecture PDN', lues > 0, lues + ' blocs');
check('parties uniques exploitables', games.length > 50, games.length + ' parties');
check('coups encodés en 3 octets + prises', games.every(game => game.mv instanceof Uint8Array && game.mv.length >= 3));
check('résultats normalisés', games.every(game => ['2-0', '1-1', '0-2', '*'].includes(game.r)));
check('joueurs normalisés', games.every(game => game.wk && game.bk && game.wk === game.wk.toLowerCase()));

/* ---------- 2. index d'ouvertures ---------- */
const builder = new Lib.IndexBuilder();
for (const game of games) builder.add(game, game.id);
const table = builder.finish().compact();
check('index construit et compacté', table.count > 1000 && table.mode === 'sorted', table.count + ' positions');
const initialKey = Core.hash32Position(Core.Position.initial());
const initialRecord = table.lookup(initialKey);
check('position initiale indexée', initialRecord >= 0);
const initialStats = table.stats(initialRecord);
check('total des parties de la position initiale = toutes les parties',
  initialStats.n === games.length, initialStats.n + ' / ' + games.length);
check('somme gain/nulle/perte cohérente',
  initialStats.w + initialStats.d + initialStats.l <= initialStats.n,
  `${initialStats.w}+${initialStats.d}+${initialStats.l} sur ${initialStats.n}`);
const explorer = Lib.explorerMoves({ cells: (() => { const cells = new Array(51).fill(0); for (let square = 31; square <= 50; square++) cells[square] = 1; for (let square = 1; square <= 20; square++) cells[square] = 3; return cells; })(), side: 0 }, table);
check('9 coups légaux depuis la position initiale', explorer.length === 9, explorer.length);
check('somme des coups = parties indexées', explorer.reduce((sum, move) => sum + move.n, 0) === games.length);

/* ---------- 3. recherche par structure vs implémentation de référence de l'app ---------- */
function referenceSearch(cells, mirror, maxPly = 60) {
  const swapped = new Uint8Array(51);
  for (let square = 1; square <= 50; square++) {
    const value = cells[square];
    swapped[square] = value === 1 ? 3 : value === 3 ? 1 : value === 2 ? 4 : value === 4 ? 2 : value;
  }
  const matches = (board, wanted) => {
    for (let square = 1; square <= 50; square++) {
      const want = wanted[square];
      if (!want) continue;
      const piece = board[square];
      if (want === 5) { if (piece !== 'e') return false; continue; }
      if (want === 1 && piece !== 'w') return false;
      if (want === 2 && piece !== 'W') return false;
      if (want === 3 && piece !== 'b') return false;
      if (want === 4 && piece !== 'B') return false;
    }
    return true;
  };
  const ids = [];
  for (const record of games) {
    const game = Core.decodeMoves(record.mv).map(moveToPdn);
    let board = createInitialBoard();
    let side = 'w';
    const found = [];
    if (matches(board, cells)) found.push(0);
    else if (mirror && matches(board, swapped)) found.push(0);
    for (let index = 0; index < game.length && index < maxPly && found.length < 4; index++) {
      const token = game[index];
      const next = Lib.resolveReference(board, side, token);
      if (!next) break;
      board = next.board;
      side = next.side;
      if (matches(board, cells)) found.push(index + 1);
      else if (mirror && matches(board, swapped)) found.push(index + 1);
    }
    if (found.length) ids.push(record.id + ':' + found.join(','));
  }
  return ids.sort();
}

// petit pont : rejeu par les règles de l'application (générateur de coups complet)
{
  const { generateLegalMoves } = await import('../src/game-rules.js');
  const { applyMove } = await import('../src/game-rules.js');
  Lib.resolveReference = (board, side, token) => {
    const parts = String(token).replace(/×/g, 'x').split(/[x-]/).map(Number);
    const isCapture = String(token).includes('x');
    const legal = generateLegalMoves(board, side).filter(move => {
      if (move.from !== parts[0] || move.to !== parts[parts.length - 1]) return false;
      if (isCapture && !move.captured.length) return false;
      if (!isCapture && move.captured.length) return false;
      if (isCapture && parts.length > 2 && move.path.length === parts.length) return move.path.every((n, i) => n === parts[i]);
      return true;
    });
    if (!legal.length) return null;
    const move = legal[0];
    return { board: applyMove(board, move), side: side === 'w' ? 'b' : 'w' };
  };
}

const makeCells = spec => {
  const cells = new Uint8Array(51);
  for (const square of spec.w || []) cells[square] = 1;
  for (const square of spec.W || []) cells[square] = 2;
  for (const square of spec.b || []) cells[square] = 3;
  for (const square of spec.B || []) cells[square] = 4;
  for (const square of spec.e || []) cells[square] = 5;
  return cells;
};

const cases = [
  ['3 pions blancs 28-29-30', makeCells({ w: [28, 29, 30] }), false],
  ['mur blanc 27-30 et mur noir 21-24', makeCells({ w: [27, 28, 29, 30], b: [21, 22, 23, 24] }), false],
  ['pion blanc 28 + pion noir 23 + case 19 vide', makeCells({ w: [28], b: [23], e: [19] }), false],
  ['2 pions noirs 28-29, symétrie de couleur', makeCells({ b: [28, 29] }), true],
  ['dame blanche sur la ligne 1', makeCells({ W: [1, 6, 11] }), false],
];
for (const [label, cells, mirror] of cases) {
  const rapide = Lib.searchStructure(games, { cells }, { maxPly: 60, limit: 10000, mirror })
    .results.map(row => row.id + ':' + row.plys.join(',')).sort();
  const reference = referenceSearch(cells, mirror);
  check('recherche identique à la référence — ' + label,
    JSON.stringify(rapide) === JSON.stringify(reference),
    rapide.length + ' partie(s)');
}

/* ---------- 4. structures ---------- */
const structure = Core.emptyStructure();
structure.cells[28] = Core.CELL.WMAN;
structure.cells[23] = Core.CELL.BMAN;
structure.cells[5] = Core.CELL.MUST_EMPTY;
const ligne = Core.structureToLine(structure);
check('chaîne de 50 caractères', ligne.length === 50 && ligne[27] === 'B' && ligne[4] === 'E');
check('aller-retour chaîne', Core.structureToLine(Core.parseStructure(ligne)) === ligne);
check('aller-retour JSON', Core.structureToLine(Core.parseStructure(Core.structureToJSON(structure))) === ligne);
check('dame noire conservée', Core.parseStructure('{"damesNoires":[3]}').cells[3] === Core.CELL.BKING);
check('chaîne invalide rejetée', (() => { try { Core.parseStructure('B.N'); return false; } catch { return true; } })());

/* ---------- 5. noms ---------- */
check('accents et casse', Core.nameKey('Tembé') === Core.nameKey('Tembe'));
check('ordre prénom/nom', Core.nameKey('Mbemba Sosthene') === Core.nameKey('Sosthene Mbemba'));

console.log('\n' + (failures ? failures + ' échec(s)' : 'Tous les tests de la base de parties sont passés.'));
process.exit(failures ? 1 : 0);
