import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright';
import {pathToFileURL} from 'node:url';const autonomeUrl=process.env.BASE_URL||pathToFileURL(new URL('../Dames-autonome.html',import.meta.url).pathname).href;

const AUTONOME = process.env.FILE || '/home/user/project/Dames-autonome.html';
const html = fs.readFileSync(AUTONOME, 'utf8');
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, offline: true });
const page = await context.newPage();
const errors = [];
const requests = [];
page.on('pageerror', error => errors.push(String(error)));
page.on('request', request => { if (!request.url().startsWith('file:') && !request.url().startsWith('blob:') && !request.url().startsWith('data:')) requests.push(request.url()); });
await page.route('**/*', route => {
  const url = route.request().url();
  if (url.startsWith('file:') || url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
  return route.abort();
});
await page.goto('file://' + path.resolve(AUTONOME));
await page.click('#menu-toggle');
await page.click('[data-page="combinaisons"]');
await page.waitForFunction(() => /Base embarquée/.test(document.querySelector('#cb-db')?.textContent || ''), { timeout: 20000 });
const report = { errors, externalRequests: requests, offlined: true };
await page.selectOption('#cb-level', '1');
await page.selectOption('#cb-scan-depth', '0');
await page.fill('#cb-route', '31x');
await page.click('#cb-generate');
await page.waitForFunction(() => {
  const panel = document.querySelector('#cb-exercise');
  return panel && !panel.hidden && document.querySelector('#cb-exercise')?.dataset.solution;
}, { timeout: 20000 });
report.level1 = {
  meta: (await page.textContent('#cb-meta')).trim(),
  pieces: await page.$$eval('#cb-board .piece', nodes => nodes.length),
  moves: (await page.evaluate(() => document.querySelector('#cb-exercise')?.dataset.solution || '')).split(' ').filter(Boolean),
};
await page.selectOption('#cb-level', '2');
await page.selectOption('#cb-scan-depth', '12');
await page.fill('#cb-route', '');
await page.click('#cb-generate');
await page.waitForFunction(() => {
  const panel = document.querySelector('#cb-exercise');
  const status = document.querySelector('#cb-generate-status')?.textContent || '';
  return (panel && !panel.hidden && document.querySelector('#cb-exercise')?.dataset.solution) || /^Échec/.test(status);
}, { timeout: 180000 });
report.level2 = {
  status: (await page.textContent('#cb-generate-status')).trim(),
  meta: (await page.textContent('#cb-meta')).trim(),
  message: (await page.textContent('#cb-message')).trim(),
};
report.overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
await page.screenshot({ path: 'perf/combinaisons/page-offline.png' });
fs.writeFileSync('perf/combinaisons/browser-offline.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
await browser.close();
