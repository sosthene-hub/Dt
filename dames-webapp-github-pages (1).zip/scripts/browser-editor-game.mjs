import { chromium } from 'playwright';
import fs from 'node:fs';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, offline: true });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
await page.goto('file:///home/user/projet/Dames-autonome.html');
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), { timeout: 60000 });

async function nav(id) {
  await page.click('#menu-toggle');
  await page.click(`[data-page="${id}"]`);
}

async function openDetails(selector) {
  const open = await page.locator(selector).evaluate(node => node.open);
  if (!open) await page.click(`${selector} summary`);
}

// 1. Position éditée puis partie contre Scan, avec annulation et reprise du point de départ.
await nav('editeur');
await page.click('#ed-clear');
await page.click('.palette-tool[data-tool="w"]');
for (const square of [32, 33, 34, 38, 39]) await page.click(`#editor-board [data-square="${square}"]`);
await page.click('.palette-tool[data-tool="b"]');
for (const square of [18, 19, 20, 13]) await page.click(`#editor-board [data-square="${square}"]`);
if (!/Position valide/.test(await page.locator('#ed-status').textContent())) throw Error('Edited position refused');
await openDetails('#ed-play');
await page.selectOption('#ed-play-side', 'w');
await page.selectOption('#ed-play-color', 'w');
await page.selectOption('#ed-play-level', 'facile');
await page.click('#ed-play-start');
await page.waitForFunction(() => document.querySelector('#game-cursor')?.textContent.startsWith('Position éditée'), { timeout: 15000 });
const startLabel = await page.locator('#game-cursor').textContent();
await page.click('#game-board [data-square="32"]');
await page.click('#game-board [data-square="28"]');
await page.waitForFunction(() => document.querySelectorAll('#game-history button').length >= 2, { timeout: 60000 });
const afterReply = await page.locator('#game-history').textContent();
await page.click('#undo');
if (await page.locator('#game-history button').count() !== 1) throw Error('Undo after edited game failed');
if (!await page.locator('#game-resume').isVisible()) throw Error('Undo must pause the edited match');
await page.click('#game-restart-pos');
if (await page.locator('#game-history button').count() !== 0) throw Error('Restart position failed');
const restartCursor = await page.locator('#game-cursor').textContent();
await page.screenshot({ path: '/home/user/perf/partie-position-editee.png', fullPage: true });

// 2. Position refusée : pion blanc sur la ligne de promotion.
await nav('editeur');
await page.click('#ed-clear');
await page.click('.palette-tool[data-tool="w"]');
for (const square of [2, 3, 12, 22]) await page.click(`#editor-board [data-square="${square}"]`);
await page.click('.palette-tool[data-tool="b"]');
for (const square of [18, 19, 20]) await page.click(`#editor-board [data-square="${square}"]`);
await openDetails('#ed-play');
await page.click('#ed-play-start');
const refused = (await page.locator('#ed-play-status').textContent()).trim();
await nav('jouer');

// 3. Combinaison jouée contre Scan.
await nav('combinaisons');
await page.waitForFunction(() => /Base embarquée/.test(document.querySelector('#cb-db')?.textContent || ''), { timeout: 30000 });
await page.selectOption('#cb-scan-depth', '0');
// Niveau 1 : la position du livre est affichée avec un avertissement si elle
// contient un pion isolé (les combinaisons du livre en comportent).
await page.selectOption('#cb-level', '1');
await page.click('#cb-generate');
await page.waitForFunction(() => { const panel = document.querySelector('#cb-exercise'); return panel && !panel.hidden && document.querySelector('#cb-exercise')?.dataset.solution; }, { timeout: 30000 });
const bookValidation = (await page.locator('#cb-validation').textContent()).trim();
// Niveau 2 : position générée, elle doit passer toutes les règles sans réserve.
await page.selectOption('#cb-level', '2');
await page.click('#cb-generate');
await page.waitForFunction(() => { const panel = document.querySelector('#cb-exercise'); return panel && !panel.hidden && document.querySelector('#cb-exercise')?.dataset.solution; }, { timeout: 60000 });
const validation = (await page.locator('#cb-validation').textContent()).trim();
if (!/Position cohérente/.test(validation)) throw Error('Generated combination not validated: ' + validation);
await openDetails('#cb-play');
await page.click('#cb-play-start');
await page.waitForFunction(() => document.querySelector('#game-cursor')?.textContent.includes('Combinaison'), { timeout: 15000 });
const combinationLabel = await page.locator('#game-cursor').textContent();

const report = {
  mode: 'Chromium, file://, réseau coupé, 412×915',
  editedGame: { startLabel, afterReply: afterReply.slice(0, 120), undoOnePly: true, restart: restartCursor },
  refusedPosition: refused,
  combination: { bookValidation, generatedValidation: validation, label: combinationLabel },
  errors,
};
fs.writeFileSync('perf/partie-position-editee.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
if (errors.length) throw Error(errors.join('\n'));
await browser.close();
