/**
 * Calibrage de la vérification Scan (deux recherches, sans multi-PV).
 * MODE=book : positions du livre ; MODE=generated LEVEL=2|3|4 : positions générées.
 * Mesure aussi la fréquence à laquelle Scan choisit le premier coup de la solution.
 */
import fs from 'node:fs';
import path from 'node:path';
import Module from 'node:module';
import { boardToHub, generateLegalMoves, applyMove, moveMatchesEngine } from '../../src/game-rules.js';
import { buildCandidate } from '../../src/combinations/generate.js';

const mode = process.env.MODE || 'book';
const level = Number(process.env.LEVEL || 2);
const sampleSize = Number(process.env.SAMPLE || 30);
const depth = Number(process.env.DEPTH || 12);
const seconds = Number(process.env.SECONDS || 2);
const db = JSON.parse(fs.readFileSync(process.env.COMB_DB || 'public/combinations-app.json', 'utf8'));
const variant = process.env.SCAN_RUNTIME === 'simd' ? 'simd' : 'scalar';
const filename = path.resolve('public/scan-wasm-' + variant + '.js');
const native = new Module(filename);
native.filename = filename;
native.paths = Module._nodeModulePaths(path.dirname(filename));
native._compile(fs.readFileSync(filename, 'utf8'), filename);
let resolveWait, searchResolve, info = [], fatal;
const ready = new Promise(resolve => { resolveWait = resolve; });
const mod = await native.exports({
  noInitialRun: true,
  print: line => {
    if (line === 'ready') resolveWait();
    if (line.startsWith('info')) info.push(line);
    if (line.startsWith('done')) searchResolve?.({ done: line, infos: info });
  },
  printErr: line => { if (line.startsWith('error')) fatal = line; },
});
const bitbases = (await import('../../src/bitbases-data.js')).default;
mod.FS.mkdirTree('/data');
mod.FS.writeFile('/data/eval', fs.readFileSync('public/scan_normal.data').subarray(0, 8503280));
mod.FS.writeFile('/data/book', fs.readFileSync('public/scan-book.bin'));
for (const [name, text] of Object.entries(bitbases)) {
  mod.FS.mkdirTree('/' + path.dirname(name));
  mod.FS.writeFile('/' + name, Buffer.from(text, 'base64'));
}
mod._main(0, 0);
const send = text => mod.ccall('scan_command', null, ['string'], [text]);
send('hub');
send('set-param name=tt-size value=22');
send('set-param name=bb-size value=4');
send('set-param name=book value=false');
send('init');
await ready;
const run = (position, d, secs) => new Promise((resolve, reject) => {
  info = [];
  const timer = setTimeout(() => reject(Error('timeout')), (secs + 8) * 1000);
  searchResolve = r => { clearTimeout(timer); resolve(r); };
  send('pos ' + position);
  send(`level depth=${d} move-time=${secs}`);
  send('go analyze');
});
const seed = Number(process.env.SEED || 11);
let state = seed;
const random = () => { state = (state * 1103515245 + 12345) % 2147483648; return state / 2147483648; };

const pool = db.entries.filter(e => e.solution.length >= 3);
const samples = [];
while (samples.length < sampleSize && pool.length) {
  const entry = pool.splice(Math.floor(random() * pool.length), 1)[0];
  if (mode === 'book') samples.push({ id: entry.id, board: entry.board, trait: entry.trait, solution: entry.solution, page: entry.page });
  else {
    const built = buildCandidate(entry, { level, rng: random });
    if (built.ok) samples.push({ id: entry.id, board: built.candidate.board, trait: built.candidate.trait, solution: built.candidate.solution, page: entry.page, added: built.candidate.added.length });
  }
}
const results = [];
for (const sample of samples) {
  try {
    send('new-game');
    const rootResult = await run('pos=' + boardToHub(sample.board, sample.trait), depth, seconds);
    const rootScore = Number((rootResult.infos.at(-1)?.match(/\bscore=([-\d.]+)/) || [])[1]);
    const numbers = sample.solution[0].split(/[x-]/).map(Number);
    const first = generateLegalMoves(sample.board, sample.trait).find(m => m.from === numbers[0] && m.to === numbers[1]);
    const after = applyMove(sample.board, first);
    const replyResult = await run('pos=' + boardToHub(after, sample.trait === 'w' ? 'b' : 'w'), depth, seconds);
    const replyScore = Number((replyResult.infos.at(-1)?.match(/\bscore=([-\d.]+)/) || [])[1]);
    const scanMove = rootResult.done.match(/\bmove=([^ ]+)/)?.[1] || null;
    const scanChooses = scanMove && moveMatchesEngine(first, scanMove);
    results.push({ id: sample.id, rootScore, replyScore, value: -replyScore, gap: rootScore + replyScore, scanMove, scanChooses, added: sample.added });
  } catch (error) {
    results.push({ id: sample.id, error: String(error.message) });
  }
}
const valid = results.filter(r => Number.isFinite(r.value));
const summary = {
  mode,
  level: mode === 'generated' ? level : null,
  depth,
  sample: results.length,
  winningAfterFirstMove: valid.filter(r => r.value >= 1.5).length,
  singleBest: valid.filter(r => r.gap <= 0.5).length,
  accepted: valid.filter(r => r.value >= 1.5 && r.gap <= 0.5).length,
  scanChoosesBookMove: results.filter(r => r.scanChooses).length,
  medianValue: valid.map(r => r.value).sort((a, b) => a - b)[Math.floor(valid.length / 2)],
  errors: results.filter(r => r.error).length,
  fatal,
};
fs.writeFileSync(process.env.OUT || `perf/combinaisons/calibration-${mode}${mode === 'generated' ? level : ''}.json`, JSON.stringify({ summary, results }, null, 2));
console.log(JSON.stringify(summary, null, 2));
