"""PC Blues deel 66 — extraction privée des diagrammes et textes.

Usage strictement personnel : les sorties contiennent des extraits du livre et
ne doivent jamais être copiées dans src/, public/ ni dans le ZIP public.

    python scripts/combinations/extract-book.py tome1.pdf tome2.pdf --out /home/user/comb-private

La reconnaissance ne fait aucun OCR : les glyphes du damier sont des bitmaps
identiques dans tout le livre. Trois prototypes (pion blanc, pion noir, dame
noire) sont appris sur les images elles-mêmes, puis chaque case est classée par
distance. Toute case douteuse est signalée, jamais devinée silencieusement.
"""
import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import numpy as np
import pymupdf as fitz
from PIL import Image

SIZE = 330
PATCH = 28


def image_array(doc, xref):
    pix = fitz.Pixmap(doc, xref)
    if pix.n != 3:
        pix = fitz.Pixmap(fitz.csRGB, pix)
    img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples).convert("L")
    if img.size != (SIZE, SIZE):
        img = img.resize((SIZE, SIZE))
    return np.asarray(img)


def square_center(n):
    """FMJD square 1..50 -> image center. Row 0 is the top; square 1 is top-left dark square."""
    row = (n - 1) // 5
    col = (n - 1) % 5 * 2 + (1 if row % 2 == 0 else 0)
    return 5 + col * 32 + 16, 5 + row * 32 + 16


def patch_at(arr, n):
    x, y = square_center(n)
    h = PATCH // 2
    return arr[y - h:y + h, x - h:x + h]


def all_patches(docs):
    """Yield (patch, doc_index, page_index, xref, square)."""
    for di, doc in enumerate(docs):
        for page in doc:
            for info in page.get_image_info(xrefs=True):
                if info["width"] != SIZE or info["height"] != SIZE:
                    continue
                arr = image_array(doc, info["xref"])
                for n in range(1, 51):
                    q = patch_at(arr, n)
                    if q.shape == (PATCH, PATCH):
                        yield q, di, page.number, info["xref"], n


def learn_templates(docs):
    counts = Counter()
    store = {}
    for q, *_ in all_patches(docs):
        if q.std() < 4:
            continue
        key = q.astype(np.uint8).tobytes()
        counts[key] += 1
        store[key] = q
    top = [(store[k].astype(float), c) for k, c in counts.most_common(3) if c >= 8]
    if len(top) != 3:
        raise SystemExit(f"Glyphes inattendus : {[c for _, c in counts.most_common(6)]}")
    bodies = [float(t[8:14, 8:20].mean()) for t, _ in top]
    # A white man body is light; the two dark glyphs are the man and the doubled king.
    wi = int(np.argmax(bodies))
    darks = [i for i in range(3) if i != wi]
    if bodies[wi] < 200 or any(bodies[i] > 120 for i in darks):
        raise SystemExit(f"Prototypes incohérents : {bodies}")
    counts_by_i = [c for _, c in top]
    man_i = max(darks, key=lambda i: counts_by_i[i])
    king_i = min(darks, key=lambda i: counts_by_i[i])
    # The king must really differ from the man (extra lower disc).
    if float(np.mean((top[man_i][0] - top[king_i][0]) ** 2)) < 500:
        raise SystemExit("Le glyphe de dame est indiscernable du pion noir")
    return {"w": top[wi][0], "b": top[man_i][0], "B": top[king_i][0]}


def classify(arr, templates):
    board = ["e"] * 51
    issues = []
    for n in range(1, 51):
        q = patch_at(arr, n)
        if q.shape != (PATCH, PATCH):
            issues.append({"square": n, "reason": "hors image"})
            continue
        if q.std() < 4:
            continue
        scores = {name: float(np.mean((q.astype(float) - t) ** 2)) for name, t in templates.items()}
        best = min(scores, key=scores.get)
        if scores[best] > 900:
            issues.append({"square": n, "reason": "glyphe inconnu", "mse": round(scores[best], 1)})
        else:
            board[n] = best
    return board, issues


def text_blocks(page):
    out = []
    for block in page.get_text("dict")["blocks"]:
        txt = "\n".join(
            "".join(span["text"] for span in line["spans"]).strip()
            for line in block.get("lines", [])
        ).strip()
        if txt:
            out.append({"bbox": [round(v, 2) for v in block["bbox"]], "text": txt})
    return sorted(out, key=lambda b: (round(b["bbox"][1], 1), b["bbox"][0]))


def text_lines(page):
    out = []
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines", []):
            txt = "".join(span["text"] for span in line["spans"]).strip()
            if txt:
                out.append({"bbox": [round(v, 2) for v in line["bbox"]], "text": txt})
    return sorted(out, key=lambda l: (round(l["bbox"][1], 1), l["bbox"][0]))


def extract(paths, outdir):
    docs = [fitz.open(p) for p in paths]
    templates = learn_templates(docs)
    metrics = Counter()
    for doc in docs:
        for page in doc:
            for info in page.get_image_info(xrefs=True):
                metrics[f"{info['width']}x{info['height']}"] += 1
    entries = []
    offset = 0
    for part, doc in enumerate(docs, 1):
        for page in doc:
            lines = text_lines(page)
            blocks = text_blocks(page)
            headers = [
                b for b in blocks
                if re.search(r"herkomst", b["text"], re.I)
                and re.search(r"(?:slagroute|(?<!slag)route)\s*:", b["text"], re.I)
            ]
            header_page = None
            images = [
                i for i in page.get_image_info(xrefs=True)
                if i["width"] >= 250 and 0.95 < i["width"] / i["height"] < 1.05
            ]
            images.sort(key=lambda i: (i["bbox"][1], i["bbox"][0]))
            for rank, info in enumerate(images):
                x0, y0, x1, y1 = info["bbox"]
                bottom = images[rank + 1]["bbox"][1] if rank + 1 < len(images) else min(800.0, y1 + 10)
                # A header block applies to every diagram below it until the next header.
                best = None
                for h in headers:
                    if h["bbox"][3] <= y0 + 2 and (best is None or h["bbox"][3] > best["bbox"][3]):
                        best = h
                header = best["text"].replace("\n", " ") if best else ""
                page_headers = [{"text": h["text"].replace("\n", " "), "y": h["bbox"][1]} for h in headers]
                if best:
                    header_page = page.number + 1
                right = [l for l in lines if l["bbox"][0] >= 400 and y0 - 4 <= l["bbox"][1] < min(bottom, y1 + 4)]
                side_text = "\n".join(l["text"] for l in right)
                table = bool(re.search(r"eindslag|schijven transporteren|combinatie-element", side_text, re.I))
                body = [
                    l for l in lines
                    if l["bbox"][0] > x1 - 2
                    and (not table or l["bbox"][0] < 403)
                    and y0 - 2 <= l["bbox"][1] < min(bottom, y1 + 6)
                ]
                arr = image_array(doc, info["xref"])
                board, issues = classify(arr, templates)
                entries.append({
                    "id": f"pcb66-{offset + page.number + 1:03}-{rank + 1:02}",
                    "page": offset + page.number + 1,
                    "part": part,
                    "bbox": [round(v, 2) for v in info["bbox"]],
                    "image_sha256": hashlib.sha256(arr.tobytes()).hexdigest(),
                    "board": board,
                    "text": "\n".join(l["text"] for l in body),
                    "header_raw": header,
                    "eindslag_raw": side_text if table else "",
                    "header_source": f"page {header_page}" if header else "aucun en-tête au-dessus",
                    "page_headers": page_headers,
                    "layout": "table" if table else "inline",
                    "recognition_issues": issues,
                })
            if (page.number + 1) % 100 == 0:
                print(f"part {part} page {page.number + 1}: {len(entries)} diagrammes")
        offset += len(doc)
    outdir.mkdir(parents=True, exist_ok=True)
    payload = {
        "format": "pcblues-extraction-v1",
        "personalUseOnly": True,
        "notice": "Contenu extrait de PC Blues deel 66 (Gerrit Boom). Usage personnel ; ne pas redistribuer.",
        "sources": [
            {"file": p.name, "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "pages": len(d)}
            for p, d in zip(paths, docs)
        ],
        "templates": {k: hashlib.sha256(v.astype(np.uint8).tobytes()).hexdigest() for k, v in templates.items()},
        "image_inventory": dict(metrics),
        "entries": entries,
    }
    (outdir / "extracted-private.json").write_text(json.dumps(payload, ensure_ascii=False))
    print("EXTRACTED", len(entries), "issues", sum(bool(e["recognition_issues"]) for e in entries))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf", nargs="+", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    extract(args.pdf, args.out)
