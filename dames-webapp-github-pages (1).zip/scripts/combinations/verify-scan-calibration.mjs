/** Calibrage : à quelle fréquence Scan choisit-il le premier coup du livre ? */
import fs from 'node:fs';
import path from 'node:path';
import Module from 'node:module';
import { boardToHub, generateLegalMoves, moveMatchesEngine } from '../../src/game-rules.js';

const db = JSON.parse(fs.readFileSync(process.env.COMB_DB || 'public/combinations-app.json', 'utf8'));
const sampleSize = Number(process.env.SAMPLE || 40);
const depth = Number(process.env.DEPTH || 12);
const seconds = Number(process.env.SECONDS || 2);
const variant = process.env.SCAN_RUNTIME === 'simd' ? 'simd' : 'scalar';
const filename = path.resolve('public/scan-wasm-' + variant + '.js');
const native = new Module(filename);
native.filename = filename;
native.paths = Module._nodeModulePaths(path.dirname(filename));
native._compile(fs.readFileSync(filename, 'utf8'), filename);
let resolveWait, searchResolve, info = [], fatal;
const ready = new Promise(resolve => { resolveWait = resolve; });
const mod = await native.exports({
  noInitialRun: true,
  print: line => {
    if (line === 'ready') resolveWait();
    if (line.startsWith('info')) info.push(line);
    if (line.startsWith('done')) searchResolve?.({ done: line, infos: info });
  },
  printErr: line => { if (line.startsWith('error')) fatal = line; },
});
const bitbases = (await import('../../src/bitbases-data.js')).default;
mod.FS.mkdirTree('/data');
mod.FS.writeFile('/data/eval', fs.readFileSync('public/scan_normal.data').subarray(0, 8503280));
mod.FS.writeFile('/data/book', fs.readFileSync('public/scan-book.bin'));
for (const [name, text] of Object.entries(bitbases)) {
  mod.FS.mkdirTree('/' + path.dirname(name));
  mod.FS.writeFile('/' + name, Buffer.from(text, 'base64'));
}
mod._main(0, 0);
const send = text => mod.ccall('scan_command', null, ['string'], [text]);
send('hub');
send('set-param name=tt-size value=22');
send('set-param name=bb-size value=4');
send('set-param name=book value=false');
send('init');
await ready;
const run = (position, d, secs) => new Promise((resolve, reject) => {
  info = [];
  const timer = setTimeout(() => reject(Error('timeout')), (secs + 8) * 1000);
  searchResolve = r => { clearTimeout(timer); resolve(r); };
  send('pos ' + position);
  send(`level depth=${d} move-time=${secs}`);
  send('go analyze');
});

const seed = Number(process.env.SEED || 7);
let state = seed;
const random = () => { state = (state * 1103515245 + 12345) % 2147483648; return state / 2147483648; };
const entries = [];
const pool = db.entries.filter(e => e.solution.length >= 3);
while (entries.length < sampleSize && pool.length) {
  entries.push(pool.splice(Math.floor(random() * pool.length), 1)[0]);
}
const results = [];
for (const entry of entries) {
  try {
    send('new-game');
    const result = await run('pos=' + boardToHub(entry.board, entry.trait), depth, seconds);
    const move = result.done.match(/\bmove=([^ ]+)/)?.[1] || null;
    const last = result.infos.at(-1) || '';
    const score = Number((last.match(/\bscore=([-\d.]+)/) || [])[1]);
    const wanted = entry.solution[0];
    const match = move && moveMatchesEngine(
      generateLegalMoves(entry.board, entry.trait).find(m => {
        const numbers = wanted.split(/[x-]/).map(Number);
        return m.from === numbers[0] && m.to === numbers[1];
      }) || { from: 0, to: 0, captured: [] },
      move,
    );
    results.push({ id: entry.id, page: entry.page, wanted, scan: move, score, depth, match, solution: entry.solution.length });
  } catch (error) {
    results.push({ id: entry.id, error: String(error.message) });
  }
}
const ok = results.filter(r => r.match).length;
const out = {
  engine: 'Scan 3.1b WASM ' + variant,
  depth,
  seconds,
  sample: results.length,
  scanChoosesBookMove: ok,
  rate: +(ok / results.length).toFixed(3),
  wins: results.filter(r => Number.isFinite(r.score) && r.score >= 2).length,
  results,
  fatal,
};
fs.writeFileSync(process.env.OUT || 'perf/combinaisons/scan-calibration.json', JSON.stringify(out, null, 2));
console.log(JSON.stringify({ sample: out.sample, rate: out.rate, wins: out.wins, depth, fatal }, null, 2));
