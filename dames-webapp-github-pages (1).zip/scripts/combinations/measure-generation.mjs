/**
 * Mesure reproductible de la génération vérifiée par Scan (Node + WASM).
 * Pour chaque niveau : essais nécessaires, causes de rejet, temps, profondeur.
 *   LEVELS=2,3,4 TARGET=8 DEPTH=12 node scripts/combinations/measure-generation.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import Module from 'node:module';
import { boardToHub } from '../../src/game-rules.js';
import { generateVerified } from '../../src/combinations/generate.js';

const db = JSON.parse(fs.readFileSync(process.env.COMB_DB || 'public/combinations-app.json', 'utf8'));
const levels = (process.env.LEVELS || '2,3,4').split(',').map(Number);
const target = Number(process.env.TARGET || 8);
const depth = Number(process.env.DEPTH || 12);
const maxAttempts = Number(process.env.ATTEMPTS || 60);
const variant = process.env.SCAN_RUNTIME === 'simd' ? 'simd' : 'scalar';
const filename = path.resolve('public/scan-wasm-' + variant + '.js');
const native = new Module(filename);
native.filename = filename;
native.paths = Module._nodeModulePaths(path.dirname(filename));
native._compile(fs.readFileSync(filename, 'utf8'), filename);
let resolveWait, searchResolve, info = [], fatal;
const ready = new Promise(resolve => { resolveWait = resolve; });
const mod = await native.exports({
  noInitialRun: true,
  print: line => {
    if (line === 'ready') resolveWait();
    if (line.startsWith('info')) info.push(line);
    if (line.startsWith('done')) searchResolve?.({ done: line, infos: info });
  },
  printErr: line => { if (line.startsWith('error')) fatal = line; },
});
const bitbases = (await import('../../src/bitbases-data.js')).default;
mod.FS.mkdirTree('/data');
mod.FS.writeFile('/data/eval', fs.readFileSync('public/scan_normal.data').subarray(0, 8503280));
mod.FS.writeFile('/data/book', fs.readFileSync('public/scan-book.bin'));
for (const [name, text] of Object.entries(bitbases)) {
  mod.FS.mkdirTree('/' + path.dirname(name));
  mod.FS.writeFile('/' + name, Buffer.from(text, 'base64'));
}
mod._main(0, 0);
const send = text => mod.ccall('scan_command', null, ['string'], [text]);
send('hub');
send('set-param name=tt-size value=22');
send('set-param name=bb-size value=4');
send('set-param name=book value=false');
send('init');
await ready;

const run = (position, d) => new Promise((resolve, reject) => {
  info = [];
  const timer = setTimeout(() => reject(Error('timeout')), 12000);
  searchResolve = r => { clearTimeout(timer); resolve(r); };
  send('pos ' + position);
  send(`level depth=${d} move-time=4`);
  send('go analyze');
});

async function search({ position, depth: d = depth }) {
  send('new-game');
  const result = await run(position, d);
  const last = result.infos.at(-1) || '';
  const score = Number((last.match(/\bscore=([-\d.]+)/) || [])[1]);
  const pv = (last.match(/pv="([^"]*)"/) || [])[1];
  return {
    move: result.done.match(/\bmove=([^ ]+)/)?.[1] || pv?.split(/\s+/)[0] || null,
    infos: [{ score, depth: Number((last.match(/\bdepth=(\d+)/) || [])[1]), pv: pv ? pv.split(/\s+/) : [] }],
  };
}

const out = { depth, target, levels: {}, fatal };
for (const level of levels) {
  const started = Date.now();
  const accepted = [];
  const stats = { attempted: 0, accepted: 0, rejected: {}, scanChecked: 0 };
  while (accepted.length < target && stats.attempted < maxAttempts) {
    const result = await generateVerified(db.entries, {
      level, attempts: 4, search, depth, minScore: 1.5, seed: 1000 + stats.attempted * 7919,
    });
    stats.attempted += result.stats.attempted;
    stats.accepted += result.stats.accepted;
    stats.scanChecked += result.stats.scanChecked;
    for (const [cause, count] of Object.entries(result.stats.rejected)) stats.rejected[cause] = (stats.rejected[cause] || 0) + count;
    if (result.candidate) accepted.push({ origin: result.candidate.origin, pieces: result.candidate.nb_pieces_blanc + result.candidate.nb_pieces_noir, added: result.candidate.added.length, value: result.candidate.scan?.value, gap: result.candidate.scan?.gap });
  }
  out.levels[level] = {
    accepted: accepted.length,
    attempted: stats.attempted,
    scanChecked: stats.scanChecked,
    acceptancePerScan: +(accepted.length / Math.max(1, stats.scanChecked)).toFixed(3),
    ms: Date.now() - started,
    medianValue: accepted.map(a => a.value).sort((a, b) => a - b)[Math.floor(accepted.length / 2)],
    medianGap: accepted.map(a => a.gap).sort((a, b) => a - b)[Math.floor(accepted.length / 2)],
    pieces: accepted.map(a => a.pieces),
    added: accepted.map(a => a.added),
    rejects: Object.entries(stats.rejected).sort((a, b) => b[1] - a[1]).slice(0, 6),
  };
}
fs.writeFileSync(process.env.OUT || 'perf/combinaisons/generation-measure.json', JSON.stringify(out, null, 2));
console.log(JSON.stringify(out, null, 2));
