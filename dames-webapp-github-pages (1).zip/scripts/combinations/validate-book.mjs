/**
 * Validation par rejeu des combinaisons extraites, avec suivi d'identité des pièces.
 * Le suivi permet de vérifier la « herkomst » : la case d'origine de la première
 * pièce adverse prise dans la rafle finale, et son trajet réel.
 */
import fs from 'node:fs';
import path from 'node:path';
import { generateLegalMoves, applyMove, sideOf, moveToHub } from '../../src/game-rules.js';

const MOVE = /^\s*(?:(?<num>\d{1,2})\.{1,3}\s*)?(?<from>\d{1,2})(?<sep>[-x])(?<to>\d{1,2})(?<chain>(?:\s*[x]\s*\d{1,2})*)\s*(?<suffix>[!?*]+)?/;

export function stripNoise(text) {
  return String(text || '')
    .split('•')[0]
    .replace(/[·]/g, ' ')
    .replace(/\u00a0/g, ' ')
    .replace(/[–—]/g, '-');
}

/** Découpe en coups ; supprime les variantes entre parenthèses et s'arrête au commentaire. */
export function tokenize(text) {
  const s = stripNoise(text).replace(/\s+/g, ' ');
  let depth = 0;
  let buffer = '';
  for (const ch of s) {
    if (ch === '(') { depth += 1; continue; }
    if (ch === ')') { depth = Math.max(0, depth - 1); continue; }
    if (depth) continue;
    buffer += ch;
    if (buffer.length > 500) break;
  }
  let rest = buffer;
  const moves = [];
  while (rest.trim()) {
    const m = MOVE.exec(rest);
    if (!m) break;
    const { from, sep, to, chain, suffix } = m.groups;
    moves.push({
      from: Number(from),
      to: Number(to),
      sep,
      squares: [Number(from), Number(to), ...((chain || '').match(/\d{1,2}/g) || []).map(Number)],
      raw: m[0].trim(),
      suffix: suffix || '',
    });
    rest = rest.slice(m[0].length);
  }
  return { moves, tail: rest.trim() };
}

function matchMove(legal, token) {
  const candidates = legal.filter(m => m.from === token.from && m.to === token.to);
  if (!candidates.length) return null;
  if (token.squares.length > 2) {
    const full = candidates.find(m => m.captured.length === token.squares.length - 2);
    if (full) return full;
  }
  return candidates[0];
}

/** Rejeu avec suivi des identifiants de pièces (case de départ au diagramme). */
export function replay(board, side, tokens) {
  let current = board.slice();
  let ids = board.map((p, i) => (p !== 'e' ? i : 0));
  let turn = side;
  const played = [];
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    if (sideOf(current[token.from]) !== turn) {
      return { ok: false, played, failedAt: i, reason: `pièce ${turn} absente en ${token.from}`, board: current, turn };
    }
    const legal = generateLegalMoves(current, turn);
    const move = matchMove(legal, token);
    if (!move) return { ok: false, played, failedAt: i, reason: `coup illégal ${token.raw}`, board: current, turn };
    if (token.sep === 'x' && !move.captured.length) return { ok: false, played, failedAt: i, reason: `prise annoncée sans prise ${token.raw}`, board: current, turn };
    if (token.sep === '-' && move.captured.length) return { ok: false, played, failedAt: i, reason: `prise obligatoire ignorée ${token.raw}`, board: current, turn };
    const capturedIds = move.captured.map(sq => ids[sq]);
    const moverId = ids[move.from];
    current = applyMove(current, move);
    ids = ids.slice();
    ids[move.from] = 0;
    for (const sq of move.captured) ids[sq] = 0;
    ids[move.to] = moverId;
    played.push({
      ...move,
      hub: moveToHub(move),
      raw: token.raw,
      side: turn,
      movedId: moverId,
      capturedIds,
      path: move.path.slice(),
    });
    turn = turn === 'w' ? 'b' : 'w';
  }
  return { ok: true, played, board: current, turn, ids };
}

export function routeOf(move) { return [move.from, ...move.path.slice(1)]; }

/** Trajectoire observée d'une pièce identifiée, depuis son départ au diagramme. */
export function trajectoryOf(played, id) {
  const squares = [];
  for (const m of played) if (m.movedId === id) squares.push(m.to);
  return squares;
}

const HEADER_ROUTE = /(?:slagroute|(?<!slag)route)\s*:\s*([0-9x.\u2026\s]+?)(?=herkomst|$)/i;
const HEADER_ORIGIN = /herkomst[^:]*:\s*([^\n]+)/i;

export function parseHeader(raw) {
  const text = String(raw || '').replace(/\n/g, ' ');
  const route = HEADER_ROUTE.exec(text);
  const origin = HEADER_ORIGIN.exec(text);
  const flags = [];
  for (const flag of ['lang', 'kort', 'met kaats', 'ad libitum']) {
    if (new RegExp(`\\b${flag}\\b`, 'i').test(text)) flags.push(flag);
  }
  const o = (origin ? origin[1] : '').trim();
  let type = null;
  if (/via dam op\s*\d{1,2}/i.test(o)) type = 'via_dame';
  else if (/^\d{1,2}\s*\(\s*-/i.test(o)) type = 'sans_prise';
  else if (/^\d{1,2}\s*\(\s*x/i.test(o)) type = 'trajet';
  else if (/^\d{1,2}/i.test(o)) type = 'cases';
  let cases = [];
  if (type === 'cases' || /\bof\b/i.test(o)) {
    cases = [...o.matchAll(/(\d{1,2})(?=\s*(?:of|,|\(|$))/g)].map(m => Number(m[1]));
  }
  return {
    raw: text.slice(0, 200),
    route_squares: route ? (route[1].match(/\d{1,2}/g) || []).map(Number) : [],
    route_truncated: route ? /\.\.\.|\u2026/.test(route[1]) : false,
    origin_text: o,
    origin_type: type,
    origin_cases: cases,
    origin_first: (o.match(/\d{1,2}/) || [])[0] ? Number((o.match(/\d{1,2}/) || [])[0]) : null,
    flags,
  };
}

function pointOf(square) {
  const row = Math.floor((square - 1) / 5);
  const col = (square - 1) % 5 * 2 + (row % 2 === 0 ? 1 : 0);
  return { row, col };
}
function onSameLine(a, b, c) {
  const A = pointOf(a), B = pointOf(b), C = pointOf(c);
  const d1 = { r: B.row - A.row, c: B.col - A.col };
  const d2 = { r: C.row - B.row, c: C.col - B.col };
  return Math.abs(d1.r) === Math.abs(d1.c) && Math.abs(d2.r) === Math.abs(d2.c)
    && Math.sign(d1.r) === Math.sign(d2.r) && Math.sign(d1.c) === Math.sign(d2.c);
}

/** La route du livre est une sous-séquence ordonnée du trajet réel, à partir du départ. */
function routeMatches(bookRoute, path) {
  if (!bookRoute.length) return false;
  if (bookRoute[0] !== path[0]) return false;
  let index = 0;
  for (let i = 1; i < bookRoute.length; i += 1) {
    const at = path.indexOf(bookRoute[i], index + 1);
    if (at < 0) return false;
    index = at;
  }
  return true;
}

function originMatches(header, originSquare, trajectory) {
  if (header.origin_type === 'via_dame') {
    return trajectory[trajectory.length - 1] === header.origin_first;
  }
  if (header.origin_cases.length) return header.origin_cases.includes(originSquare);
  return header.origin_first === originSquare;
}

export function buildDatabase(extractionPath, outPath, reportPath) {
  const data = JSON.parse(fs.readFileSync(extractionPath, 'utf8'));
  const accepted = [];
  const rejected = [];
  const byCause = {};
  const bump = cause => { byCause[cause] = (byCause[cause] || 0) + 1; };
  for (const entry of data.entries) {
    const board = entry.board.slice();
    // Les dernières pages sont l'index imprimé du livre (renvois abrégés, numéro à 4 chiffres).
    if (/\d+x\d+\.\./.test(entry.text || '') || /\n\s*\d{4}\s*$/.test(entry.text || '')) {
      rejected.push({ id: entry.id, page: entry.page, cause: 'renvoi d’index (annexe)', excerpt: (entry.text || '').slice(0, 60) });
      bump('renvoi d’index (annexe)');
      continue;
    }
    const { moves, tail } = tokenize(entry.text || '');
    if (!moves.length) {
      rejected.push({ id: entry.id, page: entry.page, cause: entry.text?.trim() ? 'aucun coup reconnu' : 'texte absent' });
      bump(entry.text?.trim() ? 'aucun coup reconnu' : 'texte absent');
      continue;
    }
    const attempts = ['w', 'b'].map(side => ({ side, ...replay(board, side, moves) }));
    const full = attempts.find(a => a.ok);
    const best = full || attempts.sort((a, b) => b.played.length - a.played.length)[0];
    if (!full) {
      const cause = best.played.length ? `illicite après ${best.played.length} coups : ${best.reason}` : best.reason;
      rejected.push({ id: entry.id, page: entry.page, cause, excerpt: (entry.text || '').slice(0, 80) });
      bump(cause.replace(/\d+/g, 'N').slice(0, 60));
      continue;
    }
    const side = full.side;
    const whiteCaptures = full.played.filter(m => m.side === 'w' && m.captured.length);
    if (!whiteCaptures.length) {
      rejected.push({ id: entry.id, page: entry.page, cause: 'solution partielle : aucune prise blanche écrite', excerpt: (entry.text || '').slice(0, 80) });
      bump('solution partielle (eindslag non écrit)');
      continue;
    }
    const headers = (entry.page_headers || []).map(h => ({ ...parseHeader(h.text), y: h.y, text: h.text }));
    if (entry.header_raw && !headers.some(h => h.text === entry.header_raw)) {
      headers.push({ ...parseHeader(entry.header_raw), y: null, text: entry.header_raw });
    }
    const withRoute = headers.filter(h => h.route_squares.length);
    let chosenCapture = null;
    let matchedHeader = null;
    let bestRank = -1;
    for (const capture of [...whiteCaptures].reverse()) {
      const path = routeOf(capture);
      const originSquare = capture.capturedIds[0] || capture.captured[0];
      const trajectory = trajectoryOf(full.played, capture.capturedIds[0]);
      for (const header of withRoute) {
        if (!routeMatches(header.route_squares, path)) continue;
        const rank = originMatches(header, originSquare, trajectory) ? 2 : 1;
        if (rank > bestRank) { bestRank = rank; chosenCapture = capture; matchedHeader = header; }
      }
      if (bestRank === 2) break;
    }
    if (!chosenCapture) {
      // Repli mesuré : la rafle qui prend le plus de pièces, la plus tardive en cas d'égalité.
      chosenCapture = whiteCaptures.reduce((best, m) => {
        if (m.captured.length !== best.captured.length) return m.captured.length > best.captured.length ? m : best;
        return full.played.indexOf(m) > full.played.indexOf(best) ? m : best;
      });
    }
    const path = routeOf(chosenCapture);
    const firstCapturedId = chosenCapture.capturedIds[0];
    const originSquare = firstCapturedId || chosenCapture.captured[0];
    const originTrajectory = trajectoryOf(full.played, firstCapturedId);
    const mismatch = [];
    if (withRoute.length && !matchedHeader) mismatch.push('route du livre non retrouvée');
    if (matchedHeader) {
      if (matchedHeader.route_squares[0] !== path[0]) mismatch.push('départ de route');
      if (!originMatches(matchedHeader, originSquare, originTrajectory)) mismatch.push('herkomst');
    }
    // La combinaison s'arrête à l'eindslag indexé ; la suite de la partie est conservée à part.
    const endIndex = full.played.indexOf(chosenCapture) + 1;
    const solution = full.played.slice(0, endIndex);
    const continuation = full.played.slice(endIndex);
    accepted.push({
      id: entry.id,
      page: entry.page,
      part: entry.part,
      layout: entry.layout,
      board,
      trait: side,
      position: `W:${board.map((p, i) => (p === 'w' ? i : 0)).filter(Boolean).join(',')}:B${board.map((p, i) => (p === 'b' ? i : 0)).filter(Boolean).join(',')}`,
      solution: solution.map(m => m.hub),
      solution_detail: solution.map(m => ({ from: m.from, to: m.to, path: m.path, captured: m.captured, side: m.side })),
      solution_pretty: solution.map(m => `${m.from}${m.captured.length ? 'x' : '-'}${m.to}`),
      continuation: continuation.map(m => m.hub),
      full_line: full.played.map(m => m.hub),
      eindslag_index: endIndex - 1,
      rafle_depart: path[0],
      rafle_identique: chosenCapture.captured[0] === chosenCapture.to,
      rafle_livre: matchedHeader ? matchedHeader.route_squares : [],
      rafle_complete: path,
      rafle_prises: chosenCapture.captured,
      rafle_source: matchedHeader ? 'en-tête du livre' : 'rejeu (prise maximale)',
      herkomst_type: matchedHeader ? matchedHeader.origin_type : 'rejeu',
      herkomst_origine_texte: matchedHeader ? matchedHeader.origin_text : '',
      herkomst_case: originSquare,
      herkomst_trajet: originTrajectory,
      herkomst_trajet_livre: matchedHeader ? matchedHeader.origin_text : '',
      drapeaux: matchedHeader ? matchedHeader.flags : [],
      header_match: matchedHeader ? (mismatch.length ? 'partiel' : 'concordant') : 'aucun',
      header_mismatch: mismatch,
      source: (entry.text || '').split('\n').slice(-1)[0].slice(0, 160),
      nb_pieces_blanc: board.filter(p => p === 'w' || p === 'W').length,
      nb_pieces_noir: board.filter(p => p === 'b' || p === 'B').length,
      text_tail: tail.slice(0, 80),
      recognition_issues: entry.recognition_issues,
    });
  }
  const index = {};
  for (let s = 1; s <= 50; s += 1) index[s] = [];
  for (const item of accepted) index[item.rafle_depart].push(item.id);
  const payload = {
    format: 'pcblues-combinations-v1',
    personalUseOnly: true,
    notice: 'Extrait de PC Blues deel 66 (Gerrit Boom). Usage personnel uniquement ; ne pas redistribuer.',
    sources: data.sources,
    stats: { diagrams: data.entries.length, accepted: accepted.length, rejected: rejected.length },
    index,
    entries: accepted,
    rejected,
  };
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify(payload));
  const summary = {
    diagrams: data.entries.length,
    accepted: accepted.length,
    rejected: rejected.length,
    header: accepted.reduce((acc, e) => { acc[e.header_match] = (acc[e.header_match] || 0) + 1; return acc; }, {}),
    causes: byCause,
    pages: [Math.min(...accepted.map(e => e.page)), Math.max(...accepted.map(e => e.page))],
    departures: Object.fromEntries(Object.entries(index).filter(([, v]) => v.length).map(([k, v]) => [k, v.length])),
  };
  if (reportPath) fs.writeFileSync(reportPath, JSON.stringify(summary, null, 2));
  return { payload, summary };
}

if (process.argv[1] && import.meta.url.endsWith(path.basename(process.argv[1]))) {
  const [, , input, output, report] = process.argv;
  const { summary } = buildDatabase(input, output, report);
  console.log(JSON.stringify(summary, null, 2));
}
