/** Réduit la base validée au strict nécessaire pour l’application (privée). */
import fs from 'node:fs';

const src = JSON.parse(fs.readFileSync('data/combinaisons/combinations-full.json', 'utf8'));
const keep = entry => ({
  id: entry.id,
  page: entry.page,
  board: entry.board,
  trait: entry.trait,
  solution: entry.solution,
  solution_pretty: entry.solution_pretty,
  rafle_depart: entry.rafle_depart,
  rafle_complete: entry.rafle_complete,
  rafle_livre: entry.rafle_livre,
  rafle_prises: entry.rafle_prises,
  rafle_source: entry.rafle_source,
  herkomst_type: entry.herkomst_type,
  herkomst_origine: entry.herkomst_origine_texte,
  herkomst_case: entry.herkomst_case,
  herkomst_trajet: entry.herkomst_trajet,
  drapeaux: entry.drapeaux,
  header_match: entry.header_match,
  source: entry.source,
  nb_pieces_blanc: entry.nb_pieces_blanc,
  nb_pieces_noir: entry.nb_pieces_noir,
});
const entries = src.entries.map(keep);
const payload = {
  format: 'pcblues-app-v1',
  personalUseOnly: true,
  notice: src.notice,
  stats: src.stats,
  index: src.index,
  entries,
};
const out = 'public/combinations-app.json';
fs.writeFileSync(out, JSON.stringify(payload));
const bytes = fs.statSync(out).size;
console.log(JSON.stringify({
  entries: entries.length,
  bytes,
  mib: +(bytes / 1048576).toFixed(2),
  departures: Object.values(src.index).filter(v => v.length).length,
  rafle_source: entries.reduce((a, e) => { a[e.rafle_source] = (a[e.rafle_source] || 0) + 1; return a; }, {}),
  header: entries.reduce((a, e) => { a[e.header_match] = (a[e.header_match] || 0) + 1; return a; }, {}),
  solution_lengths: entries.reduce((a, e) => { const k = e.solution.length; a[k] = (a[k] || 0) + 1; return a; }, {}),
}, null, 2));
