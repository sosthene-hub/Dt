import assert from 'node:assert/strict';
import fs from 'node:fs';
import {trial,rng,verify,validateConfig,isCalm,replay,matches} from '../src/generator-core.js';
import {createInitialBoard,generateLegalMoves,applyMove} from '../src/game-rules.js';
const c={root:Array(51).fill('e'),empty:[],count:20,side:'w',carrier:'w'};
validateConfig(c);assert(isCalm(createInitialBoard()));
assert.throws(()=>validateConfig({...c,count:21}));
const root=c.root.slice();root[31]='w';assert.throws(()=>validateConfig({...c,root,empty:[31]}));
assert.throws(()=>validateConfig({...c,root,count:0}));
let b=createInitialBoard();const m=generateLegalMoves(b,'w')[0];b=applyMove(b,m);assert(!matches(b,'b',c));
assert.throws(()=>replay(['1-50']));
let attempts=0,conforming=0,nontrivial=0;const random=rng(20261018);const lines=[];
for(const count of [20,18,16])for(let i=0;i<100;i++){
 attempts++;const cfg={...c,count};const p=trial(cfg,random,180);if(p){assert(verify(p,cfg));conforming++;if(p.line.length)nontrivial++;lines.push(p);const bad={...p,line:['1-50',...p.line]};assert.throws(()=>verify(bad,cfg));}}
assert(nontrivial>0);
const p=lines.find(p=>p.line.length);const drawn=p.board.map((v,n)=>n%4===0?v:'e');const empty=p.board.map((v,n)=>v==='e'&&n>0?n:0).filter(Boolean).slice(0,3);const cfg={...c,count:p.board.filter(v=>v==='w').length,root:drawn,empty,side:p.side};assert(verify(p,cfg));assert(!verify(p,{...cfg,empty:[p.board.findIndex(v=>v==='w')]}));
const report={attempts,conforming,nontrivial,fixtures:lines.length};fs.writeFileSync('generator-test-results.json',JSON.stringify(report,null,2));console.log(report);
