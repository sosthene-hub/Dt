import { chromium } from 'playwright';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';const autonomeUrl=process.env.BASE_URL||pathToFileURL(new URL('../Dames-autonome.html',import.meta.url).pathname).href;

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, offline: true });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(String(error)));
await page.route('**/*', route => {
  const url = route.request().url();
  if (/^(file|blob|data):/.test(url)) return route.continue();
  return route.abort();
});
await page.goto(autonomeUrl);
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });
async function nav(id) { await page.click('#menu-toggle'); await page.click(`[data-page="${id}"]`); }

const report = { mode: 'Chromium, file://, réseau coupé, 412×915' };

report.navigation = await page.evaluate(() => [...document.querySelectorAll('.nav-item')].map(node => node.dataset.page));
if (report.navigation.includes('creer')) throw Error('L’écran « Créer une partie » est encore présent');
if (report.navigation.includes('retro') || report.navigation.includes('recherche')) throw Error('Anciens écrans encore présents');

// 1. Analyse : Scan doit répondre tout de suite.
await nav('analyse');
await page.selectOption('#an-depth', '12');
await page.uncheck('#an-auto');
await page.click('#an-evaluate');
await page.waitForFunction(() => (document.querySelector('#an-score')?.textContent || '—').trim() !== '—', null, { timeout: 60000 });
report.analyse = {
  score: (await page.locator('#an-score').textContent()).trim(),
  meta: (await page.locator('#an-meta').textContent()).trim(),
};

// 2. Scan contre Scan : mémoire choisie, série complète.
await nav('scan-vs-scan');
const memoryOptions = await page.$$eval('#svs-mem option', nodes => nodes.map(node => `${node.value}:${node.textContent.trim()}`));
report.scanVsScan = { memoryOptions };
await page.selectOption('#svs-mem', '64');
await page.selectOption('#svs-a-depth', '3');
await page.selectOption('#svs-b-depth', '2');
await page.selectOption('#svs-a-time', '500');
await page.selectOption('#svs-b-time', '200');
await page.selectOption('#svs-games', '1');
await page.fill('#svs-speed', '0');
await page.click('#svs-start-btn');
await page.waitForFunction(() => /Série terminée/.test(document.querySelector('#svs-status')?.textContent || ''), null, { timeout: 300000 });
report.scanVsScan.status = (await page.locator('#svs-status').textContent()).trim();
report.scanVsScan.plies = await page.locator('#svs-moves button').count();
report.scanVsScan.score = (await page.locator('#svs-score').textContent()).trim();
await page.screenshot({ path: '/home/user/perf/scan-vs-scan-apres-correctif.png', fullPage: true });

// 3. Retour à l'analyse : le moteur partagé doit revenir après la libération mémoire.
await nav('analyse');
await page.click('#an-evaluate');
await page.waitForFunction(() => (document.querySelector('#an-score')?.textContent || '—').trim() !== '—', null, { timeout: 90000 });
report.analyseApresScanVsScan = (await page.locator('#an-score').textContent()).trim();

// 4. Combinaisons avec vérification Scan.
await nav('combinaisons');
await page.waitForFunction(() => /combinaisons validées/.test(document.querySelector('#cb-db')?.textContent || ''), null, { timeout: 30000 });
await page.selectOption('#cb-level', '2');
await page.selectOption('#cb-scan-depth', '12');
await page.click('#cb-generate');
await page.waitForFunction(() => {
  const panel = document.querySelector('#cb-exercise');
  return (panel && !panel.hidden && document.querySelector('#cb-exercise')?.dataset.solution)
    || /^Échec/.test(document.querySelector('#cb-generate-status')?.textContent || '');
}, null, { timeout: 180000 });
report.combinaisons = {
  meta: (await page.locator('#cb-meta').textContent()).trim(),
  status: (await page.locator('#cb-generate-status').textContent()).trim(),
};
if (!/PIONICIDE d12/.test(report.combinaisons.meta)) throw Error('La vérification par le moteur n’a pas eu lieu dans les combinaisons');

// 5. Retour au jeu : le moteur doit rejouer après la libération des combinaisons.
await nav('jouer');
await page.click('#game-new');
await page.click('#game-board [data-square="34"]');
await page.click('#game-board [data-square="30"]');
await page.waitForFunction(() => document.querySelectorAll('#game-history button').length >= 2, null, { timeout: 90000 });
report.jeu = (await page.locator('#game-history').textContent()).trim().slice(0, 40);

report.errors = errors;
fs.writeFileSync('perf/scan-disponible.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
if (errors.length) throw Error(errors.join('\n'));
await browser.close();
