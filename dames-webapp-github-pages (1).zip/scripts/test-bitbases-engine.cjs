// Browser-worker smoke test using a tiny local XMLHttpRequest shim in Node.
const fs = require('node:fs');
const path = require('node:path');
const { fileURLToPath } = require('node:url');
const workerFile = path.resolve(__dirname, '../public/scan-normal.worker.js');
global.self = global;
global.window = { encodeURIComponent, location: { pathname: workerFile } };
global.location = { pathname: workerFile };
global.self.location = { href: `file://${workerFile}` };
global.importScripts = () => {};
global.close = () => {};
global.onmessage = () => {};
const output = [];
let searchStage = 0;
let sawInfoLine = false;
const fixtures=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../bitbases-native-fixtures.json'),'utf8'));
const bitbases=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../src/bitbases-data.js'),'utf8').replace(/^export default /,'').replace(/;\s*$/,''));
let tested=0,lastScore=null;
function sendSearch(){const f=fixtures[tested];lastScore=null;global.onmessage({data:'pos pos='+(f.side==='w'?'W':'B')+f.board.slice(1).join('')});global.onmessage({data:'level depth=2'});global.onmessage({data:'go analyze'});}
global.postMessage=line=>{line=String(line);if(line==='wait'){global.onmessage({data:'set-param name=tt-size value=16'});global.onmessage({data:'set-param name=bb-size value=4'});global.onmessage({data:'init'});}if(line==='ready')setTimeout(sendSearch,0);if(line.startsWith('info')){const m=line.match(/score=([-+0-9.]+)/);if(m)lastScore=Number(m[1]);}
if(line.startsWith('done')){const f=fixtures[tested],expected=f.value===2?1:f.value===1?-1:0;console.log('fixture',tested+1,'wdl',f.value,'score',lastScore);const played=line.match(/move=([^ ]+)/)?.[1];if(!f.optimal.includes(played)){console.error('Optimal move mismatch',f,played,lastScore);process.exit(1);}tested++;if(tested===fixtures.length){clearTimeout(timeout);fs.writeFileSync(path.resolve(__dirname,'../bitbases-native-results.json'),JSON.stringify({compared:tested,depth:2,bbSize:4,passed:true},null,2));process.exit(0);}setTimeout(sendSearch,0);}};
global.XMLHttpRequest = class {
  open(_method, url) { this.url = url; }
  send() {
    const clean = decodeURIComponent(this.url.split('?')[0]);
    const file = path.resolve(path.dirname(workerFile), clean);
    try {
      const data = fs.readFileSync(file);
      this.status = 200;
      this.response = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      this.responseText = data.toString();
      setTimeout(() => this.onload?.(), 0);
    } catch (err) {
      this.status = 404; this.statusText = String(err); this.onerror?.(err);
    }
  }
};
const timeout = setTimeout(() => { console.error('Timeout: Scan did not return a move'); process.exit(1); }, 30000);
// Stage 2 (analyze mode) is scheduled from the stage-1 handler below.
require('node:vm').runInThisContext(fs.readFileSync(workerFile, 'utf8'), { filename: workerFile });
global.onmessage({data:{type:'bitbases',files:bitbases}});
global.onmessage({ data: 'hub' });
