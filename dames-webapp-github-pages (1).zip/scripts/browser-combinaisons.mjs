import fs from 'node:fs';
import { chromium } from 'playwright';

const BASE = process.env.COMB_BASE || 'http://localhost:4173/Dt/';
const DB = process.env.COMB_DB || 'public/combinations-app.json';
const OUT = process.env.COMB_OUT || 'perf/combinaisons/browser-niveaux.json';
const data = fs.readFileSync(DB, 'utf8');
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 412, height: 915 } });
const errors = [];
page.on('pageerror', error => errors.push(String(error)));
await page.addInitScript(db => { window.__COMBINATIONS__ = JSON.parse(db); }, data);
await page.goto(BASE, { waitUntil: 'domcontentloaded' });
const result = { base: BASE, levels: {}, errors, overflow: false };

async function openPage() {
  await page.click('#menu-toggle');
  await page.click('[data-page="combinaisons"]');
  await page.waitForSelector('#cb-route');
}
await openPage();
await page.waitForFunction(() => /Base embarquée|Base importée|non chargée/.test(document.querySelector('#cb-db')?.textContent || ''), { timeout: 30000 });
result.dbStatus = (await page.textContent('#cb-db')).trim();

async function runLevel(level, route, depth, timeout) {
  await page.selectOption('#cb-level', String(level));
  await page.selectOption('#cb-scan-depth', String(depth));
  await page.fill('#cb-route', route);
  const before = await page.evaluate(() => document.querySelector('#cb-exercise')?.dataset.exid || '0');
  await page.click('#cb-generate');
  await page.waitForFunction(prev => {
    const panel = document.querySelector('#cb-exercise');
    const status = document.querySelector('#cb-generate-status')?.textContent || '';
    return (panel && !panel.hidden && panel.dataset.exid !== prev) || /^Échec/.test(status);
  }, before, { timeout });
  result.lastStatus = (await page.textContent('#cb-generate-status')).trim();
  if (result.lastStatus.startsWith('Échec')) return { failed: result.lastStatus };
  const info = {
    meta: (await page.textContent('#cb-meta')).trim(),
    message: (await page.textContent('#cb-message')).trim(),
    moves: await page.$$eval('#cb-line button', nodes => nodes.map(n => n.textContent)),
    pieces: await page.$$eval('#cb-board .piece', nodes => nodes.length),
    status: (await page.textContent('#cb-status')).trim(),
  };
  // Coup joué par l’interface : la première pièce et sa case d’arrivée.
  const first = info.moves[0].replace(/^\d+\./, '');
  const parts = first.split(/[x-]/).map(Number);
  await page.click(`#cb-board [data-square="${parts[0]}"]`);
  await page.click(`#cb-board [data-square="${parts[1]}"]`);
  info.afterPlay = (await page.textContent('#cb-message')).trim();
  info.statusAfterPlay = (await page.textContent('#cb-status')).trim();
  // Résolution par l’interface : solution complète.
  await page.click('#cb-solution');
  info.afterSolution = (await page.textContent('#cb-status')).trim();
  info.activeMoves = await page.$$eval('#cb-line button.active', nodes => nodes.length);
  return info;
}

result.levels[1] = await runLevel(1, '25x', 0, 20000);
await page.screenshot({ path: 'perf/combinaisons/page-niveau1.png', fullPage: false });
result.levels[2] = await runLevel(2, '25x', 12, 120000);
await page.screenshot({ path: 'perf/combinaisons/page-niveau2.png' });
result.levels[3] = await runLevel(3, '', 12, 180000);
result.levels[4] = await runLevel(4, '', 0, 60000);
await page.fill('#cb-route', '99x');
await page.click('#cb-generate');
result.invalid = await page.evaluate(() => document.querySelector('#cb-message')?.textContent || '');
result.report = (await page.textContent('#cb-report')).trim();
result.overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
await browser.close();
fs.writeFileSync(OUT, JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
