/**
 * Réorganisation téléphone du « Damier d'analyse ».
 *
 * Vérifie, sur un vrai téléphone simulé (412×915) puis sur ordinateur (1180×900) :
 *   • la page principale ne contient que le damier, la ligne « Trait : … », la navigation
 *     de partie et la barre fixe de 5 actions ;
 *   • chaque panneau (Réglages, Position, Coups, Mauvais coups, Analyse, Outils) contient
 *     bien les options d'origine ;
 *   • un seul panneau ouvert à la fois, fermeture par ✕ / fond / Échap ;
 *   • l'état (profondeur, position, variante en cours) survit à la fermeture ;
 *   • les cibles tactiles font au moins 44 px ;
 *   • sur ordinateur, rien n'est masqué (le tiroir redevient un empilement).
 */
import assert from 'node:assert/strict';
import { chromium } from 'playwright';

const BASE = process.env.BASE_URL || 'http://127.0.0.1:5173/';
const SHOTS = process.env.SHOTS || '/tmp/qa';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2 });
const page = await context.newPage();
const errors = [];
page.on('pageerror', err => errors.push('pageerror: ' + err.message));
page.on('console', msg => { if (msg.type() === 'error') errors.push('console: ' + msg.text()); });

const visible = sel => page.locator(sel).first().isVisible();
const box = async sel => page.locator(sel).first().boundingBox();
const sheetOpen = () => page.locator('#an-sheet').evaluate(node => node.classList.contains('open'));
const openTab = async id => {
  if (!(await sheetOpen())) await page.click('#an-bar-analyse');
  await page.click(`#an-tab-${id}`);
  await page.waitForTimeout(120);
};

await page.goto(BASE, { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });
await page.click('#menu-toggle');
await page.click('[data-page="analyse"]');
await page.waitForTimeout(800);

/* ---------- 1. Page principale épurée ---------- */
assert.equal(await visible('.an-bottombar'), true, 'Barre fixe d’actions visible sur téléphone');
assert.equal(await page.locator('.an-bar-item').count(), 5, 'Cinq actions essentielles');
assert.deepEqual(
  await page.$$eval('.an-bar-item b', nodes => nodes.map(n => n.textContent.trim())),
  ['Coup conseillé', 'Annuler', 'Analyse', 'Outils', 'Menu'],
);
assert.equal(await page.locator('#an-tab-pieges').textContent(), 'Mauvais coups');

// Le damier occupe la largeur de l'écran et la page ne défile pas.
const board = await box('#analysis-board');
assert.ok(board.width >= 390, `Damier pleine largeur (${Math.round(board.width)} px)`);
assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth), false, 'Aucun débordement horizontal');
assert.equal(await page.evaluate(() => document.documentElement.scrollHeight <= window.innerHeight + 2), true, 'La page principale ne défile pas');

// Ligne compacte unique : « Trait : Blancs · 0,00 · prof. 16 · Prêt »
const statusText = (await page.locator('.an-status-line').innerText()).replace(/\s*\n\s*/g, ' ');
assert.match(statusText, /^Trait : (Blancs|Noirs).*(prof\.|Profondeur).*$/);
const statusHeight = (await box('.an-status-line')).height;
assert.ok(statusHeight <= 26, `Ligne d’état compacte (${Math.round(statusHeight)} px)`);

// Le reste est hors écran (caché) tant qu'on ne l'ouvre pas.
assert.equal(await page.locator('#manual-workshop').isVisible(), false, 'Feuille d’analyse masquée au départ');
assert.equal(await page.locator('#refutation-panel').isVisible(), false, 'Bloc mauvais coups masqué au départ');

// Cibles tactiles ≥ 44 px
for (const item of await page.locator('.an-bar-item').all()) {
  const b = await item.boundingBox();
  assert.ok(b.height >= 44, `Bouton ${await item.innerText()} ≥ 44 px`);
}
for (const sel of ['#an-first', '#an-prev', '#an-play', '#an-next', '#an-last', '#an-flip']) {
  const b = await box(sel);
  assert.ok(b.height >= 44, `Navigation ${sel} ≥ 44 px`);
}
await page.screenshot({ path: `${SHOTS}/phone-1-principal.png` });

/* ---------- 2. Contenu réellement présent dans chaque panneau ---------- */
const parentOf = sel => page.locator(sel).first().evaluate(node => node.closest('.an-sheet-panel')?.dataset.panel || null);

assert.equal(await parentOf('#an-depth'), 'reglages');
assert.equal(await parentOf('#an-auto'), 'reglages');
assert.equal(await parentOf('#an-score'), 'reglages');
assert.equal(await parentOf('#an-evaluate'), 'reglages');
assert.equal(await parentOf('#an-hint'), 'reglages');
assert.equal(await parentOf('#an-level'), 'reglages');

assert.equal(await parentOf('#an-edit'), 'position');
assert.equal(await parentOf('#an-reset'), 'position');
assert.equal(await parentOf('#an-print-position'), 'position');
assert.equal(await parentOf('#an-code'), 'position');
assert.equal(await parentOf('#an-copy'), 'position');

assert.equal(await parentOf('#played-moves'), 'coups');
assert.equal(await parentOf('#an-pv'), 'coups');
assert.equal(await parentOf('#pv-next'), 'coups');
assert.equal(await parentOf('#back-played'), 'coups');

assert.equal(await parentOf('#refutation-panel'), 'pieges');
assert.equal(await parentOf('#an-bad-moves'), 'pieges');

assert.equal(await parentOf('#manual-workshop'), 'analyse');
assert.equal(await parentOf('#man-print'), 'analyse');
assert.equal(await parentOf('#man-export-pdn'), 'analyse');
assert.equal(await parentOf('#an-annotate'), 'analyse');
assert.equal(await parentOf('#man-preview-card'), 'analyse');
assert.equal(await parentOf('#man-import-toggle'), 'analyse');

assert.equal(await parentOf('.threat-panel'), 'outils');
assert.equal(await parentOf('#tb-moves'), 'outils');
assert.equal(await parentOf('.an-links'), 'outils');

/* ---------- 3. Un seul panneau ouvert à la fois + captures ---------- */
for (const tab of ['reglages', 'position', 'coups', 'pieges', 'analyse', 'outils']) {
  await openTab(tab);
  const active = await page.$$eval('.an-sheet-panel', nodes => nodes.filter(n => getComputedStyle(n).display !== 'none').map(n => n.dataset.panel));
  assert.deepEqual(active, [tab], `Un seul panneau ouvert (${tab})`);
  assert.equal(await page.locator(`#an-tab-${tab}`).getAttribute('aria-selected'), 'true');
  assert.equal((await page.locator('#an-sheet-title').textContent()).length > 2, true, 'Titre du tiroir renseigné');
  await page.screenshot({ path: `${SHOTS}/phone-2-panneau-${tab}.png` });

  // Le damier n'est jamais détruit : il est simplement derrière le tiroir.
  assert.equal(await page.locator('#analysis-board svg, #analysis-board .cell').count() > 0, true, 'Damier toujours présent');
}

/* ---------- 4. Fermeture ✕ / fond / Échap, retour au damier ---------- */
await page.click('#an-sheet-close');
assert.equal(await sheetOpen(), false, '✕ ferme le panneau');
await openTab('outils');
await page.click('#an-sheet-backdrop', { position: { x: 200, y: 40 }, force: true });
assert.equal(await sheetOpen(), false, 'Toucher le fond ferme le panneau');
await openTab('coups');
await page.keyboard.press('Escape');
assert.equal(await sheetOpen(), false, 'Échap ferme le panneau');
assert.equal(await page.evaluate(() => document.body.classList.contains('an-sheet-lock')), false, 'Défilement rendu au damier');

/* ---------- 5. L'état est conservé à la fermeture ---------- */
await openTab('reglages');
await page.selectOption('#an-depth', '9');
await page.selectOption('#an-level', 'fort');
await page.click('#an-sheet-close');
await openTab('reglages');
assert.equal(await page.inputValue('#an-depth'), '9', 'Profondeur conservée');
assert.equal(await page.inputValue('#an-level'), 'fort', 'Niveau conservé');
assert.equal(await page.locator('#an-depth-mini').textContent(), 'prof. 9', 'Ligne compacte synchronisée');

// Une position jouée sur le damier survit à l'ouverture/fermeture des panneaux.
await page.click('#an-sheet-close');
await page.click('#analysis-board [data-square="34"]');
await page.click('#analysis-board [data-square="30"]');
await page.waitForTimeout(400);
const codeBefore = await page.inputValue('#an-code');
await openTab('analyse');
await page.click('#an-sheet-close');
assert.equal(await page.inputValue('#an-code'), codeBefore, 'Position conservée après ouverture/fermeture');
assert.equal(await page.locator('#an-bar-undo').isDisabled(), false, 'Annuler actif après un coup');
await page.click('#an-bar-undo');
await page.waitForTimeout(300);
assert.notEqual(await page.inputValue('#an-code'), codeBefore, 'Le bouton Annuler de la barre agit sur la position');

/* ---------- 6. Action qui exige le damier : le tiroir s'efface, sans rien perdre ---------- */
// Il faut un coup actif : le bouton « Autre coup… » est désactivé sur la position de départ.
await page.click('#analysis-board [data-square="34"]');
await page.click('#analysis-board [data-square="30"]');
await page.waitForTimeout(400);
await openTab('analyse');
await page.waitForTimeout(200);
assert.equal(await page.locator('#man-alt-move').isDisabled(), false, '« Autre coup… » actif sur un coup joué');
await page.click('#man-alt-move');
await page.waitForTimeout(350);
assert.equal(await sheetOpen(), false, '« Autre coup… » rend le damier accessible');
const beforeAlt = await page.inputValue('#an-code');
await page.click('#analysis-board [data-square="33"]');
await page.click('#analysis-board [data-square="28"]');
await page.waitForTimeout(600);
assert.notEqual(await page.inputValue('#an-code'), beforeAlt, 'Le coup a bien été joué sur le damier');
assert.equal(await page.locator('.an-main .manual-alt-banner').isVisible(), false, 'La consigne « jouez l’autre coup » disparaît une fois le coup joué');
await openTab('analyse');
assert.equal(await parentOf('#man-depth-badge'), 'analyse');
assert.match(await page.locator('#man-node-label').textContent(), /33-28|1\.33-28|\d+\.\d+/);
await page.screenshot({ path: `${SHOTS}/phone-3-retour-panneau.png` });

/* ---------- 7. Impression / PDF au-dessus du tiroir ---------- */
await page.click('#man-print');
await page.waitForSelector('#print-sheet', { timeout: 15000 });
assert.equal(await visible('#print-sheet'), true, 'Feuille imprimable affichée');
const printOnTop = await page.evaluate(() => {
  const sheet = document.querySelector('#print-sheet');
  const r = sheet.getBoundingClientRect();
  const top = document.elementFromPoint(r.width / 2, 40);
  return sheet.contains(top) || top === sheet;
});
assert.equal(printOnTop, true, 'La feuille imprimable passe au-dessus du tiroir');
assert.equal(await sheetOpen(), false, 'Le tiroir se referme avant l’impression');
await page.screenshot({ path: `${SHOTS}/phone-4-impression.png` });
await page.locator('#print-sheet').getByRole('button', { name: /Fermer|Fermer la feuille|✕/i }).first().click();
await page.waitForTimeout(200);
assert.equal(await page.locator('#print-sheet').count(), 0, 'Feuille imprimable refermée');

/* ---------- 8. Bloc « Mauvais coups » toujours déclenchable ---------- */
if (await sheetOpen()) await page.click('#an-sheet-close');
await page.click('#an-bar-outils'); // ouvre le tiroir sur Outils
await page.click('#an-tab-pieges');
await page.click('#an-bad-moves');
await page.waitForTimeout(600);
assert.match(await page.locator('#refutation-panel').innerText(), /A votre demande|à votre demande|Chercher les mauvais coups/i);
await page.screenshot({ path: `${SHOTS}/phone-5-pieges.png` });

/* ---------- 9. Ordinateur : interface d'origine, strictement inchangée ---------- */
const desktop = await context.newPage();
const desktopErrors = [];
desktop.on('pageerror', err => desktopErrors.push(err.message));
await desktop.setViewportSize({ width: 1180, height: 900 });
await desktop.goto(BASE, { waitUntil: 'domcontentloaded' });
await desktop.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });
await desktop.click('#menu-toggle');
await desktop.click('[data-page="analyse"]');
await desktop.waitForTimeout(900);
assert.equal(await desktop.locator('.an-shell').count(), 0, 'Aucun shell mobile sur ordinateur');
assert.equal(await desktop.locator('.an-sheet').count(), 0, 'Aucun tiroir sur ordinateur');
assert.equal(await desktop.locator('.an-bottombar').count(), 0, 'Aucune barre fixe sur ordinateur');
assert.equal(await desktop.locator('#manual-workshop').isVisible(), true, 'Feuille d’analyse visible sur ordinateur');
assert.equal(await desktop.locator('#refutation-panel').isVisible(), true, 'Bloc mauvais coups visible sur ordinateur');
assert.equal(await desktop.locator('.analysis-side').isVisible(), true, 'Colonne PIONICIDE latérale conservée sur ordinateur');
assert.equal(await desktop.locator('#an-edit').isVisible(), true, 'Boutons de position visibles sur ordinateur');
await desktop.screenshot({ path: `${SHOTS}/desktop-1-analyser.png`, fullPage: false });
await desktop.close();
assert.deepEqual(desktopErrors, [], `Erreurs console/page (ordinateur) : ${JSON.stringify(desktopErrors)}`);

/* ---------- 10. Aucune erreur console ---------- */
assert.deepEqual(errors, [], `Erreurs console/page : ${JSON.stringify(errors)}`);

await browser.close();
console.log('OK — Réorganisation téléphone : page principale épurée, 6 panneaux à la demande, état conservé, cibles ≥ 44 px, ordinateur inchangé.');
