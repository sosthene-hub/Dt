// Vérifie l'analyse des menaces de bout en bout dans un vrai navigateur :
// passage unique annotation + menaces, repères dans la liste des coups,
// flèches numérotées, récapitulatif, export PDN et feuille imprimable,
// portée à un seul camp, recalcul isolé, mémoire des résultats et mobile.
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080/';
const OUT = 'perf/threats';
fs.mkdirSync(OUT, { recursive: true });

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1180, height: 900 }, acceptDownloads: true, serviceWorkers: 'block' });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });

const report = { base: BASE, steps: [], errors };
const step = (name, detail = {}) => {
  report.steps.push({ name, ...detail });
  console.log('·', name, JSON.stringify(detail));
};

await page.goto(BASE, { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 90000 });

async function nav(id) {
  await page.evaluate(() => document.querySelector('#menu-toggle')?.click());
  await page.click(`[data-page="${id}"]`);
  await page.waitForTimeout(120);
}

// Page d'accueil : nom de l'application.
const brand = await page.textContent('.brand strong');
const title = await page.title();
assert.equal(brand.trim(), 'PIONICIDE');
assert.match(title, /PIONICIDE/);
step('marque renommée', { marque: brand.trim(), titre: title });

// Import de la partie d'exemple.
await nav('importer');
await page.click('#pdn-sample');
await page.waitForFunction(() => document.querySelectorAll('#played-moves button').length > 5, null, { timeout: 30000 });
const plies = await page.$$eval('#played-moves button', nodes => nodes.length - 1);
step('partie importée', { demiCoups: plies });

const renamedScan = await page.evaluate(() => document.body.innerText.includes('Scan'));
assert.equal(renamedScan, false, 'plus aucune mention de « Scan » à l’écran');
step('aucune mention de « Scan » dans l’interface', { ok: true });

if (await page.isChecked('#an-auto')) await page.uncheck('#an-auto');
await page.waitForFunction(() => document.querySelector('#an-status')?.textContent === 'Prêt', null, { timeout: 30000 });

// Passage unique : annotation + menaces à la profondeur 9.
await page.selectOption('#an-annot-depth', '9');
await page.check('#th-export');
assert.equal(await page.isChecked('#th-combine'), true, 'passage unique proposé par défaut');
const started = Date.now();
await page.click('#an-annotate');
await page.waitForFunction(() => /Passage unique|coups examinés/.test(document.querySelector('#an-annot-status')?.textContent || ''), null, { timeout: 600000 });
const seconds = Math.round((Date.now() - started) / 100) / 10;
const annotStatus = (await page.textContent('#an-annot-status')).trim();
const threatStatus = (await page.textContent('#th-status')).trim();
step('passage unique terminé', { secondes: seconds, annotation: annotStatus, menaces: threatStatus });
assert.match(annotStatus, /Passage unique/);
assert.match(threatStatus, /menaces/);

// Récapitulatif.
const counts = await page.$$eval('.threat-counts', nodes => nodes.map(node => node.textContent.trim()));
const top = await page.$$eval('.threat-top button', nodes => nodes.map(node => node.textContent.trim()));
step('récapitulatif', { counts, top });
assert.equal(counts.length, 2);
assert.ok(top.length >= 1 && top.length <= 3);

// Repères de la liste des coups.
const badges = await page.$$eval('#played-moves .threat-badge', nodes => nodes.map(node => node.className));
const created = badges.filter(name => name.includes('threat-created')).length;
const avoided = badges.filter(name => name.includes('threat-avoided')).length;
step('repères dans la liste', { created, avoided, total: badges.length });
assert.ok(badges.length > 0, 'au moins un repère de menace attendu');

// Clic sur un coup marqué : flèches numérotées et texte sous le damier.
const markedIndex = await page.evaluate(() => {
  const buttons = [...document.querySelectorAll('#played-moves button')];
  return buttons.findIndex(button => button.querySelector('.threat-badge')) - 1;
});
assert.ok(markedIndex >= 0);
await page.click(`#played-moves button:nth-child(${markedIndex + 2})`);
await page.waitForTimeout(150);
const overlay = await page.evaluate(() => ({
  arrows: document.querySelectorAll('#analysis-board svg.threat-arrows polyline').length,
  numbers: [...document.querySelectorAll('#analysis-board svg.threat-arrows text')].map(node => node.textContent),
  colours: [...document.querySelectorAll('#analysis-board svg.threat-arrows polyline')].map(node => node.getAttribute('stroke')),
  note: document.querySelector('#an-threat-note')?.textContent?.trim() || '',
  visible: document.querySelector('#an-threat-note')?.classList.contains('visible') || false,
}));
step('flèches du coup', { coup: markedIndex + 1, ...overlay });
assert.ok(overlay.arrows >= 1, 'des flèches attendues');
assert.ok(overlay.numbers.length === overlay.arrows);
assert.match(overlay.numbers[0], /^(1|2|3)$/);
assert.match(overlay.note, /(Menace créée|Menace évitée|Menace non calculable|Aucune menace réelle)/);
assert.ok(overlay.visible);
assert.ok(overlay.colours.every(colour => ['#2f9e5b', '#e08a1e', '#c0392b'].includes(colour)), JSON.stringify(overlay.colours));

// Recalcul isolé des deux repères sur le coup affiché.
await page.click('#th-created');
await page.waitForFunction(() => /recalculé|aucune menace|impossible/i.test(document.querySelector('#th-status')?.textContent || ''), null, { timeout: 120000 });
const singleCreated = (await page.textContent('#th-status')).trim();
await page.click('#th-avoided');
await page.waitForFunction(() => /recalculé|aucune menace|impossible/i.test(document.querySelector('#th-status')?.textContent || ''), null, { timeout: 120000 });
const singleAvoided = (await page.textContent('#th-status')).trim();
step('recalcul isolé', { created: singleCreated, avoided: singleAvoided });

// Bouton « Revenir à la partie » : les flèches disparaissent.
await page.click('#th-clear');
await page.waitForTimeout(120);
const arrowsAfterClear = await page.$$eval('#analysis-board svg.threat-arrows polyline', nodes => nodes.length);
assert.equal(arrowsAfterClear, 0);
step('flèches effacées', { arrows: arrowsAfterClear });

// Export PDN annoté avec menaces.
const [download] = await Promise.all([page.waitForEvent('download'), page.click('#an-export-pdn')]);
const pdnPath = path.resolve(OUT, 'partie-menaces.pdn');
await download.saveAs(pdnPath);
const pdn = fs.readFileSync(pdnPath, 'utf8');
const pdnCounts = {
  annotateur: (pdn.match(/\[Annotator "([^"]+)"\]/) || [])[1],
  threats: (pdn.match(/\[ThreatAnalysis "([^"]+)"\]/) || [])[1],
  commentairesMenace: (pdn.match(/\{ Menace (créée|évitée)/g) || []).length,
  profondeurMenace: (pdn.match(/\[ThreatDepth "(\d+)"\]/) || [])[1],
};
step('PDN exporté', pdnCounts);
assert.equal(pdnCounts.annotateur.startsWith('PIONICIDE'), true);
assert.equal(pdnCounts.threats, 'PIONICIDE');
assert.ok(pdnCounts.commentairesMenace > 0);
assert.equal(pdn.includes('Scan'), false, 'le PDN ne mentionne plus Scan');

// Réimport du PDN produit : tous les coups restent légaux.
await nav('importer');
await page.fill('#pdn-input', pdn);
await page.click('#pdn-load');
await page.waitForFunction(() => /demi-coups légaux|demi-coups lus/.test(document.querySelector('#pdn-status')?.textContent || ''), null, { timeout: 30000 });
const reimport = (await page.textContent('#pdn-status')).trim();
step('PDN réimporté', { statut: reimport });
assert.match(reimport, /131\/131 demi-coups légaux/);

// Mémoire : la même partie est restaurée sans recalcul.
const before = Date.now();
await nav('importer');
await page.click('#pdn-sample');
await page.waitForTimeout(400);
const restored = (await page.textContent('#an-annot-status')).trim();
const restoreMs = Date.now() - before;
step('résultats mémorisés', { ms: restoreMs, statut: restored });
assert.match(restored, /Résultats mémorisés/);
assert.equal(await page.isEnabled('#an-export-pdn'), true);

// Feuille imprimable : bloc « Menaces » et signature PIONICIDE.
await page.click('#an-print');
await page.waitForSelector('#print-sheet', { timeout: 15000 });
const sheet = await page.evaluate(() => ({
  threats: document.querySelectorAll('#print-sheet .note-threat').length,
  title: document.querySelector('#print-sheet .sheet-section')?.textContent?.trim() || '',
  meta: document.querySelector('#print-sheet .sheet-meta')?.textContent?.trim() || '',
  foot: document.querySelector('#print-sheet .sheet-foot')?.textContent?.trim() || '',
  diagrams: document.querySelectorAll('#print-sheet .diagram').length,
}));
step('feuille imprimable', sheet);
assert.equal(sheet.title, 'Menaces de la partie');
assert.ok(sheet.threats > 0);
assert.match(sheet.foot, /Partie analysée par PIONICIDE/);
await page.click('#print-sheet .sheet-toolbar button:last-of-type');
await page.waitForTimeout(100);

// Portée : coups des Blancs seulement.
await page.selectOption('#th-scope', 'w');
await page.click('#th-run');
await page.waitForFunction(() => /coups examinés/.test(document.querySelector('#th-status')?.textContent || ''), null, { timeout: 600000 });
const whiteOnly = await page.evaluate(() => ({
  status: document.querySelector('#th-status').textContent.trim(),
  recap: [...document.querySelectorAll('.threat-counts')].map(node => node.textContent.trim()),
  badges: document.querySelectorAll('#played-moves .threat-badge').length,
}));
step('portée Blancs seulement', whiteOnly);
// 131 demi-coups : 66 coups des Blancs (les Blancs ouvrent la partie).
assert.match(whiteOnly.status, /66 coups examinés/);
assert.ok(whiteOnly.badges > 0);

// Plage de coups.
await page.selectOption('#th-scope', 'range');
await page.fill('#th-from', '2');
await page.fill('#th-to', '4');
await page.click('#th-run');
await page.waitForFunction(() => /coups examinés/.test(document.querySelector('#th-status')?.textContent || ''), null, { timeout: 600000 });
const ranged = (await page.textContent('#th-status')).trim();
step('portée par plage', { statut: ranged });
// Coups n°2 à n°4 : trois coups complets, soit six demi-coups.
assert.match(ranged, /6 coups examinés/);

// Mobile : aucun débordement horizontal.
await page.setViewportSize({ width: 412, height: 915 });
await page.waitForTimeout(300);
const overflow = await page.evaluate(() => ({
  scroll: document.documentElement.scrollWidth,
  client: document.documentElement.clientWidth,
  panel: document.querySelector('.threat-panel')?.getBoundingClientRect().width,
}));
step('mobile 412×915', overflow);
assert.ok(overflow.scroll <= overflow.client + 1, `débordement ${overflow.scroll} > ${overflow.client}`);
fs.writeFileSync(path.resolve(OUT, 'rapport.json'), JSON.stringify(report, null, 2));
assert.deepEqual(errors, [], `erreurs JavaScript : ${errors.join(' | ')}`);
await browser.close();
console.log('Analyse des menaces :', report.steps.length, 'étapes, aucune erreur JavaScript.');
