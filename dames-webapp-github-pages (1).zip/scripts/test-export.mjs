// Vérifie l'annotation et l'export PDN sans navigateur : seuils, formatage des
// variantes et aller-retour PDN annoté → relecture par le parseur de l'application.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { classifyLoss, formatEval, moveNumberOf, withPlayedMoves, DEFAULT_THRESHOLDS } from '../src/analysis/annotate.js';
import { buildAnnotatedPdn, formatVariation, normaliseHeaders } from '../src/analysis/export.js';
import { parsePdnGames, replayPdnGame, moveToPdn } from '../src/pdn.js';
import { sheetModel, positionCaption } from '../src/analysis/print-sheet.js';

const tests = [];
const test = (name, fn) => tests.push({ name, fn });

test('seuils par défaut', () => {
  assert.deepEqual(DEFAULT_THRESHOLDS, { error: 0.5, blunder: 1.5 });
  assert.equal(classifyLoss(0, true), '!');
  assert.equal(classifyLoss(0, false), '');
  assert.equal(classifyLoss(0.49, false), '');
  assert.equal(classifyLoss(0.5, false), '?');
  assert.equal(classifyLoss(1.49, false), '?');
  assert.equal(classifyLoss(1.5, false), '??');
  assert.equal(classifyLoss(null, false), '');
});

test('seuils réglables', () => {
  const strict = { error: 1, blunder: 2.5 };
  assert.equal(classifyLoss(0.9, false, strict), '');
  assert.equal(classifyLoss(1.2, false, strict), '?');
  assert.equal(classifyLoss(2.6, false, strict), '??');
});

test('évaluations et numéros de coup', () => {
  assert.equal(formatEval(0), '±0,00');
  assert.equal(formatEval(1.5), '+1,50');
  assert.equal(formatEval(-0.45), '−0,45');
  assert.equal(formatEval(99), '+∞');
  assert.equal(moveNumberOf(0), 1);
  assert.equal(moveNumberOf(1), 1);
  assert.equal(moveNumberOf(2), 2);
});

const fixture = fs.readFileSync(new URL('../fixtures/Verpoest-Berte-1980.pdn', import.meta.url), 'utf8');
const game = parsePdnGames(fixture)[0];
const replay = replayPdnGame(game);
assert.equal(replay.problem, null, 'partie de test intégralement légale');
assert.ok(replay.moves.length > 100);

// Annotation synthétique : les deux premiers coups et un coup fautif, sans moteur.
const plies = replay.moves.map((move, index) => ({
  index,
  side: index % 2 === 0 ? 'w' : 'b',
  moveNumber: moveNumberOf(index),
  played: moveToPdn(move),
  best: moveToPdn(replay.moves[index]),
  symbol: index === 1 ? '??' : index === 4 ? '?' : index === 0 ? '!' : '',
  evalBeforeWhite: index % 2 === 0 ? 0.25 : -0.6,
  evalAfterWhite: index % 2 === 0 ? 0.4 : -0.5,
  loss: index === 1 ? 1.8 : index === 4 ? 0.7 : 0,
  pv: replay.moves.slice(index + 1, index + 4),
  depth: 12,
}));

test('variante numérotée', () => {
  // Un coup blanc est précédé de son numéro ; un coup noir suit sans numéro.
  assert.match(formatVariation(replay.moves.slice(0, 3), 4), /^3\. \d+-\d+ \d+-\d+ 4\. \d+-\d+$/);
  assert.match(formatVariation(replay.moves.slice(0, 3), 5), /^\d+-\d+ 4\. \d+-\d+ \d+-\d+$/);
  assert.equal(formatVariation([], 0), '');
});

test('withPlayedMoves neutralise la perte du meilleur coup', () => {
  const patched = withPlayedMoves({ plies }, replay.moves, DEFAULT_THRESHOLDS);
  for (const ply of patched) {
    if (ply.isBest) assert.equal(ply.loss, 0);
  }
  const fake = withPlayedMoves({ plies: [{ ...plies[1], best: '00-00', loss: 3 }] }, replay.moves, DEFAULT_THRESHOLDS);
  assert.equal(fake[0].symbol, '??');
});

test('en-têtes normalisés, valeurs par défaut', () => {
  const head = normaliseHeaders({ White: 'A "B"', Black: '' });
  assert.equal(head.White, "A 'B'");
  assert.equal(head.Black, 'Noirs');
  assert.equal(head.Site, 'Dames — entraînement local');
  assert.match(head.Date, /^\d{4}\.\d{2}\.\d{2}$/);
});

test('PDN annoté : intégral, relisible et identique coup pour coup', () => {
  const text = buildAnnotatedPdn({
    headers: game.headers,
    moves: replay.moves,
    plies,
    result: game.result,
    depth: 12,
    detail: 'errors',
    thresholds: DEFAULT_THRESHOLDS,
  });
  assert.match(text, /^\[Event /);
  assert.match(text, /\[White "Verpoest, Oscar"\]/);
  assert.match(text, /\[Result "2-0"\]/);
  assert.ok(text.trimEnd().endsWith('2-0'), 'le résultat ferme le fichier');
  assert.equal((text.match(/\{[^}]*prof\. 12 \}/g) || []).length, 2, 'commentaires sur les deux erreurs seulement');
  assert.equal((text.match(/\( /g) || []).length, 2, 'variantes sur les erreurs seulement');

  const reread = parsePdnGames(text)[0];
  assert.equal(reread.headers.White, game.headers.White);
  assert.equal(reread.headers.Date, game.headers.Date);
  assert.equal(reread.result, game.result);
  const again = replayPdnGame(reread);
  assert.equal(again.problem, null);
  assert.equal(again.moves.length, replay.moves.length);
  again.moves.forEach((move, index) => assert.equal(moveToPdn(move), moveToPdn(replay.moves[index])));
});

test('PDN annoté : partie complète annotée', () => {
  const full = plies.map(ply => ({ ...ply, symbol: ply.symbol || '', loss: ply.loss }));
  const text = buildAnnotatedPdn({
    headers: game.headers,
    moves: replay.moves,
    plies: full,
    result: game.result,
    depth: 16,
    detail: 'all',
    thresholds: { error: 0.4, blunder: 1.2 },
  });
  assert.equal((text.match(/\{[^}]*prof\. \d+ \}/g) || []).length, replay.moves.length);
  assert.match(text, /\[ExportDetail "all"\]/);
  assert.match(text, /\[ErrorThreshold "0.4"\]/);
  assert.equal(replayPdnGame(parsePdnGames(text)[0]).moves.length, replay.moves.length);
});

/* ---------- feuille imprimable : position ou partie, sans analyse ---------- */
test('modèle de feuille : deux coups par ligne', () => {
  const model = sheetModel(['34-29', '19-23', '40-34', '14-19', '32-28']);
  assert.equal(model.rows.length, 3);
  assert.deepEqual(model.rows[0], { n: 1, white: '34-29', black: '19-23' });
  assert.deepEqual(model.rows[2], { n: 3, white: '32-28', black: '' });
  assert.equal(model.count, 5);
});

test('modèle de feuille : position marquée', () => {
  const moves = ['34-29', '19-23', '40-34', '14-19'];
  assert.equal(sheetModel(moves, 0).marked, null);
  assert.deepEqual(sheetModel(moves, 1).marked, { n: 1, side: 'white' });
  assert.deepEqual(sheetModel(moves, 2).marked, { n: 1, side: 'black' });
  assert.deepEqual(sheetModel(moves, 3).marked, { n: 2, side: 'white' });
  assert.equal(sheetModel(moves, 99).at, 4, 'la position est bornée au dernier coup');
  assert.equal(sheetModel(moves, -3).at, 0, 'un curseur négatif retombe sur la position initiale');
  assert.equal(sheetModel([], 4).rows.length, 0);
});

test('légende de la position', () => {
  assert.match(positionCaption(0, 0, 'w'), /Position initiale/);
  assert.match(positionCaption(3, 40, 'b'), /coup 2 \(Blancs\)/);
  assert.match(positionCaption(3, 40, 'b'), /aux Noirs/);
  assert.match(positionCaption(40, 40, 'w'), /fin de la partie/);
});

let failed = 0;
for (const { name, fn } of tests) {
  try {
    fn();
    console.log('ok   ·', name);
  } catch (error) {
    failed += 1;
    console.error('FAIL ·', name, '\n     ', error.message);
  }
}
console.log(`\nExport annoté : ${tests.length - failed}/${tests.length} tests réussis.`);
if (failed) process.exit(1);
