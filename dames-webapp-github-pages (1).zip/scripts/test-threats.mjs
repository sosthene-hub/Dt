// Analyse des menaces : vérifications réelles avec le moteur WASM dans Node.
// 1. Une partie réelle est rejouée (fixture Verpoest–Berte 1980).
// 2. Les menaces créées / évitées sont vérifiées : lignes légales, seuils,
//    réutilisation du cache d'évaluations, garde « prise obligatoire ».
// 3. Les textes et le récapitulatif sont contrôlés.
import fs from 'node:fs';
import path from 'node:path';
import Module from 'node:module';
import assert from 'node:assert/strict';

import bitbases from '../src/bitbases-data.js';
import { parsePdnGames, replayPdnGame, moveMatchesPdn } from '../src/pdn.js';
import { generateLegalMoves, boardToHub, applyMove } from '../src/game-rules.js';
import { annotateGame } from '../src/analysis/annotate.js';
import {
  analyseThreats,
  analyseThreatPly,
  createMemoSearch,
  describeAvoided,
  describeCreated,
  scopeAllows,
  summarise,
  threatAnnotations,
  threatSummaryText,
} from '../src/analysis/threats.js';

const variant = process.env.SCAN_RUNTIME === 'simd' ? 'simd' : 'scalar';
const filename = path.resolve('public/scan-wasm-' + variant + '.js');
const native = new Module(filename);
native.filename = filename;
native.paths = Module._nodeModulePaths(path.dirname(filename));
native._compile(fs.readFileSync(filename, 'utf8'), filename);

let resolveWait;
let searchResolve;
let info = [];
const ready = new Promise(resolve => { resolveWait = resolve; });
const mod = await native.exports({
  noInitialRun: true,
  print: line => {
    if (line === 'ready') resolveWait();
    if (line.startsWith('info')) info.push(line);
    if (line.startsWith('done')) searchResolve?.({ done: line, infos: info.slice() });
  },
  printErr: line => { if (line.startsWith('error')) throw Error(line); },
});
mod.FS.mkdirTree('/data');
mod.FS.writeFile('/data/eval', fs.readFileSync('public/scan_normal.data').subarray(0, 8503280));
mod.FS.writeFile('/data/book', fs.readFileSync('public/scan-book.bin'));
for (const [name, text] of Object.entries(bitbases)) {
  mod.FS.mkdirTree('/' + path.dirname(name));
  mod.FS.writeFile('/' + name, Buffer.from(text, 'base64'));
}
mod._main(0, 0);
const send = text => mod.ccall('scan_command', null, ['string'], [text]);
send('hub');
send('set-param name=tt-size value=20');
send('set-param name=bb-size value=0');
send('set-param name=book value=false');
send('init');
await ready;

function parseInfo(line) {
  const read = key => {
    const match = line.match(new RegExp(`(?:^|\\s)${key}=([\\d.+-]+)`));
    return match ? Number(match[1]) : undefined;
  };
  const pvMatch = line.match(/\bpv="([^"]*)"/);
  return {
    raw: line,
    depth: read('depth'),
    score: read('score'),
    nodes: read('nodes'),
    time: read('time'),
    pv: pvMatch ? pvMatch[1].split(/\s+/).filter(Boolean) : [],
    completed: /\bcompleted=true\b/.test(line),
    timeLimited: /\blimit=time\b/.test(line),
  };
}

const searches = { calls: 0, ms: 0 };
const engineSearch = async ({ position, depth = 6, mode = 'analyze', maxTimeMs = 1500 }) => {
  const started = Date.now();
  const seconds = Math.max(0.05, Math.min(30, (Number(maxTimeMs) || 1500) / 1000));
  const reply = await new Promise((resolve, reject) => {
    info = [];
    const timer = setTimeout(() => reject(Error('recherche bloquée')), seconds * 1000 + 15000);
    searchResolve = result => { clearTimeout(timer); resolve(result); };
    send('pos ' + position);
    send(`level depth=${depth} move-time=${seconds}`);
    send('go ' + mode);
  });
  searches.calls += 1;
  searches.ms += Date.now() - started;
  const infos = reply.infos.map(parseInfo);
  return {
    move: reply.done.match(/\bmove=([^ ]+)/)?.[1] || null,
    infos,
    timeLimited: infos.some(entry => entry.timeLimited),
    timedOut: false,
    stale: false,
  };
};

const memo = createMemoSearch(engineSearch);

// ---------------------------------------------------------------- unités
const forcedEntry = {
  index: 0,
  side: 'w',
  moveNumber: 1,
  played: '',
  created: null,
  avoided: null,
  status: 'forced',
  note: 'Menace non calculable : prise obligatoire en jeu.',
};
assert.equal(threatSummaryText(forcedEntry), 'Menace non calculable : prise obligatoire en jeu.');
const quietEntry = { index: 1, side: 'b', moveNumber: 1, created: null, avoided: null, status: 'quiet', note: '' };
assert.equal(threatSummaryText(quietEntry), 'Aucune menace réelle.');
const avoidedNotParried = {
  side: 'b',
  gap: 1.8,
  line: [{ from: 27, to: 22, path: [27, 22], captured: [] }],
  captures: 0,
  parried: false,
};
assert.match(describeAvoided(avoidedNotParried), /ne pare pas cette menace/);
assert.match(describeAvoided({ ...avoidedNotParried, captures: 2, parried: true }), /rafle de 2 pions.*l’empêche/);
assert.match(describeCreated({ side: 'w', gain: 2.4, line: [{ from: 32, to: 28, path: [32, 28], captured: [] }], captures: 0 }), /Menace créée : les Blancs menacent 32-28/);
assert.equal(scopeAllows({ kind: 'w' }, { side: 'b', moveNumber: 3 }), false);
assert.equal(scopeAllows({ kind: 'range', from: 2, to: 4 }, { side: 'w', moveNumber: 3 }), true);
assert.equal(scopeAllows({ kind: 'range', from: 2, to: 4 }, { side: 'w', moveNumber: 9 }), false);
console.log('· unités de texte et de portée : OK');

// ------------------------------------------------- partie réelle : 18 coups
const pdn = fs.readFileSync('fixtures/Verpoest-Berte-1980.pdn', 'utf8');
const [game] = parsePdnGames(pdn);
const replay = replayPdnGame(game);
assert.equal(replay.problem, null, 'la partie d’exemple doit être légale');
const PLIES = 18;
const states = replay.states.slice(0, PLIES + 1);
const moves = replay.moves.slice(0, PLIES);

// L'analyse annotée remplit le cache ; les menaces doivent ensuite réutiliser
// les évaluations normales déjà faites au même niveau.
const DEPTH = 9;
const annotation = await annotateGame({ states, search: memo, depth: DEPTH, maxTimeMs: 700, pvLength: 4 });
assert.equal(annotation.cancelled, false);
const missesAfterAnnotation = memo.stats().misses;
assert.equal(missesAfterAnnotation, states.length, 'une évaluation par position');
console.log('· annotation de la partie :', states.length, 'positions, profondeur', DEPTH);

const started = Date.now();
const report = await analyseThreats({
  states,
  moves,
  search: memo,
  depth: DEPTH,
  threshold: 0.5,
  onProgress: (done, total) => { assert.ok(done <= total); },
});
const elapsed = Date.now() - started;
assert.equal(report.cancelled, false);
assert.equal(report.results.length, PLIES, 'un résultat par demi-coup');
const stats = memo.stats();
assert.ok(stats.hits > 0, 'le cache doit être réutilisé');
assert.ok(stats.misses - missesAfterAnnotation <= 2 * PLIES + 2, `évaluations supplémentaires ${stats.misses - missesAfterAnnotation}`);
console.log('· menaces :', PLIES, 'coups en', (elapsed / 1000).toFixed(1), 's ·', stats.hits, 'évaluations réutilisées ·', stats.misses - missesAfterAnnotation, 'nouvelles');

// Chaque menace retenue doit proposer une ligne de coups légaux.
function checkLine(entry, kind, baseState) {
  const threat = entry[kind];
  if (!threat) return 0;
  assert.ok(threat.line.length >= 1, `${kind} sans ligne`);
  let state = { board: baseState.board.slice(), side: baseState.side };
  for (const move of threat.line) {
    const legal = generateLegalMoves(state.board, state.side);
    const token = move.path.join('x');
    assert.ok(
      legal.some(candidate => moveMatchesPdn(candidate, move.captured.length ? token : `${move.from}-${move.to}`)),
      `${kind} : coup illégal ${token} dans la ligne`,
    );
    state = { board: applyLocal(state.board, move), side: state.side === 'w' ? 'b' : 'w' };
  }
  assert.ok(threat.captures >= 0);
  assert.ok(Number.isFinite(threat.gain ?? threat.gap));
  return 1;
}

function applyLocal(board, move) { return applyMove(board, move); }

let created = 0;
let avoided = 0;
let forced = 0;
for (const entry of report.results) {
  // Menace créée : la ligne repart de la position après le coup, avec le camp
  // qui vient de jouer au trait (l'adversaire passe). Menace évitée : la ligne
  // repart de la position avant le coup, avec l'adversaire au trait.
  created += checkLine(entry, 'created', { board: states[entry.index + 1].board, side: states[entry.index].side });
  avoided += checkLine(entry, 'avoided', { board: states[entry.index].board, side: states[entry.index].side === 'w' ? 'b' : 'w' });
  if (entry.status === 'forced') {
    forced += 1;
    assert.match(entry.note, /prise obligatoire en jeu/);
  }
  if (entry.avoided?.parried === false) assert.match(threatSummaryText(entry), /ne pare pas cette menace/);
  if (!entry.created && !entry.avoided && entry.status !== 'forced' && entry.status !== 'terminal') {
    assert.match(threatSummaryText(entry), /Aucune menace réelle/);
  }
}
assert.ok(created + avoided > 0, 'au moins une menace significative attendue sur une partie réelle');
const summary = summarise(report.results);
assert.equal(summary.created.w + summary.created.b, created);
assert.equal(summary.avoided.w + summary.avoided.b, avoided);
assert.ok(summary.top.length <= 3);
assert.ok(summary.top.every(item => item.weight > 0));
console.log('· lignes vérifiées :', created, 'menaces créées,', avoided, 'menaces évitées,', forced, 'coups à prise obligatoire');
console.log('· récapitulatif :', JSON.stringify(summary.created), JSON.stringify(summary.avoided), 'top', summary.top.map(item => item.moveNumber + (item.side === 'w' ? '.' : '…')));

// Deuxième passage : aucune nouvelle évaluation (mémoire des résultats).
const before = memo.stats().misses;
const again = await analyseThreats({ states, moves, search: memo, depth: DEPTH, threshold: 0.5 });
assert.equal(memo.stats().misses, before, 'aucun recalcul au second passage');
assert.deepEqual(again.summary, report.summary, 'résultats identiques');
console.log('· second passage : 0 nouvelle évaluation, résultats identiques');

// Portée : un seul camp.
const onlyWhite = await analyseThreats({ states, moves, search: memo, depth: DEPTH, threshold: 0.5, scope: { kind: 'w' } });
assert.ok(onlyWhite.results.filter(entry => entry.side === 'b').every(entry => entry.status === 'skipped'));
assert.ok(onlyWhite.results.filter(entry => entry.side === 'w').every(entry => entry.status !== 'skipped'));
console.log('· portée « coups des Blancs » : OK');

// Seuil élevé : beaucoup moins de menaces.
const strict = await analyseThreats({ states, moves, search: memo, depth: DEPTH, threshold: 5 });
const strictCount = strict.results.filter(entry => entry.created || entry.avoided).length;
assert.ok(strictCount <= created + avoided, 'un seuil plus haut ne peut pas ajouter de menaces');
console.log('· seuil 5 pions :', strictCount, 'menace(s) conservée(s) sur', created + avoided);

// Recalcul isolé d'un coup, comme les boutons « Menace créée / évitée ».
const sliceIndex = report.results.findIndex(entry => entry.created || entry.avoided);
if (sliceIndex >= 0) {
  const slice = await analyseThreatPly({
    before: states[sliceIndex],
    after: states[sliceIndex + 1],
    move: moves[sliceIndex],
    index: sliceIndex,
    search: memo,
    depth: DEPTH,
    threshold: 0.5,
    startSide: states[0].side,
    mode: 'both',
  });
  assert.equal(slice.index, sliceIndex);
  assert.equal(!!slice.created, !!report.results[sliceIndex].created);
  assert.equal(!!slice.avoided, !!report.results[sliceIndex].avoided);
  console.log('· recalcul isolé du coup', slice.moveNumber, ': identique au passage complet');
}

// Commentaires d'export.
const annotations = threatAnnotations(report.results);
assert.ok(annotations.size > 0, 'des commentaires de menace attendus pour l’export');
for (const [index, text] of annotations) {
  assert.ok(index >= 0 && index < PLIES);
  assert.match(text, /Menace (créée|évitée)/);
}
console.log('· export :', annotations.size, 'commentaires de menace');

// Interruption propre.
const stopped = await analyseThreats({ states, moves, search: memo, depth: DEPTH, shouldStop: () => true });
assert.equal(stopped.cancelled, true);
assert.equal(stopped.results.length, 0);
console.log('· interruption : OK');

fs.writeFileSync('perf/threats-tests.json', JSON.stringify({
  partie: 'Verpoest–Berte 1980',
  coups: PLIES,
  profondeur: DEPTH,
  seuil: 0.5,
  menacesCreees: created,
  menacesEvitees: avoided,
  prisesObligatoires: forced,
  evaluations: { moteur: searches.calls, cacheHits: memo.stats().hits, cacheMisses: memo.stats().misses },
  dureeSecondes: Math.round((elapsed / 1000) * 10) / 10,
  commentairesExport: annotations.size,
  recap: summary,
  passed: true,
}, null, 2));

console.log('Menaces : ', created, 'créées,', avoided, 'évitées, cache réutilisé, export et interruption OK.');
