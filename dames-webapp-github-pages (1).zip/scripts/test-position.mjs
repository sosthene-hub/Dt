import assert from 'node:assert/strict';
import { createInitialBoard } from '../src/game-rules.js';
import { validatePosition, positionToPdn, parsePdnPosition, countPieces } from '../src/position.js';

// --- validation ---
const initial = createInitialBoard();
assert.equal(validatePosition(initial, 'w'), null, 'initial position must be valid');
const empty = Array(51).fill('e');
assert.ok(validatePosition(empty, 'w'), 'empty board must be rejected');
const tooManyWhite = Array(51).fill('e');
for (let s = 1; s <= 20; s++) tooManyWhite[s] = 'w';
tooManyWhite[50] = 'w'; // 21st white piece
assert.ok(validatePosition(tooManyWhite, 'w'), 'more than 20 pieces must be rejected');

// --- counts ---
assert.deepEqual(countPieces(initial), { white: 20, black: 20, whiteKings: 0, blackKings: 0 });

// --- PDN export / import round trip on the initial position ---
const pdn = positionToPdn(initial, 'w');
assert.equal(pdn, 'W:W31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50:B1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20');
const parsed = parsePdnPosition(pdn);
assert.ok(parsed, 'PDN position must parse');
assert.equal(parsed.side, 'w');
assert.deepEqual(parsed.board, initial);

// --- kings and partial positions ---
const custom = Array(51).fill('e');
custom[12] = 'W'; custom[30] = 'b'; custom[7] = 'B';
const pdnCustom = positionToPdn(custom, 'b');
assert.equal(pdnCustom, 'B:WK12:B30,K7', `unexpected PDN: ${pdnCustom}`);
const parsedCustom = parsePdnPosition(pdnCustom);
assert.deepEqual(parsedCustom.board, custom);
assert.equal(parsedCustom.side, 'b');

// --- Hub 51-character code ---
const hub = 'W' + initial.slice(1).join('');
const parsedHub = parsePdnPosition(hub);
assert.deepEqual(parsedHub.board, initial);
assert.equal(parsedHub.side, 'w');

// --- rejects garbage ---
assert.equal(parsePdnPosition("n'importe quoi"), null);
assert.equal(parsePdnPosition('X:W31:B18'), null);
assert.equal(parsePdnPosition('W:W99:B18'), null, 'square out of range must be rejected');

// --- side letter round trip for black ---
assert.equal(parsePdnPosition(positionToPdn(initial, 'b')).side, 'b');

console.log('Position tests passed: validation, counts, PDN and Hub round trips.');
