import { chromium } from 'playwright';
import fs from 'node:fs';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext();
const page = await context.newPage();
const cdp = await context.newCDPSession(page);
await cdp.send('Network.enable');
await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
const errors = [];
page.on('pageerror', error => { errors.push(error.message); console.log('error', error.message); });
page.on('requestfailed', request => console.log('failed', request.url(), request.failure()?.errorText));
await page.goto('http://localhost:4173/Dt/');
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });
await page.evaluate(async () => { await navigator.serviceWorker.register('./sw.js'); await navigator.serviceWorker.ready; });
await page.waitForFunction(() => navigator.serviceWorker.controller !== null, null, { timeout: 30000 });
const cached = await page.evaluate(async () => {
  const cache = await caches.open('dames-internationales-shell-scan-wasm-v13');
  return (await cache.keys()).map(request => request.url);
});
for (const required of ['scan-wasm.worker.js', 'combinations-app.json', 'scan_normal.data']) {
  if (!cached.some(url => url.includes(required))) throw Error(`missing from precache: ${required}`);
}
if (cached.some(url => url.includes('retro.worker-'))) throw Error('removed retro worker still precached');

await context.setOffline(true);
await page.reload();
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });
await page.click('#menu-toggle');
const nav = await page.$$eval('.nav-item', nodes => nodes.map(node => node.dataset.page));
if (nav.includes('retro') || nav.includes('recherche')) throw Error('removed pages still in navigation');
await page.click('[data-page="scan-vs-scan"]');
await page.waitForFunction(() => document.querySelector('#svs-board .piece'), null, { timeout: 15000 });
await page.selectOption('#svs-a-depth', '2');
await page.selectOption('#svs-b-depth', '2');
await page.selectOption('#svs-a-time', '200');
await page.selectOption('#svs-b-time', '200');
await page.fill('#svs-speed', '0');
await page.click('#svs-start-btn');
await page.waitForFunction(() => /Série terminée/.test(document.querySelector('#svs-status')?.textContent || ''), null, { timeout: 180000 });
const series = (await page.locator('#svs-status').textContent()).trim();
await page.screenshot({ path: '/home/user/perf/scan-vs-scan-hors-ligne.png', fullPage: true });
await page.click('#menu-toggle');
await page.click('[data-page="combinaisons"]');
await page.waitForFunction(() => /combinaisons validées/.test(document.querySelector('#cb-db')?.textContent || ''), null, { timeout: 20000 });
if (errors.length) throw Error(errors.join('\n'));
fs.writeFileSync('browser-offline-results.json', JSON.stringify({
  base: '/Dt/',
  offlineReload: true,
  engineReady: true,
  combinationsPage: true,
  scanVsScanOffline: true,
  series,
  removedPages: ['retro', 'recherche'],
  cache: 'v13',
  cachedAssets: cached.length,
  errors,
}, null, 2));
console.log('Production /Dt/ hors ligne : Scan, combinaisons, Scan contre Scan : OK');
await browser.close();
