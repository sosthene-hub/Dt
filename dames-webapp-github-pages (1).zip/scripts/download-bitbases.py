"""Rebuild the Scan 2–4 piece data module from the upstream ZIP (HTTP ranges).
Optional maintenance script; Python 3 standard library only. Never downloads the 706 MiB pack in full.
"""
import base64,hashlib,io,json,pathlib,struct,urllib.request,zipfile,zlib
URL='https://hjetten.home.xs4all.nl/scan/bb.zip'
def fetch(byte_range):
    response=urllib.request.urlopen(urllib.request.Request(URL,headers={'Range':byte_range}),timeout=60)
    if response.status!=206:response.close();raise RuntimeError('Server must support HTTP byte ranges')
    return response.read(),response.headers
raw,headers=fetch('bytes=-65536');base=int(headers['Content-Range'].split(' ')[1].split('-')[0])
archive=zipfile.ZipFile(io.BytesIO(raw));files={};hashes={};size=0
for entry in archive.infolist():
    if entry.is_dir() or not any('/'+str(n)+'/' in entry.filename for n in (2,3,4)):continue
    start=entry.header_offset+base
    block,_=fetch(f'bytes={start}-{start+entry.compress_size+len(entry.filename.encode())+len(entry.extra)+130}')
    assert block[:4]==b'PK\x03\x04'
    name_length,extra=struct.unpack_from('<HH',block,26);offset=30+name_length+extra
    data=zlib.decompress(block[offset:offset+entry.compress_size],-15)
    assert len(data)==entry.file_size and zlib.crc32(data)==entry.CRC
    files[entry.filename]=base64.b64encode(data).decode();hashes[entry.filename]=hashlib.sha256(data).hexdigest();size+=len(data)
root=pathlib.Path(__file__).resolve().parent.parent
(root/'src/bitbases-data.js').write_text('export default '+json.dumps(files,separators=(',',':'))+';\n')
(root/'bitbases-provenance.json').write_text(json.dumps({'url':URL,'bytes':size,'files':hashes},indent=2))
print(len(files),'tables,',size,'bytes')
