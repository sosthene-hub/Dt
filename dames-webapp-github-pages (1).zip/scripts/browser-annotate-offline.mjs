// Contrôle hors ligne du HTML autonome (réseau coupé, file://) : annotation
// réelle, feuille imprimable et solution de combinaison pas à pas.
import { chromium } from 'playwright';
import fs from 'node:fs';

import { fileURLToPath } from 'node:url';
const FILE = process.env.FILE || fileURLToPath(new URL('../Dames-autonome.html', import.meta.url));
const OUT = process.env.OUT || 'perf/annotate';
fs.mkdirSync(OUT, { recursive: true });

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, offline: true });
const page = await context.newPage();
const errors = [];
const requests = [];
page.on('pageerror', error => errors.push(error.message));
page.on('request', request => {
  const url = request.url();
  if (!/^(file|blob|data):/.test(url)) requests.push(url);
});

await page.goto('file://' + FILE);
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });

async function nav(id) {
  await page.evaluate(() => document.querySelector('#menu-toggle')?.click());
  await page.click(`[data-page="${id}"]`);
}

await nav('importer');
await page.click('#pdn-sample');
await page.waitForFunction(() => document.querySelectorAll('#played-moves button').length > 5, null, { timeout: 30000 });
if (await page.isChecked('#an-auto')) await page.uncheck('#an-auto');
await page.waitForFunction(() => document.querySelector('#an-status')?.textContent === 'Prêt', null, { timeout: 30000 });
await page.selectOption('#an-annot-depth', '9');
const started = Date.now();
await page.click('#an-annotate');
await page.waitForFunction(
  () => /coups évalués|Passage unique/.test(document.querySelector('#an-annot-status')?.textContent || ''),
  null,
  { timeout: 300000 },
);
const annotation = { secondes: Math.round((Date.now() - started) / 100) / 10, status: (await page.textContent('#an-annot-status')).trim() };

await page.click('#played-moves button:nth-child(8)');
await page.click('#an-mark');
await page.check('#an-opt-auto');
await page.click('#an-print');
await page.waitForSelector('#print-sheet');
const sheet = await page.evaluate(() => ({
  notes: document.querySelectorAll('#print-sheet .note').length,
  diagrammes: document.querySelectorAll('#print-sheet .diagram').length,
  numerosCases: document.querySelectorAll('#print-sheet .diagram text').length,
  largeurDiagramme: Math.round(document.querySelector('#print-sheet .diagram svg').getBoundingClientRect().width),
  scrollWidth: document.querySelector('#print-sheet').scrollWidth,
  clientWidth: document.querySelector('#print-sheet').clientWidth,
}));
await page.click('#print-sheet .sheet-toolbar .secondary-button');

await nav('combinaisons');
await page.waitForFunction(() => /Base/.test(document.querySelector('#cb-db')?.textContent || ''), null, { timeout: 30000 });
await page.selectOption('#cb-level', '1');
await page.selectOption('#cb-scan-depth', '0');
await page.fill('#cb-route', '25x');
const before = await page.evaluate(() => document.querySelector('#cb-exercise')?.dataset.exid || '0');
await page.click('#cb-generate');
await page.waitForFunction(previous => {
  const panel = document.querySelector('#cb-exercise');
  return panel && !panel.hidden && panel.dataset.exid !== previous;
}, before, { timeout: 30000 });
const hiddenBefore = await page.evaluate(() => document.querySelector('#cb-line-wrap').hidden);
await page.click('#cb-solution');
const revealed = (await page.textContent('#cb-sol-label')).trim();
await page.click('#cb-sol-start');
const startLabel = (await page.textContent('#cb-sol-label')).trim();
await page.click('#cb-sol-next');
const stepLabel = (await page.textContent('#cb-sol-label')).trim();
await page.click('#cb-sol-end');
const endLabel = (await page.textContent('#cb-sol-label')).trim();
await page.click('#cb-sol-prev');
const backLabel = (await page.textContent('#cb-sol-label')).trim();
const lineWidth = await page.evaluate(() => Math.round(document.querySelector('#cb-line').getBoundingClientRect().width));

const report = {
  fichier: FILE,
  mode: 'Chromium, file://, réseau coupé, 412×915',
  annotation,
  sheet,
  solution: { hiddenBefore, revealed, startLabel, stepLabel, endLabel, backLabel, lineWidth },
  requetesExternes: requests,
  errors,
};
report.ok = !errors.length && !requests.length
  && sheet.notes > 0 && sheet.diagrammes >= 1
  && hiddenBefore === true
  && /^1\/\d+ · 1\. /.test(stepLabel)
  && sheet.scrollWidth <= sheet.clientWidth;
fs.writeFileSync(`${OUT}/rapport-hors-ligne.json`, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
await browser.close();
if (!report.ok) process.exit(1);
