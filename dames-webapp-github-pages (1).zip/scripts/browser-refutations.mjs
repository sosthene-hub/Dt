// Vérification E2E Playwright : détection à la demande des mauvais coups (?!/ ? / ??),
// visualisation pas à pas sur le damier, mode d'entraînement interactif (quiz de réfutation),
// ajout dans l'analyse manuelle imprimable et passerelle « Mener au gain contre PIONICIDE ».
import assert from 'node:assert/strict';
import { chromium } from 'playwright';

const BASE_URL = process.env.BASE_URL || 'http://127.0.0.1:5173/';

const browser = await chromium.launch({ headless: true });
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 920 } });
  const page = await context.newPage();
  const pageErrors = [];
  page.on('pageerror', err => pageErrors.push(err.message));

  // 1. Ouvre l'Éditeur, charge notre position tactique et envoie au Damier d'analyse
  await page.goto(BASE_URL + '#editeur', { waitUntil: 'networkidle' });
  await page.click('#ed-import');
  await page.fill('#ed-import-input', 'B:W27,32,37,38,43:B12,13,18,19,24');
  await page.locator('#ed-import-input').dispatchEvent('change');
  await page.click('#ed-analyze');
  await page.waitForSelector('#refutation-panel');

  // 2. Déclenche à la demande la détection des mauvais coups (profondeur 12 pour rapidité E2E)
  await page.evaluate(() => {
    const details = document.querySelector('.rf-settings-details');
    if (details) details.open = true;
  });
  await page.selectOption('#rf-depth', '12');
  await page.click('#an-bad-moves');

  // Attend l'apparition d'au moins 2 cartes de mauvais coups
  await page.waitForFunction(() => document.querySelectorAll('#rf-list .rf-card').length >= 2, null, { timeout: 25000 });

  const cardCount = await page.locator('#rf-list .rf-card').count();
  assert.ok(cardCount >= 2, `Au moins 2 mauvais coups attendus dans l'interface, obtenu ${cardCount}`);

  const winCountText = await page.locator('#rf-f-wins').textContent();
  assert.match(winCountText, /Suites gagnantes \([1-9]\d*\)/, `Au moins une suite gagnante attendue : ${winCountText}`);

  // 3. Clique sur le 1er coup de réfutation de la pire erreur et vérifie l'aperçu damier + flèche
  await page.locator('#rf-list .rf-card').first().locator('.rf-step-err').click();
  await page.waitForSelector('#analysis-board svg.threat-arrows');
  await page.screenshot({ path: '/tmp/shot-refutation-board.png', fullPage: false });
  await page.locator('#rf-panel, #refutation-panel').screenshot({ path: '/tmp/shot-refutation-panel.png' });

  // 4. Mode entraînement interactif : « 🎯 S’entraîner à réfuter »
  const firstCard = page.locator('#rf-list .rf-card').first();
  const firstPunishText = await firstCard.locator('.rf-step-punish').first().textContent();
  // Extrait ex. "2.38-33!" ou "2.38x27x16!" -> départ=premier nombre après le n° de coup, arrivée=dernier nombre
  const moveBody = firstPunishText.replace(/^\s*\d+(?:\.|…|\.\.\.)\s*/, '');
  const sqNums = (moveBody.match(/\d+/g) || []).map(Number);
  assert.ok(sqNums.length >= 2, `Coup de réfutation lisible attendu : ${firstPunishText}`);
  const fromSq = sqNums[0];
  const toSq = sqNums.at(-1);

  await firstCard.getByRole('button', { name: /S’entraîner à réfuter/ }).click();
  await page.waitForSelector('#rf-drill-card:not([hidden])');

  // Joue le coup gagnant sur le damier !
  await page.click(`#analysis-board [data-square="${fromSq}"]`);
  await page.click(`#analysis-board [data-square="${toSq}"]`);

  await page.waitForFunction(() => {
    const fb = document.querySelector('#rf-drill-feedback')?.textContent || '';
    return fb.includes('Exact') || fb.includes('Bravo') || fb.includes('Bien joué');
  }, null, { timeout: 10000 });

  await page.click('#rf-drill-quit');

  // 5. « + Tout ajouter à mon analyse » -> vérifie l'intégration dans la feuille Turbo Dambase & impression
  await page.click('#rf-add-all');
  const previewProse = await page.locator('#man-preview-card').textContent();
  assert.match(previewProse, /\[\s*Si\s+1\.\.\./, `Les mauvais coups doivent apparaître comme variantes [ Si ... ] : ${previewProse}`);

  await page.click('#man-print');
  await page.waitForSelector('#print-sheet .manual-sheet-page');
  await page.locator('#print-sheet .manual-sheet-page').screenshot({ path: '/tmp/shot-refutation-print.png' });
  await page.locator('#print-sheet').getByRole('button', { name: /Fermer/i }).click();

  // 6. « ⚔ Mener au gain contre PIONICIDE » -> lance le match depuis la position fautive
  await page.locator('#rf-list .rf-card').first().getByRole('button', { name: /Mener au gain contre PIONICIDE/ }).click();
  await page.waitForSelector('#game-board');
  const cursorText = await page.locator('#game-cursor').textContent();
  assert.match(cursorText, /Exploiter l’erreur/, `La partie d'entraînement doit démarrer sur l'erreur adverse : ${cursorText}`);

  assert.equal(pageErrors.length, 0, `Aucune erreur JS attendue : ${pageErrors.join(' | ')}`);
  console.log('✓ E2E Playwright Mauvais coups, quiz de réfutation, feuille imprimable et match d’exploitation : OK');
} finally {
  await browser.close();
}
