/* Test navigateur des nouveautés (Chrome sans interface) :
   1. import d'un fichier PDN dans la base ;
   2. recherche « joueur contre joueur » sans structure ;
   3. recherche avec année facultative ;
   4. impression d'une partie depuis les résultats ;
   5. impression de la position depuis l'explorateur.
   Usage : node scripts/browser-recherche-impression.mjs */
import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = 8911;

const server = spawn('npx', ['vite', 'preview', '--port', String(PORT), '--strictPort', '--host', '0.0.0.0'], {
  cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'],
});
let log = '';
server.stdout.on('data', chunk => { log += chunk; });
server.stderr.on('data', chunk => { log += chunk; });

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const started = Date.now();
while (!/Local:|localhost/.test(log) && Date.now() - started < 60000) await wait(200);

const failures = [];
const check = (label, condition, detail = '') => {
  if (!condition) failures.push(label + (detail ? ' — ' + detail : ''));
  console.log((condition ? '· OK   ' : '· ÉCHEC') + ' ' + label + (detail ? ' — ' + detail : ''));
};

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });

try {
  await page.goto(`http://127.0.0.1:${PORT}/#base`, { waitUntil: 'load' });
  await page.waitForSelector('.pb-tabs', { timeout: 20000 });

  /* ---------- 1. import ---------- */
  await page.setInputFiles('#pb-file', path.join(ROOT, 'fixtures/base-echantillon-200.pdn'));
  await page.waitForSelector('#pb-report:not([hidden])', { timeout: 120000 });
  const imported = await page.textContent('#pb-report');
  check('import PDN terminé', /importées/.test(imported), imported.replace(/\s+/g, ' ').slice(0, 70));

  /* ---------- 2. joueur contre joueur, sans structure ---------- */
  await page.click('.pb-tab[data-tab="search"]');
  await page.waitForSelector('#pb-sr-white');
  await page.fill('#pb-sr-white', 'koperberg');
  await page.fill('#pb-sr-black', 'springer');
  await page.click('#pb-sr-run');
  await page.waitForFunction(() => /partie\(s\) trouvée/.test(document.querySelector('#pb-sr-status')?.textContent || ''), { timeout: 60000 });
  const status = await page.textContent('#pb-sr-status');
  const rows = await page.$$eval('#pb-sr-results .pb-row-game', items => items.length);
  check('recherche joueur contre joueur', rows > 0, status.trim());
  const note = await page.textContent('#pb-sr-player-note');
  check('noms résolus affichés', /Blancs|Noirs/.test(note), note.slice(0, 90));
  const pairOk = await page.$$eval('#pb-sr-results .pb-row-text b', items => items.map(node => node.textContent));
  check('les deux joueurs apparaissent dans les résultats',
    pairOk.length > 0 && pairOk.every(text => /koperberg/i.test(text) && /springer/i.test(text)),
    pairOk[0] || '');

  /* ---------- 3. année facultative ---------- */
  await page.fill('#pb-sr-year-from', '1915');
  await page.fill('#pb-sr-year-to', '1915');
  await page.click('#pb-sr-run');
  await page.waitForFunction(() => /partie\(s\) trouvée/.test(document.querySelector('#pb-sr-status')?.textContent || ''), { timeout: 60000 });
  const dates = await page.$$eval('#pb-sr-results .pb-row-text small', items => items.map(node => node.textContent));
  check('filtre année appliqué', dates.length > 0 && dates.every(text => /1915/.test(text)), dates[0] || '');
  await page.fill('#pb-sr-year-from', '');
  await page.fill('#pb-sr-year-to', '');

  /* ---------- 4. impression d'une partie depuis la recherche ---------- */
  await page.click('#pb-sr-run');
  await page.waitForFunction(() => /partie\(s\) trouvée/.test(document.querySelector('#pb-sr-status')?.textContent || ''), { timeout: 60000 });
  await page.click('#pb-sr-results .pb-print');
  await page.waitForSelector('#print-sheet', { timeout: 15000 });
  const sheet = await page.evaluate(() => ({
    title: document.querySelector('#print-sheet .sheet-title')?.textContent || '',
    sub: document.querySelector('#print-sheet .sheet-sub')?.textContent || '',
    diagram: !!document.querySelector('#print-sheet .diagram-board'),
    pieces: document.querySelectorAll('#print-sheet .diagram-board [class*="piece"], #print-sheet .diagram-board circle, #print-sheet .diagram-board rect').length,
    moveLines: document.querySelectorAll('#print-sheet .move-line').length,
    caption: document.querySelector('#print-sheet figcaption')?.textContent || '',
    sheetOpen: document.body.classList.contains('sheet-open'),
  }));
  check('feuille d’impression ouverte', sheet.sheetOpen && sheet.title.length > 0, sheet.title);
  check('damier SVG présent', sheet.diagram && sheet.pieces > 10, sheet.pieces + ' formes');
  check('liste des coups imprimée', sheet.moveLines > 5, sheet.moveLines + ' lignes');
  check('légende de la position', /Position/.test(sheet.caption), sheet.caption);
  check('en-tête avec les deux joueurs', /–|—/.test(sheet.sub), sheet.sub);
  await page.click('#print-sheet .secondary-button');
  check('feuille refermée', (await page.$('#print-sheet')) === null);

  /* ---------- 5. impression depuis l'explorateur ---------- */
  await page.click('.pb-tab[data-tab="explorer"]');
  await page.waitForSelector('#pb-print-position');
  await page.waitForTimeout(1200);
  await page.click('#pb-print-position');
  await page.waitForSelector('#print-sheet', { timeout: 15000 });
  const explorerSheet = await page.evaluate(() => ({
    title: document.querySelector('#print-sheet .sheet-title')?.textContent || '',
    diagram: !!document.querySelector('#print-sheet .diagram-board'),
    note: document.querySelector('#print-sheet .sheet-empty') ? 'vide' : 'coups',
  }));
  check('impression depuis l’explorateur', explorerSheet.diagram && explorerSheet.title.length > 0, explorerSheet.title);
  await page.click('#print-sheet .secondary-button');

  /* ---------- 6. impression depuis l'analyse ---------- */
  await page.goto(`http://127.0.0.1:${PORT}/#analyse`, { waitUntil: 'load' });
  await page.waitForSelector('#an-print-position', { timeout: 20000 });
  await page.click('#an-print-position');
  await page.waitForSelector('#print-sheet', { timeout: 15000 });
  check('impression depuis le damier d’analyse', !!(await page.$('#print-sheet .diagram-board')));
  await page.click('#print-sheet .secondary-button');

  check('aucune erreur JavaScript', errors.length === 0, errors.slice(0, 2).join(' | '));
} catch (error) {
  failures.push('exception : ' + error.message);
  console.error(error);
} finally {
  await browser.close();
  server.kill('SIGTERM');
}

console.log('\n' + (failures.length ? failures.length + ' échec(s) :\n - ' + failures.join('\n - ') : 'Tout est passé : recherche joueur contre joueur, année facultative et impression.'));
process.exit(failures.length ? 1 : 0);
