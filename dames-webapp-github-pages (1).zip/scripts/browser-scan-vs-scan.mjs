import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';

const html = path.resolve('Dames-autonome.html');
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, offline: true });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(String(error)));
await page.route('**/*', route => {
  const url = route.request().url();
  if (url.startsWith('file:') || url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
  return route.abort();
});
await page.goto('file://' + html);
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), { timeout: 60000 });

await page.click('#menu-toggle');
await page.click('[data-page="scan-vs-scan"]');
await page.waitForFunction(() => document.querySelector('#svs-status')?.textContent.includes('Démarrer') || document.querySelector('#svs-start-btn'));

async function playSeries({ aDepth, aTime, bDepth, bTime, games, label }) {
  await page.selectOption('#svs-a-depth', String(aDepth));
  await page.selectOption('#svs-b-depth', String(bDepth));
  await page.selectOption('#svs-a-time', String(aTime));
  await page.selectOption('#svs-b-time', String(bTime));
  await page.selectOption('#svs-games', String(games));
  await page.fill('#svs-speed', '0');
  await page.click('#svs-start-btn');
  await page.waitForFunction(() => /Série terminée/.test(document.querySelector('#svs-status')?.textContent || ''), { timeout: 600000 });
  const status = (await page.locator('#svs-status').textContent()).trim();
  const score = (await page.locator('#svs-score').textContent()).trim();
  const plies = await page.locator('#svs-moves button').count();
  const moves = await page.$$eval('#svs-moves button', nodes => nodes.map(node => node.textContent.trim()));
  const turn = (await page.locator('#svs-turn').textContent()).trim();
  const pdnDownload = page.waitForEvent('download');
  await page.click('#svs-pdn');
  const download = await pdnDownload;
  const pdnPath = `/home/user/perf/${label}.pdn`;
  await download.saveAs(pdnPath);
  const pdn = fs.readFileSync(pdnPath, 'utf8');
  await page.screenshot({ path: `/home/user/perf/${label}.png`, fullPage: true });
  const headers = [...pdn.matchAll(/\[(White|Black|Result) "([^"]*)"\]/g)].map(match => `${match[1]}=${match[2]}`);
  return { label, status, score, plies, moves: moves.slice(0, 8), turn, pdnPath, headers };
}

// Partie 1 : deux niveaux franchement différents, une seule partie.
const game1 = await playSeries({ aDepth: 6, aTime: 1000, bDepth: 3, bTime: 500, games: 1, label: 'scan-vs-scan-deux-niveaux' });

// Partie 2 : deux parties avec alternance des couleurs, pour le score cumulé.
const game2 = await playSeries({ aDepth: 2, aTime: 200, bDepth: 2, bTime: 200, games: 2, label: 'scan-vs-scan-alternance' });

const report = {
  mode: 'Chromium, file://, réseau coupé, 412×915',
  date: new Date().toISOString(),
  series: [game1, game2],
  errors,
};
fs.writeFileSync('perf/scan-vs-scan.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
if (errors.length) throw Error(errors.join('\n'));
await browser.close();
