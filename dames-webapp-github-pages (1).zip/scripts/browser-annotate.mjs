// Vérifie l'export annoté de bout en bout : annotation réelle d'une partie,
// diagrammes, téléchargement du PDN, impression et réimport du fichier produit.
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';

const BASE = process.env.BASE_URL || 'http://127.0.0.1:4173/';
const OUT = 'perf/annotate';
fs.mkdirSync(OUT, { recursive: true });

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1180, height: 900 }, acceptDownloads: true });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const report = { base: BASE, steps: [], errors };
const step = (name, detail = {}) => { report.steps.push({ name, ...detail }); console.log('·', name, JSON.stringify(detail)); };

await page.goto(BASE, { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), { timeout: 60000 });
async function nav(id) {
  await page.evaluate(() => document.querySelector('#menu-toggle')?.click());
  await page.click(`[data-page="${id}"]`);
  await page.waitForSelector('#main-content');
}
await nav('importer');
await page.click('#pdn-sample');
await page.waitForFunction(() => document.querySelectorAll('#played-moves button').length > 5, { timeout: 30000 });
const plies = await page.$$eval('#played-moves button', nodes => nodes.length - 1);
step('partie importée', { demiCoups: plies });
// L'évaluation automatique est désactivée pour que la navigation ne lance pas
// une recherche à chaque clic (l'annotation a son propre passage séquentiel).
if (await page.isChecked('#an-auto')) await page.uncheck('#an-auto');
await page.waitForFunction(() => document.querySelector('#an-status')?.textContent === 'Prêt', null, { timeout: 30000 });

// Annotation réelle à profondeur 9 (rapide) sur les 132 positions.
await page.selectOption('#an-annot-depth', '9');
const started = Date.now();
await page.click('#an-annotate');
for (let tick = 0; tick < 120; tick += 1) {
  const text = (await page.textContent('#an-annot-status')).trim();
  if (/coups évalués/.test(text)) break;
  if (tick % 3 === 0) console.log('  annotation :', text);
  await page.waitForTimeout(5000);
}
const status = (await page.textContent('#an-annot-status')).trim();
step('annotation terminée', { secondes: Math.round((Date.now() - started) / 100) / 10, status });

// Deux diagrammes manuels : après le 6e et le 40e demi-coup.
const marks = [];
for (const index of [6, 40, 41]) {
  await page.click(`#played-moves button:nth-child(${index + 2})`);
  await page.click('#an-mark');
  marks.push((await page.textContent('#an-mark')).trim());
  await page.waitForTimeout(50);
}
report.markLabels = marks;
report.markInfo = (await page.textContent('#an-mark-info')).trim();
step('diagrammes marqués', { nombre: marks.length, libelle: report.markInfo });

// Les réglages de seuils et le niveau de détail doivent changer l'export.
await page.fill('#an-thr-error', '0.4');
await page.fill('#an-thr-blunder', '1.2');
await page.selectOption('#an-detail', 'errors');
await page.check('#an-opt-arrow');
await page.check('#an-opt-numbers');

const [download] = await Promise.all([page.waitForEvent('download'), page.click('#an-export-pdn')]);
const pdnPath = path.resolve(OUT, 'partie-annotee.pdn');
await download.saveAs(pdnPath);
const pdn = fs.readFileSync(pdnPath, 'utf8');
report.pdn = {
  fichier: path.basename(pdnPath),
  octets: pdn.length,
  enTete: pdn.split('\n').slice(0, 10),
  commentaires: (pdn.match(/\{[^}]*prof\./g) || []).length,
  variantes: (pdn.match(/\( [^)]*\)/g) || []).length,
  symboles: (pdn.match(/\?\?|\?|!/g) || []).length,
};
step('PDN téléchargé', { octets: pdn.length, commentaires: report.pdn.commentaires, variantes: report.pdn.variantes });

// Feuille imprimable : écran puis média impression.
await page.click('#an-print');
await page.waitForSelector('#print-sheet');
report.print = await page.evaluate(() => ({
  titres: [...document.querySelectorAll('#print-sheet .move-line')].length,
  notes: document.querySelectorAll('#print-sheet .note').length,
  diagrammes: document.querySelectorAll('#print-sheet .diagram').length,
  nombreCases: document.querySelectorAll('#print-sheet .diagram text').length,
  fleches: document.querySelectorAll('#print-sheet .diagram line').length,
  largeurDiagramme: document.querySelector('#print-sheet .diagram svg')?.getBoundingClientRect().width || 0,
  legendes: [...document.querySelectorAll('#print-sheet .diagram figcaption')].map(n => n.textContent),
  premiereNote: document.querySelector('#print-sheet .note')?.textContent || '',
  geoms: [...document.querySelectorAll('#print-sheet .diagram svg')].map(svg => {
    const r = svg.getBoundingClientRect();
    const page = document.querySelector('#print-sheet .sheet-page').getBoundingClientRect();
    return { gauche: Math.round(r.left - page.left), droite: Math.round(page.right - r.right), taille: Math.round(r.width) };
  }),
}));
await page.screenshot({ path: path.join(OUT, 'feuille-ecran.png'), fullPage: false });
await page.emulateMedia({ media: 'print' });
report.print.impression = await page.evaluate(() => ({
  barreOutils: getComputedStyle(document.querySelector('#print-sheet .sheet-toolbar')).display,
  app: getComputedStyle(document.querySelector('#app')).display,
  largeurPage: document.querySelector('#print-sheet .sheet-page').getBoundingClientRect().width,
}));
await page.screenshot({ path: path.join(OUT, 'feuille-impression.png'), fullPage: true });
// PDF réel : c'est exactement ce que produit « Imprimer / PDF » sur l'appareil.
await page.pdf({ path: path.join(OUT, 'partie-annotee.pdf'), format: 'A4', printBackground: true, margin: { top: '12mm', bottom: '12mm', left: '12mm', right: '12mm' } });
report.pdf = {
  octets: fs.statSync(path.join(OUT, 'partie-annotee.pdf')).size,
  pages: Number((fs.readFileSync(path.join(OUT, 'partie-annotee.pdf')).toString('latin1').match(/\/Count\s+(\d+)/) || [])[1] || 0),
};
await page.emulateMedia({ media: 'screen' });
step('feuille imprimable', report.print);

// Réimport du PDN produit, dans l'application.
await page.click('#print-sheet .sheet-toolbar .secondary-button');
await nav('importer');
await page.fill('#pdn-input', pdn);
await page.click('#pdn-load');
await page.waitForFunction(() => /demi-coups/.test(document.querySelector('#pdn-status')?.textContent || ''), { timeout: 30000 });
report.reimport = (await page.textContent('#pdn-status')).trim();
report.reimportPlies = await page.$$eval('#played-moves button', nodes => nodes.length - 1);
step('PDN réimporté', { statut: report.reimport, demiCoups: report.reimportPlies });

await page.screenshot({ path: path.join(OUT, 'reimport.png'), fullPage: false });
report.errors = errors;
report.ok = !errors.length && report.reimportPlies === plies && report.print.notes > 0 && report.print.diagrammes >= 3;
fs.writeFileSync(path.join(OUT, 'rapport.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify({ ok: report.ok, errors, reimport: report.reimport, print: report.print }, null, 2));
await browser.close();
if (!report.ok) process.exit(1);
