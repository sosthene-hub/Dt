#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${EMXX:=em++}"
mkdir -p public
FLAGS=(-std=c++17 -O3 -flto -DNDEBUG -fexceptions -sDISABLE_EXCEPTION_CATCHING=0 -sMODULARIZE=1 -sEXPORT_NAME=createScan -sSINGLE_FILE=1 -sENVIRONMENT=worker,node -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=33554432 -sMAXIMUM_MEMORY=536870912 -sSTACK_SIZE=2097152 -sNO_EXIT_RUNTIME=1 -sFILESYSTEM=1 '-sEXPORTED_FUNCTIONS=["_main","_scan_command"]' '-sEXPORTED_RUNTIME_METHODS=["ccall","FS"]')
"$EMXX" engine-src/*.cpp "${FLAGS[@]}" ${SCAN_EXTRA_FLAGS:-} -o "${SCAN_OUTPUT:-public/scan-wasm-scalar.js}"
