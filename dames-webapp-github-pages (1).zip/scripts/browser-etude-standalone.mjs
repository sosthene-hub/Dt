import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/* Vérifie l'écran « Partie commentée » dans le fichier autonome, sans serveur :
   PDN collé, moteur WASM embarqué, document produit hors ligne. */
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILE = process.env.BASE_URL || 'file://' + path.join(root, 'Dames-autonome.html');
const pdn = fs.readFileSync(path.join(root, 'fixtures/Verpoest-Berte-1980.pdn'), 'utf8');
let failures = 0;
const check = (label, condition, detail = '') => {
  if (!condition) failures += 1;
  console.log((condition ? '· OK   ' : '· ÉCHEC') + ' ' + label + (detail ? ' — ' + detail : ''));
};

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
await page.route('**/*', route => {
  const url = route.request().url();
  if (url.startsWith('file://') || url.startsWith('data:') || url.startsWith('blob:')) route.continue();
  else { errors.push('requête réseau : ' + url); route.abort(); }
});
await page.goto(FILE + '#etude');
await page.waitForTimeout(3000);
check('écran ouvert dans le fichier autonome', await page.isVisible('#st-run'));
await page.click('#st-paste-toggle');
await page.fill('#st-text', pdn);
await page.click('#st-load-text');
await page.waitForTimeout(800);
await page.selectOption('#st-depth', '10');
await page.selectOption('#st-time', '1500');
await page.selectOption('#st-max', '8');
/* Premier passage avec la base demandée : IndexedDB est vide ou refusé en
   file://, l'étude doit continuer et le dire. */
await page.click('#st-run');
await page.waitForFunction(() => !document.querySelector('#st-doc').disabled, null, { timeout: 600000 });
const firstDoc = await page.textContent('#st-status');
check('base demandée sans base : étude poursuivie', /terminée/i.test(firstDoc), firstDoc.slice(0, 110));
await page.click('#st-doc');
await page.waitForSelector('#study-sheet', { timeout: 15000 });
await page.waitForTimeout(600);
const firstSources = await page.evaluate(() => document.querySelector('#study-sheet').innerText.replace(/\s+/g, ' '));
check('source « base » annoncée comme vide', /Base de parties : (vide|non interrogée)/.test(firstSources));
await page.click('#study-sheet .secondary-button');
await page.waitForTimeout(400);
await page.uncheck('#st-base');
await page.click('#st-run');
await page.waitForFunction(() => !document.querySelector('#st-doc').disabled, null, { timeout: 600000 });
const status = (await page.textContent('#st-status')).replace(/\s+/g, ' ').trim();
check('étude hors ligne terminée', /terminée/i.test(status), status.slice(0, 120));
await page.click('#st-doc');
await page.waitForSelector('#study-sheet', { timeout: 15000 });
await page.waitForTimeout(800);
const doc = await page.evaluate(() => {
  const sheet = document.querySelector('#study-sheet');
  return {
    entries: sheet.querySelectorAll('.study-entry').length,
    diagrams: sheet.querySelectorAll('.study-diagram svg').length,
    text: sheet.innerText.replace(/\s+/g, ' '),
  };
});
check('document hors ligne complet', doc.entries > 0 && doc.diagrams === doc.entries,
  `${doc.entries} moments, ${doc.diagrams} diagrammes`);
check('sources annoncées', /Base de parties/.test(doc.text) && /Moteur PIONICIDE/.test(doc.text));
check('aucun artefact', !/undefined|NaN/.test(doc.text));
const fatal = errors.filter(t => !/favicon|sw\.js|manifest/i.test(t));
check('aucune erreur ni requête réseau', fatal.length === 0, fatal.slice(0, 2).join(' | '));
await browser.close();
console.log(failures ? `\nPartie commentée (fichier autonome) : ${failures} échec(s).` : '\nPartie commentée (fichier autonome) : tous les tests passent.');
process.exit(failures ? 1 : 0);
