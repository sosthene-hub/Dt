import assert from 'node:assert/strict';
import { applyMove, generateLegalMoves, moveToHub, opponent } from '../src/game-rules.js';
import { generatePuzzle, mulberry32, puzzleSeed, randomPosition, movePathsEqual } from '../src/puzzles.js';

// --- PRNG determinism ---
const rngA = mulberry32(12345);
const rngB = mulberry32(12345);
const sequenceA = Array.from({ length: 8 }, () => rngA());
const sequenceB = Array.from({ length: 8 }, () => rngB());
assert.deepEqual(sequenceA, sequenceB, 'same seed must give same sequence');
assert.notDeepEqual(sequenceA, Array.from({ length: 8 }, () => mulberry32(999)()), 'different seeds differ');

// --- random positions are legal-ish: counts within bounds, both camps present ---
for (const seed of [1, 2, 3, 42, 777]) {
  const rng = mulberry32(seed);
  for (let i = 0; i < 20; i++) {
    const { board, side } = randomPosition(rng, { pieces: 4 + Math.floor(rng() * 9), kings: true });
    let white = 0, black = 0;
    for (let s = 1; s <= 50; s++) {
      if (board[s] === 'w' || board[s] === 'W') white++;
      if (board[s] === 'b' || board[s] === 'B') black++;
    }
    assert.ok(white >= 1 && black >= 1, `both camps present (seed ${seed})`);
    assert.ok(white <= 20 && black <= 20, `piece counts within limits (seed ${seed})`);
    assert.ok(side === 'w' || side === 'b');
  }
}

// --- puzzles: solvable, unique solution, verified by the rules engine ---
let generated = 0;
let capturePuzzles = 0;
let paradePuzzles = 0;
for (let seed = 1; seed <= 400 && generated < 40; seed++) {
  const puzzle = generatePuzzle(seed);
  if (!puzzle) continue;
  generated++;
  const legal = generateLegalMoves(puzzle.board, puzzle.side);
  assert.ok(legal.length > 0, `puzzle ${seed} has legal moves`);
  const matches = legal.filter(move => movePathsEqual(move, puzzle.solution));
  assert.equal(matches.length, 1, `puzzle ${seed} solution is a legal move`);

  if (puzzle.type === 'capture') {
    capturePuzzles++;
    assert.ok(puzzle.solution.captured.length >= 2, `capture puzzle ${seed} takes >= 2`);
    const maxLen = Math.max(...legal.filter(m => m.captured.length).map(m => m.captured.length));
    assert.equal(puzzle.solution.captured.length, maxLen, `puzzle ${seed} solution is the max capture`);
    const applied = applyMove(puzzle.board, puzzle.solution);
    for (const captured of puzzle.solution.captured) assert.equal(applied[captured], 'e', `puzzle ${seed} removes captured piece`);
  } else {
    paradePuzzles++;
    // The solution is the unique move after which the opponent cannot capture at all.
    const afterSolution = applyMove(puzzle.board, puzzle.solution);
    const replies = generateLegalMoves(afterSolution, opponent(puzzle.side));
    assert.ok(replies.every(reply => reply.captured.length === 0), `parade ${seed}: no capture after solution`);
    // Every other legal move loses at least one piece.
    for (const move of legal) {
      if (movePathsEqual(move, puzzle.solution)) continue;
      const after = applyMove(puzzle.board, move);
      const opp = generateLegalMoves(after, opponent(puzzle.side));
      const worst = opp.reduce((max, reply) => Math.max(max, reply.captured.length), 0);
      assert.ok(worst >= 1, `parade ${seed}: alternative loses material`);
    }
  }
}
assert.ok(generated >= 25, `enough puzzles generated (${generated})`);
assert.ok(capturePuzzles >= 5, `capture puzzles present (${capturePuzzles})`);
assert.ok(paradePuzzles >= 5, `parade puzzles present (${paradePuzzles})`);

// --- daily seed is stable ---
assert.equal(puzzleSeed(new Date('2026-10-18T10:00:00Z')), puzzleSeed(new Date('2026-10-18T23:59:00Z')));
assert.equal(String(puzzleSeed(new Date('2026-10-18'))), '20261018');

console.log(`Puzzle tests passed: ${generated} puzzles verified (${capturePuzzles} prises, ${paradePuzzles} parades), PRNG déterministe.`);
