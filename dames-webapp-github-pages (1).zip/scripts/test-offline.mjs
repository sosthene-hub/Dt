import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const basePath = process.env.VITE_BASE_PATH || '/';
const origin = new URL(basePath, 'https://example.test/').href;
const scopePath = new URL(origin).pathname;
const cacheMap = new Map();
const listeners = {};
let online = true;
const normalize = input => new URL(typeof input === 'string' ? input : input.url, origin).href;
const cache = {
  async put(key, response) { cacheMap.set(normalize(key), response.clone()); },
  async match(key) { return cacheMap.get(normalize(key))?.clone(); },
};
const caches = {
  async open() { return cache; },
  async keys() { return ['dames-internationales-shell-v3']; },
  async delete() { return true; },
};
async function fetchLocal(input) {
  if (!online) throw new Error('offline');
  const url = new URL(typeof input === 'string' ? input : input.url, origin);
  let relative = url.pathname.slice(scopePath.length);
  if (!relative || relative === 'index.html') relative = 'index.html';
  const file = path.join(dist, relative);
  try { return new Response(await fs.readFile(file), { status: 200 }); }
  catch { return new Response('Not found', { status: 404 }); }
}
const self = {
  location: new URL('sw.js', origin),
  registration: { scope: origin },
  clients: { async claim() {} },
  addEventListener(type, handler) { listeners[type] = handler; },
  async skipWaiting() {},
};
const context = vm.createContext({ self, caches, fetch: fetchLocal, URL, Response, console });
vm.runInContext(await fs.readFile(path.join(root, 'public/sw.js'), 'utf8'), context);
let installDone;
listeners.install({ waitUntil(promise) { installDone = promise; } });
await installDone;
const expected = [
  new URL('', origin).href,
  new URL('scan-normal.worker.js', origin).href,
  ...['scan-wasm.worker.js','scan-wasm-scalar.js','scan-wasm-simd.js','scan-book.bin'].map(n=>new URL(n,origin).href),
  new URL('scan_normal.data?v=24a27f10', origin).href,
  new URL('manifest.webmanifest', origin).href,
  ...['icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon-180.png','icons/favicon-48.png'].map(n=>new URL(n,origin).href),
];
for (const url of expected) assert.ok(cacheMap.has(url), `precache is missing ${url}`);
const html = await (await cache.match(new URL('', origin).href)).text();
const assets = [...html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g)].map(match => new URL(match[1], origin).href);
for (const asset of assets) assert.ok(cacheMap.has(asset), `precache is missing app asset ${asset}`);

online = false;
let navigationResponse;
listeners.fetch({
  request: { url: origin, method: 'GET', mode: 'navigate' },
  respondWith(promise) { navigationResponse = promise; },
});
const offlinePage = await navigationResponse;
assert.equal(offlinePage.status, 200);
assert.match(await offlinePage.text(), /PIONICIDE/);
let engineResponse;
listeners.fetch({
  request: { url: new URL('scan_normal.data?v=24a27f10', origin).href, method: 'GET', mode: 'cors' },
  respondWith(promise) { engineResponse = promise; },
});
assert.equal((await engineResponse).status, 200);
// Manifeste : installable (nom, icônes 192/512, mode standalone).
const manifest = JSON.parse(await fs.readFile(path.join(dist, 'manifest.webmanifest'), 'utf8'));
assert.equal(manifest.short_name, 'PIONICIDE');
assert.equal(manifest.display, 'standalone');
assert.ok(manifest.lang === 'fr');
const sizes = manifest.icons.map(icon => icon.sizes);
assert.ok(sizes.includes('192x192') && sizes.includes('512x512'), 'icônes 192 et 512 présentes');
assert.ok(manifest.icons.some(icon => (icon.purpose || '').includes('maskable')), 'icône maskable présente');
for (const icon of manifest.icons) {
  const file = path.join(dist, icon.src);
  const bytes = await fs.readFile(file);
  assert.ok(bytes.length > 1000, `icône manquante ou vide : ${icon.src}`);
  assert.equal(bytes.subarray(1, 4).toString(), 'PNG', `icône non PNG : ${icon.src}`);
}
const distHtml = await fs.readFile(path.join(dist, 'index.html'), 'utf8');
assert.match(distHtml, /rel="manifest"/, 'index.html référence le manifeste');
assert.match(distHtml, /apple-touch-icon/, 'icône iOS déclarée');
// Icône servie hors ligne une fois la première visite faite.
let iconResponse;
listeners.fetch({
  request: { url: new URL('icons/icon-512.png', origin).href, method: 'GET', mode: 'cors' },
  respondWith(promise) { iconResponse = promise; },
});
assert.equal((await iconResponse).status, 200);
console.log(`OK — shell PIONICIDE, assets, données du moteur et manifeste d'installation précachés hors ligne (${scopePath}).`);
