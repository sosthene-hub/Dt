import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const basePath = process.env.VITE_BASE_PATH || '/';
const origin = new URL(basePath, 'https://example.test/').href;
const scopePath = new URL(origin).pathname;
const cacheMap = new Map();
const listeners = {};
let online = true;
const normalize = input => new URL(typeof input === 'string' ? input : input.url, origin).href;
const cache = {
  async put(key, response) { cacheMap.set(normalize(key), response.clone()); },
  async match(key) { return cacheMap.get(normalize(key))?.clone(); },
};
const caches = {
  async open() { return cache; },
  async keys() { return ['dames-internationales-shell-v3']; },
  async delete() { return true; },
};
async function fetchLocal(input) {
  if (!online) throw new Error('offline');
  const url = new URL(typeof input === 'string' ? input : input.url, origin);
  let relative = url.pathname.slice(scopePath.length);
  if (!relative || relative === 'index.html') relative = 'index.html';
  const file = path.join(dist, relative);
  try { return new Response(await fs.readFile(file), { status: 200 }); }
  catch { return new Response('Not found', { status: 404 }); }
}
const self = {
  location: new URL('sw.js', origin),
  registration: { scope: origin },
  clients: { async claim() {} },
  addEventListener(type, handler) { listeners[type] = handler; },
  async skipWaiting() {},
};
const context = vm.createContext({ self, caches, fetch: fetchLocal, URL, Response, console });
vm.runInContext(await fs.readFile(path.join(root, 'public/sw.js'), 'utf8'), context);
let installDone;
listeners.install({ waitUntil(promise) { installDone = promise; } });
await installDone;
const expected = [
  new URL('', origin).href,
  new URL('scan-normal.worker.js', origin).href,
  new URL('scan_normal.data?v=24a27f10', origin).href,
];
for (const url of expected) assert.ok(cacheMap.has(url), `precache is missing ${url}`);
const html = await (await cache.match(new URL('', origin).href)).text();
const assets = [...html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g)].map(match => new URL(match[1], origin).href);
for (const asset of assets) assert.ok(cacheMap.has(asset), `precache is missing app asset ${asset}`);

online = false;
let navigationResponse;
listeners.fetch({
  request: { url: origin, method: 'GET', mode: 'navigate' },
  respondWith(promise) { navigationResponse = promise; },
});
const offlinePage = await navigationResponse;
assert.equal(offlinePage.status, 200);
assert.match(await offlinePage.text(), /Dames/);
let engineResponse;
listeners.fetch({
  request: { url: new URL('scan_normal.data?v=24a27f10', origin).href, method: 'GET', mode: 'cors' },
  respondWith(promise) { engineResponse = promise; },
});
assert.equal((await engineResponse).status, 200);
console.log(`OK — le shell, les assets et les données Scan sont précachés hors ligne (${scopePath}).`);
