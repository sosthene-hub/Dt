// Tests unitaires et d'intégration moteur WASM pour la détection à la demande
// des mauvais coups (?!/ ? / ??) et de leurs variantes de réfutation vers le gain.
import fs from 'node:fs';
import path from 'node:path';
import Module from 'node:module';
import assert from 'node:assert/strict';

import bitbases from '../src/bitbases-data.js';
import { parsePdnPosition } from '../src/position.js';
import { initialState, appendState } from '../src/game-history.js';
import { generateLegalMoves, moveToHub } from '../src/game-rules.js';
import { parsePdnGames, replayPdnGame, moveToPdn } from '../src/pdn.js';
import { createMemoSearch } from '../src/analysis/threats.js';
import {
  analyzeBadMoves,
  classifyCandidateLoss,
  classifyExploitationVerdict,
  formatBadMoveStudyComment,
} from '../src/analysis/refutations.js';
import {
  createManualTree,
  addLineToTree,
  updateNodeAnnotation,
  buildAnalysisBlocks,
  blocksToPlainText,
  treeToPdn,
  parsePdnToTree,
} from '../src/analysis/manual-tree.js';

const variant = process.env.SCAN_RUNTIME === 'simd' ? 'simd' : 'scalar';
const filename = path.resolve('public/scan-wasm-' + variant + '.js');
const native = new Module(filename);
native.filename = filename;
native.paths = Module._nodeModulePaths(path.dirname(filename));
native._compile(fs.readFileSync(filename, 'utf8'), filename);

let resolveWait;
let searchResolve;
let info = [];
const ready = new Promise(resolve => { resolveWait = resolve; });
const mod = await native.exports({
  noInitialRun: true,
  print: line => {
    if (line === 'ready') resolveWait();
    if (line.startsWith('info')) info.push(line);
    if (line.startsWith('done')) searchResolve?.({ done: line, infos: info.slice() });
  },
  printErr: line => { if (line.startsWith('error')) throw Error(line); },
});
mod.FS.mkdirTree('/data');
mod.FS.writeFile('/data/eval', fs.readFileSync('public/scan_normal.data').subarray(0, 8503280));
mod.FS.writeFile('/data/book', fs.readFileSync('public/scan-book.bin'));
for (const [name, text] of Object.entries(bitbases)) {
  mod.FS.mkdirTree('/' + path.dirname(name));
  mod.FS.writeFile('/' + name, Buffer.from(text, 'base64'));
}
mod._main(0, 0);
const send = text => mod.ccall('scan_command', null, ['string'], [text]);
send('hub');
send('set-param name=tt-size value=20');
send('set-param name=bb-size value=4');
send('set-param name=book value=false');
send('init');
await ready;

function parseInfo(line) {
  const read = key => {
    const match = line.match(new RegExp(`(?:^|\\s)${key}=([\\d.+-]+)`));
    return match ? Number(match[1]) : undefined;
  };
  const pvMatch = line.match(/\bpv="([^"]*)"/);
  return {
    raw: line,
    depth: read('depth'),
    score: read('score'),
    nodes: read('nodes'),
    time: read('time'),
    pv: pvMatch ? pvMatch[1].split(/\s+/).filter(Boolean) : [],
    completed: /\bcompleted=true\b/.test(line),
    timeLimited: /\blimit=time\b/.test(line),
  };
}

const engineSearch = async ({ position, depth = 10, mode = 'analyze', maxTimeMs = 1000 }) => {
  const seconds = Math.max(0.05, Math.min(30, (Number(maxTimeMs) || 1000) / 1000));
  const reply = await new Promise((resolve, reject) => {
    info = [];
    const timer = setTimeout(() => reject(Error('recherche bloquée')), seconds * 1000 + 15000);
    searchResolve = result => { clearTimeout(timer); resolve(result); };
    send('pos ' + position);
    send(`level depth=${depth} move-time=${seconds}`);
    send('go ' + mode);
  });
  const infos = reply.infos.map(parseInfo);
  return {
    move: reply.done.match(/\bmove=([^ ]+)/)?.[1] || null,
    infos,
    timeLimited: infos.some(entry => entry.timeLimited),
    timedOut: false,
    stale: false,
  };
};

const memo = createMemoSearch(engineSearch);

// 1. Tests unitaires des seuils et verdicts
assert.equal(classifyCandidateLoss(0, true).symbol, '!');
assert.equal(classifyCandidateLoss(0.12, false).severity, 'good');
assert.equal(classifyCandidateLoss(0.32, false).symbol, '?!');
assert.equal(classifyCandidateLoss(0.85, false).symbol, '?');
assert.equal(classifyCandidateLoss(2.10, false).symbol, '??');

assert.equal(classifyExploitationVerdict(95, null).code, 'gain-force');
assert.equal(classifyExploitationVerdict(95, null).leadsToWin, true);
assert.equal(classifyExploitationVerdict(1.85, null).code, 'gain-decisif');
assert.equal(classifyExploitationVerdict(1.85, null).leadsToWin, true);
assert.equal(classifyExploitationVerdict(0.85, null).code, 'avantage-net');
assert.equal(classifyExploitationVerdict(0.0, null).code, 'avantage-lache');

// 2. Cas forcé (prise unique obligatoire) : 0 mauvais coup de choix
{
  const pos = parsePdnPosition('W:W28:B22');
  const st = initialState(pos.board, pos.side);
  const res = await analyzeBadMoves(st, { search: memo, depth: 8 });
  assert.equal(res.forced, true);
  assert.equal(res.badMoves.length, 0);
  assert.equal(res.bestPdn, '28x17');
}

// 3. Position tactique : Noirs au trait avec coups sains ET gaffes permettant une combinaison gagnante
{
  // Blancs : 27, 32, 37, 38, 43 — Noirs : 12, 13, 18, 19, 24 (trait aux Noirs)
  // Plusieurs coups noirs imprudents (ex. 24-29 ou 24-30) tombent dans des combinaisons ou pertes décisives !
  const pos = parsePdnPosition('B:W27,32,37,38,43:B12,13,18,19,24');
  const st = initialState(pos.board, pos.side);
  const res = await analyzeBadMoves(st, { search: memo, depth: 10, maxTimeMs: 800 });

  assert.equal(res.cancelled, false);
  assert.equal(res.side, 'b');
  assert.equal(res.punisherSide, 'w');
  assert.ok(res.candidates.length >= 4, 'Plusieurs coups légaux attendus');
  assert.ok(res.badMoves.length >= 2, `Au moins 2 mauvais coups attendus, obtenu ${res.badMoves.length}`);

  // Tri décroissant par perte
  for (let i = 1; i < res.badMoves.length; i += 1) {
    assert.ok(res.badMoves[i - 1].loss >= res.badMoves[i].loss - 1e-9, 'Tri par perte décroissante');
  }

  // Au moins une erreur doit offrir une suite gagnante aux Blancs avec variante légale
  const winningRef = res.badMoves.find(b => b.verdict.leadsToWin && b.refutationMoves.length >= 2);
  assert.ok(winningRef, 'Au moins un mauvais coup doit présenter une variante de réfutation gagnante');

  // Vérifie que chaque coup de la variante de réfutation est strictement légal selon les règles FMJD
  let checkStates = [winningRef.afterState];
  for (const rm of winningRef.refutationMoves) {
    const tail = checkStates.at(-1);
    const legals = generateLegalMoves(tail.board, tail.side);
    assert.ok(legals.some(l => moveToHub(l) === moveToHub(rm)), `Coup de réfutation légal : ${moveToPdn(rm)}`);
    checkStates = appendState(checkStates, rm);
  }

  // Intégration directe dans l'arbre d'analyse manuelle + aller-retour PDN + rendu imprimable
  const tree = createManualTree({ start: st, moves: [] });
  const { firstNode } = addLineToTree(tree, tree.root.id, [winningRef.move, ...winningRef.refutationMoves], { asVariation: true });
  updateNodeAnnotation(tree, firstNode.id, {
    symbol: winningRef.symbol,
    preComment: 'Si',
    comment: formatBadMoveStudyComment(winningRef, res.punisherSide),
  });
  if (firstNode.main) updateNodeAnnotation(tree, firstNode.main.id, { symbol: '!' });

  const text = blocksToPlainText(buildAnalysisBlocks(tree));
  assert.ok(text.includes(`${winningRef.pdn}${winningRef.symbol}`), `Texte imprimable attendu : ${text}`);
  const exported = treeToPdn(tree, { headers: { Event: 'Entraînement réfutations' }, result: '*' });
  const reparsed = parsePdnToTree(exported);
  assert.equal(reparsed.tree.root.variations.length, 1);
}

// 4. Position de milieu de partie réelle (fixture PDN) + annulation propre
{
  const pdnRaw = fs.readFileSync('fixtures/Verpoest-Berte-1980.pdn', 'utf8');
  const games = parsePdnGames(pdnRaw);
  const replayed = replayPdnGame(games[0]);
  let states = [initialState(replayed.start.board, replayed.start.side)];
  for (const m of replayed.moves.slice(0, 24)) states = appendState(states, m);

  const midState = states.at(-1);
  const res = await analyzeBadMoves(midState, { search: memo, depth: 9, maxTimeMs: 700 });
  assert.equal(res.cancelled, false);
  assert.ok(res.candidates.length >= 5);
  assert.ok(res.bestPdn.length >= 4);

  // Test d'annulation immédiate
  const cancelled = await analyzeBadMoves(midState, {
    search: memo,
    depth: 9,
    shouldStop: () => true,
  });
  assert.equal(cancelled.cancelled, true);
}

console.log('✓ Détection des mauvais coups (?!/ ? / ??) et variantes de réfutation : tous les tests réussis');
