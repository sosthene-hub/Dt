import assert from 'node:assert/strict';
import { applyMove, createInitialBoard, generateLegalMoves, moveMatchesEngine, moveToHub, positionKey, squareAtPosition } from '../src/game-rules.js';

const initial = createInitialBoard();
const opening = generateLegalMoves(initial, 'w');
assert.equal(opening.length, 9, 'standard start should have nine distinct white destinations');
const move3228 = opening.find(move => move.from === 32 && move.to === 28);
assert.ok(move3228, '32-28 is a legal opening move');
const afterOpening = applyMove(initial, move3228);
assert.equal(afterOpening[32], 'e');
assert.equal(afterOpening[28], 'w');
const blackReplies = generateLegalMoves(afterOpening, 'b');
assert.ok(blackReplies.some(move => move.from === 18 && move.to === 23), '18-23 is a legal Scan reply after 32-28');
const blackReply = blackReplies.find(move => move.from === 18 && move.to === 23);
const afterBlackReply = applyMove(afterOpening, blackReply);
assert.ok(generateLegalMoves(afterBlackReply, 'w').some(move => move.from === 37 && move.to === 32), '37-32 is a legal follow-up');

const captureBoard = Array(51).fill('e');
const whiteStart = squareAtPosition(5, 2);
captureBoard[whiteStart] = 'w';
captureBoard[squareAtPosition(4, 3)] = 'b';
captureBoard[squareAtPosition(2, 5)] = 'b';
captureBoard[squareAtPosition(5, 6)] = 'w';
captureBoard[squareAtPosition(4, 7)] = 'b';
const mandatory = generateLegalMoves(captureBoard, 'w');
assert.ok(mandatory.length > 0);
assert.ok(mandatory.every(move => move.captured.length === 2), 'only maximum capture sequences must be legal');
const twoCapture = mandatory[0];
assert.equal(twoCapture.captured.length, 2);
const afterCapture = applyMove(captureBoard, twoCapture);
assert.equal(afterCapture[twoCapture.from], 'e');
assert.equal(afterCapture[twoCapture.to], 'w');
for (const captured of twoCapture.captured) assert.equal(afterCapture[captured], 'e');
assert.ok(moveMatchesEngine(twoCapture, moveToHub(twoCapture)));
assert.equal(positionKey(afterCapture, 'b').startsWith('b:'), true);
const engineCaptureBoard = Array(51).fill('e');
engineCaptureBoard[18] = 'b'; engineCaptureBoard[22] = 'w'; engineCaptureBoard[23] = 'w';
assert.ok(generateLegalMoves(engineCaptureBoard, 'b').some(move => moveMatchesEngine(move, '18x27x22')), 'Scan capture notation maps to a legal local move');

const kingBoard = Array(51).fill('e');
const kingStart = squareAtPosition(6, 1);
const victim = squareAtPosition(4, 3);
kingBoard[kingStart] = 'W'; kingBoard[victim] = 'b';
const kingCaptures = generateLegalMoves(kingBoard, 'w');
assert.ok(kingCaptures.length >= 2, 'flying king may choose any empty landing beyond the captured piece');
assert.ok(kingCaptures.every(move => move.captured.length === 1 && move.captured[0] === victim));

// Captured pieces stay as blockers until the sequence ends (FMJD rule 4.11).
const blockerBoard = Array(51).fill('e');
blockerBoard[squareAtPosition(5, 4)] = 'W';
const firstBlocker = squareAtPosition(3, 6);
const secondBehind = squareAtPosition(8, 1);
blockerBoard[firstBlocker] = 'b'; blockerBoard[secondBehind] = 'b';
const blockerCaptures = generateLegalMoves(blockerBoard, 'w');
assert.ok(blockerCaptures.length > 0);
assert.ok(blockerCaptures.every(move => move.captured.length === 1), 'a previously captured piece must still block the flying king');

const promotionBoard = Array(51).fill('e');
const nearPromotion = squareAtPosition(1, 2);
promotionBoard[nearPromotion] = 'w';
const promotionMove = generateLegalMoves(promotionBoard, 'w').find(move => squareAtPosition(0, 3) === move.to);
assert.ok(promotionMove);
assert.equal(applyMove(promotionBoard, promotionMove)[promotionMove.to], 'W');

const promotionPassBoard = Array(51).fill('e');
const manBeforeBackRank = squareAtPosition(2, 1);
promotionPassBoard[manBeforeBackRank] = 'w';
promotionPassBoard[squareAtPosition(1, 2)] = 'b';
promotionPassBoard[squareAtPosition(1, 4)] = 'b';
const passThroughLine = generateLegalMoves(promotionPassBoard, 'w');
const twoJumpsThroughBackRank = passThroughLine.find(move => move.from === manBeforeBackRank && move.captured.length === 2);
assert.ok(twoJumpsThroughBackRank, 'a man can continue capturing after passing through the promotion row');
assert.equal(applyMove(promotionPassBoard, twoJumpsThroughBackRank)[twoJumpsThroughBackRank.to], 'w', 'it stays a man if the sequence ends off the promotion row');

console.log('OK — ouverture, prises maximales, pièces capturées bloquantes, dame volante, promotion et notation HUB.');
