import { chromium } from 'playwright';
import fs from 'node:fs';
import { generateLegalMoves, applyMove, opponent, positionKey } from '../src/game-rules.js';
import { probeValue } from '../src/bitbases.js';
import { newDrawState, advanceDraw, adjudicate } from '../src/draw-rules.js';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, offline: true });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push('console: ' + message.text()); });
await page.goto('file:///home/user/projet/Dames-autonome.html');
await page.waitForFunction(() => document.querySelector('#engine-status')?.textContent.includes('Prêt'), null, { timeout: 60000 });
async function nav(id) { await page.click('#menu-toggle'); await page.click(`[data-page="${id}"]`); }

// Finale nulle : dame blanche contre dame noire.
await nav('editeur');
await page.click('#ed-import');
await page.locator('#ed-import-input').fill('W:WK46:BK1');
await page.locator('#ed-import-input').dispatchEvent('change');
await page.click('#ed-analyze');
await page.waitForFunction(() => !document.querySelector('#an-status').textContent.includes('analyse'), null, { timeout: 20000 });
await page.uncheck('#an-auto');
if (!(await page.locator('#tb-result').textContent()).startsWith('Nulle')) throw Error('Exact WDL missing');

// Nulle des 5 coups jouée sur le damier, puis annulation : les compteurs reviennent.
let board = Array(51).fill('e');
board[46] = 'W'; board[1] = 'B';
let side = 'w';
let state = newDrawState(board, side);
const seen = new Set([positionKey(board, side)]);
const line = [];
for (let i = 0; i < 10; i += 1) {
  const legal = generateLegalMoves(board, side);
  const move = legal.find(m => !m.captured.length && probeValue(applyMove(board, m), opponent(side)) === 0 && !seen.has(positionKey(applyMove(board, m), opponent(side))));
  if (!move) throw Error('No safe test line');
  const before = board;
  board = applyMove(board, move);
  side = opponent(side);
  state = advanceDraw(state, before, move, board, side);
  seen.add(positionKey(board, side));
  line.push(move);
  await page.click(`#analysis-board [data-square="${move.from}"]`);
  await page.click(`#analysis-board [data-square="${move.to}"]`);
}
if (adjudicate(board, side, state)?.result !== '1/2-1/2') throw Error('Bad test line');
if (!(await page.locator('#an-status').textContent()).includes('5 coups')) throw Error('5-move UI failed');
await page.click('#an-undo');
if ((await page.locator('#tb-result').textContent()).startsWith('1/2-1/2')) throw Error('Undo failed to restore clocks');
await page.screenshot({ path: '/home/user/perf/finales-mobile.png', fullPage: true });

// Finale gagnante avec prise.
await nav('editeur');
await page.click('#ed-import');
await page.fill('#ed-import-input', 'W:WK32:BK19');
await page.locator('#ed-import-input').dispatchEvent('change');
await page.click('#ed-analyze');
if (!(await page.locator('#tb-result').textContent()).startsWith('Gain')) throw Error('Capture WDL missing');

const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
if (errors.length || overflow) throw Error(JSON.stringify({ errors, overflow }));
fs.writeFileSync('browser-finales-results.json', JSON.stringify({
  offline: true,
  fileMode: true,
  viewport: '412×915',
  tableDraw: true,
  tableWin: true,
  fiveMoveDraw: true,
  undoClocks: true,
  searchRemoved: true,
  errors,
  overflow,
  line: line.map(m => m.path),
}, null, 2));
console.log('Navigateur hors ligne : tables, nulle 5 coups, annulation : OK');
await browser.close();
