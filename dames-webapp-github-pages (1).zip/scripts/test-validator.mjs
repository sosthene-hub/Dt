import assert from 'node:assert/strict';
import fs from 'node:fs';
import { validateCombinationPosition, validatePlayablePosition, DEFAULT_VALIDATION } from '../src/combinations/validator.js';
import { generateLegalMoves } from '../src/game-rules.js';
import { generateVerified, buildCandidate } from '../src/combinations/generate.js';

const make = pieces => {
  const board = Array(51).fill('e');
  for (const [square, piece] of pieces) board[square] = piece;
  return board;
};
const codes = report => report.violations.map(v => v.code);

/* 1. Règles prises une par une. */
{
  // Pion blanc sur la ligne de promotion noire (cases 1-5).
  const board = make([[3, 'w'], [46, 'B'], [30, 'w'], [20, 'b']]);
  const report = validateCombinationPosition({ board, side: 'w', solution: [] }, {}, { scope: 'all' });
  assert.ok(codes(report).includes('pion-sur-promotion'), 'pion blanc en 3 doit être refusé');
  // Pion noir sur la ligne de promotion blanche (46-50).
  const board2 = make([[46, 'b'], [11, 'w'], [30, 'w'], [20, 'b']]);
  assert.ok(codes(validateCombinationPosition({ board: board2, side: 'w' }, {}, { scope: 'all' })).includes('pion-sur-promotion'), 'pion noir en 46 doit être refusé');
}
{
  // Plus de 20 pièces.
  const pieces = [];
  for (let n = 11; n <= 32; n += 1) pieces.push([n, 'w']);
  for (let n = 1; n <= 10; n += 1) pieces.push([n, 'b']);
  const report = validateCombinationPosition({ board: make(pieces), side: 'w' }, {}, { scope: 'all' });
  assert.ok(codes(report).includes('trop-de-pieces'));
}
{
  // Écart de matériel supérieur au maximum.
  const board = make([[11, 'w'], [12, 'w'], [13, 'w'], [14, 'w'], [15, 'w'], [16, 'w'], [20, 'b'], [30, 'b']]);
  const report = validateCombinationPosition({ board, side: 'w' }, { maxMaterialGap: 3 }, { scope: 'all' });
  assert.ok(codes(report).includes('ecart-materiel'), '6 contre 2 doit dépasser l’écart de 3');
  const tolerant = validateCombinationPosition({ board, side: 'w' }, { maxMaterialGap: 3, rejectIsolated: false }, { scope: 'all' });
  assert.ok(!codes(tolerant).includes('ecart-materiel') === false);
}
{
  // Leurre trop avancé : pion blanc rangée 2 (case 7), pion noir rangée 9 (case 44).
  const board = make([[7, 'w'], [44, 'b'], [21, 'w'], [31, 'b'], [22, 'w'], [32, 'b']]);
  const report = validateCombinationPosition({ board, side: 'w', added: [{ square: 7, color: 'w' }, { square: 44, color: 'b' }] }, {}, { scope: 'added' });
  assert.ok(codes(report).includes('pion-trop-avance'));
  // La même case est acceptée en mode promotion seule.
  const loose = validateCombinationPosition({ board, side: 'w', added: [{ square: 7, color: 'w' }] }, { whiteManMinRow: 2 }, { scope: 'added' });
  assert.ok(!codes(loose).includes('pion-trop-avance'));
}
{
  // Leurre isolé : aucune pièce amie à moins de deux cases.
  const board = make([[11, 'w'], [12, 'w'], [13, 'w'], [20, 'b'], [21, 'b'], [22, 'b'], [45, 'w']]);
  const report = validateCombinationPosition({ board, side: 'w', added: [{ square: 45, color: 'w' }] }, {}, { scope: 'added' });
  assert.ok(codes(report).includes('pion-isole'));
  const tolerated = validateCombinationPosition({ board, side: 'w', added: [{ square: 45, color: 'w' }] }, { rejectIsolated: false }, { scope: 'added' });
  assert.ok(!codes(tolerated).includes('pion-isole'));
}
{
  // Prise parasite : deux prises de même longueur au trait.
  const board = make([[32, 'w'], [19, 'b'], [20, 'b'], [12, 'w'], [7, 'b'], [45, 'B']]);
  const before = generateLegalMoves(board, 'w');
  const report = validateCombinationPosition(
    { board, side: 'w', solution: ['32x21x12'] },
    {},
    { scope: 'all' },
  );
  assert.ok(codes(report).includes('rafle-absente') || codes(report).includes('prise-parasite'), JSON.stringify(before.map(m => [m.from, m.to, m.captured])));
}

/* 2. Position jouable depuis l’éditeur. */
{
  assert.equal(validatePlayablePosition(make([[32, 'w'], [19, 'b']]), 'w').length, 0);
  assert.ok(validatePlayablePosition(make([[3, 'w'], [19, 'b']]), 'w').length > 0, 'pion sur promotion refusé');
  const blocked = make([[46, 'w'], [1, 'b']]);
  // Les blancs ont un coup légal (46 est une dame blanche) : la position reste jouable.
  assert.equal(validatePlayablePosition(blocked, 'w').length, 0);
  const noMove = make([[5, 'w'], [1, 'b']]);
  // Pion blanc en 5 est sur la promotion : refus avant même le blocage.
  assert.ok(validatePlayablePosition(noMove, 'w').some(message => /promotion/.test(message)));
}

/* 3. Génération réelle : toutes les pièces ajoutées respectent les règles. */
const db = JSON.parse(fs.readFileSync('public/combinations-app.json', 'utf8'));
const entries = db.entries;
const generation = {};
for (const level of [2, 3, 4]) {
  let accepted = 0;
  const rejected = {};
  const failures = [];
  const addedSquares = { w: [], b: [] };
  const N = 40;
  for (let seed = 0; seed < N; seed += 1) {
    const result = await generateVerified(entries, { level, attempts: 10, seed: 900 + seed, timeBudgetMs: 8000 });
    if (result.candidate) {
      accepted += 1;
      const report = validateCombinationPosition(result.candidate, DEFAULT_VALIDATION, { scope: 'added' });
      assert.ok(report.ok, `niveau ${level} : position générée refusée ${JSON.stringify(report.violations)}`);
      for (const item of result.candidate.added) addedSquares[item.color].push(item.square);
    } else {
      failures.push(Object.keys(result.stats.rejected)[0] || 'aucun candidat');
      for (const [cause, count] of Object.entries(result.stats.rejected)) rejected[cause] = (rejected[cause] || 0) + count;
    }
  }
  // Niveaux 2 et 3 : aucune perte (les contraintes d’emplacement sont larges).
  // Niveau 4 : quelques modèles du livre deviennent injouables après ajout de
  // leurres (une prise nouvelle rend un coup ultérieur illégal) ; l’application
  // réessaie 80 fois, on tolère donc 2 échecs sur 40 ici.
  assert.ok(accepted >= (level === 4 ? N - 2 : N), `niveau ${level} : ${N - accepted} échecs de génération`);
  // Aucun pion ajouté sur une rangée interdite.
  for (const square of addedSquares.w) assert.ok(Math.floor((square - 1) / 5) + 1 >= 3, `pion blanc ajouté en ${square}`);
  for (const square of addedSquares.b) assert.ok(Math.floor((square - 1) / 5) + 1 <= 8, `pion noir ajouté en ${square}`);
  generation[level] = {
    attempts: N,
    accepted,
    addedMen: { white: addedSquares.w.length, black: addedSquares.b.length },
    failures,
    rejected,
  };
}

/* 4. Base du livre : contrôle documentaire, non bloquant. */
const book = { total: entries.length, byCode: {}, promotionRow: 0, materialGap: {}, maxGap: 0 };
for (const entry of entries) {
  const report = validateCombinationPosition({ board: entry.board, side: entry.trait, solution: entry.solution }, {}, { scope: 'all' });
  for (const violation of report.violations) book.byCode[violation.code] = (book.byCode[violation.code] || 0) + 1;
  if (report.violations.some(v => v.code === 'pion-sur-promotion')) book.promotionRow += 1;
  const gap = Math.abs(entry.nb_pieces_blanc - entry.nb_pieces_noir);
  book.materialGap[gap] = (book.materialGap[gap] || 0) + 1;
  book.maxGap = Math.max(book.maxGap, gap);
}
assert.equal(book.promotionRow, 0, 'aucune position du livre ne doit avoir un pion sur une ligne de promotion');

const output = {
  date: new Date().toISOString(),
  rules: {
    promotionRow: 'aucun pion blanc en 1-5 ni noir en 46-50',
    maxPiecesPerSide: DEFAULT_VALIDATION.maxPiecesPerSide,
    maxMaterialGap: DEFAULT_VALIDATION.maxMaterialGap,
    addedMenAdvance: `blancs rangées 3-10, noirs rangées 1-8 (${DEFAULT_VALIDATION.isolationDistance} cases de voisinage)`,
    parasiticCapture: 'la rafle de la solution doit être la seule prise possible',
  },
  generation,
  book,
};
fs.writeFileSync('data/combinaisons/validation-coherence.json', JSON.stringify(output, null, 2));
console.log(JSON.stringify({ generation, book }, null, 2));
console.log('Validateur de cohérence : OK');
