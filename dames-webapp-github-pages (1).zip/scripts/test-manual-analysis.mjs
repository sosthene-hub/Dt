// Tests unitaires complets de l'analyse manuelle :
// - arbre de variantes imbriquées (ligne principale, [ variante ], ( sous-variante ; sous-variante )) ;
// - fidélité exacte au format type Turbo Dambase (comme la référence utilisateur) ;
// - commentaires avant/après coup, symboles d'appréciation et diagrammes à toute position ;
// - sérialisation JSON (localStorage) et aller-retour PDN complet.

import assert from 'node:assert/strict';
import {
  createManualTree,
  mainLineNodes,
  nodeDepth,
  playMoveOnTree,
  updateNodeAnnotation,
  deleteSubtree,
  promoteVariation,
  convertMainToVariation,
  countTreeStats,
  buildAnalysisBlocks,
  blocksToPlainText,
  serializeManualTree,
  deserializeManualTree,
  treeToPdn,
  parsePdnToTree,
} from '../src/analysis/manual-tree.js';
import { parsePdnGames, replayPdnGame, resolvePdnMove } from '../src/pdn.js';

const tests = [];
const test = (name, fn) => tests.push({ name, fn });

// Reconstitution de la partie exacte de la capture d'écran de référence (coups 1 à 20)
const MAIN_TOKENS = [
  '33-28', '18-23', '31-27', '12-18', '39-33', '7-12', '44-39', '1-7',
  '49-44', '20-24', '37-31', '14-20', '41-37', '10-14', '34-29', '23x34',
  '40x29', '20-25', '29x20', '15x24', '27-22', '18x27', '31x22', '5-10',
  '44-40', '10-15', '40-34', '14-20', '45-40', '16-21', '46-41', '21-26',
  '36-31', '17-21', '41-36', '11-16', '31-27', '12-18', // 19.31-27 12-18
  '50-45', '7-11',                                       // 20.50-45 7-11
];

function playTokenList(tree, startNodeId, tokens, firstAsVar = false) {
  let curId = startNodeId;
  const createdNodes = [];
  tokens.forEach((tok, idx) => {
    const parent = tree.nodes.get(curId);
    const res = resolvePdnMove(parent.state.board, parent.state.side, tok);
    assert.ok(res.move, `Le coup ${tok} doit être légal depuis ${curId}`);
    const step = playMoveOnTree(tree, curId, res.move, { asVariation: idx === 0 ? firstAsVar : false });
    createdNodes.push(step.node);
    curId = step.node.id;
  });
  return createdNodes;
}

test('reproduction fidèle de la structure [ variante verte ] et ( sous-variante bleue )', () => {
  const tree = createManualTree();
  playTokenList(tree, tree.root.id, MAIN_TOKENS, false);
  const mains = mainLineNodes(tree);
  assert.equal(mains.length, 41); // root + 40 demi-coups

  const move19White = mains[37]; // 19.31-27
  const move19Black = mains[38]; // 19...12-18
  const move20White = mains[39]; // 20.50-45
  const move20Black = mains[40]; // 20...7-11

  updateNodeAnnotation(tree, move19Black.id, {
    comment: 'Helaas kende de zwartspeler het idee, maar niet de details. Aangewezen is',
  });

  // Variante de niveau 1 à la place de 19...12-18 : [ 19...7-11 20.50-45 24-30 21.35x24 19x30 ... ]
  const var19 = playTokenList(tree, move19White.id, [
    '7-11', '50-45', '24-30', '35x24', '19x30', '33-29', '11-17', '22x11', '16x7', '27x16', '7-11', '16x18', '13x35',
  ], true);
  assert.equal(nodeDepth(tree, var19[0].id), 1, '19...7-11 est de profondeur 1');
  assert.equal(nodeDepth(tree, var19[4].id), 1, '21...19x30 reste de profondeur 1');

  updateNodeAnnotation(tree, var19[0].id, { comment: 'Na' });
  updateNodeAnnotation(tree, var19[1].id, { comment: 'kan dan' });
  updateNodeAnnotation(tree, var19[4].id, { comment: 'en wit staat zeer slecht. Bijvoorbeeld' });

  // Sous-variante de niveau 2 à la place de 20.50-45 dans la variante : ( De hoofdvariant ... 20.34-29 12-18 ... )
  const sub20 = playTokenList(tree, var19[0].id, ['34-29', '12-18'], true);
  assert.equal(nodeDepth(tree, sub20[0].id), 2, '20.34-29 est de profondeur 2');
  updateNodeAnnotation(tree, sub20[0].id, { preComment: 'De hoofdvariant gaat verder met' });
  updateNodeAnnotation(tree, sub20[1].id, { comment: 'en zwart heeft de laatste zet' });

  // Deuxième sous-variante de niveau 2 à la place de 22.33-29 : ( Alleen het verschrikkelijke 22.40-35 ... )
  const sub22 = playTokenList(tree, var19[4].id, ['40-35'], true);
  assert.equal(nodeDepth(tree, sub22[0].id), 2);
  updateNodeAnnotation(tree, sub22[0].id, {
    preComment: 'Alleen het verschrikkelijke',
    comment: 'biedt nog wat tegenstand',
  });

  // Commentaire sur 20.50-45 + variante avec preComment avant le 1er coup
  updateNodeAnnotation(tree, move20White.id, { comment: 'Natuurlijk' });
  const var20w = playTokenList(tree, move19Black.id, ['37-31', '26x37', '42x31', '18-23'], true);
  updateNodeAnnotation(tree, var20w[0].id, { preComment: 'Tijdens het uitspelen vergreep Thomas zich aan' });
  updateNodeAnnotation(tree, var20w[3].id, { comment: 'en zwart had de touwtjes weer in handen.' });

  // Variante sur 20...7-11
  const var20b = playTokenList(tree, move20White.id, ['24-30', '35x24', '19x30'], true);
  updateNodeAnnotation(tree, var20b[0].id, { preComment: 'Nu zit het sterke ruiltje' });
  updateNodeAnnotation(tree, var20b[2].id, { comment: 'etc. er niet in' });

  const blocks = buildAnalysisBlocks(tree);
  const text = blocksToPlainText(blocks);

  assert.match(text, /1\.33-28 18-23 2\.31-27 12-18/);
  assert.match(text, /19\.31-27 12-18 Helaas kende de zwartspeler/);
  assert.match(
    text,
    /\[ 19\.\.\.7-11 Na 20\.50-45 kan dan \( De hoofdvariant gaat verder met 20\.34-29 12-18 en zwart heeft de laatste zet\) 20\.\.\.24-30 21\.35x24 19x30 en wit staat zeer slecht\. Bijvoorbeeld 22\.33-29 \( Alleen het verschrikkelijke 22\.40-35 biedt nog wat tegenstand\) 22\.\.\.11-17/,
  );
  assert.match(text, /\n20\.50-45 Natuurlijk\n/);
  assert.match(text, /\[ Tijdens het uitspelen vergreep Thomas zich aan 20\.37-31 26x37 21\.42x31 18-23 en zwart had de touwtjes weer in handen\. \]/);
  assert.match(text, /\n20\.\.\.7-11\n/);
  assert.match(text, /\[ Nu zit het sterke ruiltje 20\.\.\.24-30 21\.35x24 19x30 etc\. er niet in \]/);
});

test('deux sous-variantes sœurs de niveau 2 séparées par « ; » dans la même parenthèse', () => {
  const tree2 = createManualTree();
  playTokenList(tree2, tree2.root.id, ['33-28', '18-23'], false);
  const varA = playTokenList(tree2, tree2.root.id, ['32-28', '18-23', '37-32'], true);
  // Deux alternatives à 2.37-32 dans varA : 2.38-32 et 2.34-29
  const subA = playTokenList(tree2, varA[1].id, ['38-32'], true);
  const subB = playTokenList(tree2, varA[1].id, ['34-29'], true);
  updateNodeAnnotation(tree2, subA[0].id, { preComment: 'Sur', comment: 'égalité.' });
  updateNodeAnnotation(tree2, subB[0].id, { preComment: 'Bien est', comment: 'avantage blanc' });

  const text = blocksToPlainText(buildAnalysisBlocks(tree2));
  assert.match(text, /\( Sur 2\.38-32 égalité\.; Bien est 2\.34-30|2\.34-29 avantage blanc\)/);
  assert.match(text, /\( Sur 2\.38-32 égalité\.; Bien est 2\.34-29 avantage blanc\)/);
});

test('diagrammes insérables partout : départ, ligne principale, variante et sous-variante', () => {
  const tree = createManualTree();
  const main = playTokenList(tree, tree.root.id, ['33-28', '18-23', '31-27', '12-18'], false);
  const v1 = playTokenList(tree, main[0].id, ['20-24', '39-33'], true);
  const sub1 = playTokenList(tree, v1[0].id, ['31-27'], true);

  updateNodeAnnotation(tree, tree.root.id, { diagram: true, diagramCaption: 'Ouverture' });
  updateNodeAnnotation(tree, main[1].id, { diagram: true, diagramCaption: 'Après 1...18-23' });
  updateNodeAnnotation(tree, v1[1].id, { diagram: true, diagramCaption: 'Dans la variante' });
  updateNodeAnnotation(tree, sub1[0].id, { diagram: true, diagramCaption: 'Dans la sous-variante' });

  const stats = countTreeStats(tree);
  assert.equal(stats.diagramCount, 4);

  const blocks = buildAnalysisBlocks(tree);
  // 2 diagrammes de premier niveau (root et main[1]) + 2 diagrammes dans les segments de variation-block
  const topDiags = blocks.filter(b => b.type === 'diagram');
  assert.equal(topDiags.length, 2);
  const varBlock = blocks.find(b => b.type === 'variation-block');
  const varDiags = varBlock.segments.filter(s => s.kind === 'diagram');
  assert.equal(varDiags.length, 2);
  assert.deepEqual(
    [...topDiags, ...varDiags].map(d => d.diagramNumber).sort((a, b) => a - b),
    [1, 2, 3, 4],
  );
});

test('aller-retour JSON (localStorage) et PDN complet (variantes, commentaires, symboles, diagrammes)', () => {
  const tree = createManualTree();
  const main = playTokenList(tree, tree.root.id, ['33-28', '18-23', '31-27', '12-18'], false);
  updateNodeAnnotation(tree, main[1].id, { symbol: '?', comment: 'Imprécis', diagram: true, diagramCaption: 'Moment critique' });
  const v1 = playTokenList(tree, main[0].id, ['20-24', '39-33'], true);
  updateNodeAnnotation(tree, v1[0].id, { preComment: 'Plus solide :', symbol: '!', comment: 'bon centre' });
  const sub1 = playTokenList(tree, v1[0].id, ['34-29'], true);
  updateNodeAnnotation(tree, sub1[0].id, { comment: 'actif', diagram: true });

  // 1. Aller-retour JSON
  const json = serializeManualTree(tree);
  const fromJson = deserializeManualTree(json);
  assert.equal(
    blocksToPlainText(buildAnalysisBlocks(fromJson)),
    blocksToPlainText(buildAnalysisBlocks(tree)),
  );

  // 2. Aller-retour PDN complet + compatibilité avec le lecteur PDN existant
  const pdn = treeToPdn(tree, { headers: { White: 'Dupont', Black: 'Martin', Event: 'Analyse test' }, result: '2-0' });
  assert.match(pdn, /\[White "Dupont"\]/);
  assert.match(pdn, /\[%diagram:Moment critique\]/);

  // Le lecteur plat existant relit toujours la partie principale sans erreur
  const flatGames = parsePdnGames(pdn);
  assert.equal(flatGames.length, 1);
  const flatReplay = replayPdnGame(flatGames[0]);
  assert.equal(flatReplay.problem, null);
  assert.equal(flatReplay.moves.length, 4);

  // Le lecteur d'arbre reconstruit toutes les variantes, sous-variantes, commentaires et diagrammes
  const reparsed = parsePdnToTree(pdn);
  assert.equal(reparsed.result, '2-0');
  assert.equal(
    blocksToPlainText(buildAnalysisBlocks(reparsed.tree)),
    blocksToPlainText(buildAnalysisBlocks(tree)),
  );
});

test('édition d’arbre : suppression, promotion et conversion en variante', () => {
  const tree = createManualTree();
  const main = playTokenList(tree, tree.root.id, ['33-28', '18-23'], false);
  main.forEach(n => { n.originMain = false; });

  // Conversion du dernier coup principal en variante [ 1...18-23 ]
  assert.equal(convertMainToVariation(tree, main[1].id), true);
  assert.equal(nodeDepth(tree, main[1].id), 1);

  // Ajout d'une seconde variante puis promotion
  const v2 = playTokenList(tree, main[0].id, ['20-24'], true);
  assert.equal(promoteVariation(tree, v2[0].id), true); // passe en tête des variantes
  assert.equal(promoteVariation(tree, v2[0].id), true); // passe en ligne principale (main[0].main était null)
  assert.equal(nodeDepth(tree, v2[0].id), 0);

  // Suppression d'une variante
  const parent = deleteSubtree(tree, main[1].id);
  assert.equal(parent?.id, main[0].id);
  assert.equal(countTreeStats(tree).variationCount, 0);
});

let failed = 0;
for (const { name, fn } of tests) {
  try {
    fn();
    console.log('ok   ·', name);
  } catch (error) {
    failed += 1;
    console.error('FAIL ·', name, '\n     ', error.stack || error.message);
  }
}
console.log(`\nAnalyse manuelle : ${tests.length - failed}/${tests.length} tests réussis.`);
if (failed) process.exit(1);
