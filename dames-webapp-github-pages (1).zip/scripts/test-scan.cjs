// Browser-worker smoke test using a tiny local XMLHttpRequest shim in Node.
const fs = require('node:fs');
const path = require('node:path');
const { fileURLToPath } = require('node:url');
const workerFile = path.resolve(__dirname, '../public/scan-normal.worker.js');
global.self = global;
global.window = { encodeURIComponent, location: { pathname: workerFile } };
global.location = { pathname: workerFile };
global.self.location = { href: `file://${workerFile}` };
global.importScripts = () => {};
global.close = () => {};
global.onmessage = () => {};
const output = [];
let searchStage = 0;
let sawInfoLine = false;
global.postMessage = line => {
  line = String(line); output.push(line);
  if (line.startsWith('info')) { sawInfoLine = true; console.log(line); }
  else console.log(line);
  if (line === 'wait') {
    global.onmessage({ data: 'set-param name=tt-size value=16' });
    global.onmessage({ data: 'set-param name=bb-size value=0' });
    global.onmessage({ data: 'init' });
  }
  if (line === 'ready') {
    // App-equivalent Hub command: replay standard game history after white 32-28.
    global.onmessage({ data: 'pos start moves="32-28"' });
    global.onmessage({ data: 'level depth=5' });
    global.onmessage({ data: 'go think' });
  }
  if (line.startsWith('done')) {
    if (searchStage === 0) {
      if (!line.startsWith('done move=18-23')) process.exitCode = 1;
      searchStage = 1;
      setTimeout(() => {
        // Capture test with two legal alternatives: black 18 may take 22 or 23.
        const squares = Array(50).fill('e'); squares[17] = 'b'; squares[21] = 'w'; squares[22] = 'w';
        global.onmessage({ data: `pos pos=B${squares.join('')}` });
        global.onmessage({ data: 'level depth=3' });
        global.onmessage({ data: 'go think' });
      }, 0);
    } else if (searchStage === 1) {
      // Analysis-board flow: arbitrary position via `pos pos=…`, then `go analyze`.
      const s = Array(50).fill('e'); s[21] = 'w'; s[22] = 'w'; s[17] = 'b';
      global.onmessage({ data: `pos pos=B${s.join('')}` });
      global.onmessage({ data: 'level depth=4' });
      global.onmessage({ data: 'go analyze' });
      searchStage = 2;
    } else {
      clearTimeout(timeout);
      if (!line.startsWith('done move=18x')) process.exitCode = 1;
      if (!sawInfoLine) { process.exitCode = 1; console.error('No info line received in analyze mode'); }
      setTimeout(() => process.exit(process.exitCode || 0), 20);
    }
  }
};
global.XMLHttpRequest = class {
  open(_method, url) { this.url = url; }
  send() {
    const clean = decodeURIComponent(this.url.split('?')[0]);
    const file = path.resolve(path.dirname(workerFile), clean);
    try {
      const data = fs.readFileSync(file);
      this.status = 200;
      this.response = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
      this.responseText = data.toString();
      setTimeout(() => this.onload?.(), 0);
    } catch (err) {
      this.status = 404; this.statusText = String(err); this.onerror?.(err);
    }
  }
};
const timeout = setTimeout(() => { console.error('Timeout: Scan did not return a move'); process.exit(1); }, 30000);
// Stage 2 (analyze mode) is scheduled from the stage-1 handler below.
require('node:vm').runInThisContext(fs.readFileSync(workerFile, 'utf8'), { filename: workerFile });
global.onmessage({ data: 'hub' });
