/* Tests du module « Étude commentée » — sans navigateur, sans IndexedDB.
   Vérifie que chaque fait imprimé correspond à un comptage indépendant :
   les statistiques de la base sont recalculées à la main à partir des parties,
   puis comparées à ce que produit le module. */
import fs from 'node:fs';
import * as Core from '../src/base/core.js';
import { makeLib } from '../src/base/index-lib.js';
import { parsePdnGames, replayPdnGame, moveToPdn } from '../src/pdn.js';
import { pieceCount, buildPlyFacts, selectMoments, buildStudyModel, summarize,
  baseMoveLabel, performancePoints, sampleClass, sameMove,
  readingSentence, engineSentences, baseSentences } from '../src/study/facts.js';

const Lib = makeLib(Core);
let failures = 0;
const check = (label, condition, detail = '') => {
  if (!condition) failures += 1;
  console.log((condition ? '· OK   ' : '· ÉCHEC') + ' ' + label + (detail ? ' — ' + detail : ''));
};

/* ---------------- jeu de données ---------------- */
const complet = 'fixtures/base-1000-parties.pdn';
const fichier = fs.existsSync(complet) ? complet : 'fixtures/base-echantillon-200.pdn';
const pdn = fs.readFileSync(fichier, 'utf8');
console.log('Jeu de test : ' + fichier);

const games = [];
const seen = new Set();
for (const raw of Core.pdnGames(pdn)) {
  const rec = Lib.prepareRecord(raw, null);
  if (!rec.pl || seen.has(rec.dv)) continue;
  seen.add(rec.dv);
  rec.id = games.length + 1;
  games.push(rec);
}
check('parties chargées', games.length > 50, games.length + ' parties');

const builder = new Lib.IndexBuilder();
for (const game of games) builder.add(game, game.id);
const table = builder.finish().compact();

/* ---------------- comptage indépendant des coups par position ----------------
   On rejoue chaque partie et on compte, à la main, combien de fois chaque coup
   a été joué depuis chaque position, avec le résultat de la partie. */
const truth = new Map(); // clé position → Map(étiquette coup → {n,w,d,l})
for (const game of games) {
  let position = Core.Position.initial();
  const result = game.r;
  for (const encoded of Core.decodeMoves(game.mv)) {
    const key = Core.hash32Position(position);
    const bucket = truth.get(key) || new Map();
    const label = baseMoveLabel(encoded);
    const entry = bucket.get(label) || { n: 0, w: 0, d: 0, l: 0, from: encoded.from, to: encoded.to, caps: encoded.caps };
    entry.n += 1;
    // Les compteurs de l'index sont vus du camp au trait : même convention ici.
    if (result === '2-0') { if (position.side === 0) entry.w += 1; else entry.l += 1; }
    else if (result === '0-2') { if (position.side === 0) entry.l += 1; else entry.w += 1; }
    else if (result === '1-1') entry.d += 1;
    // résultat inconnu : seule la fréquence compte (comme bumpResult)
    bucket.set(label, entry);
    truth.set(key, bucket);
    position = Core.applyMove(position, encoded);
  }
}
check('comptage indépendant construit', truth.size > 500, truth.size + ' positions');

/* accès à la base, comme le fera la page : cases + trait → coups statistiques */
function cellsOf(position) {
  const cells = new Array(51).fill(0);
  for (let square = 1; square <= 50; square += 1) cells[square] = position.pieceAt(square);
  return cells;
}
function baseAt(position) {
  const moves = Lib.explorerMoves({ cells: cellsOf(position), side: position.side }, table);
  return { moves };
}

/* ---------------- partie réelle à étudier ---------------- */
const firstPdn = fs.readFileSync('fixtures/Verpoest-Berte-1980.pdn', 'utf8');
const parsed = parsePdnGames(firstPdn)[0];
const game = replayPdnGame(parsed);
check('partie de test relue', game.moves.length > 10 && !game.problem, game.moves.length + ' coups');
check('états cohérents', game.states.length === game.moves.length + 1);

/* positions successives au format de la base, pour interroger l'index */
const basePositions = [];
{
  let position = Core.Position.initial();
  basePositions.push(position);
  for (const move of game.moves) {
    const legal = Lib.explorerMoves({ cells: cellsOf(position), side: position.side }, table)
      .find(candidate => sameMove(candidate, move));
    position = Core.applyMove(position, legal);
    basePositions.push(position);
  }
}

const baseAtPly = index => (index < basePositions.length - 1 ? baseAt(basePositions[index]) : null);
const labels = game.moves.map(move => moveToPdn(move));

/* ---------------- 1. exactitude des statistiques ---------------- */
const facts = buildPlyFacts({
  states: game.states,
  moves: game.moves,
  labels,
  baseAt: baseAtPly,
});
check('un fait par demi-coup', facts.length === game.moves.length);

let exact = 0;
let transpositions = 0;
let mismatches = 0;
for (const ply of facts) {
  if (!ply.baseAvailable || !ply.coverage) continue;
  const key = Core.hash32Position(basePositions[ply.index]);
  const manual = truth.get(key) || new Map();
  const manualTotal = [...manual.values()].reduce((sum, entry) => sum + entry.n, 0);
  const mine = manual.get(ply.label) || { n: 0, w: 0, d: 0, l: 0 };
  if (manualTotal === ply.coverage) {
    // Aucune transposition : les deux comptages doivent coïncider exactement.
    exact += 1;
    if (manualTotal !== ply.coverage) mismatches += 1;
    if (mine.n !== ply.played.n) { mismatches += 1; console.log(`   · fréquence ${ply.index + 1} (${ply.label}) : ${ply.played.n} ≠ ${mine.n}`); }
    if (mine.w !== ply.played.w) { mismatches += 1; console.log(`   · gains ${ply.index + 1} : ${ply.played.w} ≠ ${mine.w} (point de vue du joueur)`); }
    if (mine.d !== ply.played.d) { mismatches += 1; console.log(`   · nulles ${ply.index + 1} : ${ply.played.d} ≠ ${mine.d}`); }
    if (mine.l !== ply.played.l) { mismatches += 1; console.log(`   · pertes ${ply.index + 1} : ${ply.played.l} ≠ ${mine.l}`); }
    if (Math.abs(performancePoints(mine) - ply.played.perf) > 1e-9) mismatches += 1;
  } else {
    // Transposition : l'index voit aussi des parties arrivées autrement.
    // Les compteurs manuels doivent alors être inclus dans ceux de l'index.
    transpositions += 1;
    if (ply.coverage < manualTotal) { mismatches += 1; console.log(`   · total ${ply.index + 1} : index ${ply.coverage} < manuel ${manualTotal}`); }
    if (ply.played.n < mine.n || ply.played.w < mine.w || ply.played.d < mine.d || ply.played.l < mine.l) {
      mismatches += 1;
      console.log(`   · transposition incohérente au demi-coup ${ply.index + 1}`);
    }
  }
}
check('statistiques identiques au comptage manuel', mismatches === 0,
  `${exact} positions exactes, ${transpositions} transposition(s), ${mismatches} écart(s)`);
check('point de vue du joueur vérifié', exact >= 2 && facts[0].played.n > 0);
check('couverture détectée au début', facts.slice(0, 3).some(ply => ply.coverage > 0));

/* ---------------- 2. aucune phrase sans source ---------------- */
for (const ply of facts) {
  if (!ply.baseAvailable) continue;
  if (!ply.coverage) {
    check(`demi-coup ${ply.index + 1} : position absente annoncée`, ply.flags.novel);
    break;
  }
}

/* ---------------- 3. évaluations moteur factices, chemins de phrase ---------------- */
const engine = facts.map((ply, index) => {
  if (!ply.engine) {
    if (index === 4) return { loss: 2.1, scoreBefore: 0.4, evalBeforeWhite: 0.4, evalAfterWhite: -1.7, best: '38-32', depth: 16 };
    if (index === 6) return { loss: 0.7, scoreBefore: -0.3, evalBeforeWhite: -0.3, evalAfterWhite: -1.0, best: '43-38', depth: 16 };
    return { loss: 0, scoreBefore: 0.1, evalBeforeWhite: 0.1, evalAfterWhite: 0.1, best: labels[index], depth: 16 };
  }
  return null;
});
const factsWithEngine = buildPlyFacts({
  states: game.states, moves: game.moves, labels, baseAt: baseAtPly, engine,
});
check('gaffe classée', factsWithEngine[4].flags.blunder);
check('erreur classée', factsWithEngine[6].flags.error);
check('meilleur coup reconnu', factsWithEngine[0].engine.isBest);

const moments = selectMoments(factsWithEngine);
check('moments sélectionnés', moments.length >= 2 && moments.length <= 14, moments.length + ' moments');
check('moments dans l’ordre de la partie',
  moments.every((ply, i) => i === 0 || ply.index > moments[i - 1].index));
check('grosse erreur toujours conservée', moments.some(ply => ply.index === 4));

/* ---------------- 3 bis. ponctuation et valeurs extrêmes ---------------- */
{
  const oddEngine = facts.map((ply, index) => ({
    loss: index === 4 ? 120 : 0,
    scoreBefore: 0,
    evalBeforeWhite: index === 4 ? 99 : 0.1,
    evalAfterWhite: index === 4 ? -99 : 0.1,
    best: index === 4 ? '20-24' : labels[index],
    depth: 10,
  }));
  const odd = buildPlyFacts({ states: game.states, moves: game.moves, labels, baseAt: baseAtPly, engine: oddEngine });
  const sampled = odd.slice(0, 20).map(ply => readingSentence(ply));
  check('aucune ponctuation parasite dans les lectures',
    sampled.every(text => !/\s[;:,.](\s*[.;,:])/.test(text) && !/ ;\s*\./.test(text)),
    sampled.find(text => /\s[;:,.](\s*[.;,:])/.test(text)) || '');
  const engineText = engineSentences(odd[4]).join(' ');
  check('perte extrême sans chiffre absurde', !/1[0-9]{2},\d\spion/.test(engineText), engineText.slice(0, 140));
  const outside = buildPlyFacts({
    states: game.states, moves: game.moves, labels,
    baseAt: () => null, engine: [], options: { indexPly: 3 },
  });
  check('hors portée de l’index signalé', outside[10].flags.outOfIndex === true);
  const outsideText = baseSentences(outside[10]).join(' ');
  check('hors portée : phrase explicite', /au-delà/.test(outsideText), outsideText.slice(0, 120));
  check('dans la portée : pas de drapeau hors portée', outside[1].flags.outOfIndex === false);
}

/* ---------------- 4. modèle de document ---------------- */
const model = buildStudyModel({
  headers: { White: 'Verpoest', Black: 'Berte', Event: 'Test', Date: '1980' },
  result: '2-0',
  labels,
  plies: factsWithEngine,
  references: index => [{ w: 'Korenevsky', b: 'Zvirbulis', ev: 'URSS', dt: '1981', r: '2-0' }].slice(0, index === 4 ? 1 : 0),
  engineInfo: { games: games.length, depth: 16 },
  options: { maxMoments: 6 },
});
check('modèle : entête', model.subtitle === 'Verpoest — Berte');
check('modèle : sources affichées', model.sources.length === 2 && /Base de parties/.test(model.sources[0]));
check('modèle : résumé chiffré', model.summaryLines.length >= 3);
check('modèle : méthode rappelle le seuil d’échantillon', /5 fois/.test(model.method[0]));
check('modèle : un seul chapitre par entrée',
  model.chapters.every(chapter => chapter.entries.every(entry => entry.chapter === chapter.key)));
check('modèle : chaque entrée a une lecture', model.chapters.every(chapter =>
  chapter.entries.every(entry => entry.reading.length > 20)));
check('modèle : références rattachées', model.chapters.some(chapter =>
  chapter.entries.some(entry => entry.references.length === 1)));
check('modèle : tableau complet', model.table.length === game.moves.length);

/* ---------------- 5. robustesse : base vide, index absent ---------------- */
const empty = buildPlyFacts({
  states: game.states, moves: game.moves, labels,
  baseAt: () => ({ moves: [] }),
  engine: [],
});
check('base vide : aucune erreur', empty.length === game.moves.length);
check('base vide : positions inédites signalées', empty.every(ply => ply.flags.novel));
const noBase = buildPlyFacts({
  states: game.states, moves: game.moves, labels,
  baseAt: () => null, engine: [],
});
check('base indisponible : champs neutres', noBase.every(ply => !ply.baseAvailable && ply.coverage === 0));
const modelNoBase = buildStudyModel({ labels, plies: noBase, options: { maxMoments: 8 } });
check('base indisponible : document produit quand même', modelNoBase.table.length === game.moves.length);
check('base indisponible : la méthode le dit', /ne dit pas/.test(modelNoBase.method[0]));

/* ---------------- 6. outils ---------------- */
check('classe d’échantillon', sampleClass(0).key === 'absent' && sampleClass(3).key === 'anecdotique'
  && sampleClass(8).key === 'mince' && sampleClass(40).key === 'etabli');
check('comptage des pièces', pieceCount(game.states[0].board) === 40);
check('rendement : 3 gains 1 nulle', Math.abs(performancePoints({ n: 4, w: 3, d: 1, l: 0 }) - 87.5) < 1e-9);

console.log(failures ? `\nÉtude commentée : ${failures} échec(s).` : '\nÉtude commentée : tous les tests passent.');
process.exit(failures ? 1 : 0);
