# Livraison — série 2 : PIONICIDE, menaces, PDN moteur contre moteur

**21 octobre 2026.** Archive à téléverser : **`dames-webapp-github-pages (1).zip`** (même nom que dans le dépôt `sosthene-hub/Dt`, le workflow l’extrait tel quel).

## Les deux demandes

### 1. Bouton PDN entre les parties moteur contre moteur — opérationnel

- `⤓ PDN de la partie en cours` : à tout moment, sans attendre la fin ni arrêter le match (résultat provisoire `*`).
- `⤓ PDN` : toutes les parties de la session dans un seul fichier.
- Archive **« Parties et PDN »** : une ligne par partie avec résultat, raison de la fin, nombre de demi-coups, profondeur de chaque camp ; deux boutons par ligne — `⤓ PDN` et **`Étudier`** (ouvre la partie dans le damier d’analyse).
- Une partie **arrêtée** rejoint l’archive au lieu d’être perdue ; une nouvelle série n’efface plus les parties précédentes.
- « Afficher / copier le PDN » en secours si le navigateur bloque le téléchargement.
- En-têtes relisibles : `Event`, `White`/`Black` avec profondeur et temps par coup, `Round`, `Result`, `Termination`, `FEN` si la position de départ est préparée.

Vérifié : PDN de la partie en cours relu par l’application, **100 % de coups légaux** ; fichier de deux parties relu intégralement ; parcours navigateur complet sans erreur.

### 2. Analyse des menaces + renommage PIONICIDE

Suivant le brief `ANALYSE DES MENACES + RENOMMAGE PIONICIDE` : menace créée (le camp qui vient de jouer rejoue) et menace évitée (le trait revient à l’adversaire avant le coup, parade vérifiée après), seuil 0,5 pion, profondeur 10 par défaut, portée toute la partie / un camp / une plage de coups, exécution dans le Web Worker, repères `▲` `▼`, flèches numérotées 1-2-3 (vert / orange / rouge), récapitulatif par camp + trois coups les plus importants, recalcul isolé d’un coup, export PDN et PDF en option (décochée par défaut), **un seul passage** quand les deux analyses sont lancées ensemble, **résultats mémorisés** sans recalcul. Nom **PIONICIDE** partout dans l’interface ; moteur inchangé.

Détail complet, mesures et limites : **RAPPORT-MENACES-PIONICIDE.md**. Résultats de tests : **RAPPORT-TESTS.md** (section « série 2 »).

## Contenu de l’archive

- `src/` (dont `analysis/threats.js` et `pages/threat-panel.js`), `public/`, `scripts/` (dont `test-threats.mjs`, `browser-threats.mjs`, `browser-svs-pdn.mjs`), `fixtures/`, `third-party/`, `engine-src/`, `data/`, `perf/` (traces des nouveaux tests : `perf/threats/`, `perf/svs-pdn/`, `perf/threats-tests.json`), `package.json`, `package-lock.json`, `vite.config.js`, `index.html`, licences et rapports.
- `Dames-autonome.html` régénéré (16,0 Mo) : application hors ligne complète, menaces comprises.
- `data/livres/` reste vide : les deux tomes PDF (5,6 Mo chacun) sont fournis à part, comme précédemment.

## Publication

1. Télécharger **`dames-webapp-github-pages (1).zip`**.
2. Dans le dépôt `sosthene-hub/Dt`, remplacer le fichier ZIP de même nom à la racine (ne pas le renommer).
3. Valider sur `main` : le workflow existant extrait l’archive, lance `npm ci` puis `npm test` et publie `app/dist`.
4. Attendre la réussite de l’onglet **Actions**, puis recharger https://sosthene-hub.github.io/Dt/ . Le cache hors ligne passe en **v14** ; en cas d’ancien écran, recharger une fois de plus.

## Vérifications de cette livraison

- `npm test` : **code 0** (build, règles, position, PDN, export, **menaces**, moteur, WASM portable + SIMD, hors ligne, finales, validateur).
- `npm run test:threats` : menaces réelles sur 18 demi-coups (6 créées, 3 évitées, 3 prises obligatoires), lignes rejouées sur les règles, cache réutilisé, aucun recalcul au second passage.
- `npm run test:browser-threats` (production `/Dt/`) : 16 étapes, **0 erreur** — dont passage unique 131 coups en 3,4 s, 78 repères, flèches 1-2-3, PDN réimporté 131/131, feuille imprimable, mobile 412 × 915.
- `npm run test:browser-svs-pdn` : 10 étapes, **0 erreur** — PDN en cours de partie, archive, arrêt, étude, partie terminée, fichier multi-parties relu.
- Dix suites navigateur existantes relancées : toutes réussies.

## Limites

- La menace est une mesure du moteur à une profondeur donnée (écrite dans le récapitulatif, le PDN et le PDF), pas une base de menaces tactiques.
- Les positions à prise obligatoire ne sont pas mesurées et sont signalées comme telles.
- La mémoire des analyses vaut pour la session : recharger la page les efface (comme avant).
- Mesures faites sous Chromium/Linux ; un téléphone Android peut être plus lent.
- Les fichiers du moteur et les mentions de licence gardent le nom Scan 3.1b (GPL-3.0) : le renommage est visuel, le moteur n’est pas modifié.
