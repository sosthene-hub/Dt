const CACHE_NAME = 'dames-internationales-shell-root-v5';
const CORE_URLS = ['', 'scan-normal.worker.js', 'scan_normal.data?v=24a27f10'];
const scopeUrl = new URL(self.registration?.scope || new URL('./', self.location.href).href);
const scopePath = scopeUrl.pathname.endsWith('/') ? scopeUrl.pathname : `${scopeUrl.pathname}/`;
function absolute(url) {
  const target = new URL(url, scopeUrl);
  if (url.startsWith('/') && !target.pathname.startsWith(scopePath)) {
    return new URL(url.replace(/^\/+/, ''), scopeUrl).href;
  }
  return target.href;
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const rootUrl = absolute('');
    const page = await fetch(rootUrl, { cache: 'reload' });
    if (page.ok) {
      await cache.put(rootUrl, page.clone());
      const html = await page.clone().text();
      const assets = [...html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g)].map(match => match[1]);
      await Promise.allSettled([...new Set([...CORE_URLS.slice(1), ...assets])].map(async url => {
        const assetUrl = absolute(url);
        const response = await fetch(assetUrl, { cache: 'reload' });
        if (response.ok) await cache.put(assetUrl, response);
      }));
    } else {
      await Promise.allSettled(CORE_URLS.map(async url => {
        const assetUrl = absolute(url);
        const response = await fetch(assetUrl, { cache: 'reload' });
        if (response.ok) await cache.put(assetUrl, response);
      }));
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('dames-internationales-') && key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== scopeUrl.origin || !url.pathname.startsWith(scopePath)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    if (request.mode === 'navigate') {
      try {
        const fresh = await fetch(request);
        if (fresh.ok) await cache.put(absolute(''), fresh.clone());
        return fresh;
      } catch {
        return (await cache.match(absolute(''))) || Response.error();
      }
    }
    const saved = await cache.match(request);
    if (saved) return saved;
    try {
      const fresh = await fetch(request);
      if (fresh.ok) await cache.put(request, fresh.clone());
      return fresh;
    } catch {
      return Response.error();
    }
  })());
});
