/* Scan 3.1b C++/WebAssembly. One search thread; no SharedArrayBuffer. */
let scanModule=null,booting=false,queue=[];
const base=self.SCAN_EMBEDDED_RUNTIMES?null:new URL('./',self.location.href);
function bytes64(text){const raw=atob(text),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return bytes;}
async function initialize(config){
 try{
  let runtime=config.runtime||'scan-wasm-scalar.js';
  async function load(name){
   if(self.SCAN_EMBEDDED_RUNTIMES){(0,eval)(new TextDecoder().decode(bytes64(self.SCAN_EMBEDDED_RUNTIMES[name])));}else importScripts(new URL(name,base).href);
   return createScan({noInitialRun:true,print:line=>postMessage(line),printErr:line=>postMessage('log '+line)});
  }
  let module;
  try{module=await load(runtime);}catch(e){if(!runtime.includes('simd'))throw e;postMessage('log SIMD indisponible : repli WASM portable.');runtime='scan-wasm-scalar.js';module=await load(runtime);}
  const data=self.SCAN_EMBEDDED_DATA?bytes64(self.SCAN_EMBEDDED_DATA):new Uint8Array(await (await fetch(new URL('scan_normal.data?v=24a27f10',base))).arrayBuffer());
  if(data.length<8503280)throw Error('Données d’évaluation Scan absentes ou tronquées');
  module.FS.mkdirTree('/data');module.FS.writeFile('/data/eval',data.subarray(0,8503280));
  for(const [path,text]of Object.entries(config.files||{})){module.FS.mkdirTree('/'+path.substring(0,path.lastIndexOf('/')));module.FS.writeFile('/'+path,bytes64(text));}
  let book;
  if(self.SCAN_EMBEDDED_BOOK)book=bytes64(self.SCAN_EMBEDDED_BOOK);else {const response=await fetch(new URL('scan-book.bin',base));if(!response.ok)throw Error('Bibliothèque Scan indisponible');book=new Uint8Array(await response.arrayBuffer());}
  if(book)module.FS.writeFile('/data/book',book);
  module._main(0,0);scanModule=module;
  postMessage({type:'runtime',runtime:runtime.includes('simd')?'WASM SIMD':'WASM scalaire',threads:1,hashMiB:config.hashMiB||64,bookLoaded:!!book});
  for(const text of queue.splice(0))module.ccall('scan_command',null,['string'],[text]);
 }catch(e){postMessage('error Initialisation WASM : '+e.message);}
}
onmessage=({data})=>{if(data&&data.type==='bitbases'){if(!booting){booting=true;initialize(data);}return;}if(typeof data!=='string')return;if(scanModule)scanModule.ccall('scan_command',null,['string'],[data]);else queue.push(data);};
