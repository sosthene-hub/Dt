# Phase 4 — Import PDN et relecture de parties

## Réalisé
- **Import PDN** (`src/pdn.js`, `src/pages/import.js`) : chargement d’un fichier `.pdn` ou collage de texte, détection de plusieurs parties dans un même document, en-têtes (Event, Site, Date, White, Black, Result, FEN).
- Le tokenizer extrait les coups en ignorant numéros, commentaires `{…}`, variantes `(…)`, NAGs `$n` et annotations `!?`.
- **Relecture complète** : damier avec navigation coup par coup (⏮ ◀ ▶ ⏭, flèches du clavier), liste de coups cliquable avec numéro et trait, lecture automatique, dernier coup surligné.
- Positions de départ personnalisées via l’en-tête `FEN` (notation PDN ou code Hub).
- Validation pendant la relecture : un coup illégal arrête la lecture avec un message précis (n° et notation du coup).
- Bouton « Analyser cette position » depuis la relecture vers le damier d’analyse.
- **Export PDN** : la page de partie télécharge la partie en cours au format PDN (`⤓ PDN`), avec résultat détecté (victoire, défaite, nulle).
- Notation PDN correcte des prises multiples (toutes les cases d’atterrissage, ex. `27x17x9`), distincte du format Hub du moteur.

## Vérifications
`npm test` passe : build, règles, positions/PDN, parseur PDN (tokenizer, en-têtes, multi-parties, correspondance des coups, sérialisation aller-retour), moteur (think, position arbitraire, analyze), cache hors ligne.

## Limites / validation requise
- Test tactile sur téléphone Android toujours à faire (aucun appareil disponible ici).
- Les variantes et commentaires PDN sont ignorés à la lecture (pas encore rejoués ni affichés).
- L’import gère les parties standards ; les rares extensions PDN (figures NAG détaillées, annulations exotiques) ne sont pas interprétées.
- Sections encore en préparation : Apprendre, Problèmes, Générateur de positions, Recherche avancée.
