# Livraison — étude, PDN, interface de jeu et rétrograde

## 1. Deux variantes indépendantes

**Importer une partie** ouvre désormais directement l’étude à deux lignes :

1. **Coups de la partie jouée** : tous les coups importés ou transmis depuis votre match contre Scan. Cliquer un coup, avancer/reculer, aller au début/à la fin ou rejouer automatiquement.
2. **Variante proposée par Scan** : suite calculée depuis la position évaluée, avec indication explicite de son point de départ. Les boutons « Racine / Variante ◀ / Variante ▶ » explorent cette suite sans modifier la partie. « Revenir à la partie » retrouve le même demi-coup original.

Les coups de la variante Scan sont validés légalement avant affichage. Évaluer une autre position renouvelle cette variante. Une exploration manuelle est également séparée de la partie. Les compteurs de nulle suivent chaque branche. Un damier chargé seul ne permet pas de connaître son historique antérieur.

## 2. PDN Verpoest–Berte 1980

Le lecteur accepte désormais les prises abrégées `départ x arrivée`, y compris les rafles, et les prises explicites avec toutes les cases d’atterrissage. Il traite également le symbole `×`, le point final après le dernier coup et les résultats de dames `2-0 / 0-2` sans les prendre pour des déplacements.

Dans votre partie, `27... 11x31` est la rafle **11 → 22 → 31**, capturant **17 et 27**. Les 131 demi-coups jusqu’à `66. 27-36` se rejouent intégralement. Le bouton d’exemple charge votre partie, également incluse dans `fixtures/Verpoest-Berte-1980.pdn`.

Une prise abrégée réellement ambiguë, conduisant à plusieurs damiers finaux différents, reste refusée avec un diagnostic distinct. Si plusieurs trajets produisent exactement le même damier, un trajet légal compatible est retenu : ce n’est pas une certitude sur le trajet physiquement suivi en 1980. Les règles de prise obligatoire/maximale n’ont pas été changées.

## 3. Accueil / Jouer

- Blancs par défaut : aucun choix de camp obligatoire. « Votre camp » permet aussi Noirs ou Au hasard ; appliquer par « Nouvelle partie ».
- Scan commence automatiquement si vous choisissez les Noirs.
- Début, arrière, avant, présent et relecture automatique de l’historique.
- « Auto » rejoue les coups déjà joués ; ce n’est pas un mode Scan contre Scan.
- Consulter l’historique ne modifie pas le match ; revenir au présent pour jouer.
- « Annuler le dernier coup » retire exactement un demi-coup et met le match en pause. « Reprendre le match » relance le camp concerné, y compris Scan si c’est son tour.
- « Analyser cette partie » transmet la partie entière et la position consultée aux deux lignes de l’étude.
- Retourner le damier sans changer les couleurs ni le trait.

### Flèche de trajet

Calque SVG indépendant, `pointer-events: none`, jaune semi-transparent. La ligne brisée passe par toutes les cases d’atterrissage des rafles ; un déplacement long de dame suit la diagonale. Les cases de départ et d’arrivée sont surlignées. Flèche et surlignage sont conservés jusqu’au coup suivant, adaptés à l’historique et à l’annulation, inversés géométriquement avec le plateau. Pas de flèche au départ ni dans l’éditeur.

Les fichiers de règles, de nulles, de tables, l’enveloppe moteur et le worker Scan sont identiques à la livraison précédente ; contrôles SHA-256 dans `core-integrity.json`.

## 4. Dessin complet → origine à 20 pions par camp

Le mode par défaut du générateur est maintenant **Position complète : retrouver son origine**. Toutes les pièces du damier final doivent être dessinées ; les autres cases sont vides. Pions, dames, gomme et trait final sont disponibles. Charger un code ou utiliser « Origine de cette position » depuis l’analyse / le bouton équivalent de l’éditeur.

La recherche remonte des prédécesseurs : déplacements inversés, restitution d’adversaires capturés, rafles inversées et retour possible avant promotion. Chaque hypothèse est acceptée uniquement si un coup légal normal la transforme exactement en la position suivante. L’objectif reste le départ réglementaire : **20 pions blancs, 20 pions noirs, Blancs au trait**. Atteindre seulement un damier quelconque à 20 pièces ne suffit pas.

Toute suite trouvée est rejouée à neuf dans le sens normal depuis ce départ. Elle doit aboutir exactement au dessin et au trait choisi. La preuve peut ensuite être remontée, rejouée, exportée en PDN/JSON ou ouverte dans l’étude à deux lignes.

### Limites importantes

C’est une **recherche rétrograde heuristique bornée**, pas un solveur exhaustif d’atteignabilité. Budget de nœuds, profondeur, largeur de faisceau, hypothèses par position et pièces restituées par rafle sont réglables. Certaines rafles sont hors recherche si leur nombre de prises dépasse votre réglage ; la taille du faisceau et le budget peuvent exclure une bonne piste. Une position éloignée de l’ouverture peut ne donner aucune preuve, même si elle est atteignable. Le message est alors « non trouvée dans ces limites », jamais « impossible ».

Les parties importées ou jouées depuis le départ standard sont mémorisées localement comme historiques de preuve. Si elles contiennent déjà votre dessin, l’application peut en retrouver une suite vérifiée ; la source **« Historique connu »** est indiquée, distinctement d’une nouvelle recherche rétrograde. Une position finale ne permet pas, en général, d’identifier la seule partie historiquement jouée : plusieurs suites peuvent être compatibles.

L’ancien tirage de structures partielles reste accessible par le sélecteur de mode, sans confusion avec ce nouveau dessin complet.

## Livrables et publication

Le HTML autonome conserve interface, Scan, données, tables et les deux workers de recherche. Il fonctionne sans API ni connexion après téléchargement. Ouvrir réellement dans Chrome, pas dans un visualiseur qui interdit les workers. Android physique reste à tester.

Pour votre dépôt **Dt**, remplacer le fichier racine **dames-webapp-github-pages (1).zip**, sans changer son nom, et valider sur `main`. Le workflow existant extrait cette archive, exécute `npm ci`, `npm test` et publie le build sous `/Dt/`. Aucune publication dans votre compte n’a été effectuée depuis cette session.
