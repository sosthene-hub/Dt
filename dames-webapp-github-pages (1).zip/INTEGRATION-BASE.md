# Intégration du module « Base de parties » dans PIONICIDE

Ajout d'un septième écran au menu : **▤ Base de parties** (import PDN massif, explorateur d'ouvertures, recherche par structure).
Le moteur Scan n'est pas touché : la page ne parle qu'à son propre Web Worker.

## Fichiers ajoutés

| Fichier | Rôle |
|---|---|
| `src/base/core.js` | noyau autonome : damier 10×10, générateur de coups international, Zobrist, masques de bits, structures, lecture PDN, table d'index |
| `src/base/index-lib.js` | bibliothèque d'indexation et de recherche (préparation des parties, index d'ouvertures, rejeu par masques) |
| `src/base/worker.js` | Web Worker : IndexedDB (`pionicide-base`), import fichier par fichier avec reprise, index d'ouvertures, recherche par structure, export/import de la base, alias |
| `src/base/page.js` | écran « Base de parties » : 5 onglets (Importer, Explorateur, Structures, Recherche, Base) |
| `src/base/base.css` | styles de la page, tous préfixés `.pb-` (aucune collision avec l'existant) |
| `scripts/test-base.mjs` | 26 contrôles automatisés, branchés sur `npm test` |
| `fixtures/base-echantillon-200.pdn` | 200 parties réelles (extrait du fichier de 1 000) pour les tests |

## Fichiers modifiés

| Fichier | Modification |
|---|---|
| `src/main.js` | import de la page, entrée de menu `base`, `case 'base'` dans `createPage` |
| `package.json` | script `test:base`, ajouté à la chaîne `npm test` |

Aucune autre modification : `game-rules.js`, `engine.js`, `pdn.js`, le worker Scan, le service worker et `vite.config.js` sont inchangés. Vite compile le worker à part (`dist/assets/worker-*.js`, 36 Ko) : il n'est pas dans le bundle principal.

## Fonctions de la page

- **Importer** : un ou plusieurs `.pdn` / `.txt`, traitement par lots de 4 Mo dans le worker, progression, pause, reprise au même octet après interruption, rapport final (importées / doublons / ignorées **avec motif** / tronquées / joueurs distincts) et mesures de l'appareil (ms par partie, parties/s, stockage, mémoire d'index).
- **Explorateur** : index Zobrist sur 30 demi-coups, % gain/nulle/perte par coup, clic pour jouer, « parties de cette position » avec filtres joueur / couleur / période / événement, ouverture d'une partie au demi-coup concerné.
- **Structures** : éditeur à 6 états par appui répété (pion blanc, dame blanche, pion noir, dame noire, case vide obligatoire, libre), chaîne de 50 caractères, JSON, enregistrement / renommage / suppression / export.
- **Recherche** : structure enregistrée ou dessinée, symétrie de couleur, filtre joueur, rejeu **par opérations binaires** (sans générateur de coups), progression, ouverture au coup trouvé.
- **Base** : compteurs, stockage persistant, export/import du fichier de base `.pbase`, reconstruction de l'index (profondeur réglable), table d'alias des joueurs, analyse des doublons.

## Passerelles avec le reste de PIONICIDE

Trois boutons relient la base aux écrans existants, via `store.js` (aucun couplage direct) :

| Bouton | Effet |
|---|---|
| **Analyser cette partie** | remplit `store.analysisDraft` (partie jouée, coups, en-têtes, résultat) puis ouvre **Damier d'analyse** : évaluation PIONICIDE, variantes, export annoté, tables de finales |
| **Jouer cette position** | remplit `store.playDraft` puis ouvre **Accueil / Jouer** contre le moteur |
| **Vers l'éditeur de structure** | copie la position courante dans l'éditeur de structures du module |

## Déploiement

Le workflow `.github/workflows/main.yml` décompresse `dames-webapp-github-pages (1).zip` à la racine du dépôt puis lance `npm ci && npm test` et publie `app/dist`. Pour publier cette version :

1. remplacer le fichier `dames-webapp-github-pages (1).zip` du dépôt par celui fourni (**même nom exact**) ;
2. pousser sur `main` : le workflow reconstruit et teste (dont `test:base`), puis déploie.

> Variante plus propre, si tu veux t'affranchir du zip : mettre le contenu du projet directement à la racine du dépôt et remplacer dans le workflow les deux lignes `unzip … -d app` / `cd app` par `cd .`. Dis-moi si tu veux que je prépare cette version du workflow.

## Vérifications effectuées

- `npm test` : **toute la suite existante passe** (règles, PDN, export, menaces, moteur Scan, WASM, hors ligne, finales, validateur) + `test:base` (26 contrôles OK).
- `npm run build` : OK, worker compilé à part (36 Ko).
- Parcours navigateur réel (Chromium, 412×915) sur le build de production : import du fichier de 1 000 parties → 977 importées / 11 doublons / 12 ignorées (motifs affichés) ; explorateur : 9 coups, 300 parties listées pour la position après `32-28` ; ouverture d'une partie ; recherche par structure : 132 parties en 27 ms ; export de la base ; passerelles « Analyser » et « Jouer » testées (l'analyse affiche bien l'évaluation PIONICIDE de la partie réelle). Aucune erreur JavaScript.
- Recherche par structure comparée à l'implémentation de référence de l'application (`generateLegalMoves` + `applyMove` de `game-rules.js`) sur 5 structures et 192 parties réelles : **résultats identiques**.

## Vérification du zip livré (archive de déploiement)

Extraction du zip dans un dossier neuf, `npm ci`, `npm run build`, `npm run test:base` puis parcours navigateur complet sur ce build : identiques aux résultats ci-dessus (977 / 11 / 12, 300 parties pour la position après `32-28`, recherche 132 parties en 31 ms, passerelles « Analyser » et « Jouer » opérationnelles, aucune erreur JS). Le diff avec l'archive d'origine ne contient que : `package.json`, `src/main.js`, `src/base/*` (4 fichiers + le CSS), `scripts/test-base.mjs`, `fixtures/base-echantillon-200.pdn` et ce document.
