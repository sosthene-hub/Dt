# Scan contre Scan, parties depuis une position, validateur de cohérence

**Livraison du 20 octobre 2026.** Cette version ajoute le mode **Scan contre Scan**, le lancement d'une partie depuis l'éditeur ou une combinaison, et un **validateur de cohérence** appliqué aux positions de combinaison. La recherche rétrograde et la recherche avancée sont retirées, comme demandé ; l'accueil « Jouer », « Créer une partie » et le reste de l'application sont conservés.

## 1. Scan contre Scan

| Élément | Mise en œuvre |
|---|---|
| Deux moteurs | Deux instances `ScanEngine`, **un Web Worker chacune** : l'interface ne bloque jamais pendant les calculs. 64 Mio de table de transposition par moteur. |
| Réglages séparés | Profondeur 2 à 20 et temps par coup (0,2 à 15 s) pour Scan A et pour Scan B. Un Scan fort peut affronter un Scan faible. |
| Position de départ | Position initiale, ou **position préparée** venant de l'éditeur ou d'une combinaison (option activée dès qu'une position est préparée). |
| Contrôles | Démarrer, Pause, Reprendre, Arrêter, vitesse d'affichage de 0 à 2 s entre les coups. |
| Affichage | Damier avec la flèche du trajet, liste des coups en notation FMJD (1. 32-28 1… 19-23), évaluation Scan du coup joué avec sa profondeur. |
| Fin de partie | Détection par les règles FMJD : plus de coup légal, troisième répétition (6.1), 25 coups de dames (6.2), limites de finale (6.3–6.4). Résultat affiché avec son motif. Garde-fou à 300 demi-coups. |
| Export | Bouton **PDN** : un fichier par série, en-têtes White/Black avec la profondeur, résultat, et FEN si la position de départ n'est pas la position initiale. |
| Séries | 1 à 6 parties enchaînées, **couleurs alternées** à chaque partie, score cumulé affiché (victoire 1, nulle ½). |
| Mobile | Deux workers, pas de SharedArrayBuffer, pas de thread bloquant ; testé hors ligne en 412×915. |

## 2. Jouer une position contre Scan

- **Éditeur** : bouton « Jouer contre Scan à partir de cette position », avec choix de **ma couleur**, du **camp au trait** et du **niveau de Scan** avant de lancer.
- **Contrôles avant lancement** : aucun pion sur une ligne de promotion, au plus 20 pièces par camp, au moins une pièce de chaque camp, et au moins un coup légal pour le camp au trait. Message clair sinon, par exemple « ⚠ Pion sur la ligne de promotion (cases 2, 3). »
- **Damier principal** : même interface que les parties normales (flèche de trajet, liste des coups, annulation, relecture, analyse, PDN). La partie utilise désormais la position exacte (`pos=`) et non plus la suite de coups depuis le départ standard — sans quoi le livre d'ouvertures renvoyait un coup illégal.
- **Recommencer cette position** : la position de départ est mémorisée ; le bouton recharge exactement le même point. « Nouvelle partie » repart du départ standard.
- **Combinaisons** : bouton « Jouer cette position contre Scan » dans l'exercice, avec les mêmes choix.

## 3. Validateur de cohérence des combinaisons

Appliqué **avant l'affichage** de chaque position (`src/combinations/validator.js`), sans toucher à la rafle du livre.

| Règle | Détail | Réglable |
|---|---|---|
| Ligne de promotion | Aucun pion blanc sur 1–5, aucun pion noir sur 46–50 ; seules les dames y sont admises. | – |
| Maximum de pièces | 20 pièces par camp. | – |
| Écart de matériel | Différence entre camps ≤ 3 pièces. | 1 à 5, défaut 3 |
| Avancée des leurres | Pas de pion blanc ajouté sur les rangées 1–2, ni de pion noir sur les rangées 9–10. | « stricte » ou « promotion seulement » |
| Pion isolé | Un pion ajouté doit avoir un voisin de son camp à 2 cases (Chebyshev). Les pièces de la rafle du livre sont exemptées. | refuser / tolérer |
| Prise parasite | Au trait initial, la rafle de la solution doit être la seule prise possible. | – |

Les pièces ajoutées par les niveaux 2 à 4 sont désormais **choisies dans les zones autorisées et près d'une pièce amie**, avec 12 tentatives de placement. Effet mesuré : la génération ne perd plus de candidats à cause de ces règles.

**Contrôle de la base du livre (2880 entrées)** — informatif, non bloquant :

| Constat | Entrées |
|---|---|
| Positions sans réserve | 2246 |
| Pion isolé (typique d'une combinaison) | 628 |
| Pion au-delà de la limite d'avancée | 15 |
| Prise concurrente au trait | 6 |
| Écart de matériel > 3 | 1 |
| Pion sur une ligne de promotion | **0** |

Au niveau 1, la position du livre reste affichée ; un bandeau signale les réserves éventuelles. Aux niveaux 2 à 4, toute position qui viole une règle est **rejetée** et remplacée.

## 4. Tests exécutés

| Test | Résultat |
|---|---|
| `npm test` (build, règles, position, PDN, moteur, WASM ×2, hors ligne, finales, validateur) | **réussi**, code 0 — trace `tests-execution.log` |
| `node scripts/test-validator.mjs` | **réussi** — chaque règle prise isolément, position jouable acceptée/refusée, 40 générations par niveau : niveaux 2 et 3 **40/40**, niveau 4 **39/40** (un modèle du livre devient injouable après ajout de leurres, cause comptée) |
| `node scripts/browser-scan-vs-scan.mjs` | **réussi** — partie complète à deux niveaux + série avec alternance |
| `node scripts/browser-editor-game.mjs` | **réussi** — partie depuis l'éditeur, annulation, reprise de la position, position refusée, combinaison jouée contre Scan |
| `node scripts/browser-offline-finales.mjs` | **réussi** — production `/Dt/` hors ligne, cache **v13**, Scan, combinaisons et Scan contre Scan |
| `node scripts/browser-study.mjs`, `browser-finales.mjs`, `browser-check.mjs`, `browser-combinaisons*.mjs` | **réussis** après retrait des pages rétrograde et recherche |

### Partie Scan contre Scan livrée (deux niveaux)

- Blancs : **Scan A, profondeur 6, 1 s par coup**. Noirs : **Scan B, profondeur 3, 0,5 s par coup**.
- Résultat : **1/2-1/2** après **89 coups (177 demi-coups)**, « même position et même trait pour la troisième fois (FMJD 6.1) ».
- Fichier : `perf/scan-vs-scan-deux-niveaux.pdn`, captures : `perf/scan-vs-scan-deux-niveaux.png`.

### Série de deux parties avec alternance

- Deux parties à profondeur 2 (0,2 s), couleurs alternées : la première avec **Scan A aux Blancs**, la seconde avec **Scan B aux Blancs**.
- Score cumulé : **1,5 — 0,5** ; deuxième partie nulle par répétition triple.
- Fichier : `perf/scan-vs-scan-alternance.pdn` (deux parties, en-têtes distincts).

### Partie depuis une position éditée

- Position dessinée : pions blancs 32, 33, 34, 38, 39 ; pions noirs 18, 19, 20, 13 ; trait aux Blancs, humain Blancs, niveau Facile.
- Coup joué 32-28, réponse **Scan 18-23**, annulation d'un demi-coup (match en pause), « Recommencer cette position » ramène à 0 coup.
- Position illégale testée : pion blanc en 2 et 3 → refus « Pion sur la ligne de promotion (cases 2, 3) ».
- Combinaison : validation « ✓ Position cohérente », puis partie lancée depuis la position de la page 272.
- Trace : `perf/partie-position-editee.json`, capture `perf/partie-position-editee.png`.

## 5. Limites

- Deux moteurs = deux workers et deux tables de transposition ; sur un téléphone ancien, fermer l'onglet libère la mémoire. Aucun test sur appareil Android physique.
- La pause laisse finir le calcul en cours (jusqu'à 15 s au réglage maximal), puis la partie attend.
- Les moteurs restent à une profondeur objectif bornée par le temps ; ce n'est pas une force Elo garantie.
- Au niveau 1 du livre, les réserves signalées sont documentaires : la position est authentique et reste jouable.
- Le validateur ne prouve pas qu'une position est atteignable depuis le départ standard ; il vérifie les six règles demandées.
