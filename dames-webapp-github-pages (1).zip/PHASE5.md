# Phase 5 — Problèmes tactiques et générateur de positions

## Réalisé
- **Problèmes** (`src/puzzles.js`, `src/pages/problems.js`) : puzzles tactiques générés et **prouvés résolubles** par le moteur de règles local, deux types :
  - *Prise maximale* : une unique séquence capture le maximum de pièces (2 à 4+).
  - *La parade* : un seul coup évite la perte de matériel, les alternatives perdent au moins une pièce.
- Puzzle du jour (graine déterministe datée, identique pour tous), puzzle suivant (graine aléatoire), recommencer.
- Validation de la réponse coup par coup, compteur de puzzles résolus et série, difficulté (Facile/Normal/Fort).
- Indice Scan (analyse à profondeur 7, départ du coup conseillé) avec confirmation moteur de la solution.
- **Générateur de positions** (`src/pages/generateur.js`) : contraintes (pièces par camp 2-20, dames autorisées, trait, prise disponible obligatoire), graine affichée et réappliquable, contrôle de validité en direct, envoi vers l’analyse ou l’éditeur, copie du code PDN.

## Vérifications
`npm test` passe : build, règles, positions/PDN, parseur PDN, **puzzles (nouveau : 40 puzzles générés vérifiés — solution légale, unique, prise maximale confirmée, parades sans perte)**, moteur, cache hors ligne.

## Limites / validation requise
- Test tactile sur téléphone Android toujours à faire (aucun appareil disponible ici).
- Les puzzles sont garantis par le générateur de règles ; Scan est utilisé comme confirmation et pour les indices, pas comme source de vérité.
- Sections encore en préparation : Apprendre, Recherche avancée. Manifeste PWA (Phase 6) à venir.
