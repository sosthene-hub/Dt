# Rapport de livraison — 18 octobre 2026

## Exécuté et réussi

- Build Vite avec base `/Dt/` : réussi.
- Tests existants règles FMJD, position, import PDN, Scan réel et cache hors ligne : réussis (`npm test`). Les anciens tests puzzles ont été retirés avec ce module.
- Générateur : **300 essais de parties**, **137 suites rejouées conformes**, dont **37 non vides**. Les 100 autres correspondent au cas témoin 20 contre 20, position initiale acceptée avec preuve vide. Configurations : 20, 18 et 16 pions par camp, racine libre, graine 20261018, 100 essais chacune, limite 180 demi-coups.
- Assertions supplémentaires : racine et vides imposés sur une partie effectivement atteinte ; rejet de conflit pion/vide, effectifs invalides, mauvais trait, suite illégale et faux vide obligatoire ; vérification du calme initial.
- **Test navigateur réel du fichier autonome en file://**, Chromium headless, fenêtre 412 × 915 : Scan prêt ; lancement d’un lot ; affichage de **10 témoins** ; export JSON ; dessin d’un vide et récupération après rechargement ; aucune erreur JavaScript ; aucun débordement horizontal.
- Lot navigateur : **429 parties essayées**, **102 suites conformes** (doublons compris), **100 candidats uniques analysés par Scan à profondeur 3**, **100 retenus** et 10 témoins visibles. 18 pions par camp, racine libre, trait blanc, graine 20261018, budget 500, tolérance équilibre **10**. Arrêt à la limite de 100 candidats. Le seuil 10 est volontairement large pour tester le circuit complet : ces résultats ne constituent pas 100 positions certifiées équilibrées à une tolérance habituelle.
- Le JSON `echantillon-test-100-positions.json` conserve ce lot, ses preuves et variantes Scan. `generator-test-results.json` et `browser-test-results.json` contiennent les compteurs automatisés.

## Non certifié / limites

- Pas de test sur appareil Android physique. L’émulation de taille mobile ne remplace pas un appareil réel.
- Pas de preuve de réussite sur toute racine arbitraire : recherche stochastique bornée, pas de solveur exhaustif.
- Tests de profondeur 3 et tests moteur existants jusqu’à 5 ; profondeur 20 proposée mais non certifiée en durée/mémoire. Tout score trop peu profond est refusé.
- Scan asm.js existant, pas WASM. Ce critère du prompt n’est donc pas entièrement satisfait.
- Les dix témoins sont affichés pour votre contrôle humain ; aucun jugement humain de qualité stratégique n’est revendiqué.
- Pas de publication GitHub effectuée. Remplacer l’archive existante du même nom déclenchera le workflow existant.

## Architecture de confiance

Chaque candidat provient uniquement de coups légaux depuis le départ, avec prises maximales et promotion. La suite complète est rejouée à neuf et comparée au damier final. Les deux effectifs exacts, pions fixes, vides, trait et absence de dames sont alors contrôlés. Le calme pour les deux camps et le contact isolé sont filtrés avant Scan. Un worker Scan séparé de celui du jeu évite les interférences. Le score est ramené aux blancs et filtré sans condition sur la préservation de la structure dans la variante principale.
