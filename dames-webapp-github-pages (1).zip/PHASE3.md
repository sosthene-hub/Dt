# Phase 3 — Éditeur de positions et damier d’analyse

## Réalisé
- **Éditeur de partie** (`src/pages/editor.js`) : placement de pions et dames des deux camps, gomme, position initiale, vider, inversion des camps, trait au choix, contrôle de validité (au moins une pièce, 20 pièces maximum par camp), code de position au format PDN (`W:W31,…:B18,…`) avec copie, import de code (PDN ou code Hub sur 51 caractères), et envoi direct au damier d’analyse.
- **Damier d’analyse** (`src/pages/analysis.js`) : partie libre pour les deux camps avec validation locale des règles (prises obligatoires, capture maximale, dames volantes, promotion), annulation, réinitialisation, évaluation automatique ou à la demande par Scan, profondeur réglable (3/5/7/9), affichage du score en hommes vu du trait, barre d’avantage, profondeur/nœuds/temps, variante principale (PV) et meilleur coup surligné sur le damier.
- **Moteur partagé** (`src/engine.js`) : un seul Web Worker Scan 3.1 pour la partie et l’analyse, recherches séquentielles avec `go analyze` (lignes `info` temps réel) et `go think`, sécurité temporelle et annulation de la recherche précédente.
- **Damier réutilisable** (`src/board-view.js`) : rendu commun aux trois plateaux, avec orientation, sélection, dernier coup, cibles légales et marqueurs personnalisés.
- **Codes de position** (`src/position.js`) : validation, export/import PDN et code Hub, comptage de pièces.
- Architecture en pages montées/démontées par le shell (`src/main.js`) avec conservation de l’état lors de la navigation.

## Protocole utilisé
Le protocole Hub (documenté dans `node_modules/scan3.1.js/protocol.txt`) permet de soumettre une position quelconque : `pos pos=W<50 caractères>` suivi de `level depth=N` et `go analyze`. Le score est exprimé en hommes du point de vue du trait ; ±99,9x signale une position gagnante. Une position terminale renvoie `done` sans `move=`.

## Vérifications
`npm test` passe : build, règles, positions/PDN (nouveau `test:position`), moteur (mode `think`, position arbitraire et mode `analyze` avec vérification des lignes `info`), cache hors ligne.

## Limites / validation requise
- Aucun appareil Chrome Android disponible ici : test tactile et hors ligne réel sur téléphone toujours à faire.
- L’analyse est locale et interactive ; elle ne détecte pas les nulles par répétition (outil d’étude, pas une partie).
- Les sections Apprendre, Problèmes, Importer, Générateur et Recherche avancée restent des écrans de préparation.
