# Rapport de livraison — quatre phases demandées

**18 octobre 2026 — Étude, PDN, jeu et rétrograde.**

## 1. Partie jouée et variante Scan

Test réel dans Chromium, fichier autonome ouvert en `file://`, réseau coupé, fenêtre **412 × 915** :

- Import de la partie complète : 131 boutons de coups plus le départ dans la ligne de partie.
- Analyse Scan depuis le demi-coup 54 ; variante calculée et coups légaux affichés dans la seconde ligne.
- Navigation dans cette variante puis retour au même code de position original, sans modification de la partie.
- Accès au dernier demi-coup 131.
- Transmission du match contre Scan à l’étude, avec conservation de l’historique.

La variante présentée est celle effectivement calculée depuis sa racine indiquée ; ce n’est pas une liste de recommandations précalculées pour tous les coups de la partie.

## 2. Régression PDN Verpoest–Berte 1980

Fixture fournie, métadonnées et **131 demi-coups**. Relecture légale intégrale jusqu’à **66. 27-36**, sans erreur.

**27... 11x31** est résolu en :

- trajet **11 → 22 → 31** ;
- pièces capturées : **17 et 27**.

Tests supplémentaires : symbole × ; résultats 2-0 et 0-2 exclus des déplacements ; point final ; export PDN avec rafles explicites puis réimport produisant exactement le même damier final. Le faux déplacement simple `11-31` et la fausse prise `11x32` sont rejetés dans cette position.

Un cas réel de rafle ambiguë `2x4`, avec plusieurs ensembles de pièces capturées, est refusé tant que le trajet n’est pas précisé. La notation complète correspondante est acceptée. Aucune règle de prise maximale n’a été assouplie.

## 3. Jeu et flèches

Vérifications réelles dans Chromium :

- partie jouée directement avec les Blancs, sans choix obligatoire ;
- sélection des Noirs et premier coup automatique de Scan pour les Blancs ;
- retour/avance dans l’historique et relecture automatique ;
- annulation d’un seul demi-coup, pause explicite puis possibilité de reprendre ;
- flèche de l’historique correctement restaurée après annulation ;
- disparition au départ et à la nouvelle partie ; absence dans l’éditeur ;
- retournement du damier avec coordonnées de flèche reflétées ;
- rafle du 27e coup : **trois points SVG**, pas seulement départ/arrivée ;
- calque réellement `pointer-events: none` ; aucun débordement horizontal dans l’étude ou le générateur rétrograde.

Tests unitaires : immutabilité des états d’historique, trait alterné, état initial sans trajet et transformation géométrique des points selon l’orientation.

**Fichiers de règles, de nulles, de tables et de moteur inchangés**, vérification SHA-256 par comparaison à la livraison précédente dans `core-integrity.json` :
`src/game-rules.js`, `src/draw-rules.js`, `src/bitbases.js`, `src/engine.js`, `public/scan-normal.worker.js`.

Les flèches sont des éléments SVG d’affichage, sans appel ni modification de la recherche Scan. Aucune mesure de performance sur téléphone physique n’est revendiquée.

## 4. Recherche rétrograde depuis un damier complet

### Tests unitaires

- **1 445 prédécesseurs inverses** contrôlés sur des positions issues du PDN, incluant pions, dames, captures multiples et promotion. Chaque coup avant → après est légal et restitue exactement le damier cible.
- Recherche depuis **7 dessins** représentant les préfixes d’ouverture de longueur 0 à 6 : **7 preuves** retrouvées puis rejouées depuis la position initiale ; **6 non vides**, une preuve vide pour le départ lui-même. Total : **292 positions rétrogrades explorées**.
- Budgets : 500 nœuds, profondeur 12, faisceau 30, au plus 2 restitutions par rafle et 500 hypothèses par position pour ces sept essais.
- Cas budget insuffisant : résultat « non trouvé », non transformé en preuve d’impossibilité.
- Rejet d’une fausse suite ; recherche d’une preuve dans un historique connu, avec attribution et revalidation complète.

### Navigateur, hors ligne

Dans un contexte neuf sans historique mémorisé, dessin complet après les cinq premiers demi-coups de la partie : **preuve rétrograde de 5 demi-coups**, **107 positions explorées**, **863 hypothèses inverses contrôlées**. Cette cible comporte une prise blanche et une prise noire dans sa preuve ; l’origine retrouvée est bien le départ à 20 pions de chaque camp.

Vérifications : lecture jusqu’au départ 20 contre 20, flèche absente au départ et présente au dessin final. Dans un autre contexte ayant importé la partie, une preuve de la position finale est retrouvée et marquée distinctement **« Historique connu »**.

**Limite : recherche heuristique bornée, pas solveur exhaustif.** Aucun test ne garantit de retrouver la preuve d’un dessin arbitraire ou d’une finale lointaine. Une suite compatible n’est pas nécessairement la partie historiquement jouée. Les limites de rafle, faisceau, profondeur et hypothèses sont affichées et réglables.

## Régressions de la livraison précédente

`VITE_BASE_PATH=/Dt/ npm test` : réussi. Build, règles, positions, PDN, Scan, cache, générateur de structures, tables et nouveaux tests étude/rétrograde.

- Tables : 41 fichiers réels, couverture **2 à 4 pièces au total** ; 18 890 contrôles de cohérence, 60 positions comparées aux choix de Scan en analyse et 55 en mode jeu avec plusieurs coups optimaux.
- Nulles : tests 25/16/5 coups par camp, répétition et priorité de victoire. Navigateur : nulle à cinq coups et restauration après annulation.
- Bibliothèque/recherche : enregistrement, filtres, import/export et persistance après rechargement.
- Ancien tirage de structures : 300 essais unitaires, 137 preuves conformes (dont 37 non vides) ; lot navigateur de 429 essais, 102 preuves conformes avec doublons, 100 candidats uniques analysés à profondeur 3 et 10 témoins visibles. Tolérance 10 volontairement large pour tester le circuit technique, pas certifier l’équilibre.
- Build servi sous **/Dt/** : service worker réellement activé ; contexte passé hors ligne puis rechargé ; Scan, ancien générateur et **nouveau worker rétrograde** fonctionnent. Tous les workers sont précachés.

## Journaux et limites restantes

Résultats détaillés : `tests-execution.log`, `study-retro-test-results.json`, `browser-study-results.json`, `finales-test-results.json`, `browser-finales-results.json`, `browser-offline-results.json`, `browser-test-results.json` et résultats natifs des bitbases.

Le HTML autonome inclut les ressources et workers, sans dépendance à un service distant. Les tests sont faits avec Chromium réel en taille mobile ; **Android physique non testé**. Les tables 5–6 pièces restent non incluses, le moteur reste JavaScript/asm.js et la profondeur 20 n’est pas certifiée en temps/mémoire. Le manifeste d’installation PWA n’est pas ajouté dans cette livraison.

**Aucune publication GitHub effectuée** : remplacer l’archive existante de même nom déclenchera votre workflow.
