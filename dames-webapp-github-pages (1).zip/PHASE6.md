# Phase 6 — Bouclage du projet

1er novembre 2026 · version publiée **1.0.0** · ce document clôt la série des phases 0 à 6.

## Ce qui a été fait dans cette phase

### Application installable (manifeste PWA)

Le manifeste était la seule pièce encore annoncée comme « à venir » (voir la fin de `PHASE5.md`). Il existe désormais :

- `public/manifest.webmanifest` : nom complet et nom court **PIONICIDE**, description française, `lang: fr`, `start_url: "./"`, `scope: "./"`, `display: standalone` (repli `minimal-ui`), fond et thème `#101a24`, orientation portrait, trois **raccourcis** (Jouer, Damier d'analyse, Base de parties) ;
- `public/icons/` : `icon-192.png`, `icon-512.png`, `maskable-512.png` (zone de sécurité respectée pour Android), `apple-touch-icon-180.png`, `favicon-48.png` — disque doré « P » sur damier discret, dans l'esprit du bandeau de l'application ;
- `index.html` : `rel="manifest"`, `theme-color`, `color-scheme`, `apple-touch-icon`, métadonnées iOS (plein écran), et un message `noscript` lisible (placé dans le `body` : dans le `head`, le parseur HTML de Vite refuse un texte dans `noscript`) ;
- `src/style.css` : style du bandeau d'installation.

### Installation et navigation

- **Invitation à installer** (`beforeinstallprompt`) : bandeau discret en bas de l'écran, bouton « Installer », « × » qui n'insiste plus jamais (`localStorage`), disparition définitive après installation, message de confirmation. Aucune invite sur un appareil où l'application est déjà installée.
- **Liens directs** : `#jouer`, `#analyse`, `#base`… ouvrent directement l'écran voulu, mettent l'URL à jour pendant la navigation et fonctionnent depuis les raccourcis du manifeste.
- **Journal de version** : la console indique `PIONICIDE 1.0.0 — installé | navigateur`.

### Service worker

- Cache `dames-internationales-shell-pionicide-v15` : le manifeste et les cinq icônes entrent dans le précache, donc l'application installée reste complète hors ligne dès la première visite.
- Les anciens caches (`v14` et antérieurs) sont supprimés à l'activation.

### Version et documentation

- `package.json` : version `1.0.0`, description et licence renseignées.
- `README.md` et `RAPPORT-TESTS.md` mis à jour ; `PHASE6.md` (ce document) décrit l'état final et la procédure de publication.

## Vérifications de clôture

### Suite automatique — `npm test`

| Contrôle | Résultat |
|---|---|
| `npm run build` (Vite, 34 modules, worker de la base compilé à part) | OK |
| `test:rules` — ouverture, prises maximales, dame volante, promotion, notation HUB | OK |
| `test:position` — validation, compteurs, aller-retour PDN et Hub | OK |
| `test:pdn` — lecture, en-têtes, multi-parties, appariement, sérialisation | OK |
| `test:export` — PDN annoté, seuils, relecture | 8/8 |
| `test:threats` — menaces réelles sur Verpoest–Berte 1980, cache, portée, interruption | OK (4 créées, 3 évitées, 2 lignes écartées « prise immédiate ») |
| `test:engine`, `test:wasm` (scalaire et SIMD), `test:finales`, `test:bitbases-*` | OK |
| `test:offline` — shell, assets, données du moteur **et manifeste + icônes** précachés | OK |
| `test:validator` — cohérence du livre de combinaisons | OK |
| `test:base` — 38 contrôles : lecture PDN, index, recherche par structure comparée aux règles de l'application, structures, noms tolérants | OK |

### Contrôles navigateur (build de production, Chromium, 412 × 915)

- `npm run test:browser-pwa` : manifeste servi et complet (nom, `standalone`, `fr`, 3 raccourcis), trois icônes servies en `image/png` et décodées, icône iOS 180 × 180, service worker actif avec manifeste et icônes en cache, bandeau d'installation affiché et invite réellement déclenchée, `#base` ouvre l'écran attendu, **rechargement réseau coupé : l'application se charge et s'affiche**. Aucune erreur JavaScript.
- `npm run test:browser-base` : parcours complet de la base de parties — import (192 parties de la fixture, ou les 1 000 du fichier réel avec `PDN=…`), explorateur, ouverture d'une partie, structures, recherche, export, et les deux passerelles « Analyser » et « Jouer ». Aucune erreur JavaScript.

### Mesures réelles retenues pour la version 1.0.0

Fichier de 1 000 parties (`test_1000_parties.txt`) : **977 importées, 11 doublons, 12 ignorées avec motif, 1 tronquée**, 360 joueurs, import ≈ 0,5 ms par partie, index 21 036 positions / 0,6 Mo, stockage 20 Mo sur 10 Go de quota, recherche par structure 27 à 46 ms, base de 200 parties : 4 568 positions / 0,1 Mo. Extrapolation 100 000 parties : ≈ 55 s d'import, ≈ 63 Mo d'index, ≈ 155 Mo de stockage, recherche ≈ 2,4 s.

## État final du projet

Sept écrans, tous accessibles par le menu et par lien direct :

1. **Accueil / Jouer** — partie contre PIONICIDE, niveaux, réglages du moteur ;
2. **PIONICIDE contre PIONICIDE** — deux moteurs, séries, PDN, archive ;
3. **Damier d'analyse** — évaluation, variante, partie annotée, menaces, tables de finales, exports PDN et PDF ;
4. **Éditeur de partie** — placement, code de position, jeu depuis une position ;
5. **Importer une partie** — PDN, relecture ;
6. **Combinaisons** — 2 880 combinaisons, niveaux, validateur ;
7. **Base de parties** — import massif, explorateur d'ouvertures, recherche par structure, export `.pbase`, passerelles vers l'analyse et le jeu.

Réglages transversaux de cette version : **une seule profondeur** (sélecteur du damier d'analyse, 16 par défaut, 3 à 25) pour l'évaluation, l'annotation et les menaces ; **une prise immédiate n'est pas une menace** ; **recherche par nom tolérante aux fautes de frappe** dans la base.

Côté moteur, rien n'a changé : Scan 3.1b C++/WASM (GPL-3.0), 64 Mio de table de transparence (128 Mio et SIMD en option), tables de finales 2 à 4 pièces. La base de parties parle uniquement à son propre worker et ne touche pas au moteur.

## Publication

1. Téléverser l'archive **`dames-webapp-github-pages (1).zip`** (20,2 Mo, 297 fichiers) à la racine du dépôt `sosthene-hub/Dt`, en remplacement de l'archive qui porte exactement ce nom.
2. Déposer `tome-1.pdf` et `tome-2.pdf` dans `data/livres/` (facultatif, hors archive à cause de la limite de 25 Mo par fichier).
3. Pousser sur `main` : le workflow existant extrait l'archive, lance `npm ci` puis `npm test`, et publie `app/dist`.
4. Attendre le coche verte de l'onglet Actions, puis recharger https://sosthene-hub.github.io/Dt/ (en cas d'ancien écran : vider les données du site, le cache est passé en v15).
5. Sur Android : menu Chrome **⋮ → Installer l'application** (ou le bandeau proposé au premier chargement). L'icône PIONICIDE s'ouvre alors en plein écran, hors ligne.

## Ce qui reste à faire de votre côté

- **Test sur un téléphone Android physique** : impossible ici (les contrôles mobiles sont faits sous Chromium Linux à 412 × 915). À vérifier en priorité : le rendu du damier, le glisser des pièces, la taille de l'invite d'installation et le temps d'analyse à profondeur 16.
- **Vinculation du dossier `data/livres/`** si les deux tomes PDF doivent être servis.
- **Choix produit** : à profondeur 16, annoter une partie entière de 72 coups prend plusieurs minutes sur téléphone ; le sélecteur unique permet de redescendre à 12 sans rien perdre des autres fonctions.

## Limites connues, assumées

- Le moteur est un moteur de recherche heuristique : une profondeur n'est jamais garantie, seulement visée dans un budget de temps.
- Les tables de finales s'arrêtent à 4 pièces au total.
- La base de parties vit dans le stockage du navigateur : `navigator.storage.persist()` est demandé, mais un nettoyage manuel des données du site l'efface (l'export `.pbase` sert de sauvegarde).
- 12 parties du corpus de test restent non indexables (5 hors damier 10 × 10, 7 sans position de départ) : comportement attendu, signalé dans le rapport d'import.
- Le fichier `Dames-autonome.html` reste fourni pour un usage hors serveur ; il embarque désormais aussi le worker de la base de parties.
