# PHASE 8 — Recherche joueur contre joueur et impression

Deux demandes, livrées ensemble :

1. chercher **un joueur contre un joueur** dans l'onglet Recherche de la base,
   avec l'**année en option** ;
2. pouvoir **imprimer une position** non seulement depuis l'analyse, mais aussi
   depuis l'**explorateur** et depuis la **recherche** — pour garder une partie
   qui plaît.

## 1. Recherche joueur contre joueur

Onglet **Base de parties → Recherche**, désormais organisé en deux blocs :

| Bloc | Champs |
| --- | --- |
| **Joueur contre joueur** | Joueur des Blancs, Joueur des Noirs, Année de *(facultatif)*, Année à *(facultatif)* |
| **Structure** *(facultatif)* | structure enregistrée, demi-coups max, symétrie, résultats max |

- Chaque nom passe par la **recherche approximative** existante : accents, casse,
  nom seul, initiales et fautes de frappe sont acceptés. La note sous les champs
  rappelle quels joueurs ont réellement été reconnus (« Blancs : … · Noirs : … »).
- **L'année est facultative** : vide, aucune contrainte de date ; sinon la ou les
  années saisies filtrent sur la date des parties (bornes incluses).
- Les deux blocs **se combinent** : structure *et* joueurs *et* année.
- Si aucune structure n'est choisie, la recherche parcourt **toutes les parties**
  (`searchGames`), avec une barre de progression et la même limite d'affichage.
- Chaque résultat porte **Ouvrir** (damier de l'explorateur) et **Imprimer**.

Technique : nouveau résolveur de filtres `resolveSearchFilters` dans
`src/base/worker.js` (deux jeux de clés joueurs, bornes d'année) et extension de
`passFilters` dans `src/base/index-lib.js` (`whitePlayers`, `blackPlayers`,
année). Les anciens filtres restent acceptés.

Résultat mesuré sur l'échantillon de 200 parties : « koperberg » + « springer »
trouve 2 parties en 4 ms ; avec l'année 1915, 1 partie — celle qui correspond.

## 2. Impression partout

Nouveau module `src/analysis/print-sheet.js`, volontairement **indépendant de
l'analyse** : on imprime ce que l'on voit, sans lancer le moteur.

- Feuille A4 mise en page : titre, joueurs, événement, date, résultat, **damier
  en SVG** (net à l'impression, numéroté 1 à 50), légende de la position,
  **liste complète des coups** en deux colonnes, pied de page.
- Trois points d'entrée :

| Page | Bouton | Ce qui est imprimé |
| --- | --- | --- |
| **Explorateur** | « Imprimer la position » | le damier dans l'orientation affichée, le demi-coup courant et, si une partie est ouverte, tous ses coups |
| **Recherche** (résultats) | « Imprimer » sur chaque ligne | la partie complète, avec **deux diagrammes** : position initiale et position finale |
| **Damier d'analyse** | « Imprimer la position » | la position affichée (partie ou variante), avec la liste des coups joués |

Les résultats de l'onglet Explorateur (« Parties de cette position ») reçoivent
aussi le bouton **Imprimer**.

La fonction `sheetModel` (répartition des coups en lignes Blancs / Noirs, position
marquée, bornes) est pure et testée sous Node : 3 nouveaux tests dans
`scripts/test-export.mjs` (11/11 au total).

## Vérifications

- `npm test` : **tous les tests passent**, aucune régression (noyau, PDN, export,
  base de parties, finales, PWA).
- Nouveau test navigateur `npm run test:recherche-impression`
  (`scripts/browser-recherche-impression.mjs`, Chromium sans interface) :
  import d'un PDN, recherche joueur contre joueur, filtre d'année, impression
  depuis la recherche, l'explorateur et l'analyse. **14 contrôles, tous OK**,
  aucune erreur JavaScript.

## Notes d'usage

- Les feuilles s'impriment via la boîte de dialogue du navigateur ; « Enregistrer
  au format PDF » donne un fichier partageable.
- L'impression ne dépend pas du moteur : elle fonctionne même si l'analyse n'a
  jamais été lancée.
- Sur téléphone, l'aperçu de la feuille est lisible et le bouton « Imprimer /
  PDF » ouvre le partage du système.
