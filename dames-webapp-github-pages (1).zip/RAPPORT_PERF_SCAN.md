# Scan amélioré — diagnostic, mesures et limites

**Livraison du 19 octobre 2026.** Application, HTML autonome et sources C++ inclus. Les mesures ci-dessous ont réellement été exécutées ; leurs traces sont dans `perf/`. Ce rapport remplace les anciennes indications « asm.js, pas WASM » des livraisons précédentes.

## Résultat et configuration retenue

- Vrai **Scan 3.1b C++ recompilé en WebAssembly**, pas une réécriture JavaScript et pas une évaluation simulée.
- Compilation Emscripten **3.1.74**, `-O3 -flto -DNDEBUG`, exceptions C++ nécessaires à l’arrêt propre, sans `fast-math`.
- **64 Mio de transposition par moteur** par défaut ; **128 Mio en option** dans « Réglages Scan » sur la page de jeu. Ce n’est pas la mémoire totale de l’application.
- Variante WASM portable par défaut. Variante `-msimd128` livrée en option, avec repli portable si elle ne se charge pas. Le SIMD n’a pas gagné de façon reproductible ici.
- Recherche dans un **Web Worker**, un fil de calcul par instance. Aucun faux multithreading ajouté.
- Objectifs de profondeur 12/16/20/22/25 et plafonds de temps 1/4/15/30/90 secondes selon le niveau.
- Deadline contrôlée **dans la récursion native**, toutes les 2 048 incrémentations de nœuds. En cas d’arrêt, retour à la meilleure variante de la dernière itération terminée.
- Petite bibliothèque d’ouvertures native rétablie et réellement utilisée en jeu ; jamais pour court-circuiter l’analyse.
- Tables automatiques 2–4 pièces conservées et retestées. Tables 5/6 non ajoutées : poids et coût mémoire détaillés plus bas.

**Bilan mesuré à profondeur 20, moteurs déjà échauffés, trois répétitions :** ancien asm.js / 1 Mio : médiane **4,709 s**, environ **1 932 kn/s** ; nouvelle version portable / 64 Mio : **0,650 s**, environ **9 680 kn/s**. Soit environ **7,25 fois moins de temps pour finir cette profondeur** et **5 fois le débit de nœuds annoncé**, sur cette position et cette machine. Cela combine compilation, mémoire et corrections décrites ci-dessous, pas seulement une instruction magique.

**Aucune performance Android physique ni aucun classement Elo n’est certifié.** Les observations utilisateur « 110 kn/s » et « lidraughts 2 700 kn/s, profondeur 25 en 84 s » ne sont pas des mesures contrôlées de ce protocole. La position, le matériel, les réglages et la définition des compteurs peuvent différer. Un gain Linux ne se transpose pas proportionnellement à un téléphone.

## 1. Protocole reproductible

### Position commune

Verpoest–Berte 1980, **après le 40e demi-coup**, Blancs au trait, 15 pièces contre 15 :

```text
W:W27,28,32,34,36,37,38,39,40,42,43,45,47,48,49:B3,4,6,8,9,11,12,13,14,15,16,17,18,19,23
```

Position et plateau machine : `perf/position.json`. Même position dans les comparaisons compilation, mémoire, SIMD, niveaux et bibliothèque. Cette position n’est pas une finale à quatre pièces ni une position de bibliothèque.

### Environnement et définition des nombres

- Linux x64, processeur présenté par l’environnement : **Intel Xeon @ 2,60 GHz**, deux processeurs logiques ; Chromium **156.0.8078.4** headless. Ressources virtualisées, donc variabilité possible.
- Un Worker de recherche actif à la fois pendant les benchmarks. Les essais d’interface sont distincts.
- Temps mural : départ de `go` jusqu’à `done`, **hors téléchargement, instanciation et initialisation**. Le coût des échanges Worker pendant la recherche est inclus.
- `kn/s = nodes / time / 1000`, calculé à partir des sorties Scan. Le champ Hub historique `nps` est exprimé en **millions** de nœuds/s, pas directement en kn/s ; on ne l’affiche pas sans conversion.
- Dans l’ancien binaire, la dernière ligne `info` peut précéder la fin de l’itération. Son débit est un **instantané**, pas nécessairement le compteur final. Le temps mural jusqu’à `done` confirme la profondeur terminée. Pour les essais arrêtés de force, la profondeur annoncée n’est pas une preuve d’itération terminée.
- La nouvelle compilation émet explicitement `completed=true` après une itération terminée et réémet la variante retenue à l’arrêt. Les traces complètes sont conservées, y compris les PV intermédiaires.
- Les médianes sont indiquées lorsqu’il y a trois répétitions. Les lignes à un essai ne sont pas présentées comme une étude statistique.

Pour rejouer : installer Playwright/Chromium, servir la racine du projet sur le port 4174, puis lancer `node scripts/bench-perf.mjs baseline`, `wasm`, `final`, `release`, `warm`, `levels`, `simd-release` ou `book`. Le contrôle O3 sans les nouveaux arrêts reste dans `perf-baseline/scan-wasm-o3.js`. L’ancien Worker et l’ancien wrapper sont également conservés dans ce dossier.

## 2. Diagnostic précis de l’ancienne intégration

| Point | Constat vérifié |
|---|---|
| Origine | Vrai Scan compilé C++ vers asm.js, paquet `scan3.1.js@1.1.0`, pas un moteur réécrit en JS |
| Version | Binaire historique annoncé 3.1b ; les sources anciennes fournies dans le paquet portent encore 3.1. Le nouveau build utilise le port amont identifié 3.1b, sources incluses |
| Threads | Un Worker, un fil de recherche ; les fonctions d’entrée ne constituent pas un deuxième fil de calcul |
| Transposition | `tt-size=16` est un **exposant du nombre d’entrées**, pas 16 ou 64 Mo. `2^16 × 16 octets = 1 Mio` |
| Niveaux | Constantes 3, 5, 7, 9 ; l’interface de jeu n’exposait que facile/normal/fort |
| Temps | Aucun `move-time` envoyé ; entrée native par défaut proche de 1 000 000 s. Le délai JS de 20 s ne stoppait pas réellement le moteur et pouvait rendre un résultat sans coup |
| Tables | 41 fichiers authentiques, 2–4 pièces au total, **2 682 273 octets** de données |
| Ouvertures | Pas de `book.cpp`, pas de livre chargé ou sondé dans cette intégration |

Mesure des anciennes profondeurs, même position, un essai par niveau :

| Profondeur | Temps jusqu’à `done` | kn/s de la dernière info |
|---:|---:|---:|
| 3 | 0,017 s | 47 |
| 5 | 0,038 s | 103 |
| 7 | 0,071 s | 169 |
| 9 | 0,141 s | 240 |
| 12 | 0,263 s | 504 |
| 14 | 0,438 s | 803 |
| 16 | 0,938 s | 1 037 |

Les faibles débits sur les recherches minuscules incluent l’échauffement et les échanges ; ne pas les confondre avec un débit stabilisé. Sources : `results-baseline.json`, `results-warm.json`.

## 3. Étape WebAssembly — gain isolé avant les nouveaux réglages

Première compilation O3/LTO du port 3.1b, sans bibliothèque utilisée, **même petite TT de 1 Mio** :

| Objectif atteint | asm.js historique, un essai | WASM O3, médiane de 3 | kn/s avant → après |
|---:|---:|---:|---:|
| 14 | 0,438 s | 0,0765 s | 803 → 4 617 |
| 16 | 0,938 s | 0,1445 s | 1 037 → 6 825 |

À profondeur 16, le temps baisse ici d’environ **6,5 fois**. Les petits écarts de nombre de nœuds sont visibles dans les traces : le port amont 3.1b comprend notamment des corrections de ply dans la recherche par rapport aux anciennes sources du paquet ; on ne prétend pas avoir exécuté un arbre binaire strictement identique instruction par instruction.

Sources : `results-baseline.json`, `results-wasm.json`. Les sources et la commande de construction sont livrées dans `engine-src/` et `scripts/build-scan-wasm.sh`.

## 4. Mémoire de transposition — 64 Mio retenus, 128 Mio optionnels

Les paramètres corrects sont `tt-size=22` pour 64 Mio et `23` pour 128 Mio. Le nouveau tas WASM peut croître ; son plafond configuré est 512 Mio. **L’ancien asm.js a échoué par OOM à 128 Mio** pendant l’essai ; ce n’est pas masqué comme une réussite.

Même nouvelle compilation finale, profondeur 25 terminée, trois répétitions par taille :

| TT | Temps mural médian | kn/s médian | Nœuds finaux |
|---:|---:|---:|---:|
| 1 Mio | 11,472 s | 11 709 | 134 269 428 |
| **64 Mio** | **6,585 s** | **9 369** | **61 541 770** |
| 128 Mio | 11,261 s | 9 158 | 102 839 044 |

**Plus de mémoire n’a pas été plus rapide sur ce milieu de partie.** La TT change les collisions, l’ordre et l’arbre d’une recherche sélective ; le nombre de nœuds et le débit ne varient pas de façon monotone. Avec 64 Mio on finit ici environ 1,74 fois plus vite qu’avec 1 Mio, bien que le débit brut soit inférieur. Avec 128 Mio on travaille davantage sur cette position. D’où le choix prudent de 64 Mio et non une promesse « 128 = deux fois mieux ».

Un moteur de jeu et un moteur d’analyse peuvent chacun posséder leur propre mémoire. La taille de TT affichée n’inclut ni les données d’évaluation, ni les tables, ni les copies JS/WASM et le navigateur.

Sources : `results-release.json`. L’ancien asm.js, ajusté à 64 Mio pour comparaison exploratoire, atteignait profondeur 20 en 3,839 s / 1 458 kn/s ; à 128 Mio il n’a pas initialisé sa mémoire (`results-deep.json`).

## 5. Temps et nouveaux niveaux

| Niveau | Avant | Objectif désormais | Plafond par coup | Atteint sur le milieu de partie | Temps mural mesuré | kn/s |
|---|---:|---:|---:|---:|---:|---:|
| Facile | 3 | 12 | 1 s | 12 | 0,069 s | 2 882 |
| Normal | 5 | 16 | 4 s | 16 | 0,171 s | 5 904 |
| Fort | 7 | 20 | 15 s | 20 | 0,659 s | 9 590 |
| Expert | 9, constante non exposée en jeu | 22 | 30 s | 22 | 1,715 s | 10 834 |
| Grand maître | absent | 25 | 90 s | 25 | 5,991 s | 10 303 |

Source : `results-levels.json`, un passage par niveau. Pour profondeur 25, les répétitions séparées donnent 6,38 à 6,78 s avec 64 Mio. **Il s’agit d’objectifs et de plafonds**, pas d’une obligation d’utiliser tout le temps. Une ouverture de bibliothèque ou un coup forcé peut être joué rapidement. La profondeur n’est pas garantie sur Android ni sur toutes les positions. Le nom Grand maître n’est pas une certification de classement.

Le moteur vérifie maintenant la deadline dans la récursion. Si la limite arrive dans une itération, cette itération est abandonnée et le coup/score/PV de l’itération terminée précédente est rétabli. Un coup légal de secours existe même si la première itération n’a pas fini. Un watchdog JS supplémentaire à plafond + 3 s termine et relance le Worker si nécessaire ; il ne laisse pas une recherche tourner indéfiniment. Les minuteries restent dépendantes de la suspension éventuelle d’un onglet par Chrome, ce n’est pas un système temps réel dur.

Vérifications : test natif 60 ms, résultat légal et reprise d’une recherche suivante ; test fichier autonome 1,2 s, environ 1,20 s mesurées, retour d’une itération terminée. Traces : `wasm-regression*.json`, `browser-perf.json`.

Le générateur n’accepte maintenant que les scores marqués **itération terminée** à la profondeur demandée. Une PV intermédiaire profonde ne suffit plus à valider un résultat. L’analyse conserve la PV complète de repli, pas seulement un coup inventé.

## 6. SIMD — compilé, mesuré, pas imposé

Même position, 64 Mio, profondeur 23 terminée, trois passages alternés :

| Build | Temps médian | kn/s médian |
|---|---:|---:|
| Portable O3/LTO | 3,038 s | 8 897 |
| SIMD O3/LTO | 3,063 s | 8 821 |

Écart médian légèrement défavorable au SIMD, dans la variabilité d’exécution. À profondeur 20 un autre passage donnait 0,683 s portable contre 0,767 s SIMD. Scan travaille beaucoup sur des bitboards 64 bits et des accès mémoire ; activer SIMD n’implique pas vectoriser utilement tout le moteur. Les deux variantes passent les **120 mêmes cas de finales chacune**. La sélection SIMD / 128 Mio fonctionne également dans le HTML autonome hors ligne. Aucun gain SIMD Android n’est revendiqué.

Sources : `results-final.json`, `results-simd-release.json`, `wasm-regression-simd.json`, `browser-perf.json`.

## 7. Multithreading et fichier local Android

**Non implémenté, conformément à la contrainte de compatibilité locale.** Le port actuel est mono-fil. Les pthreads WebAssembly usuels nécessitent une mémoire partagée et un contexte isolé ; compiler avec `-pthread` ne rétablit pas à lui seul les recherches parallèles supprimées dans ce port.

Dans le test réel `file://` hors ligne : `crossOriginIsolated=false`, `typeof SharedArrayBuffer="undefined"`, Worker disponible. Le fichier local ne peut pas fournir les en-têtes serveur COOP/COEP. Nous n’avons pas contourné les sécurités du navigateur et n’avons pas testé un téléphone physique. Deux Workers indépendants n’ont pas été présentés comme deux fils coopérant à une même recherche.

**Alternative :** une version HTTPS hébergée avec les en-têtes d’isolation appropriés, puis un port véritablement multi-thread à mesurer, ou une application Android native intégrant Scan. L’hébergement GitHub Pages standard ne permet pas de configurer librement ces en-têtes ; une autre infrastructure ou une stratégie d’isolation spécifique serait nécessaire. Cela constituerait une livraison distincte, pas le HTML local promis ici.

Impact avant/après sur la position commune : toujours **1 fil**, aucun gain multi-thread attribué. La performance du build retenu est celle du tableau 64 Mio.

## 8. Tables 5/6 pièces — poids réel, décision explicite

Inventaire du répertoire central de l’archive officielle `https://hjetten.home.xs4all.nl/scan/bb.zip` :

| Taille | Fichiers | Données décompressées | Somme des contenus ZIP compressés |
|---|---:|---:|---:|
| 2 | 4 | 691 octets | 406 octets |
| 3 | 12 | 47 569 octets | 16 165 octets |
| 4 | 25 | 2 634 013 octets | 852 408 octets |
| **5** | **44** | **73 620 274 octets ≈ 70,2 Mio** | **24 744 987 octets ≈ 23,6 Mio** |
| **6** | **70** | **2 022 951 666 octets ≈ 1,884 Gio** | **714 363 812 octets ≈ 681,3 Mio** |

Les tailles compressées sont les sommes par fichier, hors en-têtes ZIP. Détails : `perf/table-sizes.json`. Les bases 2–4 déjà intégrées ont été téléchargées et vérifiées dans le travail précédent ; les 5/6 n’ont pas été téléchargées ni chargées pour cette livraison.

- **6 pièces : non faisable avec ce budget**, bien au-delà du plafond de mémoire WASM configuré et du format Android autonome visé.
- **5 pièces : techniquement intégrables dans une architecture plus lourde, mais non retenues comme raisonnables pour cet autonome Android.** Avec le mécanisme embarqué existant, elles ajouteraient environ **93,6 Mio de base64** au HTML, plus les chaînes, buffers décompressés et copies dans chaque moteur. Le fichier autonome passerait bien au-delà de 100 Mio et augmenterait fortement le risque mémoire, surtout avec deux instances. Les compresser dans le HTML réduirait le téléchargement, pas les 70,2 Mio natifs nécessaires ni toutes les copies.
- Une future distribution web pourrait utiliser un pack compressé chargé une seule fois dans le Worker et conservé hors ligne ; cela demande une gestion de mémoire et un chargement différents, à tester sur le téléphone cible. **Ce mécanisme n’est pas livré et aucun résultat exact à cinq pièces n’est annoncé.**

Sur la position commune à 30 pièces, la racine est hors couverture. Aucun gain de tables 5/6 n’est attribué. Les tables automatiques 2–4 et leurs résultats WDL restent inchangés ; le WDL ne remplace pas les compteurs FMJD et l’historique.

## 9. Bibliothèque d’ouvertures

L’ancienne intégration ne chargeait aucun livre. La nouvelle reprend le petit livre natif distribué par l’amont : `public/scan-book.bin`, avec `book.cpp/.hpp`. Il est embarqué dans le HTML, installé dans le système de fichiers du Worker, initialisé puis sondé **uniquement pour jouer**. Son chargement ne suffit pas comme preuve : les tests vérifient réellement un `info source=book` et la légalité du coup choisi depuis le départ.

Sur le **même milieu de partie**, bibliothèque désactivée / activée, profondeur 20 et trois passages : médianes **0,722 s / 0,713 s**, **8 809 / 8 860 kn/s**, exactement **6 166 290 nœuds** dans les deux cas. Aucun gain structurel : cette position n’est pas dans le livre ; la différence est du bruit de mesure. En position initiale, le coup de livre est effectivement utilisé et l’interface indique « Bibliothèque d’ouvertures ». Les coups de livre peuvent varier entre coups légaux admissibles : aucun score Elo n’est inventé.

Sources : `results-book.json`, `wasm-regression*.json`, `browser-perf.json`.

## 10. Régressions et livraison

`VITE_BASE_PATH=/Dt/ npm test` passe, y compris les deux builds WASM. Contrôles Chromium supplémentaires réussis :

- HTML autonome `file://` réellement hors ligne, affichage mobile 412×915 ; aucune requête moteur distante nécessaire ; aucun débordement horizontal observé.
- SIMD + 128 Mio, livre réellement utilisé, limite interne 1,2 s, **72 frames pendant le calcul**, intervalle maximal observé **16,8 ms**, menu utilisable.
- Navigation pendant une analyse native profonde : Worker effectivement terminé ; nouvelle analyse profondeur 3 utilisable, sans ancienne réponse réattribuée.
- Production `/Dt/` : précache des deux builds WASM, Worker, livre et données ; rechargement hors ligne, génération et rétrograde fonctionnels.
- PDN historique **131/131 demi-coups**, rafle via 11→22→31, deux lignes partie/Scan indépendantes, relecture, annulation, choix du camp, flèches et orientation.
- Règles et finales existantes conservées ; **120 cas de coups optimaux par build WASM**, plus les tests historiques ; recherche rétrograde toujours bornée, jamais présentée comme exhaustive.
- Générateur : 100 analyses / 100 résultats dans le contrôle technique à seuil très large, 10 damiers témoins ; ce test valide la chaîne, pas la force des positions.

Voir aussi `RAPPORT-TESTS.md`. Les échecs exploratoires sont conservés : OOM asm.js à 128 Mio ; absence de gain SIMD stable ; 128 Mio moins rentable sur la position ; tables 5/6 et multi-thread non livrés. Un premier lancement de l’outil de prévisualisation sans son chemin `/Dt/` a produit une 404 ; le serveur a été relancé avec le bon chemin et le test hors ligne final a ensuite réussi.

**Contenu à utiliser :** ZIP portant exactement le nom demandé, HTML autonome, présent rapport et sources. Les anciens documents à quatre phases décrivent l’état avant optimisation ; ils sont historiques pour leurs mentions de l’ancien moteur. Cette livraison n’a pas été publiée sur le compte GitHub de l’utilisateur.
