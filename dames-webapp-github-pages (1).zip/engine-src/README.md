# Sources du Scan actif — GPL-3.0

Vrai Scan 3.1b de Fabien Letouzey, port RoepStoep/scan-wasm ; livre repris de RoepStoep/scan-3.1. Commits et SHA-256 : `provenance.json`. La licence amont est conservée dans `LICENSE`.

## Reconstruction

Installer / activer **Emscripten 3.1.74**, puis depuis la racine :

```sh
bash scripts/build-scan-wasm.sh
SCAN_EXTRA_FLAGS=-msimd128 SCAN_OUTPUT=public/scan-wasm-simd.js bash scripts/build-scan-wasm.sh
npm run test:wasm
npm run standalone
```

`EMXX` peut préciser le chemin de `em++`. Les binaires JS/WASM embarqués sont déjà livrés : Emscripten n’est pas nécessaire à `npm ci`, `npm test` ou au déploiement GitHub Pages. Chaque fichier runtime contient son propre module WASM base64 pour fonctionner en fichier local sans fetch de `.wasm`.

## Adaptations locales

- `search.cpp` : deadline monotone vérifiée toutes les 2 048 incrémentations de nœuds ; exception locale rattrapée ; restauration de l’itération terminée ; PV finale et statistiques explicites ; coup légal de secours ; finalisation Hub pour coup forcé et terminal ; livre natif en mode jeu uniquement.
- `util.hpp` : horloge monotone pour les temps écoulés.
- `main.cpp`, `var.cpp/.hpp` : paramètre et initialisation du livre.
- `book.cpp/.hpp` : sources natives ; suppression de l’appel au seul imprimeur de débogage `list::disp`, absent du port et désactivé dans l’amont.
- Le wrapper `public/scan-wasm.worker.js` installe les données locales dans le FS Emscripten. Le wrapper applicatif sérialise les recherches et peut terminer / relancer le Worker.

L’ancien binaire asm.js et l’ancien wrapper sont conservés dans `perf-baseline/`. Les sources historiques du paquet npm restent dans `third-party/scan3.1` ; elles ne sont plus celles compilées pour le moteur actif. Les règles JavaScript FMJD de l’interface restent dans leur module indépendant.
