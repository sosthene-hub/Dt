# Module Combinaisons — extraction, validation, génération

**Livraison du 19 octobre 2026.** Le générateur de positions de l’onglet « Générateur » est remplacé par un module **Combinaisons** construit sur *PC Blues deel 66 — Standaardcombinaties* (Gerrit Boom). La recherche rétrograde reste accessible dans un onglet séparé.

> **Tout est inclus, en deux temps.** Sur autorisation explicite du propriétaire du projet, la base extraite, les deux tomes PDF d’origine et le HTML autonome avec la base embarquée sont tous livrés. GitHub refusant tout fichier de plus de 25 Mo en téléversement web, les deux PDF (5,6 Mo chacun) voyagent **hors du ZIP** et s’ajoutent en un second téléversement dans `data/livres/`. Aucun import n’est nécessaire : les 2880 combinaisons sont disponibles dès l’ouverture, PDF ou pas. La source (Gerrit Boom, *PC Blues deel 66*) est citée dans l’application et dans les données.

## 1. Ce qui a changé dans l’application

| Avant | Maintenant |
|---|---|
| Onglet « Générateur de positions » : racine dessinée, atteignabilité, positions calmes, validation Scan | Onglet **Combinaisons** : rafle demandée, niveau 1 à 4, exercice joué sur le damier |
| Générateur de motifs et son worker | Supprimés du code livré |
| — | Onglet **Recherche rétrograde** conservé tel quel |
| — | Base de 2880 combinaisons livrée avec l’application |
| Moteur Scan WASM et règles | Inchangés, réutilisés pour la vérification |

L’onglet Combinaisons propose :

- un champ de rafle libre (`38x`, `38x27`, `38x27x16`, tout préfixe) ;
- des filtres facultatifs : nombre total de pièces (≤ 20, 21–30, ≥ 31) et longueur de la solution (≤ 5, 6–9, ≥ 10 demi-coups) ;
- le choix du niveau 1 à 4 et une vérification Scan à profondeur 12, 16, 20 ou désactivée ;
- un exercice jouable : le joueur doit trouver le premier coup gagnant, les réponses forcées sont enchaînées, l’indice désigne la pièce, « Solution » affiche la ligne complète avec la flèche de la rafle ;
- si la rafle demandée n’existe pas, l’application le dit et liste les routes proches disponibles depuis la même case de départ ;
- les réglages (rafle, niveau, profondeur, filtres) sont mémorisés entre les visites ;
- un rapport de session compte, par niveau, les essais, les acceptations et les causes de rejet.

## 2. Extraction du livre

Deux tomes fournis, 370 pages chacun. Chaque diagramme est une image 330 × 330 px, damier 10 × 10 avec bordure, cases de 32 px, pions et dames en bitmaps.

- **Aucun OCR.** Trois prototypes de glyphes sont appris sur les images elles-mêmes (pion blanc, pion noir, dame noire), puis chaque case est classée par distance au prototype. Le vide se reconnaît à sa variance quasi nulle. Les 8 cases douteuses sur 162 050 (0,25 %) sont signalées dans les données, jamais devinées.
- **Association image ↔ texte par géométrie réelle.** Les positions des images sur la page sont lues dans le PDF (pas l’ordre des objets), puis les blocs de texte sont associés par niveau vertical. Les pages tardives (tableaux à trois colonnes) sont traitées par la même règle, avec la colonne de droite comme métadonnées.
- **En-têtes.** `slagroute` ou `route`, `herkomst eerste vijandelijke schijf`, ainsi que les drapeaux `lang`, `kort`, `met kaats`, `ad libitum` sont structurés. La casse et les variantes d’orthographe sont gérées.
- **Solutions.** Les variantes entre parenthèses et les commentaires sont retirés ; la notation abrégée du livre (`24x22` sans les prises intermédiaires) est acceptée et confrontée aux coups légaux.
- Les dernières pages sont l’index imprimé du livre ; ses renvois abrégés sont rejetés explicitement.

**3241 diagrammes** extraits sur les deux tomes.

## 3. Validation par rejeu

Toutes les solutions ont été rejouées avec le **moteur de règles FMJD de l’application** : prise majoritaire obligatoire, dames volantes, pions bloquants pendant la rafle, promotion en fin de coup. Les pièces sont suivies par identifiant, ce qui permet de vérifier la *herkomst* : case d’origine de la première pièce adverse prise dans la rafle finale et son trajet réel.

| Résultat | Nombre |
|---|---:|
| Diagrammes extraits | 3241 |
| **Combinaisons validées** | **2880** |
| Rejetées | 361 |

Principales causes de rejet :

| Cause | Nombre |
|---|---:|
| Solution partielle : le livre n’écrit pas l’eindslag (position « gagnante », suite non notée) | 180 |
| Aucun coup reconnu dans le texte (commentaire seul, diagramme de démonstration) | 53 |
| Texte absent (page d’illustration ou de titre) | 19 |
| Pièce annoncée absente après quelques coups (erreur de diagramme ou de notation) | 38 |
| Coup illégal après rejeu (prise majoritaire, dame volante, sens de déplacement) | 38 |
| Renvoi d’index (dernière page) | 1 |
| Autres cas isolés | 32 |

Les combinaisons conservées sont réparties sur 44 cases de départ (aucune rafle ne part de 1, 6, 7, 8, 9 ni 18). L’index par case est fourni dans la base ; les trois plus fournies sont 35 (238), 34 (215) et 38 (210).

### En-tête du livre et rejeu

| Concordance | Nombre |
|---|---:|
| Concordant (route et herkomst retrouvées) | 917 |
| Partiel (route retrouvée, herkomst ou détail différent) | 300 |
| Aucun en-tête de route au-dessus du diagramme | 1663 |

Quand l’en-tête donne une route, elle est retrouvée par le rejeu dans la grande majorité des cas ; les écarts sont conservés avec leur cause dans la base complète (`header_mismatch`) plutôt que corrigés silencieusement. Les 1663 entrées sans en-tête utilisent la **prise maximale tardive** comme rafle de référence, ce qui est une convention explicite, pas une donnée du livre.

**Limite importante :** la solution s’arrête à l’eindslag indexé ; la suite de la partie est conservée à part (`continuation`) et n’est pas demandée au joueur. Pour les 180 positions partielles, aucune combinaison n’est proposée : le livre n’en donne pas la fin.

## 4. Option « Demander une rafle »

- La saisie accepte tout préfixe de route. La base est indexée par pion de départ.
- Si la route existe telle quelle (position du livre), elle est servie directement.
- Sinon, un modèle est **translaté** pour que sa rafle commence par la case demandée et suive le préfixe demandé. La translation conserve la couleur des cases et le sens de déplacement.
- **Rotation et miroir exclus.** Une rotation à 180° inverse les camps et le sens de marche des pions ; un miroir change la couleur des cases. Les employer produirait des positions où la solution n’est plus légale. C’est une limite explicite du générateur.
- Si aucune translation n’est possible, l’application refuse et propose les routes proches de la même case de départ.

## 5. Niveaux de difficulté

Le squelette du modèle (pièces qui bougent, prises, cases de passage, herkomst) est **intouchable**. Les pièces ajoutées sont placées hors de ces cases, avec une distance minimale, en équilibrant le matériel.

| Niveau | Règle appliquée | Acceptation mesurée (400 tirages simulés) |
|---|---|---:|
| 1 | Position exacte du livre | 100 % (120/120 échantillons rejoués) |
| 2 | +2 à 4 pièces neutres, loin de la combinaison | 344/400 = 86 % |
| 3 | +4 à 8 pièces, distance réduite (leurres possibles) | 192/400 = 48 % |
| 4 | +8 à 12 pièces, distance réduite | 71/400 = 18 % (avant validateur) ; 39/40 sans Scan après placement contraint (voir 5 bis) |

Les échecs de génération ont des causes mesurées : une pièce ajoutée crée une prise obligatoire qui détourne la solution, une trajectoire sort du damier, ou il n’y a pas assez de cases libres. Ces positions sont rejetées, jamais livrées.

**Leurres et prise forcée : deux exigences du cahier des charges se contredisent.** Le niveau 3 demande des leurres, notamment une prise concurrente tentante, alors que la règle de validation impose de rejeter toute pièce ajoutée qui crée une prise obligatoire différente. La seconde règle a été retenue : une position dont le coup de départ n’est pas forcé par la prise majoritaire est refusée. Les « leurres » du niveau 3 sont donc des pièces proches qui rendent la position moins lisible, pas des prises alternatives légales. Aucun leurrage par prise forcée n’est livré.

Contrôles obligatoires pour chaque position acceptée :

1. la solution se rejoue intégralement avec le moteur de règles ;
2. la rafle finale est identique à celle du modèle (départ, arrivée, prises) ;
3. aucune prise obligatoire concurrente au coup de départ ;
4. écart de matériel ≤ 1 pièce et ≤ 40 pièces au total ;
5. longueur minimale de solution au niveau 4 (quatre demi-coups) ;
6. la rafle demandée reste respectée.

### Vérification Scan

Scan ne fournit pas de multi-PV dans cette intégration. La vérification fait donc deux recherches à profondeur égale :

1. **la position après le premier coup de la solution** est-elle gagnante pour les Blancs ? (score adverse retourné) ;
2. si oui, **le score du meilleur coup** est-il proche de celui du coup de la solution (écart ≤ 0,5) ?

Seuils : gain ≥ +1,5 pion, écart ≤ 0,5. Une position dont le gain est absent est rejetée sans seconde recherche.

**Calibrage sur un échantillon de 30 positions du livre, profondeur 12 :** Scan choisit le premier coup de la solution dans **22 cas sur 30 (73 %)**. La médiane de la valeur après ce coup est de +1,72. Ce chiffre mesure la cohérence entre la notation du livre et le moteur ; il ne prouve pas qu’un humain trouvera la combinaison.

**Génération vérifiée, profondeur 12, Linux x64 (même machine que le rapport Scan) :**

| Niveau | Positions acceptées | Essais | Vérifications Scan | Acceptation par vérification | Temps médian observé | Valeur médiane | Écart médian au meilleur coup |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2 | 6 | 11 | 11 | 54,5 % | < 1 s au total | +2,71 | −0,03 |
| 3 | 5 | 60 | 32 | 15,6 % | ≈ 2 s au total | +4,09 | −0,09 |
| 4 | 4 | 60 | 10 | 40,0 % | < 1 s au total | +3,64 | +0,03 |

Échantillons petits et variables : ces taux ne sont pas des garanties. Sur téléphone, compter plusieurs secondes à dizaines de secondes par tirage vérifié ; l’interface affiche l’essai en cours et s’arrête après 45 s en signalant les causes.

**Classement réel de difficulté.** La profondeur est imposée (12 par défaut) ; le gain est mesuré après le premier coup, l’écart au meilleur coup est mesuré à la même profondeur. L’intégration Scan ne fournit pas de multi-PV : le nombre exact de coups candidats à score proche et la profondeur minimale à laquelle la victoire apparaît ne peuvent pas être obtenus sans modifier le protocole du moteur. Ces deux valeurs ne sont donc pas revendiquées ; le niveau affiché reste celui du catalogue (1 à 4), pas une classification calculée.

**Ce que la vérification ne prouve pas :** l’unicité du coup au sens strict. Deux coups peuvent gagner avec un écart inférieur au seuil. Le niveau 3/4 est donc « difficulté mesurée par heuristique », pas une classification certifiée.

## 5 bis. Validateur de cohérence (ajout du 20 octobre 2026)

Un contrôle systématique précède désormais l'affichage d'une position de combinaison. Il ne modifie jamais la rafle du livre ; il refuse les positions générées qui ne tiennent pas debout.

| Règle | Mise en œuvre | Réglage |
|---|---|---|
| Ligne de promotion | Aucun pion blanc sur 1–5, aucun pion noir sur 46–50. | – |
| Maximum de pièces | 20 pièces par camp. | – |
| Écart de matériel | ≤ 3 pièces entre les camps. | 1 à 5 (défaut 3) |
| Avancée des leurres | Aucun pion blanc ajouté sur les rangées 1–2, aucun pion noir sur 9–10. | stricte / promotion seulement |
| Pion isolé | Un pion ajouté doit avoir un voisin de son camp à 2 cases ; les pièces de la rafle sont exemptées. | refuser / tolérer |
| Prise parasite | Au trait, la rafle de la solution doit être la seule prise possible. | – |

Conséquences dans le générateur : les pièces des niveaux 2 à 4 sont tirées **dans les zones autorisées et à portée d'une pièce amie**, avec 12 tentatives de placement. Sur 40 générations par niveau : **niveau 2 : 40/40, niveau 3 : 40/40, niveau 4 : 39/40** (le seul échec vient d'un modèle du livre dont un coup devient illégal après ajout de leurres — cause comptée, position rejetée). Ces règles ne font donc pas chuter le taux d'acceptation, contrairement aux anciens placements libres.

Contrôle documentaire de la base du livre (2880 entrées), non bloquant :

| Constat | Entrées |
|---|---:|
| Sans réserve | 2246 |
| Pion isolé (fréquent dans une combinaison) | 628 |
| Pion au-delà de la limite d'avancée | 15 |
| Prise concurrente au trait | 6 |
| Écart de matériel > 3 | 1 |
| Pion sur une ligne de promotion | 0 |

Au niveau 1, la position du livre est affichée telle quelle avec un bandeau d'avertissement si elle présente une réserve. Aux niveaux 2 à 4, une position qui viole une règle est rejetée avant affichage. Trace : `data/combinaisons/validation-coherence.json`.

**Notion de position jouable** (éditeur, combinaisons) : pas de pion sur une ligne de promotion, ≤ 20 pièces par camp, au moins une pièce par camp et au moins un coup légal pour le camp au trait. C'est ce contrôle qui autorise ou refuse le bouton « Jouer cette position contre Scan ».

## 6. Tests exécutés

- `npm test` complet (règles, position, PDN, moteur, WASM scalaire et SIMD, hors ligne, finales, étude/rétrograde) : **réussi**.
- `node scripts/test-combinaisons.mjs` — 2880 combinaisons rejouées, index vérifié, 120 positions de niveau 1, 160 positions générées contrôlées (niveaux 2–4), quatre routes demandées respectées, route impossible refusée.
- Navigateur, build `/Dt/` : niveaux 1 à 4 générés, un coup joué par l’interface, solution complète, aucun débordement mobile.
- Fichier autonome, `file://`, réseau bloqué : base embarquée reconnue, exercice de niveau 1 et niveau 2 vérifié par Scan, aucune requête externe.
- Repli sans fichier JSON : import manuel, persistance après rechargement, exercice de niveau 1.
- Contrôle visuel : 5 exercices de niveau 1 sur des départs différents, solutions non vides, rafle affichée, réglages mémorisés.

Traces : `perf/combinaisons/browser-niveaux.json`, `browser-offline.json`, `browser-import.json`, `perf/combinaisons-tests.json`, `perf/combinaisons/validation-summary.json`.

## 7. Limites et décisions honnêtes

- **Contenu du livre inclus** à la demande du propriétaire du projet : la source est citée ; vérifier les droits avant toute republication publique sur GitHub.
- **Extraction non parfaite** : 361 rejets sur 3241, dont 180 solutions partielles assumées. Aucune entrée rejetée n’est utilisée.
- **Reconnaissance des dames** : seulement 10 occurrences de dames noires dans tout le livre ; le quatrième glyphe est appris sur ces cas et vérifié par distance, mais une dame blanche n’apparaît pas comme pièce posée dans les diagrammes de ce recueil. Les positions avec dames restent rejouées et validées par les règles.
- **Pas de rotation/miroir** : une rafle demandée n’est servie que si une translation du modèle est possible.
- **Pas de preuve d’unicité** : vérification par écart de score, pas par comparaison exhaustive de tous les coups.
- **Niveaux 3 et 4** : acceptation plus faible ; l’application peut échouer après 45 s et l’annonce clairement. Le niveau 4 exige une solution d’au moins quatre demi-coups.
- **Pas de Scan sur téléphone physique** : les mesures viennent de Chromium sur Linux ; les temps Android seront plus longs.
- Les positions générées restent des **exercices de combinaison** ; elles ne constituent pas une base de parties ni une preuve de gain théorique.

## 8. Fichiers livrés

| Fichier | Rôle |
|---|---|
| `public/combinations-app.json` | base utilisée par l’application, 2880 entrées, 2,3 Mio ; précachée par le service worker |
| `Dames-autonome.html` | application hors ligne complète, base embarquée ; **15,3 Mio** : l’évaluation Scan, qui pèse 8,1 Mio de code, est stockée **compressée en gzip** et décompressée à l’ouverture par `DecompressionStream` (Chrome/Android) |
| `data/combinaisons/combinations-full.json` | base complète (4,9 Mio) : détails de rejeu, causes d’écart d’en-tête, rejets |
| `data/combinaisons/extraction-brute.json` | extraction brute (2,6 Mio) : diagrammes, textes, en-têtes, positions sur la page |
| `data/combinaisons/validation-summary.json` | bilan chiffré de la validation (repris dans les tableaux ci-dessus) |
| `data/combinaisons/generation-measure.json`, `scan-calibration.json` | mesures de génération et de calibrage Scan |
| `tome-1.pdf`, `tome-2.pdf` | **fournis à côté du ZIP**, pas dedans : à déposer dans `data/livres/` du dépôt (5,6 Mo chacun, acceptés séparément par GitHub) ; servent à rejouer l’extraction |
| `scripts/combinations/extract-book.py`, `validate-book.mjs` | chaîne d’extraction et de validation reproductible |

L’application charge la base depuis `combinations-app.json` (même origine), sinon depuis IndexedDB, sinon depuis la copie embarquée dans le HTML autonome. Si aucune source n’est disponible, l’écran d’import propose le fichier ; la base reste alors stockée localement et n’est jamais envoyée sur le réseau.

Le ZIP livré fait **18,1 Mio (19,0 Mo)** et 249 fichiers, donc sous la limite GitHub de 25 Mo. Il contient tout sauf les deux PDF ; `data/livres/` y est présent avec un `LIRE-MOI.txt` qui rappelle où déposer les tomes.

Pour régénérer la base depuis les PDF :

```sh
python scripts/combinations/extract-book.py data/livres/tome-1.pdf data/livres/tome-2.pdf --out data/combinaisons
node scripts/combinations/validate-book.mjs data/combinaisons/extraction-brute.json data/combinaisons/combinations-full.json data/combinaisons/validation-summary.json
node scripts/combinations/build-app-data.mjs
```
