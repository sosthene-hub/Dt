# Export annoté, diagrammes et solution pas à pas

20 octobre 2026. Cette livraison répond à la demande `AMELIORATION.txt` : export PDN annoté, version imprimable / PDF sans courbe, diagrammes SVG, réglages d'export, et solution de combinaison parcourue par boutons au lieu d'une liste de variantes.

## 1. Annotation de la partie

Fichier `src/analysis/annotate.js` (nouveau), branché sur le moteur Scan existant, **sans aucune modification de `src/engine.js` ni du WASM**.

- Une seule recherche Scan par position, à la profondeur choisie (9, 12, 16 ou 20 ; 12 par défaut) avec un plafond de 1,5 s par position.
- La valeur du coup joué se déduit de la position suivante : `valeur = −(score de la position d'après)`, puis `perte = score avant + score après`. Aucune seconde recherche : c'est la convention d'analyse exacte quand l'adversaire joue le meilleur coup.
- Symboles : `!` si le coup joué est le meilleur coup de Scan, `?` au-delà du seuil d'erreur, `??` au-delà du seuil de grosse erreur. Un coup égal au meilleur coup n'est jamais compté comme perte, même si la recherche enfant renvoie un écart résiduel.
- Variante conseillée : ligne principale du moteur rejouée coup par coup par le moteur de règles (`generateLegalMoves` + `moveMatchesEngine`), limitée à 6 demi-coups et arrêtée au premier coup non reconnu. Une variante affichée est donc toujours jouable.
- Posés terminales (camp sans coup légal) traitées sans planter : score −99, aucune variante.
- Arrêt possible à tout moment (bouton « Arrêter ») : l'export précédent reste intact.

Mesures sur `fixtures/Verpoest-Berte-1980.pdn` (131 demi-coups), Chromium, `file://` :

| Profondeur | Durée totale | Résultat |
|---|---|---|
| 9 | 1,7 s | 72 `!`, 9 `?`, 2 `??` |
| 12 (défaut) | 4,1 s | 83 `!`, 7 `?`, 2 `??` |
| 16 | 12,2 s | 84 `!`, 7 `?`, 3 `??` |

## 2. PDN annoté

`src/analysis/export.js` → `buildAnnotatedPdn`.

- En-tête : `Event`, `Site`, `Date`, `Round`, `White`, `Black`, `Result`, plus `Annotator`, `EvalPerspective "Blancs"`, `ErrorThreshold`, `BlunderThreshold`, `ExportDetail`. Les valeurs manquantes sont remplacées (jamais de `[White ""]`).
- Tous les coups sont écrits, en notation PDN de l'application (rafles complètes).
- Par coup annoté : symbole puis commentaire `{ −0,45, prof. 12 }`, évaluations vues des Blancs, virgule décimale, `−∞`/`+∞` pour les positions terminales.
- Pour chaque `?` ou `??` : la variante Scan entre parenthèses, numérotée (`( 48. 45-40 29-33 49. 28x39 … )`).
- Niveau de détail « erreurs seulement » (défaut) : seuls les coups fautifs portent un commentaire ; « toute la partie » annote chaque coup. Tous les coups restent écrits dans les deux cas.
- Le fichier se rouvre tel quel : le lecteur PDN ignore commentaires, symboles et variantes (vérifié : 131/131 demi-coups, mêmes coups, mêmes en-têtes).

## 3. Version imprimable / PDF

`openPrintSheet` (même module) construit une feuille A4 dans la page, sans dépendance externe.

- En-tête : titre, joueurs, tournoi, date, résultat, moteur et profondeur, seuils en clair.
- Liste des coups **sur deux colonnes** (Blancs / Noirs) avec le numéro du coup ; en mode « erreurs » seules les lignes concernées sont imprimées, les coups fautifs sont gras (`?`) ou gras souligné (`??`).
- Sous chaque erreur : mon coup, meilleur coup de Scan, évaluation avant, évaluation après, perte, variante conseillée.
- Diagrammes sous le coup concerné, avec la légende « Coup N · coup · aux X de jouer ».
- **Aucune courbe ni graphique** (exigence de la demande).
- `@media print` : `@page A4`, marge 12 mm, application masquée, barre d'outils masquée, feuille sans ombre ni fond. Le bouton « Imprimer / PDF » ouvre la boîte d'impression du navigateur, où l'on choisit « Enregistrer au format PDF ».
- PDF réel produit par Chromium à partir de cette feuille : **3 pages**, 206 Ko pour la partie annotée d'exemple (`perf/annotate/partie-annotee.pdf`).

## 4. Diagrammes SVG

`src/analysis/diagram.js` → `boardSvg`.

- Damier 10×10 en SVG pur, 1 000 × 1 000 unités, affiché à **52–55 mm** (5,5 cm) : net à l'impression et dans le PDF.
- Contraste noir et blanc : cases jouables gris moyen, cases claires blanches, pions blancs cerclés de noir, pions noirs pleins, dames marquées d'un anneau intérieur contrasté (lisible sans couleur).
- Options : **flèche du meilleur coup** (ligne à halo blanc, pointe noire, visible sur case sombre comme sur pièce), **numérotation des cases de 1 à 50** (chiffres à liseré blanc).
- Diagrammes toujours orientés Blancs en bas, comme la feuille imprimée.
- Bouton « Ajouter un diagramme à l'export » sur la position affichée, après avoir parcouru la partie ; le bouton devient « Retirer le diagramme du coup N » quand la position est déjà marquée.
- Case « Diagramme automatique après chaque `??` », en plus des diagrammes manuels.
- Un diagramme manuel s'imprime même si le coup n'est pas une erreur et que l'export est en mode « erreurs ».

## 5. Réglages d'export

- **Niveau de détail** : erreurs et grosses erreurs (défaut) / toute la partie.
- **Profondeur d'annotation** : 9, 12 (défaut), 16, 20.
- **Seuils ajustables** : `?` à 0,5 pion et `??` à 1,5 pion par défaut, champs numériques (0,1 à 5 et 0,1 à 9). Les deux seuils sont maintenus cohérents (le `??` ne peut pas passer sous le `?`).
- Cases à cocher : flèche du meilleur coup, numérotation 1–50, diagramme automatique sur `??`.
- Le panneau affiche en permanence le nombre de diagrammes joints (manuels + automatiques).

## 6. Combinaisons : solution pas à pas

La liste complète des demi-coups (jusqu'à 15 boutons) est remplacée par une ligne compacte : `⏮` (début), `◀` (demi-coup précédent), l'étape courante (`7/11 · 4. 34x23`, numérotée selon le camp au trait), `▶` (suivant) et `⏭` (fin). Les boutons sont gris lorsqu'ils ne peuvent pas agir. Avant révélation, la ligne reste masquée ; « Solution » révèle la position finale, puis `⏮` revient au départ et `▶` fait avancer d'un demi-coup. La notation complète reste disponible dans `data-solution` pour les tests et la copie. Hauteur mesurée de la ligne : 34 px au lieu de plusieurs rangées de boutons.

## 7. Vérifications exécutées

- `node scripts/test-export.mjs` : **8/8** — seuils par défaut et réglés, formatage des évaluations, numérotation des variantes depuis un coup blanc ou noir, neutralisation de la perte du meilleur coup, en-têtes, PDN annoté relisible et identique coup pour coup (131/131), mode « toute la partie ».
- `node scripts/browser-annotate.mjs` (production `/Dt/`, Chromium) : partie importée (131 demi-coups) → annotation réelle profondeur 9 → 11 commentaires et 11 variantes dans le PDN téléchargé → feuille imprimable (11 blocs d'erreur, 3 diagrammes, 150 numéros de cases, flèches présentes, diagramme de 208 px à l'écran et 52 mm à l'impression, application et barre d'outils masquées en média impression) → **PDN réimporté dans l'application : 131/131 demi-coups légaux** → PDF de 3 pages.
- Même test sur `Dames-autonome.html` en `file://`, réseau non utilisé : **réussi**. Contrôle hors ligne dédié `node scripts/browser-annotate-offline.mjs` : annotation réelle (1,7 s), 11 blocs d'erreur, 3 diagrammes (1 manuel + 2 automatiques), solution pas à pas de « 1/9 · 1. 34-29 » à « 9/9 · 5. 25x12 » puis retour « 8/9 », largeur de ligne 342 px, **0 requête externe, 0 erreur**.
- Contrôle mobile 412×915, `file://` : panneau d'export sans débordement (372 px), feuille 392 px, 3 diagrammes (1 manuel + 2 automatiques), 11 blocs d'erreur, aucune erreur JS.
- Non-régression : `npm test` (code 0), `browser-check`, `browser-study`, `browser-combinaisons`, `browser-combinaisons-import`, `browser-combinaisons-offline`, `browser-editor-game`, `browser-scan-disponible`, `browser-finales`, `browser-offline-finales` : **tous réussis**, 0 erreur JS.

Traces : `perf/annotate/rapport.json`, `perf/annotate/partie-annotee.pdn`, `perf/annotate/partie-annotee.pdf`, `perf/annotate/feuille-ecran.png`, `perf/annotate/feuille-impression.png`, `perf/annotate/mobile-feuille.png`, `perf/annotate/mobile-panneau-export.png`, `perf/combinaisons/page-solution-pas-a-pas.png`.

## 8. Limites annoncées

- La perte est calculée avec le score de la position suivante : elle suppose la meilleure réaction adverse. Un enchaînement de plusieurs erreurs peut donc être réparti différemment entre les coups, comme dans toute analyse automatique.
- La profondeur est un objectif ; un plafond de 1,5 s par position s'applique sur un appareil lent.
- Le rendu de la feuille dépend du navigateur : « Enregistrer au format PDF » depuis Chrome / Chromium donne le résultat mesuré ; les navigateurs mobiles peuvent réduire la marge.
- Les diagrammes sont toujours orientés Blancs en bas.
- Aucun export graphique, conformément à la demande.
