# Brancher PIONICIDE sur Lidraughts — compte `Iam_a_bot`

État vérifié à l'instant sur l'API publique de Lidraughts :

- le compte **`Iam_a_bot` existe** ;
- il porte le titre **BOT** ✔ (la bascule est donc déjà faite) ;
- **0 partie jouée** dans toutes les cadences — parfait pour démarrer ;
- profil : <https://lidraughts.org/@/Iam_a_bot>

Il ne reste que trois choses : un jeton, un fichier de configuration, un
lancement.

---

## Étape 1 — Installer Node.js (une seule fois)

Téléchargez la version **LTS** sur <https://nodejs.org> et installez-la en
laissant les options par défaut.

Vérification :

```bash
node --version
```

Il faut **v20 ou plus**. Rien d'autre à installer : le moteur, l'évaluation et
les tables de finales sont déjà dans le dossier `public/` de l'archive.

## Étape 2 — Extraire l'archive

Décompressez `dames-webapp-github-pages (1).zip` dans un dossier de travail,
par exemple `C:\PIONICIDE` (Windows) ou `~/PIONICIDE` (macOS/Linux).

> Ce dossier n'est pas destiné à GitHub Pages : le pont est du code Node, il
> tourne sur votre machine. GitHub Pages ne sert que des fichiers statiques.

Ouvrez un terminal **dans ce dossier** — celui qui contient `bridge/` :

```bash
cd C:\PIONICIDE          # Windows
cd ~/PIONICIDE           # macOS / Linux
ls bridge                # doit lister bot.mjs, engine.cjs, setup.mjs…
```

## Étape 3 — Créer le jeton d'accès

1. Connectez-vous en tant que **`Iam_a_bot`** sur <https://lidraughts.org>.
2. Ouvrez <https://lidraughts.org/account/oauth/token>.
3. Donnez un nom au jeton (par exemple « PIONICIDE local »), **cochez toutes les
   cases**, validez.
4. **Copiez le jeton tout de suite** : il ne sera plus jamais affiché.

## Étape 4 — L'assistant de branchement

```bash
node bridge/setup.mjs
```

Collez le jeton quand il le demande. Le script :

- vérifie le jeton auprès de Lidraughts ;
- contrôle le titre BOT ;
- écrit `bridge/config.json` (fichier local, jamais à publier).

Attendu :

```
✓ Jeton valide — compte « Iam_a_bot »
✓ Titre BOT confirmé : l'API Bot acceptera les coups.
✓ Configuration écrite dans bridge/config.json
```

En cas de `401`, c'est que le jeton est incomplet ou révoqué : regénérez-en un.

## Étape 5 — Contrôle final

```bash
node bridge/bot.mjs --check
```

Doit afficher le nom du compte et le titre BOT.

## Étape 6 — Premier vrai essai, en privé

Dans un terminal :

```bash
node bridge/bot.mjs --allow Sosthene
```

Puis, depuis votre compte **`Sosthene`** (autre navigateur), défiez
`Iam_a_bot` en **amicale 5 min + 2 s**.

Le bot doit accepter en quelques secondes et jouer. C'est le test décisif : s'il
passe, tout le reste n'est que répétition.

> Le moteur démarre en ~0,7 s et reste chaud ensuite. Le terminal doit rester
> ouvert pendant toute la partie : le fermer = abandon.

## Étape 7 — Ouvrir au public (quand vous voulez)

```bash
node bridge/bot.mjs
```

Le bot accepte alors tous les défis conformes à `bridge/config.json` (jeu de
dames standard, cadences de 1 à 30 minutes). Conseils :

- inscrivez `Iam_a_bot` dans l'équipe <https://lidraughts.org/team/lidraughtsbots>
  pour que les joueurs le trouvent ;
- remplissez sa page de profil avec les cadences acceptées (comme le font les
  autres bots) ;
- laissez-le tourner le plus longtemps possible : les parties classées sont ce
  qui construit une note officielle.

## Ce qui se passe ensuite

- Chaque partie jouée est archivée : `bridge/games/<id>.pdn` + une ligne dans
  `bridge/games/session.jsonl`.
- Ces fichiers s'importent directement dans l'onglet « importer » de
  l'application, pour analyse.
- Suivi en direct : <https://lidraughts.org/tv/bot>.

## En cas de problème

| Symptôme | Cause | Solution |
| --- | --- | --- |
| `Aucun jeton trouvé` | `config.json` absent | relancer `node bridge/setup.mjs` |
| `401` sur les coups | jeton sans droit `bot:play` | recréer le jeton en cochant **toutes** les cases |
| `403` | compte sans titre BOT | normalement réglé pour `Iam_a_bot` |
| le bot ne répond à aucun défi | `--allow` actif avec un autre nom | relancer sans `--allow` ou avec le bon pseudo |
| `429` | trop de requêtes | attendre une minute, ne pas relancer en boucle |
| le bot perd au temps en 1+0 | WebAssembly plus lent que le natif | jouer 5+2 ou plus long |
