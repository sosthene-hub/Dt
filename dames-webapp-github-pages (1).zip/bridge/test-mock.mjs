/* PONT LIDRAUGHTS — essai de bout en bout sans Lidraughts.
   Ce script monte un faux serveur qui imite les endpoints de l'API Bot
   (compte, flux d'événements, défi, flux de partie, envoi de coup), lance le
   bot contre lui, puis vérifie que le coup envoyé est légal d'après le noyau
   de PIONICIDE. Aucun jeton, aucun réseau. */
import http from 'node:http';
import { spawn } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import * as Core from '../src/base/core.js';
import { replayMoves, resolveGameMove, moveToPdn } from './positions.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const received = { accepted: [], declined: [], moves: [], chats: [], exported: 0 };
const GAME_ID = 'essai01';

const server = http.createServer((request, response) => {
  const url = new URL(request.url, 'http://127.0.0.1');
  const json = (payload, status = 200) => {
    response.writeHead(status, { 'content-type': 'application/json' });
    response.end(JSON.stringify(payload));
  };
  const ndjson = () => { response.writeHead(200, { 'content-type': 'application/x-ndjson' }); };

  if (url.pathname === '/api/account') {
    return json({ id: 'pionicide', username: 'PIONICIDE', title: 'BOT', perfs: { blitz: { rating: 1500 } } });
  }

  if (url.pathname === '/api/stream/event') {
    ndjson();
    const send = payload => response.write(JSON.stringify(payload) + '\n');
    // 1) un inconnu : doit être décliné par la liste d'invités
    send({
      type: 'challenge',
      challenge: {
        id: 'defi00',
        rated: false,
        variant: { key: 'standard' },
        speed: 'blitz',
        timeControl: { limit: 300, increment: 2 },
        challenger: { name: 'Inconnu' },
      },
    });
    // 2) l'invité : doit être accepté
    send({
      type: 'challenge',
      challenge: {
        id: 'defi01',
        rated: false,
        variant: { key: 'standard' },
        speed: 'blitz',
        timeControl: { limit: 300, increment: 2 },
        challenger: { name: 'Sosthene' },
      },
    });
    setTimeout(() => send({ type: 'gameStart', game: { id: GAME_ID, variant: { key: 'standard' } } }), 600);
    return; // flux laissé ouvert, comme le vrai serveur
  }

  if (/^\/api\/challenge\/[^/]+\/accept$/.test(url.pathname)) {
    received.accepted.push(url.pathname.split('/')[3]);
    return json({ ok: true });
  }
  if (/^\/api\/challenge\/[^/]+\/decline$/.test(url.pathname)) {
    received.declined.push(url.pathname.split('/')[3]);
    return json({ ok: true });
  }

  if (url.pathname === `/api/bot/game/stream/${GAME_ID}`) {
    ndjson();
    let posted = 0;
    const state = () => ({
      type: 'gameState',
      moves: received.moves.join(' '),
      status: 'started',
      wtime: 298000,
      btime: 298000,
      winc: 2000,
      binc: 2000,
    });
    response.write(JSON.stringify({
      type: 'gameFull',
      id: GAME_ID,
      variant: { key: 'standard' },
      clock: { initial: 300000, increment: 2000 },
      white: { name: 'PIONICIDE', title: 'BOT' },
      black: { name: 'Sosthene' },
      state: state(),
    }) + '\n');
    // Une fois le coup reçu, on renvoie l'état et on ferme le flux.
    const watch = setInterval(() => {
      if (received.moves.length === posted) return;
      posted = received.moves.length;
      response.write(JSON.stringify(state()) + '\n');
      if (posted >= 1) {
        clearInterval(watch);
        // fin de partie simulée, comme un abandon de l'adversaire
        setTimeout(() => {
          response.write(JSON.stringify({ ...state(), status: 'resign', winner: 'white' }) + '\n');
          setTimeout(() => response.end(), 300);
        }, 300);
      }
    }, 100);
    request.on('close', () => clearInterval(watch));
    return;
  }

  const moveMatch = /^\/api\/bot\/game\/([^/]+)\/move\/(\d+)$/.exec(url.pathname);
  if (moveMatch) {
    const part = moveMatch[2];
    // Le serveur simulé applique le coup comme le ferait Lidraughts : légalité FMJD.
    try {
      const tokens = [...received.moves, part];
      replayMoves(tokens);
      received.moves.push(part);
      return json({ ok: true });
    } catch (error) {
      console.error('  serveur simulé : coup refusé —', error.message);
      response.writeHead(400, { 'content-type': 'application/json' });
      return response.end(JSON.stringify({ error: error.message }));
    }
  }

  if (url.pathname === `/game/export/${GAME_ID}`) {
    received.exported++;
    response.writeHead(200, { 'content-type': 'application/x-draughts-pdn' });
    return response.end('[Event "essai"]\n[White "PIONICIDE"]\n[Black "Sosthene"]\n[Result "0-1"]\n\n1. 32-28 19-23 2. 28x19 14x23\n');
  }

  const chatMatch = /^\/api\/bot\/game\/([^/]+)\/chat$/.exec(url.pathname);
  if (chatMatch && request.method === 'POST') {
    let body = '';
    request.on('data', chunk => { body += chunk; });
    request.on('end', () => {
      received.chats.push(new URLSearchParams(body).get('text'));
      json({ ok: true });
    });
    return;
  }

  response.writeHead(404, { 'content-type': 'application/json' });
  response.end(JSON.stringify({ error: 'endpoint non simulé : ' + url.pathname }));
});

await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const port = server.address().port;
console.log(`serveur simulé sur 127.0.0.1:${port}`);

const gamesDir = path.join(ROOT, 'bridge', 'games-essai');
fs.rmSync(gamesDir, { recursive: true, force: true });
const child = spawn(process.execPath, [
  path.join(ROOT, 'bridge', 'bot.mjs'),
  '--base', `http://127.0.0.1:${port}`,
  '--allow', 'Sosthene',
  '--games-dir', gamesDir,
], {
  cwd: ROOT,
  env: { ...process.env, LIDRAUGHTS_BOT_TOKEN: 'jeton-de-test' },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let output = '';
child.stdout.on('data', chunk => { output += chunk; process.stdout.write('  bot › ' + chunk); });
child.stderr.on('data', chunk => { output += chunk; process.stdout.write('  bot ! ' + chunk); });

const deadline = Date.now() + 90000;
while (Date.now() < deadline && received.moves.length === 0) {
  await new Promise(resolve => setTimeout(resolve, 250));
}
// on laisse le temps de l'archivage
await new Promise(resolve => setTimeout(resolve, 2500));
child.kill('SIGKILL');
server.close();

const failures = [];
if (!received.accepted.includes('defi01')) failures.push('défi de l’invité non accepté');
if (!received.declined.includes('defi00')) failures.push('défi d’un inconnu non décliné');
if (received.declined.includes('defi01')) failures.push('défi de l’invité refusé à tort');
if (received.moves.length !== 1) failures.push(`${received.moves.length} coup(s) envoyé(s) au lieu d’un`);
if (received.moves.length === 1) {
  const { moves } = { moves: received.moves };
  const position = replayMoves([]).position;
  const move = resolveGameMove(position, moves[0]);
  console.log(`coup reçu : ${moves[0]} → ${moveToPdn(move)} (rejoué sans erreur par les règles FMJD)`);
  const legal = Core.generateMoves(position).map(candidate => Core.moveToPdn(candidate));
  if (!legal.includes(moveToPdn(move))) failures.push('coup illégal');
}
if (!received.chats.length) failures.push('message de présentation absent');
const archive = path.join(gamesDir, `${GAME_ID}.pdn`);
if (!fs.existsSync(archive)) failures.push('partie non archivée en PDN');
else if (!/\[White "PIONICIDE"\]/.test(fs.readFileSync(archive, 'utf8'))) failures.push('PDN archivé illisible');
if (!fs.existsSync(path.join(gamesDir, 'session.jsonl'))) failures.push('journal de session absent');

if (failures.length) {
  console.error('\nÉCHEC — ' + failures.join(' ; '));
  console.error(output.split('\n').slice(-25).join('\n'));
  process.exit(1);
}
console.log('OK — défi accepté, partie suivie, coup légal envoyé, présentation postée : le pont fonctionne de bout en bout.');
process.exit(0);
