# Faire jouer un ami contre PIONICIDE — mode « session privée »

Objectif : ton ami (ou toi sur `Sosthene`) joue contre PIONICIDE, maintenant,
sans que d'autres joueurs s'invitent.

## Décision à prendre : qui possède le compte PIONICIDE ?

| Option | Qui joue contre PIONICIDE | Inconvénients |
| --- | --- | --- |
| **A. Compte séparé `PIONICIDE`** (recommandé) | ton ami, avec son propre compte | il faut créer le compte (5 min) |
| **B. Transformer `Sosthene` en bot** | ton ami, avec son compte | **tu ne peux plus jamais jouer à la main sur `Sosthene`** : la bascule BOT est irréversible et `Sosthene` a déjà joué, donc Lidraughts la refusera de toute façon |

L'option B est techniquement impossible : Lidraughts n'accepte la bascule que
pour un compte **qui n'a jamais joué une seule partie**. Donc : **option A**.

## Ce qu'il faut faire, dans l'ordre

### 1. Créer le compte bot (une fois)
Voir `DEMARRAGE-COMPTE-BOT.md`. Résumé : `/signup`, confirmer l'e-mail,
**ne jouer aucune partie**, créer un jeton sur `/account/oauth/token`,
puis `POST /api/bot/account/upgrade`.

### 2. Lancer le bot en session privée

```bash
node bridge/bot.mjs --allow Sosthene,MonAmi
```

- `--allow` limite les défis à ces pseudos : n'importe qui d'autre reçoit un
  refus automatique et poli.
- Sans `--allow`, le bot accepte tous les défis conformes à `config.json`
  (session publique).
- `--max-games` dans `config.json` (défaut 2) limite les parties simultanées ;
  au-delà, les défis sont refusés car le moteur ne calcule qu'une position à la fois.

### 3. Ton ami lance le défi

Depuis son compte : page du profil PIONICIDE → « Défier », ou directement
<https://lidraughts.org/?user=PIONICIDE#challenge>.

Cadence conseillée pour une première rencontre : **5 min + 2 s**.
Le bot accepte en quelques secondes, puis joue.

> Sur Lidraughts, un bot **peut** jouer une partie classée contre un humain
> (vérifié : les bots du site en jouent tous les jours). Pour une rencontre
> amicale entre amis, préférez toutefois « amicale » : cela évite de faire
> bouger la note d'un compte humain contre une machine. Pour mesurer PIONICIDE,
> c'est l'inverse : les classées sont exactement ce qu'il faut.

### 4. Suivre la partie

- La partie est visible à <https://lidraughts.org/tv/bot> si elle est publique.
- Dans le terminal, le bot affiche chaque coup joué, sa profondeur et son score.
- À la fin, la partie est **archivée automatiquement** dans `bridge/games/` :
  un fichier `<id>.pdn` (lisible par ton application PIONICIDE) et une ligne
  dans `session.jsonl`.

## Réutiliser les parties dans l'application

Les fichiers PDN de `bridge/games/` s'importent tels quels dans l'onglet
« importer » de PIONICIDE : ils servent ensuite de base d'analyse, et de
matière première pour mesurer le niveau réel du moteur.

## Rappels

- Le jeton reste dans `bridge/config.json` (déjà exclu du partage par
  `bridge/.gitignore`) : ne le collez jamais dans un message.
- Le bot doit tourner pendant toute la partie : fermer le terminal = abandon.
- Une coupure réseau est gérée (reconnexion automatique du flux d'événements),
  mais une partie en cours au moment de l'arrêt est perdue pour le bot.
