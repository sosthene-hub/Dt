/* PONT LIDRAUGHTS — contrôle de fair-play.
   Analyse des parties réelles avec le moteur de PIONICIDE pour repérer une
   assistance logicielle probable. Ce script ne prouve rien : il produit des
   chiffres objectifs à joindre à un signalement.

   Usage :
     node bridge/fairplay.mjs --user Pseudo --max 5
     node bridge/fairplay.mjs --user Pseudo --vs Sosthene --max 5
     node bridge/fairplay.mjs --url https://lidraughts.org/XXXXXXXX
   Options : --depth 12 (profondeur d'analyse) --ms 300 (temps par coup)
             --detail (table coup par coup)

   Indicateurs, calculés camp par camp :
     - accord   : part des coups joués qui sont exactement le meilleur coup du moteur ;
     - perte    : écart d'évaluation entre le meilleur coup et le coup joué,
                  en unités Scan (0 = coup parfait) ;
     - temps    : médiane et irrégularité du temps de réflexion, d'après les
                  horloges inclues dans l'export PDN ; part de coups joués en
                  moins d'une seconde ; temps passé sur des coups forcés.
   Un moteur branché en direct donne en général un accord très élevé, une perte
   quasi nulle et un temps de réflexion qui ne suit pas la difficulté. */
import { createRequire } from 'node:module';
import * as Core from '../src/base/core.js';
import { posCommand, matchEngineMove, moveToPdn } from './positions.mjs';

const require = createRequire(import.meta.url);
const { createPionicideEngine } = require('./engine.cjs');

const BASE = 'https://lidraughts.org';
const args = process.argv.slice(2);
const value = flag => {
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : null;
};
const USER = value('--user');
const VS = value('--vs');
const MAX = Number(value('--max')) || 3;
const URL_ARG = value('--url');
const DEPTH = Number(value('--depth')) || 12;
const MS = Number(value('--ms')) || 300;
const DETAIL = args.includes('--detail');

/* ------------------------------- récupération ------------------------------- */

async function fetchPdn() {
  const headers = { Accept: 'application/x-draughts-pdn' };
  if (URL_ARG) {
    const gameId = URL_ARG.replace(/^.*lidraughts\.org\/([A-Za-z0-9]{8}).*$/, '$1');
    const response = await fetch(`${BASE}/game/export/${gameId}?clocks=true&moves=true&tags=true`, { headers });
    if (!response.ok) throw new Error(`export impossible (${response.status})`);
    return response.text();
  }
  if (!USER) throw new Error('indiquez --user Pseudo ou --url <partie>');
  const params = new URLSearchParams({ max: String(MAX), clocks: 'true', moves: 'true', tags: 'true' });
  if (VS) params.set('vs', VS);
  const response = await fetch(`${BASE}/api/games/user/${encodeURIComponent(USER)}?${params}`, { headers });
  if (!response.ok) throw new Error(`export impossible (${response.status}) — trop de requêtes ? réessayez plus tard`);
  return response.text();
}

const tag = (block, name) => (new RegExp(`\\[${name} "([^"]*)"\\]`).exec(block) || [])[1] || null;

/** Découpe un PDN en parties : coups + horloge restante après chaque coup. */
function parseGames(text) {
  const games = [];
  for (const block of text.split(/\n\s*\n\s*\n/)) {
    const line = block.split('\n').find(candidate => /^\s*1\./.test(candidate));
    if (!line) continue;
    const moves = [];
    const clocks = [];
    const pattern = /(\d{1,2}(?:[-x]\d{1,2})+)(?:\s*\{?\[%clock ([^\]]*)\]\}?)?/g;
    for (const match of line.matchAll(pattern)) {
      const numbers = match[1].split(/[-x]/).map(Number);
      if (numbers.some(number => number < 1 || number > 50)) continue; // résultat (2-0…)
      moves.push(match[1]);
      clocks.push(match[2] || null);
    }
    games.push({
      id: (tag(block, 'Site') || '').split('/').pop(),
      white: tag(block, 'White'),
      black: tag(block, 'Black'),
      result: tag(block, 'Result'),
      timeControl: tag(block, 'TimeControl'),
      moves,
      clocks,
    });
  }
  return games;
}

/** Temps restant du camp demandé, dans une annotation « w0:03:00 B0:03:00 ». */
function clockOf(annotation, side) {
  if (!annotation) return null;
  const found = (side === 'w' ? /w(\d+):(\d+):(\d+)/ : /[bB](\d+):(\d+):(\d+)/).exec(annotation);
  if (!found) return null;
  return Number(found[1]) * 3600 + Number(found[2]) * 60 + Number(found[3]);
}

function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)];
}

/* --------------------------------- analyse --------------------------------- */

const engine = createPionicideEngine({ hashMiB: 64 });

async function analyseGame(game, target) {
  const side = game.white?.toLowerCase() === target.toLowerCase() ? 'w' : 'b';
  const limit = Number((/^(\d+)/.exec(game.timeControl || '') || [])[1] || 0);
  const increment = Number((/\+(\d+)/.exec(game.timeControl || '') || [])[1] || 0);
  let position = Core.Position.initial();
  const rows = [];
  let previousRest = null;

  for (let ply = 0; ply < game.moves.length; ply++) {
    const mover = ply % 2 === 0 ? 'w' : 'b';
    let move = null;
    try { move = Core.resolveMove(position, game.moves[ply]).move; } catch { break; }
    if (!move) break;

    const legalCount = Core.generateMoves(position).length;
    const rest = clockOf(game.clocks[ply], mover);
    let spent = null;
    if (rest != null && mover === side) {
      const before = previousRest == null ? limit + increment : previousRest + increment;
      spent = Math.max(0, before - rest);
      previousRest = rest;
    }

    let best = null;
    let loss = null;
    if (mover === side) {
      const top = await engine.search({ position: posCommand(position), depth: DEPTH, moveTimeMs: MS });
      if (top.move) {
        best = matchEngineMove(position, top.move);
        const after = Core.applyMove(position, move);
        const reply = await engine.search({ position: posCommand(after), depth: DEPTH, moveTimeMs: MS });
        if (Number.isFinite(top.score) && Number.isFinite(reply.score) && Math.abs(top.score) < 50) {
          loss = Math.max(0, top.score + reply.score); // score adverse => signe inversé
        }
      }
    }

    rows.push({ ply, mover, played: moveToPdn(move), best: best ? moveToPdn(best) : null, loss, legalCount, spent });
    position = Core.applyMove(position, move);
  }
  return { side, rows };
}

function report(target, side, rows) {
  const mine = rows.filter(row => row.mover === side && row.best);
  if (!mine.length) return;
  const agreement = mine.filter(row => row.played === row.best).length / mine.length;
  const losses = mine.map(row => row.loss).filter(value_ => value_ != null);
  const times = rows.filter(row => row.mover === side && row.spent != null).map(row => row.spent);
  const forced = rows.filter(row => row.mover === side && row.legalCount === 1 && row.spent != null);
  const meanLoss = losses.length ? losses.reduce((sum, value_) => sum + value_, 0) / losses.length : null;
  const fast = times.filter(time => time <= 1).length / (times.length || 1);
  const spread = times.length > 2 ? Math.max(...times) - Math.min(...times) : 0;

  console.log(`  ${target} (${side === 'w' ? 'Blancs' : 'Noirs'})`);
  console.log(`    coups analysés ................ ${mine.length}`);
  console.log(`    accord avec le meilleur coup .. ${(agreement * 100).toFixed(0)} %`);
  if (meanLoss != null) console.log(`    perte moyenne ................. ${meanLoss.toFixed(3)} (unités Scan)`);
  console.log(`    temps médian par coup ......... ${median(times).toFixed(1)} s (amplitude ${spread.toFixed(0)} s)`);
  console.log(`    coups joués en ≤ 1 s .......... ${(fast * 100).toFixed(0)} %`);
  if (forced.length) console.log(`    coups forcés .................. ${forced.length}, temps médian ${median(forced.map(row => row.spent)).toFixed(1)} s`);

  const flags = [];
  if (mine.length >= 20 && agreement >= 0.9) flags.push('accord très élevé');
  if (mine.length >= 20 && meanLoss != null && meanLoss < 0.05) flags.push('perte quasi nulle');
  if (mine.length >= 20 && fast >= 0.6 && median(times) < 3) flags.push('coups rapides et réguliers');
  if (forced.length >= 3 && median(forced.map(row => row.spent)) > 8) flags.push('temps important sur des coups forcés');
  console.log(`    signaux ....................... ${flags.length ? flags.join(' ; ') : 'aucun signal marqué'}`);

  if (DETAIL) {
    for (const row of rows.filter(candidate => candidate.mover === side)) {
      console.log(`      ${String(row.ply + 1).padStart(2)} ${row.played.padEnd(10)} ${row.played === row.best ? '=' : '≠'} ${String(row.best || '').padEnd(10)}${row.legalCount === 1 ? 'forcé' : '     '} ${row.spent != null ? row.spent.toFixed(0) + ' s' : ''}`);
    }
  }
}

async function main() {
  const text = await fetchPdn();
  const games = parseGames(text).slice(0, URL_ARG ? 1 : MAX);
  if (!games.length) { console.log('aucune partie trouvée.'); return; }
  await engine.start();
  for (const game of games) {
    console.log(`\n=== ${game.white} – ${game.black} · ${game.timeControl || '?'} · ${game.result} · ${game.id}`);
    const targets = USER && [game.white, game.black].some(name => name?.toLowerCase() === USER.toLowerCase())
      ? [game.white?.toLowerCase() === USER.toLowerCase() ? game.white : game.black]
      : [game.white, game.black];
    for (const target of targets) {
      if (!target) continue;
      const { side, rows } = await analyseGame(game, target);
      report(target, side, rows);
    }
  }
  engine.stop();
  console.log('\nRappel : ces chiffres ne prouvent rien. Un joueur très fort peut avoir un accord élevé,');
  console.log('un tricheur prudent peut rester dans les normes. Un signalement se fait par le bouton');
  console.log('« Signaler » de Lidraughts, avec ces relevés — jamais par une accusation publique.');
}

main().catch(error => { console.error(error.message); process.exit(1); });
