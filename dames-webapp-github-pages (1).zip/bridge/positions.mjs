/* PONT LIDRAUGHTS — positions et coups.
   Conversions entre la notation de Lidraughts (suites de cases : « 3429 »,
   « 233228 ») et les coups du noyau de PIONICIDE (src/base/core.js).
   Aucun générateur de coups réinventé : la légalité est vérifiée par le noyau.

   Format de position du moteur (protocole Hub de Scan, vérifié sur le binaire
   de public/scan-wasm-scalar.js) : une lettre de trait puis les 50 cases dans
   l'ordre standard, une lettre par case — w = pion blanc, b = pion noir,
   W = dame blanche, B = dame noire, e = case vide. C'est exactement la forme
   produite par boardToHub() dans src/game-rules.js, donc on réutilise la
   représentation du noyau sans conversion de numérotation.
   Exemple au départ : « W » + « b »×20 + « e »×10 + « w »×20. */
import * as Core from '../src/base/core.js';

/** Position de départ. */
export function initialPosition() {
  return Core.Position.initial();
}

/** « 3429 » ou « 233228 » → liste de cases [34, 29] / [23, 32, 28]. */
export function squaresOf(token) {
  const digits = String(token).replace(/[^0-9]/g, '');
  if (digits.length < 4 || digits.length % 2 !== 0) {
    throw new Error(`coup Lidraughts illisible : « ${token} »`);
  }
  const squares = [];
  for (let i = 0; i < digits.length; i += 2) squares.push(Number(digits.slice(i, i + 2)));
  return squares;
}

/**
 * Retrouve un coup légal à partir d'un coup Lidraughts.
 * Accepte aussi la notation PDN (« 34-29 », « 23x32x28 ») pour les tests.
 */
export function resolveGameMove(position, token) {
  if (/[x-]/.test(String(token))) {
    const result = Core.resolveMove(position, token);
    if (!result.move) throw new Error(`coup refusé (${token}) : ${result.reason}`);
    return result.move;
  }
  const squares = squaresOf(token);
  const from = squares[0];
  const to = squares[squares.length - 1];
  const legal = Core.generateMoves(position).filter(move => move.from === from && move.to === to);
  if (!legal.length) throw new Error(`coup illégal d’après les règles FMJD : ${token}`);
  if (legal.length === 1) return legal[0];
  // Plusieurs prises entre les mêmes cases : on compare les cases traversées.
  const wanted = squares.slice(1);
  const exact = legal.find(move => move.path.length === wanted.length
    && move.path.every((square, index) => square === wanted[index]));
  return exact || legal[0];
}

/** Rejoue une suite de coups Lidraughts : position finale + coups du noyau. */
export function replayMoves(tokens = []) {
  let position = initialPosition();
  const moves = [];
  for (const token of tokens) {
    const move = resolveGameMove(position, token);
    moves.push(move);
    position = Core.applyMove(position, move);
  }
  return { position, moves };
}

/** Rejoue une suite de coups Lidraughts et rend la position. */
export function positionAfterMoves(tokens = []) {
  return replayMoves(tokens).position;
}

/** Coup du noyau → notation Hub du moteur : « 34-29 » ou « 27x38x47 ». */
export function moveToHub(move) {
  const path = move.path && move.path.length ? move.path : [move.to];
  const separator = move.caps && move.caps.length ? 'x' : '-';
  return [move.from, ...path].join(separator);
}

/**
 * Position → valeur de la commande « pos » du moteur.
 * Le moteur attend « pos pos=<chaîne de 51 caractères> ». La lettre de tête est
 * celle du camp au trait : elle doit donc refléter l'état du noyau, sinon Scan
 * cherche pour le mauvais camp.
 */
export function enginePosition(position) {
  const side = position.side === Core.BLACK ? 'B' : 'W';
  const letter = { [Core.WMAN]: 'w', [Core.WKING]: 'W', [Core.BMAN]: 'b', [Core.BKING]: 'B' };
  let squares = '';
  for (let square = 1; square <= 50; square++) squares += letter[position.pieceAt(square)] || 'e';
  return side + squares;
}

/** Commande complète prête à envoyer au moteur. */
export function posCommand(position) {
  return `pos pos=${enginePosition(position)}`;
}

/**
 * Coup du moteur → coup du noyau, ou null s'il est illégal.
 * Scan abrège les rafles non ambiguës (« 26x17 » plutôt que « 26x17x21 »),
 * donc on identifie d'abord par départ et arrivée, puis par les prises citées.
 */
export function matchEngineMove(position, notation) {
  if (!notation) return null;
  const numbers = String(notation).split(/[x-]/).map(Number).filter(value => Number.isFinite(value));
  if (numbers.length < 2) return null;
  const [from, to, ...caps] = numbers;
  const candidates = Core.generateMoves(position).filter(move => move.from === from && move.to === to);
  if (!candidates.length) return null;
  if (candidates.length === 1) return candidates[0];
  const exact = candidates.find(move => caps.every(square => move.caps.includes(square)));
  return exact || candidates[0];
}

/**
 * Coup du noyau → morceaux pour l'API Lidraughts.
 * L'API attend des paires de cases, un envoi par segment de rafle
 * (comportement du client de référence lidraughts-bot).
 */
export function moveToApiParts(move) {
  const steps = [move.from, ...(move.path && move.path.length ? move.path : [move.to])];
  const parts = [];
  for (let index = 0; index + 1 < steps.length; index++) {
    parts.push(String(steps[index]).padStart(2, '0') + String(steps[index + 1]).padStart(2, '0'));
  }
  return parts;
}

/** Forme compacte en un seul envoi : « 3429 », « 233228 ». */
export function moveToApiSingle(move) {
  return [move.from, ...(move.path && move.path.length ? move.path : [move.to])]
    .map(square => String(square).padStart(2, '0')).join('');
}

/** Notation PDN lisible (« 23x32x28 ») pour les journaux. */
export function moveToPdn(move) {
  return Core.moveToPdn(move);
}

/** Nombre de pièces restantes, pour décider de pousser la profondeur en finale. */
export function material(position) {
  return position.count();
}
