#!/usr/bin/env node
/* PONT LIDRAUGHTS — PIONICIDE joue sur lidraughts.org.
   Modes :
     node bridge/bot.mjs                      → connexion réelle (jeton requis)
     node bridge/bot.mjs --selftest 12        → PIONICIDE contre lui-même, 12 demi-coups
     node bridge/bot.mjs --check              → vérifie le jeton et le statut BOT
     node bridge/bot.mjs --base http://127.0.0.1:PORT --dry   → essai contre un serveur simulé
   Le bot ne joue que les variantes et les cadences autorisées dans bridge/config.json. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { LidraughtsClient } from './lidraughts.mjs';
import {
  initialPosition, replayMoves, posCommand, matchEngineMove,
  moveToApiParts, moveToPdn, material,
} from './positions.mjs';

const require = createRequire(import.meta.url);
const { createPionicideEngine } = require('./engine.cjs');
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const DEFAULTS = {
  base: 'https://lidraughts.org',
  accept: {
    rated: true,
    variants: ['standard'],
    minLimit: 60,
    maxLimit: 1800,
    minIncrement: 0,
    maxIncrement: 60,
  },
  engine: {
    hashMiB: 64,
    depth: 20,
    minMoveMs: 300,
    maxMoveMs: 12000,
    clockShare: 40,     // on donne au moteur 1/40 du temps restant…
    incrementShare: 0.8, // … plus une part du gain par coup
    criticalPieces: 16,  // en dessous, on pousse la profondeur (finales)
  },
  maxGames: 2,
  gamesDir: 'bridge/games',
  announce: 'PIONICIDE — moteur Scan 3.1b (WASM), joue ici par l’API Bot de Lidraughts.',
};

function stamp() {
  return new Date().toISOString().slice(11, 19);
}
function log(message) {
  console.log(`[${stamp()}] ${message}`);
}

function loadConfig() {
  const file = path.join(ROOT, 'bridge', 'config.json');
  let config = {};
  if (fs.existsSync(file)) {
    try { config = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (error) { throw new Error(`bridge/config.json illisible : ${error.message}`); }
  }
  const merged = {
    ...DEFAULTS,
    ...config,
    accept: { ...DEFAULTS.accept, ...(config.accept || {}) },
    engine: { ...DEFAULTS.engine, ...(config.engine || {}) },
  };
  merged.token = process.env.LIDRAUGHTS_BOT_TOKEN || config.token || '';
  if (process.env.LIDRAUGHTS_BASE) merged.base = process.env.LIDRAUGHTS_BASE;
  return merged;
}

function challengeAllowed(challenge, accept, challenger = '') {
  const variant = challenge.variant?.key || challenge.variant || 'standard';
  const allow = (accept.allow || []).map(name => name.toLowerCase());
  if (allow.length && !allow.includes(String(challenger).toLowerCase())) {
    return `« ${challenger} » n’est pas sur la liste des invités`;
  }
  if (!accept.variants.includes(variant)) return `variante ${variant} non prise en charge`;
  if (challenge.rated && !accept.rated) return 'partie classée refusée par la configuration';
  const limit = Number(challenge.timeControl?.limit ?? challenge.speed === 'correspondence' ? NaN : challenge.timeControl?.limit);
  const increment = Number(challenge.timeControl?.increment ?? 0);
  if (challenge.speed === 'correspondence') return 'parties par correspondance non prises en charge';
  if (Number.isFinite(limit) && (limit < accept.minLimit || limit > accept.maxLimit)) {
    return `cadence ${limit}s hors limites (${accept.minLimit}–${accept.maxLimit})`;
  }
  if (increment < accept.minIncrement || increment > accept.maxIncrement) {
    return `incrément ${increment}s hors limites`;
  }
  if (!/^standard$/.test(variant) && variant !== 'standard') return `variante ${variant} non prise en charge`;
  return null;
}

/** Budget de temps pour un coup, à partir de l'horloge restante. */
function thinkBudget(state, engine, ourClock, incrementMs) {
  const remaining = Number.isFinite(ourClock) && ourClock > 0 ? ourClock : 60000;
  const base = remaining / engine.clockShare + incrementMs * engine.incrementShare;
  const safe = Math.max(engine.minMoveMs, Math.min(engine.maxMoveMs, Math.floor(base)));
  // Ne jamais consommer plus de la moitié de ce qui reste.
  return Math.max(engine.minMoveMs, Math.min(safe, Math.floor(remaining * 0.5)));
}

class Bot {
  constructor(config) {
    this.config = config;
    this.client = new LidraughtsClient({ token: config.token, base: config.base, log });
    this.engine = createPionicideEngine({ hashMiB: config.engine.hashMiB, log: () => {} });
    this.account = null;
    this.games = new Map();
    this.stopping = false;
  }

  async start() {
    this.account = await this.client.account();
    log(`compte connecté : ${this.account.username} · titre « ${this.account.title || '—'} »`);
    if (this.account.title !== 'BOT') {
      log('ATTENTION : ce compte n’a pas le statut BOT. L’API Bot refusera les coups.');
      log('           Créez un compte neuf puis POST /api/bot/account/upgrade (irréversible).');
    }
    log('démarrage du moteur PIONICIDE (WebAssembly)…');
    const started = Date.now();
    await this.engine.start();
    log(`moteur prêt en ${Date.now() - started} ms · table ${this.config.engine.hashMiB} Mio · profondeur ${this.config.engine.depth}`);
  }

  async run() {
    await this.start();
    let backoff = 1000;
    while (!this.stopping) {
      try {
        log('écoute des événements Lidraughts…');
        await this.client.streamEvents(event => this.onEvent(event));
        log('flux fermé par le serveur, reconnexion.');
      } catch (error) {
        log(`flux interrompu : ${error.message}`);
      }
      if (this.stopping) break;
      await new Promise(resolve => setTimeout(resolve, backoff));
      backoff = Math.min(backoff * 2, 30000);
    }
  }

  async onEvent(event) {
    if (event.type === 'challenge') {
      const challenge = event.challenge;
      const who = challenge.challenger?.name || challenge.challenger?.username || 'inconnu';
      const reason = challengeAllowed(challenge, this.config.accept, who);
      if (reason) {
        log(`défi de ${who} refusé : ${reason}`);
        await this.client.declineChallenge(challenge.id, 'later').catch(error => log(`refus impossible : ${error.message}`));
        return;
      }
      log(`défi de ${who} (${challenge.rated ? 'classé' : 'amical'}, ${challenge.timeControl?.limit ?? '?'}s + ${challenge.timeControl?.increment ?? 0}s) → accepté`);
      await this.client.acceptChallenge(challenge.id).catch(error => log(`acceptation impossible : ${error.message}`));
      return;
    }
    if (event.type === 'challenge' && this.games.size >= (this.config.maxGames || 2)) {
      // trop de parties en cours : le moteur est unique, on refuse poliment
      log(`défi de ${event.challenge?.challenger?.name || '?'} refusé : ${this.games.size} partie(s) déjà en cours`);
      await this.client.declineChallenge(event.challenge.id, 'later').catch(() => {});
      return;
    }
    if (event.type === 'gameStart') {
      const game = event.game;
      log(`partie ${game.id} démarrée (${game.variant?.key || 'standard'})`);
      this.followGame(game.id).catch(error => log(`partie ${game.id} : ${error.message}`));
    }
  }

  async followGame(gameId) {
    const session = {
      id: gameId,
      moves: [],
      myColor: null,
      movesSent: 0,
      clock: {},
      increment: 0,
      finished: false,
      thinking: false,
      announced: false,
      opponent: null,
    };
    this.games.set(gameId, session);
    try {
      await this.client.streamGame(gameId, async event => {
        if (session.finished) return;
        if (event.type === 'gameFull') {
          session.myColor = this.resolveColor(event);
          session.opponent = session.myColor === 'white' ? event.black?.name : event.white?.name;
          session.increment = Number(event.clock?.increment || 0) * 1000;
          log(`partie ${gameId} : PIONICIDE joue les ${session.myColor === 'white' ? 'Blancs' : 'Noirs'} contre ${session.opponent || 'adversaire'}`);
          if (!session.announced && this.config.announce) {
            session.announced = true;
            await this.client.chat(gameId, this.config.announce).catch(() => {});
          }
          await this.onState(session, event.state || {});
          return;
        }
        if (event.type === 'gameState') {
          await this.onState(session, event);
          return;
        }
        if (event.type === 'chatLine') return;
      });
    } finally {
      this.games.delete(gameId);
    }
  }

  /** Enregistre la partie terminée : fichier PDN + ligne de journal de session. */
  async archive(session) {
    const directory = path.resolve(ROOT, this.config.gamesDir || 'bridge/games');
    fs.mkdirSync(directory, { recursive: true });
    let text = '';
    for (let attempt = 0; attempt < 6 && !text.trim(); attempt++) {
      try {
        const response = await this.client.request(`/game/export/${session.id}?clocks=true&moves=true&tags=true`, { accept: 'application/x-draughts-pdn' });
        text = await response.text();
      } catch (error) {
        if (attempt === 5) log(`partie ${session.id} : export PDN indisponible (${error.message})`);
      }
      if (!text.trim()) await new Promise(resolve => setTimeout(resolve, 1500));
    }
    if (text.trim()) fs.writeFileSync(path.join(directory, `${session.id}.pdn`), text.trim() + '\n');
    const summary = {
      date: new Date().toISOString(),
      partie: session.id,
      adversaire: session.opponent || null,
      couleur: session.myColor,
      resultat: session.result || null,
      demiCoups: session.moves.length,
      coups: session.moves.join(' '),
      pdn: text.trim() ? `${session.id}.pdn` : null,
    };
    fs.appendFileSync(path.join(directory, 'session.jsonl'), JSON.stringify(summary) + '\n');
    log(`partie ${session.id} archivée dans ${path.relative(ROOT, directory)} (${summary.demiCoups} demi-coups)`);
  }

  resolveColor(event) {
    const myName = (this.account?.username || '').toLowerCase();
    const white = (event.white?.name || event.white?.id || '').toLowerCase();
    const black = (event.black?.name || event.black?.id || '').toLowerCase();
    if (white === myName) return 'white';
    if (black === myName) return 'black';
    // Repli : le champ color de gameFull n'existe pas, on regarde qui est un bot.
    if (event.white?.title === 'BOT' && event.black?.title !== 'BOT') return 'white';
    if (event.black?.title === 'BOT' && event.white?.title !== 'BOT') return 'black';
    return 'white';
  }

  async onState(session, state) {
    if (state.status && state.status !== 'started' && state.status !== 'created') {
      session.finished = true;
      session.result = { status: state.status, winner: state.winner || null };
      log(`partie ${session.id} terminée : ${state.status}${state.winner ? ' · vainqueur ' + state.winner : ''}`);
      await this.archive(session);
      return;
    }
    if (typeof state.moves === 'string') session.moves = state.moves.trim() ? state.moves.trim().split(/\s+/) : [];
    session.clock = {
      white: Number(state.wtime ?? state.whiteTime ?? NaN),
      black: Number(state.btime ?? state.blackTime ?? NaN),
    };
    if (session.myColor == null) return;
    const ourTurn = (session.moves.length % 2 === 0) === (session.myColor === 'white');
    if (!ourTurn || session.thinking) return;
    if (session.movesSent === session.moves.length && session.movesSent > 0) return;
    session.thinking = true;
    try {
      await this.play(session);
    } catch (error) {
      log(`partie ${session.id} : coup impossible — ${error.message}`);
    } finally {
      session.thinking = false;
    }
  }

  async play(session) {
    const { position } = replayMoves(session.moves);
    const ourClock = session.myColor === 'white' ? session.clock.white : session.clock.black;
    const budget = thinkBudget(session.clock, this.config.engine, ourClock, session.increment);
    const count = material(position);
    const critical = count.w + count.b <= this.config.engine.criticalPieces;
    const depth = Math.min(30, this.config.engine.depth + (critical ? 2 : 0));
    const started = Date.now();
    const result = await this.engine.search({
      position: posCommand(position),
      depth,
      moveTimeMs: budget,
    });
    if (!result.move) throw new Error('le moteur n’a pas rendu de coup');
    // Le moteur rend une notation Hub : la légalité est vérifiée par le noyau de l'app.
    const move = matchEngineMove(position, result.move);
    if (!move) throw new Error(`coup du moteur non reconnu : ${result.move}`);
    const parts = moveToApiParts(move);
    const elapsed = Date.now() - started;
    const info = `prof. ${result.depthReached ?? '?'} · ${(result.score ?? 0).toFixed(2)} · ${elapsed} ms`;
    if (this.config.dry) {
      log(`[simulation] coup ${moveToPdn(move)} (${parts.join(' ')}) · ${info}`);
    } else {
      await this.client.playMove(session.id, parts);
      log(`coup joué : ${moveToPdn(move)} (${parts.join(' ')}) · ${info}`);
    }
    session.movesSent = session.moves.length + 1;
  }
}

/* ---------------------------------- modes ---------------------------------- */

async function selftest(plies) {
  const Core = await import('../src/base/core.js');
  const engine = createPionicideEngine({ hashMiB: 32 });
  await engine.start();
  let position = initialPosition();
  const moves = [];
  const written = [];
  const started = Date.now();
  for (let ply = 0; ply < plies; ply++) {
    const result = await engine.search({ position: posCommand(position), depth: 16, moveTimeMs: 1200 });
    if (!result.move) throw new Error(`aucun coup au demi-coup ${ply + 1}`);
    const move = matchEngineMove(position, result.move);
    if (!move) throw new Error(`coup illégal proposé par le moteur : ${result.move}`);
    moves.push(move);
    written.push(moveToPdn(move));
    log(`demi-coup ${String(ply + 1).padStart(2)} · ${moveToPdn(move).padEnd(9)} · prof. ${result.depthReached ?? '?'} · ${(result.score ?? 0).toFixed(2)} · api ${moveToApiParts(move).join(' ')}`);
    position = Core.applyMove(position, move);
  }
  log(`auto-test terminé : ${plies} demi-coups en ${((Date.now() - started) / 1000).toFixed(1)} s`);
  log('partie : ' + written.join(' '));
  engine.stop();
}

async function check() {
  const config = loadConfig();
  if (!config.token) {
    console.error('Aucun jeton trouvé.');
    console.error('  1. cp bridge/config.example.json bridge/config.json');
    console.error('  2. collez le jeton dans le champ « token »');
    console.error('  (ou : LIDRAUGHTS_BOT_TOKEN=… node bridge/bot.mjs --check)');
    process.exit(1);
  }
  const client = new LidraughtsClient({ token: config.token, base: config.base });
  const account = await client.account();
  log(`jeton valide pour ${account.username} · titre « ${account.title || '—'} » · ${account.perfs?.blitz ? 'blitz ' + account.perfs.blitz.rating : 'aucun blitz'}`);
  if (account.title !== 'BOT') {
    log('ce compte n’est pas un compte BOT : appelez POST /api/bot/account/upgrade avec ce jeton (irréversible, compte sans partie).');
  }
}

const args = process.argv.slice(2);
const options = { base: null, dry: false, challenge: null, rated: true, limit: 300, increment: 2, color: 'random', allow: null, open: false, gamesDir: null };
const value = flag => {
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : null;
};
options.base = value('--base');
options.dry = args.includes('--dry');
options.rated = !args.includes('--casual');
options.challenge = value('--challenge');
options.limit = Number(value('--limit')) || 300;
options.increment = Number(value('--increment')) || 0;
options.color = value('--color') || 'random';
options.allow = value('--allow');
options.open = args.includes('--open');
options.gamesDir = value('--games-dir');

const mode = args.find(argument => argument.startsWith('--') && !['--base', '--dry', '--casual', '--challenge', '--limit', '--increment', '--color', '--rated', '--allow', '--open', '--games-dir'].includes(argument)) || '';
if (mode === '--selftest') {
  await selftest(Number(value('--selftest')) || 10);
} else if (mode === '--check') {
  await check();
} else {
  const config = loadConfig();
  if (options.base) config.base = options.base;
  if (options.allow) config.accept.allow = options.allow.split(',').map(name => name.trim()).filter(Boolean);
  if (options.open) config.accept.allow = [];
  if (options.gamesDir) config.gamesDir = options.gamesDir;
  config.dry = options.dry;
  if (config.accept.allow.length) {
    log(`session privée : seuls ${config.accept.allow.join(', ')} peuvent défier PIONICIDE`);
  } else {
    log('session publique : tous les défis conformes à config.json sont acceptés');
  }
  if (!config.dry && !config.token) {
    console.error('Aucun jeton. Mettez-le dans bridge/config.json (« token ») ou dans LIDRAUGHTS_BOT_TOKEN.');
    process.exit(1);
  }
  const bot = new Bot(config);
  if (options.challenge) {
    await bot.start();
    const answer = await bot.client.challenge(options.challenge, {
      rated: options.rated,
      limit: options.limit,
      increment: options.increment,
      color: options.color,
    });
    log(`défi envoyé à ${options.challenge} : ${answer.id || JSON.stringify(answer)} (${options.rated ? 'classé' : 'amical'}, ${options.limit}s + ${options.increment}s, couleur ${options.color})`);
    log('en attente de la réponse : si le défi est accepté, la partie arrive dans le flux d’événements et PIONICIDE la joue.');
    await bot.run().catch(error => log(`arrêt : ${error.message}`));
  } else {
    process.on('SIGINT', () => { log('arrêt demandé'); bot.stopping = true; bot.engine.stop(); process.exit(0); });
    await bot.run();
  }
}
