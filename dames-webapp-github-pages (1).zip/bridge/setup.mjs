#!/usr/bin/env node
/* PONT LIDRAUGHTS — assistant de branchement.
   Pose une seule question (le jeton), vérifie qu'il fonctionne, contrôle que le
   compte porte bien le titre BOT, puis écrit bridge/config.json.
   Aucune étape irréversible : ce script ne modifie jamais le compte.

   Usage :  node bridge/setup.mjs
            node bridge/setup.mjs --token <JETON>     (pour tester sans saisie) */
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CONFIG = path.join(ROOT, 'bridge', 'config.json');
const EXAMPLE = path.join(ROOT, 'bridge', 'config.example.json');
const BASE = 'https://lidraughts.org';

const args = process.argv.slice(2);
const givenToken = (() => {
  const index = args.indexOf('--token');
  return index >= 0 ? args[index + 1] : null;
})();

function say(text = '') { console.log(text); }

async function main() {
  say('=== Branchement de PIONICIDE sur Lidraughts ===');
  say();

  let token = givenToken;
  if (!token) {
    say('1. Ouvrez https://lidraughts.org/account/oauth/token en étant connecté');
    say('   au compte Iam_a_bot, cochez TOUTES les cases, validez.');
    say('2. Copiez le jeton affiché (il ne sera plus jamais montré).');
    say();
    const rl = readline.createInterface({ input: stdin, output: stdout });
    token = (await rl.question('Collez le jeton puis Entrée : ')).trim();
    rl.close();
  }
  if (!token) { say('Aucun jeton fourni. Rien n’a été modifié.'); process.exit(1); }

  say();
  say('Vérification auprès de Lidraughts…');
  let account = null;
  try {
    const response = await fetch(`${BASE}/api/account`, { headers: { Authorization: `Bearer ${token}` } });
    if (response.status === 401) {
      say('✗ Le jeton est refusé (401). Causes possibles :');
      say('  - jeton copié incomplet (espaces, retour à la ligne) ;');
      say('  - jeton révoqué ou remplacé par un plus récent.');
      say('  Regénérez-en un sur https://lidraughts.org/account/oauth/token');
      process.exit(1);
    }
    if (!response.ok) {
      say(`✗ Réponse inattendue du serveur : ${response.status}`);
      process.exit(1);
    }
    account = await response.json();
  } catch (error) {
    say(`✗ Lidraughts injoignable : ${error.message}`);
    say('  Vérifiez la connexion Internet puis relancez.');
    process.exit(1);
  }

  say(`✓ Jeton valide — compte « ${account.username} »`);
  const isBot = account.title === 'BOT';
  if (isBot) {
    say('✓ Titre BOT confirmé : l’API Bot acceptera les coups.');
  } else {
    say('✗ Ce compte n’a PAS le titre BOT.');
    say('  À faire une seule fois, irréversible, compte sans partie :');
    say(`  curl -X POST ${BASE}/api/bot/account/upgrade -H "Authorization: Bearer <JETON>"`);
    say('  Le jeton a été enregistré quand même : relancez ce script après la bascule.');
  }

  const example = fs.existsSync(EXAMPLE) ? JSON.parse(fs.readFileSync(EXAMPLE, 'utf8')) : {};
  const config = {
    ...example,
    token,
    base: BASE,
  };
  fs.writeFileSync(CONFIG, JSON.stringify(config, null, 2) + '\n');
  say();
  say(`✓ Configuration écrite dans ${path.relative(ROOT, CONFIG)}`);
  say('  (ce fichier ne doit jamais être publié : il est déjà exclu du partage)');
  say();
  say('Prochaine étape, au choix :');
  say('  node bridge/bot.mjs --check                       vérifier le compte');
  say('  node bridge/bot.mjs --allow Sosthene              n’accepter que vous');
  say('  node bridge/bot.mjs                              accepter tous les défis');
}

main().catch(error => { console.error('Erreur :', error.message); process.exit(1); });
