/* PONT LIDRAUGHTS — client d'API.
   Uniquement des endpoints publics et documentés de Lidraughts
   (https://lidraughts.org/api, spécification OpenAPI du dépôt lidraughts-api).
   Aucune dépendance : fetch et flux NDJSON de Node 20. */

export class LidraughtsClient {
  constructor({ token = '', base = 'https://lidraughts.org', log = () => {} } = {}) {
    this.token = token;
    this.base = base.replace(/\/$/, '');
    this.log = log;
  }

  get headers() {
    return this.token ? { Authorization: `Bearer ${this.token}` } : {};
  }

  async request(path, { method = 'GET', form = null, accept = 'application/json' } = {}) {
    const headers = { Accept: accept, ...this.headers };
    let body;
    if (form) {
      headers['Content-Type'] = 'application/x-www-form-urlencoded';
      body = new URLSearchParams(form).toString();
    }
    const response = await fetch(`${this.base}${path}`, { method, headers, body });
    if (!response.ok) {
      const text = await response.text().catch(() => '');
      throw new Error(`${method} ${path} → ${response.status} ${text.slice(0, 160)}`);
    }
    return response;
  }

  /** Profil du compte : sert à vérifier le jeton et le statut BOT. */
  async account() {
    return (await this.request('/api/account')).json();
  }

  /** Flux d'événements (défis, débuts de partie). Appelle onEvent pour chaque objet JSON. */
  async streamEvents(onEvent, { signal } = {}) {
    const response = await this.request('/api/stream/event', { accept: 'application/x-ndjson', signal });
    await readNdjson(response, onEvent, { signal });
  }

  /** État d'une partie. Chaque ligne : gameFull, gameState, chatLine… */
  async streamGame(gameId, onEvent, { signal } = {}) {
    const response = await this.request(`/api/bot/game/stream/${gameId}`, { accept: 'application/x-ndjson', signal });
    await readNdjson(response, onEvent, { signal });
  }

  async acceptChallenge(challengeId) {
    await this.request(`/api/challenge/${challengeId}/accept`, { method: 'POST' });
  }

  async declineChallenge(challengeId, reason = 'later') {
    await this.request(`/api/challenge/${challengeId}/decline`, { method: 'POST', form: { reason } });
  }

  /** Envoie un coup. « parts » = paires de cases, un appel par segment de rafle. */
  async playMove(gameId, parts) {
    let last = null;
    for (const part of [].concat(parts)) {
      last = await this.request(`/api/bot/game/${gameId}/move/${part}`, { method: 'POST' });
    }
    return last;
  }

  async chat(gameId, text, room = 'player') {
    await this.request(`/api/bot/game/${gameId}/chat`, { method: 'POST', form: { room, text: String(text).slice(0, 140) } });
  }

  async resign(gameId) {
    await this.request(`/api/bot/game/${gameId}/resign`, { method: 'POST' });
  }

  async abort(gameId) {
    await this.request(`/api/bot/game/${gameId}/abort`, { method: 'POST' });
  }

  /** Défi lancé par le bot (utile pour tester : le bot défie son propre compte). */
  async challenge(username, { rated = false, limit = 300, increment = 2, color = 'random', variant = 'standard' } = {}) {
    return (await this.request(`/api/challenge/${encodeURIComponent(username)}`, {
      method: 'POST',
      form: {
        rated: String(rated),
        'clock.limit': String(limit),
        'clock.increment': String(increment),
        color,
        variant,
      },
    })).json();
  }
}

/** Lit un flux NDJSON et rend chaque objet à onEvent. */
async function readNdjson(response, onEvent, { signal } = {}) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  try {
    while (true) {
      if (signal?.aborted) break;
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let index;
      while ((index = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, index).trim();
        buffer = buffer.slice(index + 1);
        if (!line) continue;
        let payload = null;
        try { payload = JSON.parse(line); } catch { continue; }
        await onEvent(payload);
      }
    }
  } finally {
    try { await reader.cancel(); } catch { /* flux déjà fermé */ }
  }
}
