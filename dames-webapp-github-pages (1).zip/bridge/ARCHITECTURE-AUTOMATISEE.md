# L'automatisation complète : comment c'est monté

But de cette note : comprendre l'architecture d'un bot qui joue à la place d'un
humain sur son propre compte, pour **savoir ce qu'on regarde** quand on soupçonne
une partie. C'est de l'anatomie, pas un mode d'emploi.

Rappel du cadre : sur Lidraughts, faire jouer un moteur depuis un compte humain
est une triche (règlement, section Fair Play). La voie autorisée existe et c'est
celle de `bridge/bot.mjs` : un compte **BOT**, l'API officielle, un titre affiché.

## Ce que la page expose (constaté sur lidraughts.org)

- `<cg-board></cg-board>` est **vide** dans le HTML servi : les pièces sont
  dessinées ensuite par JavaScript à partir des données de la partie.
- La page porte `data-socket-domain="socket.lidraughts.org"` : le transport des
  coups est un **websocket**, ouvert avec le cookie de session du compte.
- Un panneau `data-panel="fen-pdn"` et un champ `analyse__underboard__fen`
  affichent la position courante **en clair**.
- Le site est **logiciel libre** : ses sélecteurs, ses noms de classes et son
  protocole websocket sont publics.

Autrement dit, tout ce dont un automate a besoin est accessible depuis la page.

## Les six couches d'un automate

```
   ┌──────────────────────────────────────────────────────────┐
   │ 1. INJECTION      comment le code entre dans la page     │
   ├──────────────────────────────────────────────────────────┤
   │ 2. PERCEPTION     où est la position, à qui de jouer     │
   ├──────────────────────────────────────────────────────────┤
   │ 3. DÉCISION       quel coup (moteur local)               │
   ├──────────────────────────────────────────────────────────┤
   │ 4. ACTION         comment le coup est « joué »           │
   ├──────────────────────────────────────────────────────────┤
   │ 5. RYTHME         quand jouer (imitation d'humain)       │
   ├──────────────────────────────────────────────────────────┤
   │ 6. BOUCLE         attendre, surveiller, recommencer      │
   └──────────────────────────────────────────────────────────┘
```

### 1. Injection — quatre portes d'entrée

| Porte | Ce que c'est | Difficulté |
| --- | --- | --- |
| Extension de navigateur (script de contenu) | du code s'exécute dans la page à chaque chargement | faible |
| Userscript (gestionnaire de scripts) | même chose, sans empaqueter une extension | très faible |
| Navigateur piloté (protocole de débogage) | le navigateur est lancé par le programme, qui contrôle l'onglet de l'extérieur | moyenne |
| Injection manuelle (console, marque-page) | le joueur colle le code une fois par partie | faible, mais visible |

Le point commun : le code s'exécute **dans la page**, donc avec les mêmes droits
que le site lui-même — y compris l'accès au cookie de session et au websocket.

### 2. Perception — quatre façons de lire la position

| Source | Contenu | Remarque |
| --- | --- | --- |
| DOM du plateau (`cg-board`) | pièces dessinées, chacune avec sa classe (couleur, pion/dame) et sa position en pixels | lisible après rendu |
| Champ FEN / panneau PDN | la position en texte, telle que le site l'affiche | le plus simple, aucune géométrie |
| État JavaScript de la page | l'objet de partie du site, en mémoire | le plus complet (coups, horloges, statut) |
| Frames du websocket | chaque coup arrive du serveur en clair | nécessite d'intercepter la connexion |

Savoir « à qui de jouer » se déduit de la couleur du compte et du nombre de
coups — c'est dans l'état de la page. Aucune ambiguïté possible.

### 3. Décision — le moteur

Deux montages :

- **dans la page** : un moteur compilé en WebAssembly (Scan tient dans un
  fichier de ~400 ko, PIONICIDE en contient un) — zéro installation, zéro
  processus visible dans le système ;
- **hors de la page** : un petit serveur local qui expose le moteur par HTTP ou
  par le protocole UCI ; la page l'appelle en `localhost`. C'est ce que fait
  l'écosystème des moteurs d'échecs, et c'est réutilisable tel quel.

Mesuré sur le moteur de PIONICIDE : profondeur 12 en 35–49 ms, profondeur 16 en
164–175 ms, sur des positions de milieu de partie.

### 4. Action — trois façons de « jouer » le coup

| Moyen | Comment | Trace |
| --- | --- | --- |
| Événements de pointeur synthétiques sur le plateau | on calcule les coordonnées des deux cases et on envoie un clic ; le site le traite comme un clic humain | `isTrusted=false`, absence de trajectoire de souris |
| Appel direct de la fonction du site | on invoque la même fonction que le clic aurait déclenchée | rien de visible côté DOM |
| Message sur le websocket avec le cookie de session | on parle au serveur sans passer par l'interface | la latence et le rythme sont les seules traces |

La troisième voie est exactement ce que fait un client de bot officiel — la
différence n'est pas technique, elle est statutaire : **quel compte**.

### 5. Rythme — la couche qui trahit

Un automate naïf joue en quelques dizaines de millisecondes, à latence constante.
La couche de rythme sert à imiter un humain :

- attente d'un délai variable avant de jouer ;
- délai plus long sur les coups « difficiles », court sur les coups forcés ;
- pause aléatoire entre le calcul et l'action ;
- parfois : simulation de mouvement de souris, hésitations, coups annulés.

C'est précisément cette couche qui produit les **signatures** de la triche :
un temps de réflexion trop régulier, ou trop décorrélé de la difficulté réelle
de la position. Et plus la couche de rythme est soignée, moins l'automate est
avantageux : il finit par jouer au rythme d'un humain avec la qualité d'une
machine — ce qui reste visible dans la **qualité**, pas dans le temps.

### 6. Boucle

Surveiller l'arrivée du coup adverse (DOM, état, ou websocket), déclencher les
couches 2 à 5, recommencer. C'est la partie la plus fragile : elle dépend des
sélecteurs du site et se casse à chaque refonte visuelle.

## Ce que chaque couche laisse comme trace

| Couche | Trace exploitable | Exploitée par |
| --- | --- | --- |
| Injection | `navigator.webdriver`, empreinte de navigateur inhabituelle, extension détectable | modérateurs, dispositif anti-triche |
| Perception | aucune trace (lecture locale) | — |
| Décision | aucune trace réseau si le moteur est local | — |
| Action (clics synthétiques) | événements non fiables, absence de mouvement de souris, clics au pixel près | analyse de session |
| Action (websocket) | latence et rythme, corrélation avec d'autres comptes et adresses IP | serveur |
| Rythme | distribution des temps trop régulière, décorrélée de la difficulté | **le signal le plus solide** |
| Boucle | jouer alors que l'onglet est en arrière-plan, aucune pause de session | analyse de session |

## Comparaison des trois familles

| Méthode | Coût pour le tricheur | Efficacité | Risque de détection |
| --- | --- | --- | --- |
| Double écran / recopie | 3 à 8 s par coup | bonne en partie lente, nulle en blitz | moyen |
| Surcouche qui propose | un clic | très bonne, toutes cadences | moyen à élevé |
| Automatisation complète | un clic pour lancer, puis rien | maximale | **élevé** : la régularité est presque impossible à masquer |
| Assistance sélective (3–4 coups) | un clic, quelques fois | bonne | faible — mais moins de gain |

La hiérarchie explique pourquoi l'automatisation complète est **plus rare** que
la surcouche : elle demande de maintenir du code contre les évolutions du site,
et elle laisse la signature la plus nette — un joueur qui ne faiblit jamais et
qui ne s'arrête jamais.

## Ce qui devrait vous alerter, dans l'ordre

1. **Aucune faute sur une série de parties**, y compris dans des positions
   tactiques compliquées — et cela à toutes les cadences.
2. **Temps de réflexion quasi identique** d'un coup à l'autre, et du temps
   passé sur des coups forcés.
3. **Aucune baisse de qualité** en fin de partie longue, quand la fatigue
   devrait se voir.
4. **Refus systématique des cadences longues**, ou abandon dès que la partie
   s'engage.
5. **Comportement de session** : partie jouée d'un seul trait, sans interruption,
   sans temps mort.

Aucun de ces points, pris seul, ne prouve quoi que ce soit. C'est leur
**accumulation sur plusieurs parties** qui parle — et c'est exactement ce que
`bridge/fairplay.mjs` chiffre (perte moyenne, temps médian, régularité, coups
forcés), à joindre à un signalement plutôt qu'à une accusation publique.
