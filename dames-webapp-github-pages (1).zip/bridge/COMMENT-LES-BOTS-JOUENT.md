# Comment les bots Lidraughts jouent avec des humains

Notes vérifiées sur lidraughts.org le 6 novembre 2026.

## Le principe : deux identités, jamais mélangées

Chaque personne qui exploite un bot tient **deux comptes** :

| Compte | Sert à | Moteur autorisé ? |
| --- | --- | --- |
| Compte **humain** (ex. `Sosthene`) | jouer soi-même, en humain | **jamais** — c'est l'interdiction de triche |
| Compte **BOT** (ex. `PIONICIDE`) | faire jouer un moteur par l'API | oui, explicitement autorisé |

Le compte humain garde sa vie normale (parties, classement, tournois, arène).
Le compte bot n'existe que pour l'API : il ne peut pas jouer « à la main ».

## Comment un humain rencontre un bot

Uniquement par **défi** (« challenge game »). La documentation de l'API est
explícite : *« Bots can only play challenge games: lobby and tournaments are
off-limits. »* Un bot n'apparaît donc jamais dans le salon, ni dans une arène.

En pratique, trois chemins :

1. Page du compte bot → bouton **Défier**.
2. Liste des bots en ligne : <https://lidraughts.org/player/bots> (chaque
   exploitant y décrit ses conditions : cadences acceptées, classées ou non).
3. **Bot TV** : <https://lidraughts.org/tv/bot> — regarder, puis défier.

Le défi peut venir des deux côtés : l'humain défie le bot, ou le bot envoie un
défi à l'humain (`POST /api/challenge/{username}`).

## Les parties classées contre des humains : oui

C'est la différence avec Lichess. Vérifié sur les données publiques du site : le
compte `bot-test` (titre BOT, ≈ 2 500 en blitz) a joué 60 parties **classées**
récentes en bullet, blitz et rapide contre une dizaine d'humains différents
(`Nityananda`, `Taximan`, `frois`, `peremoga_Ivan`…), avec échange de points
Elo dans les deux sens.

Conséquence pour la mesure de force : **un bot obtient une note officielle
Lidraughts en jouant des classées contre des humains.** C'est exactement ce
qu'il faut pour répondre à « quelle est la vraie force de PIONICIDE ? ».

## Comment les exploitants s'organisent

- Un petit ordinateur ou un serveur qui tourne en continu : le bot doit être
  connecté pour recevoir les défis (c'est exactement ce que fait
  `bridge/bot.mjs`).
- Le compte bot est inscrit dans l'équipe des bots et sa page de profil indique
  les cadences acceptées.
- L'exploitant teste son propre bot avec son compte humain — mais alors en
  **amicale**, pour ne pas fausser les deux notes.
- Certains tiennent plusieurs bots (variantes différentes, niveaux différents).

## Ce que cela implique concrètement pour vous

- `Sosthene` reste votre compte humain : rien à y changer, aucune bascule.
- `PIONICIDE` est un compte séparé, en titre BOT, qui ne joue que par l'API.
- Votre ami peut défier `PIONICIDE` depuis son propre compte, en amicale ou en
  classée, sans limite de durée de relation : le bot répond tant qu'il tourne.
- Pour mesurer PIONICIDE : laissez-le accepter les défis **classés** des
  humains (c'est le réglage par défaut de `bridge/config.json`,
  `"rated": true`), sur des cadences de 5 min et plus.
