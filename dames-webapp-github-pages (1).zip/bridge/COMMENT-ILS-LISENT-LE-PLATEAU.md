# Famille n°2 : « la surcouche qui lit le plateau »

Comment un programme peut voir le plateau et proposer un coup, sans jamais
passer par l'API. Notes techniques, sans code — l'objectif est de comprendre le
mécanisme pour savoir quoi observer.

## Le point de départ : sur lidraughts, le plateau est déjà du texte

Vérifié sur une vraie page de partie (`lidraughts.org/1jWr5RUy`) :

- le plateau est un élément `cg-wrap` (« chessground ») : des pièces
  positionnées en CSS sur une grille ;
- la page contient aussi un panneau `data-panel="fen-pdn"` et un champ
  `analyse__underboard__fen` : **la position courante existe en clair dans le
  document**, pas seulement sous forme d'image ;
- les coups circulent dans le flux de données de la page (JSON), en clair.

Conclusion : pour un programme, lire la position ne demande **aucune**
reconnaissance d'image. C'est une simple lecture de texte. C'est vrai sur
lidraughts parce que le site est un logiciel libre, dont le code HTML est
public — un tricheur n'a rien eu à deviner.

## Les trois niveaux techniques de la famille n°2

**a) Extension de navigateur / script de page.**
Un script chargé dans la page lit la position (texte ci-dessus), l'envoie à un
moteur — localement, ou même à un moteur qui tourne dans le navigateur en
WebAssembly — et affiche le coup dans un coin de l'écran. Aucune automatisation
du jeu : le joueur clique lui-même. Côté serveur, cela ressemble à un joueur
normal, à une exception près : la latence.

**b) Capture d'écran + reconnaissance (OCR / détection de pièces).**
Un programme externe photographie la fenêtre, découpe la grille, classe chaque
case (vide / pion blanc / pion noir / dame blanche / dame noire) et reconstruit
la position. Utilisé quand le tricheur ne veut pas toucher au navigateur, ou
pour un site dont le HTML n'est pas exploitable. Sur les dames c'est
particulièrement facile : 50 cases, 4 types de pièces, formes très contrastées.

**c) Saisie manuelle assistée (le plus simple, le plus répandu).**
Pas de programme du tout : une application d'analyse sur téléphone, ou une page
d'analyse ouverte dans un autre onglet, où le joueur recompose la position à la
main puis lit le coup proposé. C'est la version la plus difficile à détecter
techniquement, puisqu'il n'y a rien à détecter : seulement un humain qui
consulte.

## Pourquoi les dames s'y prêtent plus que les échecs

- 50 cases, 4 types de pièces : la position tient dans une chaîne courte, facile
  à lire, à transmettre et à saisir.
- Les moteurs de dames sont petits (Scan tient dans un fichier WebAssembly de
  400 ko) : faire tourner un moteur fort **dans la page** est trivial, sans
  aucune installation.
- Un moteur de dames atteint très vite un niveau quasi parfait sur les
  finales (tables de 2 à 6 pièces), donc l'assistance est spectaculaire en fin
  de partie — précisément là où un humain faiblit.

À noter dans votre propre projet : PIONICIDE contient déjà toutes les briques
d'un tel outil (moteur WebAssembly, analyse, menaces). C'est exactement pour
cela que la règle est simple : ces briques s'utilisent **hors partie**, ou
depuis un compte marqué BOT — jamais pendant une partie en cours.

## Ce que cela laisse comme traces

Le point faible d'une surcouche n'est pas la lecture du plateau, c'est
**l'humain au milieu** :

| Trace | Pourquoi elle apparaît |
| --- | --- |
| temps de réflexion constant | c'est le temps de copier-coller, pas de réfléchir |
| temps long sur un coup forcé | seul un moteur « réfléchit » là où il n'y a rien à réfléchir |
| coups instantanés dans des positions complexes | inverse du comportement humain |
| aucune hésitation, aucune reprise | pas de retour en arrière sur un coup envisagé |
| qualité constante du début à la fin | un humain se fatigue et faiblit |
| latence trop régulière | une machine répond en un temps presque fixe |

Un programme peut décider de mal jouer exprès, ou d'attendre un temps aléatoire
pour imiter un humain. Mais alors il perd l'avantage qui motivait la triche, et
ses résultats redeviennent ceux d'un joueur normal : la triche s'annule
d'elle-même.

## Ce qui est détectable côté serveur, et ce qui ne l'est pas

- **Détectable :** la qualité des coups sur une série, la distribution des temps,
  la corrélation d'adresses IP et d'empreintes de navigateur avec le moteur
  utilisé ailleurs, les signalements.
- **Non détectable de façon fiable :** une lecture de page locale, une capture
  d'écran, ou un joueur qui consulte un ami. Rien de tout cela ne laisse de
  trace réseau.

D'où la conclusion des modérateurs : la détection de la triche est
**statistique et comportementale**, jamais une preuve technique isolée. C'est
pourquoi ils examinent des séries de parties, pas une partie.

---

# Cas des cadences courtes : et une partie de 2 minutes ?

Objection naturelle : à 2 minutes, il n'y a pas le temps de recopier un coup
depuis un deuxième écran. C'est vrai — pour la méthode « double écran ». Mais
l'assistance par surcouche ne fonctionne pas ainsi, et les chiffres le montrent.

## Ce que coûte réellement un coup assisté

Mesures faites avec le moteur de PIONICIDE (WebAssembly, un cœur), sur des
positions réelles de milieu de partie, **sans livre d'ouvertures** :

| Profondeur | Temps de calcul |
| --- | --- |
| 10 | 22–23 ms |
| 12 | 35–49 ms |
| 14 | 73–82 ms |
| 16 | 164–175 ms |

Autrement dit : **un moteur déjà chargé dans la page répond en moins d'un
cinquième de seconde.** Il n'y a aucun copier-coller : la surcouche surligne la
case de départ et la case d'arrivée, le joueur clique. Le coût pour le tricheur
se réduit au temps d'un clic.

Et un moteur chargé une fois reste chaud : la table de transposition, le livre
et les tables de finales sont déjà en mémoire ; les coups suivants coûtent le
même temps, pas davantage.

## Ce que la cadence autorise

| Cadence | Temps moyen par coup (partie de ~45 coups) | Verdict |
| --- | --- | --- |
| 2 min + 0 s | ≈ 2,7 s | assistance facile |
| 2 min + 1 s | ≈ 3,7 s | confortable |
| 1 min + 0 s | ≈ 1,3 s | serré mais faisable (clic + 0,2 s de calcul) |
| 30 s + 0 s | ≈ 0,7 s | au ras du possible |

La conclusion est nette : **2 minutes n'est pas une protection.** C'est même
une cadence très fréquentée par les tricheurs, pour une raison simple : à cette
vitesse, ce ne sont pas les connaissances qui départagent mais les fautes de
précipitation — exactement ce qu'un moteur ne commet jamais.

## L'effet paradoxal sur la détection

La cadence courte compresse deux signaux et en amplifie un troisième :

- **temps** : les durées se resserrent, le signal devient plus bruité — donc
  moins exploitable ;
- **régularité** : un humain à 2 minutes enchaîne les coups à des rythmes très
  variables ; une assistance garde une latence quasi constante ;
- **qualité** : c'est là que tout bascule. À 2 minutes, un humain **commet plus
  de fautes** qu'en partie lente. Un joueur assisté, lui, n'en commet aucune.
  L'écart de qualité entre les deux devient donc **plus visible**, pas moins.

C'est pourquoi `bridge/fairplay.mjs` calcule la perte moyenne d'évaluation et
pas seulement le temps : sur une cadence courte, c'est le chiffre qui parle.

## Ce que cela implique pour vous, en pratique

- Une défaite en 2 minutes ne prouve rien dans un sens ni dans l'autre. Un
  adversaire plus rapide et plus tactique gagne, un adversaire assisté aussi.
- Si un doute persiste sur un joueur précis : **proposez 5+2 ou 10+5.** Un
  tricheur évite presque toujours les cadences longues — moins de gain, plus de
  risque. Un joueur honnête accepte volontiers.
- Sur une série, les chiffres de `fairplay.mjs` (perte moyenne, temps,
  régularité) tranchent mieux que l'impression laissée par une seule partie.
