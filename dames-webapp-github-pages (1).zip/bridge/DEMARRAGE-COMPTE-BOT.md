# Ouvrir le compte BOT de PIONICIDE — liste à suivre

Vérifié sur lidraughts.org le 5 novembre 2026.

## Réponse courte

Oui : **inscription normale**, aucune procédure spéciale n'existe pour créer un
compte bot. Ce qui est spécial, c'est **ce qu'il ne faut pas faire** entre
l'inscription et la bascule en BOT : **ne jouer aucune partie.**

## Étape 1 — Inscription (navigateur normal, Chrome, depuis chez vous)

Page : **<https://lidraughts.org/signup>**
(attention, `/account/signup` renvoie une erreur 404)

Le formulaire demande exactement :

| Champ | Contrainte |
| --- | --- |
| Nom d'utilisateur | 2 à 20 caractères |
| Mot de passe | 4 caractères minimum (mettez-en bien plus) |
| E-mail | **obligatoire** |
| reCAPTCHA | obligatoire — donc à faire dans un vrai navigateur |

Conseils :
- **Choisissez le nom définitif maintenant.** Il apparaîtra partout avec le
  titre BOT. `PIONICIDE` est **libre** (vérifié), les autres noms de bots
  existants (`DraughtsBot`, `YoBot_v2`) sont pris.
- Mot de passe unique, noté dans votre gestionnaire de mots de passe.
- L'e-mail sert uniquement à la confirmation et à la récupération ; une adresse
  dédiée évite de mélanger avec votre compte `Sosthene`.

## Étape 2 — Confirmer l'e-mail tout de suite

Cliquez le lien reçu, puis vérifiez que vous êtes bien connecté sur
<https://lidraughts.org/account/profile>.

## Étape 3 — La règle absolue avant la bascule

> **Ne jouez AUCUNE partie avec ce compte avant l'étape 5.**

La documentation de l'API est explicite : *« The account cannot have played any
game before becoming a Bot account. »* Cela inclut :

- une partie contre un joueur, même amicale, même abandonnée aussitôt ;
- une partie contre l'ordinateur / « jouer avec la machine » ;
- accepter un défi, même pour voir.

Une seule partie rend la bascule en BOT **impossible**, et il n'existe aucun
recours. Si cela arrive : recommencez avec un nouveau compte.

À éviter aussi par prudence : poster sur le forum, envoyer des messages
publics. Rien ne l'interdit, mais un compte bot neuf n'en a pas besoin.

## Étape 4 — Créer le jeton d'accès

Page : **<https://lidraughts.org/account/oauth/token>**

- Cochez **toutes** les cases (c'est la recommandation de l'équipe Lidraughts
  Bots ; le minimum vital est `bot:play` + `challenge:write`).
- Validez, puis **copiez le jeton immédiatement** : il ne sera plus jamais
  affiché.

## Étape 5 — Basculer le compte en BOT (une seule fois, irréversible)

Depuis un terminal :

```bash
curl -X POST https://lidraughts.org/api/bot/account/upgrade \
     -H "Authorization: Bearer <VOTRE_JETON>"
```

Réponse attendue : `{"ok":true}`. Vérification :

```bash
curl -s https://lidraughts.org/api/account \
     -H "Authorization: Bearer <VOTRE_JETON>"
```

Le champ `"title"` doit valoir `"BOT"`. Vous pouvez aussi simplement faire :

```bash
node bridge/bot.mjs --check
```

À partir de cet instant :
- le compte ne peut plus jouer « à la main » sur le site ;
- il n'accepte des parties que par l'API Bot ;
- il apparaît dans **Bot TV** : <https://lidraughts.org/tv/bot>.

## Étape 6 — Le rendre visible et challengeable

Rejoignez l'équipe des bots : <https://lidraughts.org/team/lidraughtsbots>
(c'est là que les joueurs viennent chercher des adversaires artificiels).
Attention : rejoindre l'équipe **ne donne pas** le statut BOT — c'est l'étape 5
qui le fait.

## Étape 7 — Brancher PIONICIDE

1. Copier `bridge/config.example.json` en `bridge/config.json`.
2. Y coller le jeton dans le champ `token`.
3. `node bridge/bot.mjs --check` → doit afficher le nom du compte et le titre BOT.
4. `node bridge/bot.mjs` → le bot écoute les défis.

**Ne partagez jamais ce fichier** : le jeton donne le contrôle total du compte.

## Étape 8 — Premier essai grandeur réelle (le meilleur test)

Avant de défier des inconnus, faites-le jouer contre vous :

1. Restez connecté en tant que `Sosthene` sur lidraughts (autre navigateur).
2. Ouvrez la page du compte PIONICIDE et lancez-lui un défi **amical, 5 min + 2 s**.
3. PIONICIDE doit accepter en quelques secondes et jouer.

Si ce premier essai passe, tout le reste n'est que répétition. Ensuite seulement,
lancez la campagne classée contre de vrais adversaires.

## Récapitulatif des pièges

| Piège | Conséquence |
| --- | --- |
| jouer une partie avant l'étape 5 | compte définitivement inutilisable comme bot |
| oublier de confirmer l'e-mail | jeton et API refusés |
| jeton non copié à la création | il faut en regénérer un (sans conséquence) |
| nom choisi à la légère | visible sur toutes les parties ; le changer après coup est possible mais déroutant |
| jeton collé dans un fichier public | n'importe qui joue avec votre compte |
