/* PONT LIDRAUGHTS — moteur.
   Exécute le binaire WebAssembly de PIONICIDE (Scan 3.1b) directement dans Node,
   sans navigateur : mêmes fichiers que l'application (public/), donc exactement
   la même force de calcul que dans l'app.
   Protocole Hub, identique à src/engine.js :
     hub  →  attente de « wait »  →  set-param (tt-size, bb-size, book)
     init →  attente de « ready » →  pos … / level depth=N move-time=S / go think
   Le moteur répond « info … » puis « done move=… ». */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const APP_ROOT = path.resolve(__dirname, '..');

// Message clair si le pont a été sorti de l'application (il a besoin de public/
// et de src/ : le moteur et le noyau de règles ne sont pas dupliqués).
for (const needed of ['public/scan-wasm-scalar.js', 'src/base/core.js', 'src/bitbases.js']) {
  if (!fs.existsSync(path.join(APP_ROOT, needed))) {
    throw new Error(
      `Le dossier bridge/ doit rester à côté de « public/ » et « src/ » (manquant : ${needed}).\n`
      + 'Extrayez l’archive complète dames-webapp-github-pages et lancez le pont depuis sa racine.');
  }
}
const PUBLIC = path.join(APP_ROOT, 'public');

const EVAL_BYTES = 8503280;

function createPionicideEngine({ hashMiB = 64, log = () => {} } = {}) {
  const api = { get ready() { return ready; } };
  let bindings = null; // module emscripten
  let send = null;
  let ready = false;
  const listeners = new Set();

  const emit = line => { for (const listener of [...listeners]) listener(line); };

  /** Attend une ligne qui satisfait le prédicat. À appeler AVANT d'envoyer la commande. */
  function waitFor(predicate, timeout, label) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        listeners.delete(listener);
        reject(new Error(`moteur : délai dépassé en attendant ${label}`));
      }, timeout);
      const listener = line => {
        if (!predicate(line)) return;
        clearTimeout(timer);
        listeners.delete(listener);
        resolve(line);
      };
      listeners.add(listener);
    });
  }

  async function start() {
    const source = fs.readFileSync(path.join(PUBLIC, 'scan-wasm-scalar.js'), 'utf8');
    // Le binaire emscripten s'exporte lui-même en CommonJS.
    const holder = { exports: {} };
    new Function('require', 'module', 'exports', '__dirname', '__filename', source)(
      require, holder, holder.exports, PUBLIC, path.join(PUBLIC, 'scan-wasm-scalar.js'));
    const createScan = holder.exports;
    if (typeof createScan !== 'function') throw new Error('scan-wasm-scalar.js ne s’est pas chargé');

    const module = await createScan({
      noInitialRun: true,
      print: line => emit(line),
      printErr: line => emit('log ' + line),
    });

    const evaluation = fs.readFileSync(path.join(PUBLIC, 'scan_normal.data'));
    if (evaluation.length < EVAL_BYTES) throw new Error('données d’évaluation Scan incomplètes');
    module.FS.mkdirTree('/data');
    module.FS.writeFile('/data/eval', evaluation.subarray(0, EVAL_BYTES));
    module.FS.writeFile('/data/book', fs.readFileSync(path.join(PUBLIC, 'scan-book.bin')));

    // Tables de finales 2–4 pièces : les mêmes que dans l'application.
    const { bitbaseFiles } = await import(pathToFileURL(path.join(APP_ROOT, 'src', 'bitbases.js')).href);
    for (const [file, base64] of Object.entries(bitbaseFiles || {})) {
      const target = '/' + file;
      module.FS.mkdirTree(target.substring(0, target.lastIndexOf('/')));
      module.FS.writeFile(target, Buffer.from(base64, 'base64'));
    }

    bindings = module;
    try { module._main(0, 0); } catch { /* le programme principal rend la main ; les commandes restent actives */ }
    send = text => {
      try { module.ccall('scan_command', null, ['string'], [text]); }
      catch (error) { emit('log ccall : ' + error.message); }
    };

    const hubAnswer = waitFor(line => line === 'wait', 30000, 'la bannière Hub');
    send('hub');
    await hubAnswer;

    const exponent = Math.max(16, Math.round(Math.log2(hashMiB) + 16));
    const initDone = waitFor(line => line === 'ready' || line.startsWith('error'), 90000, 'l’initialisation');
    send(`set-param name=tt-size value=${exponent}`);
    send('set-param name=bb-size value=4');
    send('set-param name=book value=true');
    send('init');
    const line = await initDone;
    if (line.startsWith('error')) throw new Error(line);
    ready = true;
    return api;
  }

  /**
   * Cherche un coup.
   * @param {object} options
   * @param {string} options.position  commande « pos … » du moteur, par exemple
   *   « pos pos=Wbc… » (voir posCommand() dans positions.mjs) ou « pos start »
   * @param {number} options.depth     profondeur maximale
   * @param {number} options.moveTimeMs budget de temps
   */
  async function searchOne({ position = 'pos start', depth = 18, moveTimeMs = 3000 } = {}) {
    if (!ready || !bindings) throw new Error('moteur non démarré');
    const infos = [];
    const collector = line => { if (line.startsWith('info')) infos.push(line); };
    listeners.add(collector);
    const done = waitFor(line => line.startsWith('done') || line.startsWith('error'), moveTimeMs + 120000, 'la fin de la recherche');
    send(position.startsWith('pos ') ? position : `pos ${position}`);
    send(`level depth=${Math.max(1, Math.min(30, depth))} move-time=${(Math.max(20, moveTimeMs) / 1000).toFixed(3)}`);
    send('go think');
    // La recherche est menée pendant que la boucle d'événements tourne (timers emscripten).
    const line = await done;
    listeners.delete(collector);
    if (line.startsWith('error')) throw new Error(line);
    const completed = infos.filter(info => /\bcompleted=true\b/.test(info)).at(-1) || infos.at(-1) || '';
    return {
      move: (/\bmove=(\S+)/.exec(line) || [])[1] || null,
      ponder: (/\bponder=(\S+)/.exec(line) || [])[1] || null,
      infos,
      lastInfo: completed,
      score: Number((/\bscore=(-?[\d.]+)/.exec(completed) || [])[1]),
      depthReached: Number((/\bdepth=(\d+)/.exec(completed) || [])[1]) || null,
    };
  }

  /**
   * File d'attente : le protocole Hub ne sait mener qu'une recherche à la fois.
   * Deux parties simultanées (deux joueurs) sont donc jouées l'une après l'autre ;
   * sans cela, les réponses « info »/« done » des deux recherches se mélangent.
   */
  let chain = Promise.resolve();
  function search(options) {
    const run = chain.then(() => searchOne(options), () => searchOne(options));
    chain = run.then(() => {}, () => {});
    return run;
  }

  function stop() {
    ready = false;
    listeners.clear();
    bindings = null;
    send = null;
  }

  api.start = start;
  api.search = search;
  api.stop = stop;

  return api;
}

module.exports = { createPionicideEngine };
