# Ceux qui trichent : comment ils font, et comment on les repère

Notes vérifiées sur lidraughts.org le 6 novembre 2026 (FAQ Fair Play, règlement,
témoignages de modérateurs sur les forums).

## Ce qui est interdit (règlement Lidraughts)

> « L'utilisation de toute aide extérieure pour renforcer ses connaissances et/ou
> sa capacité de calcul afin d'obtenir un avantage déloyal. » Sont cités :
> **moteur**, **livre d'ouvertures** (sauf en correspondance), **tables de
> finales**, **demander de l'aide à un autre joueur**.

Et le point clé pour votre question : **l'API Bot n'est pas un outil de triche.**
Elle refuse tout compte sans titre BOT, elle est signalée partout (« BOT » à côté
du nom, présence dans Bot TV), et ses parties déclenchent un affichage explicite.
Un tricheur ne peut donc pas passer par là : il doit contourner le site.

## Comment ils font, concrètement

Trois familles, de la plus grossière à la plus discrète :

**1. Le double écran (le plus courant).** Le joueur ouvre une deuxième fenêtre ou
un deuxième appareil, y rejoue la position, et recopie le coup. La variante
« paresseuse » de ce procédé utilise l'adversaire artificiel du site lui-même :
une partie anonyme en parallèle sert de source de coups. C'est exactement ce que
décrivait un fil du forum dès 2018 (« il suffit de jouer contre la machine avec
un compte anonyme et de recopier »).

**2. La surcouche logicielle.** Un programme lit l'état de la page (le plateau
affiché, parfois le flux réseau) et affiche le coup du moteur à côté. Le joueur
clique lui-même. Rien n'est automatisé côté serveur, donc aucune trace
technique évidente.

**3. L'assistance sélective.** Le joueur ne consulte le moteur que dans les
positions critiques — trois ou quatre fois par partie. C'est de loin le plus
difficile à démasquer, et celui qui produit les meilleurs résultats pour le
tricheur.

À côté de cela il y a l'aide humaine : un ami plus fort qui souffle les coups.
Le règlement le prévoit explicitement.

## Comment Lidraughts les repère

La FAQ est volontairement discrète (« nous n'entrons pas dans les détails, cela
faciliterait le contournement »), mais les modérateurs ont décrit publiquement
les axes :

- **Accord avec le moteur et qualité constante.** Les parties sont comparées à
  une analyse : un joueur qui joue systématiquement les meilleurs coups, sans
  faiblesse, sur des positions difficiles, sort de la distribution humaine.
  Ce n'est pas un coup isolé qui compte, c'est la régularité sur une série.
- **Temps de réflexion irrationnel.** C'est le signal le plus parlant et le
  moins imitable : perdre beaucoup de temps sur un coup forcé, ou jouer
  instantanément une position très complexe. Un humain a un temps de réflexion
  qui suit la difficulté ; un tricheur, le temps de copier-coller.
- **Preuves techniques.** Même adresse IP que le moteur utilisé dans un autre
  onglet ou appareil, empreinte de navigateur, comptes liés.
- **Signalements.** Chaque signalement est examiné ; plusieurs modérateurs
  peuvent intervenir. Les décisions sont prises sur dossier, pas sur une
  impression de partie.
- **Sanctions.** Marquage du compte (interdiction des parties classées),
  retrait des gains, et **remboursement de points aux victimes** : les 40
  dernières victoires et nulles classées des 3 derniers jours sont rejouées au
  profit des adversaires, si leur note n'était pas provisoire.
- **Recours.** Par courriel à contact@lidraughts.org ; les décisions sont
  rarement annulées.

Point important : un message « cheat detected » peut apparaître **en cours de
partie** (notamment contre un adversaire anonyme) et vous donner la victoire.

## Pourquoi « il joue logiquement » n'est pas une preuve

Le jeu de dames est un jeu de logique : les forts joueurs jouent de façon
« informatique » par nature, et beaucoup de parties se terminent par des nulles
identiques. Un adversaire qui ne commet pas de faute évidente, qui joue des
coups théoriques et qui évite les complications est peut-être simplement
meilleur que vous — ou très prudent. Les modérateurs signalent d'ailleurs que
beaucoup de signalements sont « simplement le fait d'un adversaire qui a joué
une bonne partie ».

Accuser à tort est le vrai risque : cela n'apporte rien, et les accusations
publiques dans le clavardage sont mal vues (mise en cause publique).

## Ce que vous pouvez faire, dans l'ordre

1. **Signaler** via le bouton « Signaler » sur la page du compte ou de la partie,
   option assistance logicielle. Restez factuel : date, cadence, ce qui vous a
   paru étrange.
2. **Exporter la partie en PDN** (l'export contient les horloges) et la garder.
3. **Passer la partie à l'analyse** avec `bridge/fairplay.mjs` (voir ci-dessous) :
   cela produit des chiffres, pas des impressions.
4. **Laisser les modérateurs décider.** Ils ont l'historique complet du compte,
   vous ne voyez qu'une partie.

## L'outil fourni : `bridge/fairplay.mjs`

```bash
# Une partie précise (avec horloges)
node bridge/fairplay.mjs --url https://lidraughts.org/1jWr5RUy --depth 16 --ms 400

# Les 5 dernières parties classées d'un compte
node bridge/fairplay.mjs --user Pseudo --max 5 --depth 16 --ms 400

# Vos parties contre un adversaire précis
node bridge/fairplay.mjs --user Pseudo --vs Sosthene --max 5

# Détail coup par coup
node bridge/fairplay.mjs --user Pseudo --max 1 --detail
```

Pour chaque camp il calcule : l'accord avec le meilleur coup du moteur, la perte
moyenne d'évaluation (0 = coup parfait), le temps médian par coup, la part de
coups joués en moins d'une seconde, et le temps passé sur des coups forcés.

### Exemple mesuré (partie réelle, bot-test – Nityananda, 180+3, classée)

| | bot-test (moteur) | Nityananda (humain, MI) |
| --- | --- | --- |
| accord meilleur coup (prof. 16) | 76 % | 68 % |
| perte moyenne | **0,013** | **0,101** |
| temps médian par coup | 0,0 s | 1,0 s |
| coups en ≤ 1 s | 97 % | 54 % |

Lecture : **la perte moyenne sépare nettement les deux**, alors que l'accord
brut, lui, ne suffit pas — un maître qui suit la théorie a un accord élevé.
C'est pourquoi un seul chiffre ne doit jamais servir d'accusation.

### Limites de l'outil

- Il ne voit que la partie ; les modérateurs voient le compte entier.
- Un tricheur qui consulte peu le moteur produit des chiffres normaux.
- Une analyse à faible profondeur (12) écrase les écarts : utilisez 16 à 18.
- Lidraughts limite le nombre d'exports ; restez sous `--max 5` par appel.
