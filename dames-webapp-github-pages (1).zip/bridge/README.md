# PIONICIDE sur Lidraughts

Ce dossier fait jouer **PIONICIDE** (Scan 3.1b compilé en WebAssembly, celui de
l'application) sur **lidraughts.org**, via l'API Bot officielle. Le moteur reste
exactement le même binaire que dans l'application : rien du projet n'est modifié.

```
bridge/
  engine.cjs          moteur headless : charge public/scan-wasm-scalar.js dans Node
  positions.mjs       conversions Lidraughts ↔ noyau PIONICIDE (src/base/core.js)
  lidraughts.mjs      client de l'API Bot (flux NDJSON, coups, défis)
  bot.mjs             boucle de jeu : écoute, accepte, joue, gère l'horloge
  test-mock.mjs       essai complet hors ligne (faux serveur)
  config.example.json modèle de configuration
```

## 1. Préparer le compte

L'API Bot exige un compte portant le titre **BOT**. Cette bascule est
**irréversible** et n'est possible que sur un compte **qui n'a jamais joué
aucune partie**. Un compte existant (par exemple `Sosthene`) ne peut pas être
converti : il faut créer un compte neuf, réservé au bot.

1. Créer un compte neuf sur lidraughts.org (nom libre, par exemple `PIONICIDE`).
2. Ouvrir <https://lidraughts.org/account/security> → **Personal API access token**,
   cocher les droits `bot:play` et `challenge:write`, générer, copier le jeton.
3. Passer le compte en bot, une seule fois :

```bash
curl -X POST https://lidraughts.org/api/bot/account/upgrade \
     -H "Authorization: Bearer <JETON>"
```

Réponse : le profil avec `"title": "BOT"`. À partir de là le compte ne peut plus
jouer comme un humain, et il apparaît dans Bot TV (`/tv/bot`).

## 2. Configurer et lancer

Le plus simple :

```bash
node bridge/setup.mjs        # demande le jeton, vérifie le compte, écrit config.json
```

À la main :

```bash
cp bridge/config.example.json bridge/config.json   # puis coller le jeton
node bridge/bot.mjs --check                        # vérifie jeton + titre BOT
node bridge/bot.mjs                                # écoute et joue
```

Node 20 ou plus, aucune dépendance à installer : le moteur, l'évaluation et les
tables de finales sont lus dans `public/` comme dans le navigateur. Démarrage du
moteur : environ 0,7 s, pour 64 Mio de table de transposition.

Le jeton peut aussi être passé par l'environnement :
`LIDRAUGHTS_BOT_TOKEN=… node bridge/bot.mjs`.

## 3. Modes

| Commande | Effet |
| --- | --- |
| `node bridge/bot.mjs` | écoute les défis, accepte, joue toutes les parties |
| `node bridge/bot.mjs --challenge Sosthene --limit 600 --increment 5` | le bot **défie** un joueur précis (classé par défaut, `--casual` pour amical, `--color white|black|random`) |
| `node bridge/bot.mjs --check` | contrôle du jeton et du statut BOT |
| `node bridge/bot.mjs --selftest 20` | PIONICIDE contre lui-même, 20 demi-coups, sans réseau |
| `node bridge/bot.mjs --allow Sosthene,MonAmi` | **session privée** : seuls ces comptes peuvent défier le bot |
| `node bridge/test-mock.mjs` | essai de bout en bout contre un faux serveur |
| `node bridge/fairplay.mjs --user Pseudo --max 5` | relevé objectif sur les parties d'un compte (accord moteur, perte moyenne, temps de réflexion) |

À la fin de chaque partie, le bot exporte le PDN dans `bridge/games/<id>.pdn`
et ajoute une ligne de bilan dans `bridge/games/session.jsonl` (adversaire,
couleur, résultat, nombre de demi-coups). Ces fichiers s'importent directement
dans l'onglet « importer » de l'application.

Le bot refuse poliment (décline) les variantes non prises en charge, les parties
par correspondance et les cadences hors limites — limites réglables dans
`config.json`, section `accept`.

## 4. Gestion du temps

Le budget d'un coup vaut `temps restant / 40 + 0,8 × incrément`, borné par
`minMoveMs` et `maxMoveMs`, et jamais plus de la moitié du temps restant. En
dessous de 16 pièces au total, la profondeur visée augmente de 2 (finales,
épaulées par les tables 2–4 pièces).

Mesures relevées sur la machine de développement (un cœur, WebAssembly) :

| Réglage | Temps réel | Profondeur atteinte |
| --- | --- | --- |
| prof. 16, 0,6 s | 0,1–0,3 s | 16 |
| prof. 18, 3 s | 0,3 s | 18 |
| prof. 22, 8 s | 3,1 s | 22 |

Le moteur natif de Scan va environ 5 à 10 fois plus vite : à 1 s par coup,
PIONICIDE en WebAssembly joue nettement en dessous du Scan de référence. C'est
la raison des recommandations ci-dessous.

## 5. Mesurer la vraie force

Pour que la mesure ait un sens :

- **cadence 5 min + 2 s minimum**, idéalement 10 + 5 ou 15 + 5 (en dessous, le
  bot joue tronqué) ;
- parties **classées** uniquement — seules les classées alimentent la note ;
- **plusieurs parties par adversaire**, couleurs inversées (`--color`) ;
- noter que le jeu de dames est très drawish : un écart de niveau se lit sur la
  durée, pas sur une partie (beaucoup de nulles même entre forts joueurs) ;
- comparer avec les bots déjà notés : `DraughtsBot` (≈ 2024 en blitz),
  et les autres comptes de l'équipe `lidraughtsbots`.

Une première série utile : 6 parties 5+2 contre un joueur du top local, puis
6 parties 10+5 contre plus fort, en relevant la note après chaque paire.

## 6. Dépannage

| Symptôme | Cause probable |
| --- | --- |
| `POST /api/bot/game/…/move/… → 401` | jeton absent, expiré, ou droits `bot:play` non cochés |
| `→ 403` | le compte n'a pas le titre BOT (étape 3) |
| aucune réponse, moteur muet | `pos` mal formé : la position doit être `pos pos=<51 caractères>` (voir `positions.mjs`) |
| `429` | trop de requêtes ; espacer, ne pas relancer en boucle |
| le bot perd au temps | cadence trop courte pour le WebAssembly : augmenter l'incrément |

## 7. Ce que ce pont ne fait pas

- Il ne joue pas les variantes autres que le jeu de dames standard (frisian,
  antidraughts, breakthrough, russian, brazilian) : elles sont déclinées.
- Il ne cherche pas d'adversaire tout seul : il accepte les défis et peut en
  lancer un sur commande.
- Il ne modifie pas le moteur : la force affichée est celle de l'application.
